
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <emmintrin.h>
#include <limits.h>
#include <pmmintrin.h>
#include <immintrin.h>
#include <stdint.h>	/* for uint64 definition */
#include <sched.h>
#include <pthread.h>
#include <sys/syscall.h>
#include <sys/mman.h>
#include <omp.h>



void Gaussian_Blur(unsigned char **frame1,unsigned char **filt,const unsigned int M, const unsigned int N);
void Gaussian_Blur_default(unsigned char **frame1,unsigned char **filt,const unsigned int M, const unsigned int N,const unsigned int divisor, unsigned char **filter5x5);
void Gaussian_Blur_1d_default(unsigned char **frame1,unsigned char **filt,const unsigned int M, const unsigned int N);


void Gaussian_Blur_when_zeros_around(unsigned char **frame1,unsigned char **filt,const unsigned int M, const unsigned int N);
void Gaussian_Blur_1d_when_zeros_around(unsigned char **frame1,unsigned char **filt,const unsigned int M, const unsigned int N);


//-----old routines
void Gaussian_Blur_AVX_ver4_plus_less_load_1_store(unsigned char **frame1,unsigned char **filt,const unsigned int M, const unsigned int N);
void Gaussian_Blur_AVX_ver4_plus_less_load_1_store_reg_blocking(unsigned char **frame1,unsigned char **filt,const unsigned int M, const unsigned int N);

//------------------------5x5 routines ------------------------------------
//this function has more packing instructions than step28 in the main loop because output is shifted 3/4 positions and some data are lost. moreover, can i reduce divisions?
void Gaussian_Blur_optimized_5x5(unsigned char **frame1,unsigned char **filt,const unsigned int M, const unsigned int N, const unsigned int divisor);
int loop_reminder_high_reminder_values(unsigned char **frame1,unsigned char **filt,const unsigned int M, const unsigned int N,const unsigned int row, const unsigned int col,const unsigned int REMINDER_ITERATIONS,const unsigned int division_case,const __m256i c0,const __m256i c1,const __m256i c2,const __m256i c0_sh1,const __m256i c1_sh1,const __m256i c2_sh1,const __m256i c0_sh2,const __m256i c1_sh2,const __m256i c2_sh2, const __m256i f,const unsigned int divisor);
int loop_reminder_low_reminder_values(unsigned char **frame1,unsigned char **filt,const unsigned int M, const unsigned int N,const unsigned int row, const unsigned int col,const unsigned int REMINDER_ITERATIONS,const unsigned int division_case,const __m256i c0,const __m256i c1,const __m256i c2,const __m256i c0_sh1,const __m256i c1_sh1,const __m256i c2_sh1,const __m256i c0_sh2,const __m256i c1_sh2,const __m256i c2_sh2, const __m256i f);
int loop_reminder_first_rows_high_reminder_values(unsigned char **frame1,unsigned char **filt,const unsigned int M, const unsigned int N,const unsigned int col,const unsigned int REMINDER_ITERATIONS,const unsigned int division_case,const __m256i c0,const __m256i c1,const __m256i c2,const __m256i c0_sh1,const __m256i c1_sh1,const __m256i c2_sh1,const __m256i c0_sh2,const __m256i c1_sh2,const __m256i c2_sh2, const __m256i f,const unsigned int divisor);
int loop_reminder_first_rows_low_reminder_values(unsigned char **frame1,unsigned char **filt,const unsigned int M, const unsigned int N,const unsigned int col,const unsigned int REMINDER_ITERATIONS,const unsigned int division_case,const __m256i c0,const __m256i c1,const __m256i c2,const __m256i c0_sh1,const __m256i c1_sh1,const __m256i c2_sh1,const __m256i c0_sh2,const __m256i c1_sh2,const __m256i c2_sh2, const __m256i f);
int loop_reminder_last_rows_high_reminder_values(unsigned char **frame1,unsigned char **filt,const unsigned int M, const unsigned int N,const unsigned int col,const unsigned int REMINDER_ITERATIONS,const unsigned int division_case,const __m256i c0,const __m256i c1,const __m256i c2,const __m256i c0_sh1,const __m256i c1_sh1,const __m256i c2_sh1,const __m256i c0_sh2,const __m256i c1_sh2,const __m256i c2_sh2, const __m256i f,const unsigned int divisor);
int loop_reminder_last_rows_low_reminder_values(unsigned char **frame1,unsigned char **filt,const unsigned int M, const unsigned int N,const unsigned int col,const unsigned int REMINDER_ITERATIONS,const unsigned int division_case,const __m256i c0,const __m256i c1,const __m256i c2,const __m256i c0_sh1,const __m256i c1_sh1,const __m256i c2_sh1,const __m256i c0_sh2,const __m256i c1_sh2,const __m256i c2_sh2, const __m256i f);

void Gaussian_Blur_optimized_5x5_step28(unsigned char **frame1,unsigned char **filt,const unsigned int M, const unsigned int N, const unsigned int divisor);

//LAST FUNCTIONS
void Gaussian_Blur_optimized_5x5_step28_less_div(unsigned char **frame1,unsigned char **filt,const unsigned int M, const unsigned int N, const unsigned short int divisor, unsigned char **filter);
int loop_reminder_high_reminder_values_less_div(unsigned char **frame1,unsigned char **filt,const unsigned int M, const unsigned int N,const unsigned int row, const unsigned int col,const unsigned int REMINDER_ITERATIONS,const unsigned int division_case,const __m256i c0,const __m256i c1,const __m256i c2,const __m256i c0_sh1,const __m256i c1_sh1,const __m256i c2_sh1,const __m256i c0_sh2,const __m256i c1_sh2,const __m256i c2_sh2, const __m256i f,const unsigned short int divisor,unsigned char **filter5x5);
int loop_reminder_low_reminder_values_less_div(unsigned char **frame1,unsigned char **filt,const unsigned int M, const unsigned int N,const unsigned int row, const unsigned int col,const unsigned int REMINDER_ITERATIONS,const unsigned int division_case,const __m256i c0,const __m256i c1,const __m256i c2,const __m256i c0_sh1,const __m256i c1_sh1,const __m256i c2_sh1,const __m256i c0_sh2,const __m256i c1_sh2,const __m256i c2_sh2, const __m256i c0_sh3,const __m256i c1_sh3,const __m256i c2_sh3,const __m256i c0_sh4,const __m256i c1_sh4,const __m256i c2_sh4,const __m256i c0_sh5,const __m256i c1_sh5,const __m256i c2_sh5,const __m256i f);
int loop_reminder_first_less_div(unsigned char **frame1,unsigned char **filt,const unsigned int M, const unsigned int N, const unsigned int col,const unsigned int REMINDER_ITERATIONS,const unsigned int division_case,const __m256i c0,const __m256i c1,const __m256i c2,const __m256i c0_sh1,const __m256i c1_sh1,const __m256i c2_sh1,const __m256i c0_sh2,const __m256i c1_sh2,const __m256i c2_sh2, const __m256i f,const unsigned short int divisor, unsigned char **filter5x5);
int loop_reminder_last_less_div(unsigned char **frame1,unsigned char **filt,const unsigned int M, const unsigned int N, const unsigned int col,const unsigned int REMINDER_ITERATIONS,const unsigned int division_case,const __m256i c0,const __m256i c1,const __m256i c2,const __m256i c0_sh1,const __m256i c1_sh1,const __m256i c2_sh1,const __m256i c0_sh2,const __m256i c1_sh2,const __m256i c2_sh2, const __m256i f,const unsigned short int divisor, unsigned char **filter5x5);
__m256i division(const unsigned int division_case, __m256i m2, const __m256i f);
const unsigned int prepare_for_division(const unsigned short int divisor);

//------------5x5 seperable filter routines------------------------------
//reminder for first and last two rows has not been implemented yet
//for k=5 2d applies 30x, 24+, 6 / , while 1d applies 26x, 16+, 10 /. Therefore, when divisor=power of 2, 1d is better
void Gaussian_Blur_optimized_5x5_seperable_filter(unsigned char **frame1,unsigned char **filt,const unsigned int M, const unsigned int N, const unsigned int divisor, const unsigned char filter5x5[5][5]);
void Gaussian_Blur_optimized_5x5_seperable_filter_less_div(unsigned char **frame1,unsigned char **filt,const unsigned int M, const unsigned int N, const unsigned int divisor, const unsigned char filter5x5[5][5]);
int loop_reminder_low_reminder_values_seperable(unsigned char **frame1,unsigned char **filt,const unsigned int M, const unsigned int N,const unsigned int row, const unsigned int col,const unsigned int REMINDER_ITERATIONS,const unsigned int division_case,const __m256i cx,const __m256i cx_sh1,const __m256i cx_sh2,const __m256i cx_sh3,const __m256i cx_sh4,const __m256i cx_sh5,const __m256i cy0, const __m256i cy1,const __m256i cy2,const __m256i cy0_sh1,const __m256i cy1_sh1, const __m256i cy2_sh1,const __m256i f);
int loop_reminder_high_reminder_values_seperable(unsigned char **frame1,unsigned char **filt,const unsigned int M, const unsigned int N,const unsigned int row, const unsigned int col,const unsigned int REMINDER_ITERATIONS,const unsigned int division_case,const __m256i cx,const __m256i cx_sh1,const __m256i cx_sh2,const __m256i cx_sh3,const __m256i cx_sh4,const __m256i cx_sh5,const __m256i cy0, const __m256i cy1,const __m256i cy2,const __m256i cy0_sh1,const __m256i cy1_sh1, const __m256i cy2_sh1,const __m256i f,const unsigned int divisor);


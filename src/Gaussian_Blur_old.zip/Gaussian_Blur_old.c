#include "Gaussian_Blur.h"


 //after every 5 mask elements I insert a zero. This is because there is no mul command for 8bit in AVX/SSE. The only command I can use is maddubs which mults and adds the intermediate results. Thus, the 5th element will be added with the 6th which is always zero.
unsigned char gaussian_filter_5x5[9][32] __attribute__((aligned(64))) ={
		{2,4,5,4,2,0,2,4,5,4,2,0,2,4,5,4,2,0,2,4,5,4,2,0,2,4,5,4,2,0,0,0},
		{4,9,12,9,4,0,4,9,12,9,4,0,4,9,12,9,4,0,4,9,12,9,4,0,4,9,12,9,4,0,0,0},
		{5,12,15,12,5,0,5,12,15,12,5,0,5,12,15,12,5,0,5,12,15,12,5,0,5,12,15,12,5,0,0,0},

		{0,2,4,5,4,2,0,2,4,5,4,2,0,2,4,5,4,2,0,2,4,5,4,2,0,2,4,5,4,2,0,0},
		{0,4,9,12,9,4,0,4,9,12,9,4,0,4,9,12,9,4,0,4,9,12,9,4,0,4,9,12,9,4,0,0},
		{0,5,12,15,12,5,0,5,12,15,12,5,0,5,12,15,12,5,0,5,12,15,12,5,0,5,12,15,12,5,0,0},

		{0,0,2,4,5,4,2,0,2,4,5,4,2,0,2,4,5,4,2,0,2,4,5,4,2,0,2,4,5,4,2,0},
		{0,0,4,9,12,9,4,0,4,9,12,9,4,0,4,9,12,9,4,0,4,9,12,9,4,0,4,9,12,9,4,0},
		{0,0,5,12,15,12,5,0,5,12,15,12,5,0,5,12,15,12,5,0,5,12,15,12,5,0,5,12,15,12,5,0},
};


unsigned char gaussian_filter_5x5_test[18][32] __attribute__((aligned(64))) ={
		{2,4,5,4,2,0,2,4,5,4,2,0,2,4,5,4,2,0,2,4,5,4,2,0,2,4,5,4,2,0,0,0},
		{4,9,12,9,4,0,4,9,12,9,4,0,4,9,12,9,4,0,4,9,12,9,4,0,4,9,12,9,4,0,0,0},
		{5,12,15,12,5,0,5,12,15,12,5,0,5,12,15,12,5,0,5,12,15,12,5,0,5,12,15,12,5,0,0,0},

		{0,2,4,5,4,2,0,2,4,5,4,2,0,2,4,5,4,2,0,2,4,5,4,2,0,2,4,5,4,2,0,0},
		{0,4,9,12,9,4,0,4,9,12,9,4,0,4,9,12,9,4,0,4,9,12,9,4,0,4,9,12,9,4,0,0},
		{0,5,12,15,12,5,0,5,12,15,12,5,0,5,12,15,12,5,0,5,12,15,12,5,0,5,12,15,12,5,0,0},

		{0,0,2,4,5,4,2,0,2,4,5,4,2,0,2,4,5,4,2,0,2,4,5,4,2,0,2,4,5,4,2,0},
		{0,0,4,9,12,9,4,0,4,9,12,9,4,0,4,9,12,9,4,0,4,9,12,9,4,0,4,9,12,9,4,0},
		{0,0,5,12,15,12,5,0,5,12,15,12,5,0,5,12,15,12,5,0,5,12,15,12,5,0,5,12,15,12,5,0},

		{0,0,0,2,4,5,4,2,0,2,4,5,4,2,0,2,4,5,4,2,0,2,4,5,4,2,0,2,4,5,4,2},
		{0,0,0,4,9,12,9,4,0,4,9,12,9,4,0,4,9,12,9,4,0,4,9,12,9,4,0,4,9,12,9,4},
		{0,0,0,5,12,15,12,5,0,5,12,15,12,5,0,5,12,15,12,5,0,5,12,15,12,5,0,5,12,15,12,5},

		{0,0,0,0,2,4,5,4,2,0,2,4,5,4,2,0,2,4,5,4,2,0,2,4,5,4,2,0,0,0,0,0},
		{0,0,0,0,4,9,12,9,4,0,4,9,12,9,4,0,4,9,12,9,4,0,4,9,12,9,4,0,0,0,0,0},
		{0,0,0,0,5,12,15,12,5,0,5,12,15,12,5,0,5,12,15,12,5,0,5,12,15,12,5,0,0,0,0,0},

		{0,0,0,0,0,2,4,5,4,2,0,2,4,5,4,2,0,2,4,5,4,2,0,2,4,5,4,2,0,0,0,0},
		{0,0,0,0,0,4,9,12,9,4,0,4,9,12,9,4,0,4,9,12,9,4,0,4,9,12,9,4,0,0,0,0},
		{0,0,0,0,0,5,12,15,12,5,0,5,12,15,12,5,0,5,12,15,12,5,0,5,12,15,12,5,0,0,0,0},
};


__attribute__((aligned(64))) unsigned short int f_vector[16]; //initialized by 'prepare_for_division()' routine
unsigned int b;

const unsigned char reminder_msk1[31][32] __attribute__((aligned(64))) ={//this lookup table is used in the loop reminder
		{255,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
		{255,255,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
		{255,255,255,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
		{255,255,255,255,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
		{255,255,255,255,255,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
		{255,255,255,255,255,255,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
		{255,255,255,255,255,255,255,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
		{255,255,255,255,255,255,255,255,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
		{255,255,255,255,255,255,255,255,255,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
		{255,255,255,255,255,255,255,255,255,255,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
		{255,255,255,255,255,255,255,255,255,255,255,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
		{255,255,255,255,255,255,255,255,255,255,255,255,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
		{255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
		{255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
		{255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
		{255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
		{255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0},
		{255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,0,0,0,0,0,0,0,0,0,0,0,0},
		{255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,0,0,0,0,0,0,0,0,0,0,0},
		{255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,0,0,0,0,0,0,0,0,0,0},
		{255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,0,0,0,0,0,0,0,0,0},
		{255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,0,0,0,0,0,0,0,0},
		{255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,0,0,0,0,0,0,0},
		{255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,0,0,0,0,0,0},
		{255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,0,0,0,0,0},
		{255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,0,0,0,0},
		{255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,0,0,0},
		{255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,0,0},
		{255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,0},
		{255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255},
		{255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255},
} ;


const unsigned char reminder_msk2[31][32] __attribute__((aligned(64))) ={//this lookup table is used in the loop reminder
		{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
		{255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
		{255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
		{255,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
		{255,255,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
		{255,255,255,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
		{255,255,255,255,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
		{255,255,255,255,255,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
		{255,255,255,255,255,255,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
		{255,255,255,255,255,255,255,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
		{255,255,255,255,255,255,255,255,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
		{255,255,255,255,255,255,255,255,255,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
		{255,255,255,255,255,255,255,255,255,255,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
		{255,255,255,255,255,255,255,255,255,255,255,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
		{255,255,255,255,255,255,255,255,255,255,255,255,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
		{255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
		{255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
		{255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
		{255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
		{255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0},
		{255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,0,0,0,0,0,0,0,0,0,0,0,0},
		{255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,0,0,0,0,0,0,0,0,0,0,0},
		{255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,0,0,0,0,0,0,0,0,0,0},
		{255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,0,0,0,0,0,0,0,0,0},
		{255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,0,0,0,0,0,0,0,0},
		{255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,0,0,0,0,0,0,0},
		{255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,0,0,0,0,0,0},
		{255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,0,0,0,0,0},
		{255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,0,0,0,0},
		{255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,0,0,0},
		{255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,0,0},
};



const unsigned char gaussianMask[5][5]={
		{2,4,5,4,2},
		{4,9,12,9,4},
		{5,12,15,12,5},
		{4,9,12,9,4},
		{2,4,5,4,2},
};



const unsigned char gaussianMask_1d[5]={1,4,6,4,1};

unsigned char gaussian_filter_5x5_seperable_y[6][32] __attribute__((aligned(64))) ={
		{1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0},
		{4,0,4,0,4,0,4,0,4,0,4,0,4,0,4,0,4,0,4,0,4,0,4,0,4,0,4,0,4,0,4,0},
		{6,0,6,0,6,0,6,0,6,0,6,0,6,0,6,0,6,0,6,0,6,0,6,0,6,0,6,0,6,0,6,0},
		{0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1},
		{0,4,0,4,0,4,0,4,0,4,0,4,0,4,0,4,0,4,0,4,0,4,0,4,0,4,0,4,0,4,0,4},
		{0,6,0,6,0,6,0,6,0,6,0,6,0,6,0,6,0,6,0,6,0,6,0,6,0,6,0,6,0,6,0,6},
};

unsigned char gaussian_filter_5x5_seperable_x[6][32] __attribute__((aligned(64))) ={
		{1,4,6,4,1,0,1,4,6,4,1,0,1,4,6,4,1,0,1,4,6,4,1,0,1,4,6,4,1,0,0,0},
		{0,1,4,6,4,1,0,1,4,6,4,1,0,1,4,6,4,1,0,1,4,6,4,1,0,1,4,6,4,1,0,0},
		{0,0,1,4,6,4,1,0,1,4,6,4,1,0,1,4,6,4,1,0,1,4,6,4,1,0,1,4,6,4,1,0},
		{0,0,0,1,4,6,4,1,0,1,4,6,4,1,0,1,4,6,4,1,0,1,4,6,4,1,0,1,4,6,4,1},
		{0,0,0,0,1,4,6,4,1,0,1,4,6,4,1,0,1,4,6,4,1,0,1,4,6,4,1,0,0,0,0,0},
		{0,0,0,0,0,1,4,6,4,1,0,1,4,6,4,1,0,1,4,6,4,1,0,1,4,6,4,1,0,0,0,0},
};


void Gaussian_Blur_when_zeros_around(unsigned char **frame1,unsigned char **filt,const unsigned int M, const unsigned int N){

	int row,col,rowOffset,colOffset,newPixel;

	/*---------------------- Gaussian Blur ---------------------------------*/
		for (row = 2; row < N+2; row++) {
			for (col = 2; col < M+2; col++) {
				newPixel = 0;
				for (rowOffset=-2; rowOffset<=2; rowOffset++) {
					for (colOffset=-2; colOffset<=2; colOffset++) {

	                   newPixel += frame1[row+rowOffset][col+colOffset] * gaussianMask[2 + rowOffset][2 + colOffset];
					}
				        }
			filt[row-2][col-2] = (unsigned char) (newPixel / 159);
			}
		}

}

void Gaussian_Blur_default(unsigned char **frame1,unsigned char **filt,const unsigned int M, const unsigned int N,const unsigned int divisor,unsigned char **filter){

	int row,col,rowOffset,colOffset;
	unsigned short int newPixel;
	unsigned char pix;

	/*---------------------- Gaussian Blur ---------------------------------*/
		for (row = 0; row < N; row++) {
			for (col = 0; col < M; col++) {
				newPixel = 0;
				for (rowOffset=-2; rowOffset<=2; rowOffset++) {
					for (colOffset=-2; colOffset<=2; colOffset++) {

						if ( (row+rowOffset<0) || (row+rowOffset>=N) || (col+colOffset<0) || (col+colOffset>=M) )
							pix=0;
						else
							pix=frame1[row+rowOffset][col+colOffset];

	                   newPixel += pix * filter[2 + rowOffset][2 + colOffset];
					}
				        }
			filt[row][col] = (unsigned char) (newPixel / divisor);

			}
		}
}


void Gaussian_Blur_1d_default(unsigned char **frame1,unsigned char **filt,const unsigned int M, const unsigned int N){


	int row,col,rowOffset,colOffset,newPixel;
	unsigned char pix;
	unsigned char temp[M];

	/*---------------------- Gaussian Blur ---------------------------------*/
		for (row = 0; row < N; row++) {
			for (col = 0; col < M; col++) {
				newPixel = 0;
				for (rowOffset=-2; rowOffset<=2; rowOffset++) {

						if ( (row+rowOffset<0) || (row+rowOffset>=N) )
							pix=0;
						else
							pix=frame1[row+rowOffset][col];

	                   newPixel += pix * gaussianMask_1d[2 + rowOffset];
					}

			temp[col] = (unsigned char) (newPixel / 16);
			}

			for (col = 0; col < M; col++) {
							newPixel = 0;
							for (colOffset=-2; colOffset<=2; colOffset++) {

									if ( (col+colOffset<0) || (col+colOffset>=M) )
										pix=0;
									else
										pix=temp[col+colOffset];

				                   newPixel += pix * gaussianMask_1d[2 + colOffset];
								}

						filt[row][col] = (unsigned char) (newPixel / 16);
						}

		}


}


/*---------------------- Gaussian Blur ---------------------------------*/
void Gaussian_Blur(unsigned char **frame1,unsigned char **filt,const unsigned int M, const unsigned int N){



int pixel,row,col,rowOffset,colOffset;
__m256i const0,const1,const2,r0,r1,r2,r3,r4;

const0=_mm256_set_epi8(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,4,5,4,2);
const1=_mm256_set_epi8(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,4,9,12,9,4);
const2=_mm256_set_epi8(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,5,12,15,12,5);

/*---------------------- Gaussian Blur ---------------------------------*/

	for (row = 2; row < N-2; row++) {
		for (col = 2; col < M-30; col++) { //last subscript value of loadu is : M-a-1-2 + 32 == M-1 -> a=30

		//load the 5 rows
		r0=_mm256_loadu_si256( (__m256i *) &frame1[row-2][col-2]);
		r1=_mm256_loadu_si256( (__m256i *) &frame1[row-1][col-2]);
		r2=_mm256_loadu_si256( (__m256i *) &frame1[row][col-2]);
		r3=_mm256_loadu_si256( (__m256i *) &frame1[row+1][col-2]);
		r4=_mm256_loadu_si256( (__m256i *) &frame1[row+2][col-2]);

		//multiply with the mask
		r0=_mm256_maddubs_epi16(r0,const0);
		r1=_mm256_maddubs_epi16(r1,const1);
		r2=_mm256_maddubs_epi16(r2,const2);
		r3=_mm256_maddubs_epi16(r3,const1);
		r4=_mm256_maddubs_epi16(r4,const0);

		//vertical add
		r0=_mm256_add_epi16(r0,r1);
		r2=_mm256_add_epi16(r2,r3);
		r0=_mm256_add_epi16(r0,r2);
		r0=_mm256_add_epi16(r0,r4);

		//horizontal add
		r0=_mm256_hadd_epi16(r0,r0);
		r0=_mm256_hadd_epi16(r0,r0);
		r0=_mm256_hadd_epi16(r0,r0);

		pixel=_mm256_extract_epi16(r0,0);
		filt[row][col] = (unsigned char) (pixel / 159);
		}

		for (col = M-30; col < M-2; col++) {
		   pixel = 0;
		   for (rowOffset=-2; rowOffset<=2; rowOffset++) {
		    for (colOffset=-2; colOffset<=2; colOffset++) {

                    pixel += frame1[row+rowOffset][col+colOffset] * gaussianMask[2 + rowOffset][2 + colOffset];
				}
			        }
		filt[row][col] = (unsigned char) (pixel / 159);
	}

}


}









//this program reduces the number of times the input image is read. I read 6 times consecutive locations and then jump forward. I can read once and use for 4 times (thus read input 2 times). It is the same if I read once and use for 3 times.

//for the general case (generate pixel 0,1), the 1st iteration of col loop needs different masks (starting from 5,4,2,0,...then starting from 4,5,4,2,0,...) as well as the last iteration of col loop (ending to 2,4,5). In the end of col loop, I need if conditions according to the N%30 value.

void Gaussian_Blur_AVX_ver4_plus_less_load_1_store(unsigned char **frame1,unsigned char **filt,const unsigned int M, const unsigned int N){

	//after every 5 mask elements I insert a zero. This is because there is no mul command for 8bit in AVX/SSE. The only command I can use is maddubs which mults and adds the intermediate results. Thus, the 5th element will be added with the 6th which is always zero.
	const __m256i c0=_mm256_set_epi8(0,0,0,2,4,5,4,2,0,2,4,5,4,2,0,2,4,5,4,2,0,2,4,5,4,2,0,2,4,5,4,2);
	const __m256i c1=_mm256_set_epi8(0,0,0,4,9,12,9,4,0,4,9,12,9,4,0,4,9,12,9,4,0,4,9,12,9,4,0,4,9,12,9,4);
	const __m256i c2=_mm256_set_epi8(0,0,0,5,12,15,12,5,0,5,12,15,12,5,0,5,12,15,12,5,0,5,12,15,12,5,0,5,12,15,12,5);

	const __m256i c0_sh1=_mm256_set_epi8(0,0,2,4,5,4,2,0,2,4,5,4,2,0,2,4,5,4,2,0,2,4,5,4,2,0,2,4,5,4,2,0);
	const __m256i c1_sh1=_mm256_set_epi8(0,0,4,9,12,9,4,0,4,9,12,9,4,0,4,9,12,9,4,0,4,9,12,9,4,0,4,9,12,9,4,0);
	const __m256i c2_sh1=_mm256_set_epi8(0,0,5,12,15,12,5,0,5,12,15,12,5,0,5,12,15,12,5,0,5,12,15,12,5,0,5,12,15,12,5,0);

	const __m256i c0_sh2=_mm256_set_epi8(0,2,4,5,4,2,0,2,4,5,4,2,0,2,4,5,4,2,0,2,4,5,4,2,0,2,4,5,4,2,0,0);
	const __m256i c1_sh2=_mm256_set_epi8(0,4,9,12,9,4,0,4,9,12,9,4,0,4,9,12,9,4,0,4,9,12,9,4,0,4,9,12,9,4,0,0);
	const __m256i c2_sh2=_mm256_set_epi8(0,5,12,15,12,5,0,5,12,15,12,5,0,5,12,15,12,5,0,5,12,15,12,5,0,5,12,15,12,5,0,0);


	const __m256i f  = _mm256_set_epi16(52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759);
	const __m256i mask  = _mm256_set_epi8(0,0,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255);
	const __m256i mask2  = _mm256_set_epi8(0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0);
	const __m256i mask3  = _mm256_set_epi16(0,0,0,0,0,0,0,65535,0,0,0,0,0,0,0,0);
	const __m256i mask4  = _mm256_set_epi8(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,255,0,0,0,0,0,0,0,0,0,0,0,0);
	const __m256i mask5  = _mm256_set_epi8(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0);



#pragma omp parallel
{

int row,col;
register __m256i r0,r1,r2,r3,r4,m0,m1,m2,m3,m4,output;


/*---------------------- Gaussian Blur ---------------------------------*/

     #pragma omp for schedule(static)
	for (row = 2; row < N-2; row++) {
	  for (col = 2; col < M-26; col+=30){
	 //last col value that does not read outside of the array bounds is (col<M-29)
		//col iteration computes output pixels of 2,8,14,20,26
		// col+1 iteration computes output pixels of 3,9,15,21,27
		// col+2 iteration computes output pixels of 4,10,16,22,28
		// col+3 iteration computes output pixels of 5,11,17,23,29
		// col+4 iteration computes output pixels of 6,12,18,24,30
		// col+5 iteration computes output pixels of 7,13,19,25,31
		//afterwards, col2 becomes 32 and repeat the above process

		//1st col iteration
		//load the 5 rows
		r0=_mm256_loadu_si256( (__m256i *) &frame1[row-2][col-2]);
		r1=_mm256_loadu_si256( (__m256i *) &frame1[row-1][col-2]);
		r2=_mm256_loadu_si256( (__m256i *) &frame1[row][col-2]);
		r3=_mm256_loadu_si256( (__m256i *) &frame1[row+1][col-2]);
		r4=_mm256_loadu_si256( (__m256i *) &frame1[row+2][col-2]);

		//multiply with the mask
		m0=_mm256_maddubs_epi16(r0,c0);
		m1=_mm256_maddubs_epi16(r1,c1);
		m2=_mm256_maddubs_epi16(r2,c2);
		m3=_mm256_maddubs_epi16(r3,c1);
		m4=_mm256_maddubs_epi16(r4,c0);

		//vertical add
		m0=_mm256_add_epi16(m0,m1);
		m2=_mm256_add_epi16(m2,m3);
		m0=_mm256_add_epi16(m0,m2);
		m0=_mm256_add_epi16(m0,m4);

		//hozizontal additions
		//hadd(0:5)   and store filt[row[col]
		//hadd(6:11)   and store filt[row[col+8]
		//hadd(12:17) and store filt[row[col+14]
		//hadd(18:23) and store filt[row[col+20]
		//hadd(24:30) and store filt[row[col+26]

		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
		m4=_mm256_and_si256(m0,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m3 = _mm256_mulhi_epu16(m2, f);             // multiply high unsigned words
		m1 = _mm256_sub_epi16(m2, m3);                     // subtract
		m1 = _mm256_srli_epi16(m1, 16);             // shift right logical with w
		m3 = _mm256_add_epi16(m3, m1);                    // add
		m2=_mm256_srli_epi16(m3, 7);            // shift right logical with b

		//and with mask to keep just 0,6,12,18,24
		output = _mm256_and_si256(m2,mask);
		/*
		filt[row][col] = (unsigned char) _mm256_extract_epi16(m2,0);
		filt[row][col+6] = (unsigned char) _mm256_extract_epi16(m2,3);
		filt[row][col+12] = (unsigned char) _mm256_extract_epi16(m2,6);
		filt[row][col+18] = (unsigned char) _mm256_extract_epi16(m2,9);
		filt[row][col+24] = (unsigned char) _mm256_extract_epi16(m2,12);*/

		//2nd col iteration
		//multiply with the mask
		m0=_mm256_maddubs_epi16(r0,c0_sh1);
		m1=_mm256_maddubs_epi16(r1,c1_sh1);
		m2=_mm256_maddubs_epi16(r2,c2_sh1);
		m3=_mm256_maddubs_epi16(r3,c1_sh1);
		m4=_mm256_maddubs_epi16(r4,c0_sh1);

		//vertical add
		m0=_mm256_add_epi16(m0,m1);
		m2=_mm256_add_epi16(m2,m3);
		m0=_mm256_add_epi16(m0,m2);
		m0=_mm256_add_epi16(m0,m4);

		//hozizontal additions
		//hadd(0:5)   and store filt[row[col]
		//hadd(6:11)   and store filt[row[col+8]
		//hadd(12:17) and store filt[row[col+14]
		//hadd(18:23) and store filt[row[col+20]
		//hadd(24:30) and store filt[row[col+26]

		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
		m4=_mm256_and_si256(m0,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m3 = _mm256_mulhi_epu16(m2, f);             // multiply high unsigned words
		m1 = _mm256_sub_epi16(m2, m3);                     // subtract
		m1 = _mm256_srli_epi16(m1, 16);             // shift right logical with w
		m3 = _mm256_add_epi16(m3, m1);                    // add
		m2=_mm256_srli_epi16(m3, 7);            // shift right logical with b

		//and with mask to keep just 0,6,12,18,24
		m2 = _mm256_and_si256(m2,mask);
		m2 = _mm256_slli_si256(m2,1);
		output = _mm256_add_epi8(output,m2);
		/*
		filt[row][col+1] = (unsigned char) _mm256_extract_epi16(m2,0);
		filt[row][col+1+6] = (unsigned char) _mm256_extract_epi16(m2,3);
		filt[row][col+1+12] = (unsigned char) _mm256_extract_epi16(m2,6);
		filt[row][col+1+18] = (unsigned char) _mm256_extract_epi16(m2,9);
		filt[row][col+1+24] = (unsigned char) _mm256_extract_epi16(m2,12);*/

                 //3rd col iteration
		//multiply with the mask
		m0=_mm256_maddubs_epi16(r0,c0_sh2);
		m1=_mm256_maddubs_epi16(r1,c1_sh2);
		m2=_mm256_maddubs_epi16(r2,c2_sh2);
		m3=_mm256_maddubs_epi16(r3,c1_sh2);
		m4=_mm256_maddubs_epi16(r4,c0_sh2);

		//vertical add
		m0=_mm256_add_epi16(m0,m1);
		m2=_mm256_add_epi16(m2,m3);
		m0=_mm256_add_epi16(m0,m2);
		m0=_mm256_add_epi16(m0,m4);

		//hozizontal additions
		//hadd(0:5)   and store filt[row[col]
		//hadd(6:11)   and store filt[row[col+8]
		//hadd(12:17) and store filt[row[col+14]
		//hadd(18:23) and store filt[row[col+20]
		//hadd(24:30) and store filt[row[col+26]

		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
		m4=_mm256_and_si256(m2,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m3 = _mm256_mulhi_epu16(m2, f);             // multiply high unsigned words
		m1 = _mm256_sub_epi16(m2, m3);                     // subtract
		m1 = _mm256_srli_epi16(m1, 16);             // shift right logical with w
		m3 = _mm256_add_epi16(m3, m1);                    // add
		m2=_mm256_srli_epi16(m3, 7);            // shift right logical with b

		//and with mask to keep just 2,8,14,20,26
		m2 = _mm256_and_si256(m2,mask2);
		output = _mm256_add_epi8(output,m2);
		/*
		filt[row][col+2] = (unsigned char) _mm256_extract_epi16(m2,1);
		filt[row][col+2+6] = (unsigned char) _mm256_extract_epi16(m2,4);
		filt[row][col+2+12] = (unsigned char) _mm256_extract_epi16(m2,7);
		filt[row][col+2+18] = (unsigned char) _mm256_extract_epi16(m2,10);
		filt[row][col+2+24] = (unsigned char) _mm256_extract_epi16(m2,13);*/


		//4th col iteration
		//load the 5 rows
		r0=_mm256_loadu_si256( (__m256i *) &frame1[row-2][col+3-2]);
		r1=_mm256_loadu_si256( (__m256i *) &frame1[row-1][col+3-2]);
		r2=_mm256_loadu_si256( (__m256i *) &frame1[row][col+3-2]);
		r3=_mm256_loadu_si256( (__m256i *) &frame1[row+1][col+3-2]);
		r4=_mm256_loadu_si256( (__m256i *) &frame1[row+2][col+3-2]);

		//multiply with the mask
		m0=_mm256_maddubs_epi16(r0,c0);
		m1=_mm256_maddubs_epi16(r1,c1);
		m2=_mm256_maddubs_epi16(r2,c2);
		m3=_mm256_maddubs_epi16(r3,c1);
		m4=_mm256_maddubs_epi16(r4,c0);

		//vertical add
		m0=_mm256_add_epi16(m0,m1);
		m2=_mm256_add_epi16(m2,m3);
		m0=_mm256_add_epi16(m0,m2);
		m0=_mm256_add_epi16(m0,m4);

		//hozizontal additions
		//hadd(0:5)   and store filt[row[col]
		//hadd(6:11)   and store filt[row[col+8]
		//hadd(12:17) and store filt[row[col+14]
		//hadd(18:23) and store filt[row[col+20]
		//hadd(24:30) and store filt[row[col+26]

		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
		m4=_mm256_and_si256(m0,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m3 = _mm256_mulhi_epu16(m2, f);             // multiply high unsigned words
		m1 = _mm256_sub_epi16(m2, m3);                     // subtract
		m1 = _mm256_srli_epi16(m1, 16);             // shift right logical with w
		m3 = _mm256_add_epi16(m3, m1);                    // add
		m2=_mm256_srli_epi16(m3, 7);            // shift right logical with b

		//and with mask to keep just 0,6,12,18,24
		m2 = _mm256_and_si256(m2,mask);
		m2 = _mm256_slli_si256(m2,3);
		output = _mm256_add_epi8(output,m2);
		/*
		filt[row][col+3] = (unsigned char) _mm256_extract_epi16(m2,0);
		filt[row][col+3+6] = (unsigned char) _mm256_extract_epi16(m2,3);
		filt[row][col+3+12] = (unsigned char) _mm256_extract_epi16(m2,6);
		filt[row][col+3+18] = (unsigned char) _mm256_extract_epi16(m2,9);
		filt[row][col+3+24] = (unsigned char) _mm256_extract_epi16(m2,12);*/

		//5th col iteration
		//multiply with the mask
		m0=_mm256_maddubs_epi16(r0,c0_sh1);
		m1=_mm256_maddubs_epi16(r1,c1_sh1);
		m2=_mm256_maddubs_epi16(r2,c2_sh1);
		m3=_mm256_maddubs_epi16(r3,c1_sh1);
		m4=_mm256_maddubs_epi16(r4,c0_sh1);

		//vertical add
		m0=_mm256_add_epi16(m0,m1);
		m2=_mm256_add_epi16(m2,m3);
		m0=_mm256_add_epi16(m0,m2);
		m0=_mm256_add_epi16(m0,m4);

		//hozizontal additions
		//hadd(0:5)   and store filt[row[col]
		//hadd(6:11)   and store filt[row[col+8]
		//hadd(12:17) and store filt[row[col+14]
		//hadd(18:23) and store filt[row[col+20]
		//hadd(24:30) and store filt[row[col+26]

		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
		m4=_mm256_and_si256(m0,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m3 = _mm256_mulhi_epu16(m2, f);             // multiply high unsigned words
		m1 = _mm256_sub_epi16(m2, m3);                     // subtract
		m1 = _mm256_srli_epi16(m1, 16);             // shift right logical with w
		m3 = _mm256_add_epi16(m3, m1);                    // add
		m2=_mm256_srli_epi16(m3, 7);            // shift right logical with b

		//and with mask to keep just 0,6,12,18,24
		m2 = _mm256_and_si256(m2,mask);
		m1 = _mm256_slli_si256(m2,4);
		output = _mm256_add_epi8(output,m1);

		//output = _mm256_insert_epi8(output,_mm256_extract_epi8(m2,12),16);
		m2=_mm256_and_si256(m2,mask4);
		m2=_mm256_permute2f128_si256(m2,m2,1);
		m2=_mm256_srli_si256(m2,12);
		output=_mm256_add_epi8(output,m2);

		/*
		filt[row][col+4] = (unsigned char) _mm256_extract_epi16(m2,0);
		filt[row][col+4+6] = (unsigned char) _mm256_extract_epi16(m2,3);
		filt[row][col+4+12] = (unsigned char) _mm256_extract_epi16(m2,6);
		filt[row][col+4+18] = (unsigned char) _mm256_extract_epi16(m2,9);
		filt[row][col+4+24] = (unsigned char) _mm256_extract_epi16(m2,12);*/

                 //6th col iteration
		//multiply with the mask
		m0=_mm256_maddubs_epi16(r0,c0_sh2);
		m1=_mm256_maddubs_epi16(r1,c1_sh2);
		m2=_mm256_maddubs_epi16(r2,c2_sh2);
		m3=_mm256_maddubs_epi16(r3,c1_sh2);
		m4=_mm256_maddubs_epi16(r4,c0_sh2);

		//vertical add
		m0=_mm256_add_epi16(m0,m1);
		m2=_mm256_add_epi16(m2,m3);
		m0=_mm256_add_epi16(m0,m2);
		m0=_mm256_add_epi16(m0,m4);

		//hozizontal additions
		//hadd(0:5)   and store filt[row[col]
		//hadd(6:11)   and store filt[row[col+8]
		//hadd(12:17) and store filt[row[col+14]
		//hadd(18:23) and store filt[row[col+20]
		//hadd(24:30) and store filt[row[col+26]

		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);
		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
		m4=_mm256_and_si256(m2,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m3 = _mm256_mulhi_epu16(m2, f);             // multiply high unsigned words
		m1 = _mm256_sub_epi16(m2, m3);                     // subtract
		m1 = _mm256_srli_epi16(m1, 16);             // shift right logical with w
		m3 = _mm256_add_epi16(m3, m1);                    // add
		m2=_mm256_srli_epi16(m3, 7);            // shift right logical with b

		//and with mask to keep just 2,8,14,20,26
		m2 = _mm256_and_si256(m2,mask2);
		m1 = _mm256_slli_si256(m2,3);
		output = _mm256_add_epi8(output,m1);

		//output = _mm256_insert_epi8(output,_mm256_extract_epi8(m2,14),17);
		m2=_mm256_and_si256(m2,mask5);
		m2=_mm256_permute2f128_si256(m2,m2,1);
		m2=_mm256_srli_si256(m2,13);
		output=_mm256_add_epi8(output,m2);

		_mm256_storeu_si256( (__m256i *) &filt[row][col],output);
		//extract insert
		/*
		filt[row][col+5] = (unsigned char) _mm256_extract_epi16(m2,1);
		filt[row][col+5+6] = (unsigned char) _mm256_extract_epi16(m2,4);
		filt[row][col+5+12] = (unsigned char) _mm256_extract_epi16(m2,7);
		filt[row][col+5+18] = (unsigned char) _mm256_extract_epi16(m2,10);
		filt[row][col+5+24] = (unsigned char) _mm256_extract_epi16(m2,13);*/
		}
		//padding code. The last three iterations  ABOVE get outside of the array bounds. The last three col iterations read outside but the garbage values are multiplied by zeros (last three mask zeros). From now on, I must include another mask with extra zeros.
//It is faster to read outside of the array's bounds and then fill the right values. there is an insert command that inserts a value to the vector


}

}//end of parallel


}








//this program reduces the number of times the input image is read. I read 6 times consecutive locations and then jump forward. I can read once and use for 4 times (thus read input 2 times). It is the same if I read once and use for 3 times.
//SOS. gia na kanw reg blocking prepei na exw col+=3 oxi col+=6

void Gaussian_Blur_AVX_ver4_plus_less_load_1_store_reg_blocking(unsigned char **frame1,unsigned char **filt,const unsigned int M, const unsigned int N){

	//after every 5 mask elements I insert a zero. This is because there is no mul command for 8bit in AVX/SSE. The only command I can use is maddubs which mults and adds the intermediate results. Thus, the 5th element will be added with the 6th which is always zero.
	const __m256i c0=_mm256_set_epi8(0,0,0,2,4,5,4,2,0,2,4,5,4,2,0,2,4,5,4,2,0,2,4,5,4,2,0,2,4,5,4,2);
	const __m256i c1=_mm256_set_epi8(0,0,0,4,9,12,9,4,0,4,9,12,9,4,0,4,9,12,9,4,0,4,9,12,9,4,0,4,9,12,9,4);
	const __m256i c2=_mm256_set_epi8(0,0,0,5,12,15,12,5,0,5,12,15,12,5,0,5,12,15,12,5,0,5,12,15,12,5,0,5,12,15,12,5);

	const __m256i c0_sh1=_mm256_set_epi8(0,0,2,4,5,4,2,0,2,4,5,4,2,0,2,4,5,4,2,0,2,4,5,4,2,0,2,4,5,4,2,0);
	const __m256i c1_sh1=_mm256_set_epi8(0,0,4,9,12,9,4,0,4,9,12,9,4,0,4,9,12,9,4,0,4,9,12,9,4,0,4,9,12,9,4,0);
	const __m256i c2_sh1=_mm256_set_epi8(0,0,5,12,15,12,5,0,5,12,15,12,5,0,5,12,15,12,5,0,5,12,15,12,5,0,5,12,15,12,5,0);

	const __m256i c0_sh2=_mm256_set_epi8(0,2,4,5,4,2,0,2,4,5,4,2,0,2,4,5,4,2,0,2,4,5,4,2,0,2,4,5,4,2,0,0);
	const __m256i c1_sh2=_mm256_set_epi8(0,4,9,12,9,4,0,4,9,12,9,4,0,4,9,12,9,4,0,4,9,12,9,4,0,4,9,12,9,4,0,0);
	const __m256i c2_sh2=_mm256_set_epi8(0,5,12,15,12,5,0,5,12,15,12,5,0,5,12,15,12,5,0,5,12,15,12,5,0,5,12,15,12,5,0,0);


	const __m256i f  = _mm256_set_epi16(52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759);
	const __m256i mask  = _mm256_set_epi8(0,0,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255);
	const __m256i mask2  = _mm256_set_epi8(0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0);
	const __m256i mask3  = _mm256_set_epi16(0,0,0,0,0,0,0,65535,0,0,0,0,0,0,0,0);
	const __m256i mask4  = _mm256_set_epi8(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,255,0,0,0,0,0,0,0,0,0,0,0,0);
	const __m256i mask5  = _mm256_set_epi8(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0);



#pragma omp parallel
{
unsigned int extra_iter,row,col;
register __m256i r0,r1,r2,r3,r4,m0,m1,m2,m3,m4,output,output2,output3,output4;


/*---------------------- Gaussian Blur ---------------------------------*/

     #pragma omp for schedule(static)
	for (row = 2; row < N-2; row+=4) {
	  for (col = 2; col < M-26; col+=30){
	    for (extra_iter=0;extra_iter<2;extra_iter++){
	 //last col value that does not read outside of the array bounds is (col<M-29)
		//col iteration computes output pixels of 2,8,14,20,26
		// col+1 iteration computes output pixels of 3,9,15,21,27
		// col+2 iteration computes output pixels of 4,10,16,22,28
		// col+3 iteration computes output pixels of 5,11,17,23,29
		// col+4 iteration computes output pixels of 6,12,18,24,30
		// col+5 iteration computes output pixels of 7,13,19,25,31
		//afterwards, col2 becomes 32 and repeat the above process

		if (extra_iter==0){
		//1st col iteration
		//load the 5 rows
		r0=_mm256_loadu_si256( (__m256i *) &frame1[row-2][col-2]);
		r1=_mm256_loadu_si256( (__m256i *) &frame1[row-1][col-2]);
		r2=_mm256_loadu_si256( (__m256i *) &frame1[row][col-2]);
		r3=_mm256_loadu_si256( (__m256i *) &frame1[row+1][col-2]);
		r4=_mm256_loadu_si256( (__m256i *) &frame1[row+2][col-2]);

		//multiply with the mask
		m0=_mm256_maddubs_epi16(r0,c0);
		m1=_mm256_maddubs_epi16(r1,c1);
		m2=_mm256_maddubs_epi16(r2,c2);
		m3=_mm256_maddubs_epi16(r3,c1);
		m4=_mm256_maddubs_epi16(r4,c0);

		//vertical add
		m0=_mm256_add_epi16(m0,m1);
		m2=_mm256_add_epi16(m2,m3);
		m0=_mm256_add_epi16(m0,m2);
		m0=_mm256_add_epi16(m0,m4);

		//hozizontal additions
		//hadd(0:5)   and store filt[row[col]
		//hadd(6:11)   and store filt[row[col+8]
		//hadd(12:17) and store filt[row[col+14]
		//hadd(18:23) and store filt[row[col+20]
		//hadd(24:30) and store filt[row[col+26]

		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
		m4=_mm256_and_si256(m0,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m3 = _mm256_mulhi_epu16(m2, f);             // multiply high unsigned words
		m1 = _mm256_sub_epi16(m2, m3);                     // subtract
		m1 = _mm256_srli_epi16(m1, 16);             // shift right logical with w
		m3 = _mm256_add_epi16(m3, m1);                    // add
		m2=_mm256_srli_epi16(m3, 7);            // shift right logical with b

		//and with mask to keep just 0,6,12,18,24
		output = _mm256_and_si256(m2,mask);


		//2nd col iteration
		//multiply with the mask
		m0=_mm256_maddubs_epi16(r0,c0_sh1);
		m1=_mm256_maddubs_epi16(r1,c1_sh1);
		m2=_mm256_maddubs_epi16(r2,c2_sh1);
		m3=_mm256_maddubs_epi16(r3,c1_sh1);
		m4=_mm256_maddubs_epi16(r4,c0_sh1);

		//vertical add
		m0=_mm256_add_epi16(m0,m1);
		m2=_mm256_add_epi16(m2,m3);
		m0=_mm256_add_epi16(m0,m2);
		m0=_mm256_add_epi16(m0,m4);

		//hozizontal additions
		//hadd(0:5)   and store filt[row[col]
		//hadd(6:11)   and store filt[row[col+8]
		//hadd(12:17) and store filt[row[col+14]
		//hadd(18:23) and store filt[row[col+20]
		//hadd(24:30) and store filt[row[col+26]

		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
		m4=_mm256_and_si256(m0,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m3 = _mm256_mulhi_epu16(m2, f);             // multiply high unsigned words
		m1 = _mm256_sub_epi16(m2, m3);                     // subtract
		m1 = _mm256_srli_epi16(m1, 16);             // shift right logical with w
		m3 = _mm256_add_epi16(m3, m1);                    // add
		m2=_mm256_srli_epi16(m3, 7);            // shift right logical with b

		//and with mask to keep just 0,6,12,18,24
		m2 = _mm256_and_si256(m2,mask);
		m2 = _mm256_slli_si256(m2,1);
		output = _mm256_add_epi8(output,m2);


                 //3rd col iteration
		//multiply with the mask
		m0=_mm256_maddubs_epi16(r0,c0_sh2);
		m1=_mm256_maddubs_epi16(r1,c1_sh2);
		m2=_mm256_maddubs_epi16(r2,c2_sh2);
		m3=_mm256_maddubs_epi16(r3,c1_sh2);
		m4=_mm256_maddubs_epi16(r4,c0_sh2);

		//vertical add
		m0=_mm256_add_epi16(m0,m1);
		m2=_mm256_add_epi16(m2,m3);
		m0=_mm256_add_epi16(m0,m2);
		m0=_mm256_add_epi16(m0,m4);

		//hozizontal additions
		//hadd(0:5)   and store filt[row[col]
		//hadd(6:11)   and store filt[row[col+8]
		//hadd(12:17) and store filt[row[col+14]
		//hadd(18:23) and store filt[row[col+20]
		//hadd(24:30) and store filt[row[col+26]

		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
		m4=_mm256_and_si256(m2,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m3 = _mm256_mulhi_epu16(m2, f);             // multiply high unsigned words
		m1 = _mm256_sub_epi16(m2, m3);                     // subtract
		m1 = _mm256_srli_epi16(m1, 16);             // shift right logical with w
		m3 = _mm256_add_epi16(m3, m1);                    // add
		m2=_mm256_srli_epi16(m3, 7);            // shift right logical with b

		//and with mask to keep just 2,8,14,20,26
		m2 = _mm256_and_si256(m2,mask2);
		output = _mm256_add_epi8(output,m2);

	//------------------row+1
		//r0=_mm256_loadu_si256( (__m256i *) &frame1[row-2][col-2]);
		//r1=_mm256_loadu_si256( (__m256i *) &frame1[row-1][col-2]);
		//r2=_mm256_loadu_si256( (__m256i *) &frame1[row][col-2]);
		//r3=_mm256_loadu_si256( (__m256i *) &frame1[row+1][col-2]);
		//r4=_mm256_loadu_si256( (__m256i *) &frame1[row+2][col-2]);
		r0=_mm256_loadu_si256( (__m256i *) &frame1[row+3][col-2]);

		//multiply with the mask
		m0=_mm256_maddubs_epi16(r1,c0);
		m1=_mm256_maddubs_epi16(r2,c1);
		m2=_mm256_maddubs_epi16(r3,c2);
		m3=_mm256_maddubs_epi16(r4,c1);
		m4=_mm256_maddubs_epi16(r0,c0);

		//vertical add
		m0=_mm256_add_epi16(m0,m1);
		m2=_mm256_add_epi16(m2,m3);
		m0=_mm256_add_epi16(m0,m2);
		m0=_mm256_add_epi16(m0,m4);

		//hozizontal additions
		//hadd(0:5)   and store filt[row[col]
		//hadd(6:11)   and store filt[row[col+8]
		//hadd(12:17) and store filt[row[col+14]
		//hadd(18:23) and store filt[row[col+20]
		//hadd(24:30) and store filt[row[col+26]

		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
		m4=_mm256_and_si256(m0,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m3 = _mm256_mulhi_epu16(m2, f);             // multiply high unsigned words
		m1 = _mm256_sub_epi16(m2, m3);                     // subtract
		m1 = _mm256_srli_epi16(m1, 16);             // shift right logical with w
		m3 = _mm256_add_epi16(m3, m1);                    // add
		m2=_mm256_srli_epi16(m3, 7);            // shift right logical with b

		//and with mask to keep just 0,6,12,18,24
		output2 = _mm256_and_si256(m2,mask);


		//2nd col iteration
		//multiply with the mask
		m0=_mm256_maddubs_epi16(r1,c0_sh1);
		m1=_mm256_maddubs_epi16(r2,c1_sh1);
		m2=_mm256_maddubs_epi16(r3,c2_sh1);
		m3=_mm256_maddubs_epi16(r4,c1_sh1);
		m4=_mm256_maddubs_epi16(r0,c0_sh1);

		//vertical add
		m0=_mm256_add_epi16(m0,m1);
		m2=_mm256_add_epi16(m2,m3);
		m0=_mm256_add_epi16(m0,m2);
		m0=_mm256_add_epi16(m0,m4);

		//hozizontal additions
		//hadd(0:5)   and store filt[row[col]
		//hadd(6:11)   and store filt[row[col+8]
		//hadd(12:17) and store filt[row[col+14]
		//hadd(18:23) and store filt[row[col+20]
		//hadd(24:30) and store filt[row[col+26]

		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
		m4=_mm256_and_si256(m0,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m3 = _mm256_mulhi_epu16(m2, f);             // multiply high unsigned words
		m1 = _mm256_sub_epi16(m2, m3);                     // subtract
		m1 = _mm256_srli_epi16(m1, 16);             // shift right logical with w
		m3 = _mm256_add_epi16(m3, m1);                    // add
		m2=_mm256_srli_epi16(m3, 7);            // shift right logical with b

		//and with mask to keep just 0,6,12,18,24
		m2 = _mm256_and_si256(m2,mask);
		m2 = _mm256_slli_si256(m2,1);
		output2 = _mm256_add_epi8(output2,m2);


                 //3rd col iteration
		//multiply with the mask
		m0=_mm256_maddubs_epi16(r1,c0_sh2);
		m1=_mm256_maddubs_epi16(r2,c1_sh2);
		m2=_mm256_maddubs_epi16(r3,c2_sh2);
		m3=_mm256_maddubs_epi16(r4,c1_sh2);
		m4=_mm256_maddubs_epi16(r0,c0_sh2);

		//vertical add
		m0=_mm256_add_epi16(m0,m1);
		m2=_mm256_add_epi16(m2,m3);
		m0=_mm256_add_epi16(m0,m2);
		m0=_mm256_add_epi16(m0,m4);

		//hozizontal additions
		//hadd(0:5)   and store filt[row[col]
		//hadd(6:11)   and store filt[row[col+8]
		//hadd(12:17) and store filt[row[col+14]
		//hadd(18:23) and store filt[row[col+20]
		//hadd(24:30) and store filt[row[col+26]

		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
		m4=_mm256_and_si256(m2,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m3 = _mm256_mulhi_epu16(m2, f);             // multiply high unsigned words
		m1 = _mm256_sub_epi16(m2, m3);                     // subtract
		m1 = _mm256_srli_epi16(m1, 16);             // shift right logical with w
		m3 = _mm256_add_epi16(m3, m1);                    // add
		m2=_mm256_srli_epi16(m3, 7);            // shift right logical with b

		//and with mask to keep just 2,8,14,20,26
		m2 = _mm256_and_si256(m2,mask2);
		output2 = _mm256_add_epi8(output2,m2);

	//------------------row+2
		//r0=_mm256_loadu_si256( (__m256i *) &frame1[row-2][col-2]);
		//r1=_mm256_loadu_si256( (__m256i *) &frame1[row-1][col-2]);
		//r2=_mm256_loadu_si256( (__m256i *) &frame1[row][col-2]);
		//r3=_mm256_loadu_si256( (__m256i *) &frame1[row+1][col-2]);
		//r4=_mm256_loadu_si256( (__m256i *) &frame1[row+2][col-2]);
		r1=_mm256_loadu_si256( (__m256i *) &frame1[row+4][col-2]);

		//multiply with the mask
		m0=_mm256_maddubs_epi16(r2,c0);
		m1=_mm256_maddubs_epi16(r3,c1);
		m2=_mm256_maddubs_epi16(r4,c2);
		m3=_mm256_maddubs_epi16(r0,c1);
		m4=_mm256_maddubs_epi16(r1,c0);

		//vertical add
		m0=_mm256_add_epi16(m0,m1);
		m2=_mm256_add_epi16(m2,m3);
		m0=_mm256_add_epi16(m0,m2);
		m0=_mm256_add_epi16(m0,m4);

		//hozizontal additions
		//hadd(0:5)   and store filt[row[col]
		//hadd(6:11)   and store filt[row[col+8]
		//hadd(12:17) and store filt[row[col+14]
		//hadd(18:23) and store filt[row[col+20]
		//hadd(24:30) and store filt[row[col+26]

		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
		m4=_mm256_and_si256(m0,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m3 = _mm256_mulhi_epu16(m2, f);             // multiply high unsigned words
		m1 = _mm256_sub_epi16(m2, m3);                     // subtract
		m1 = _mm256_srli_epi16(m1, 16);             // shift right logical with w
		m3 = _mm256_add_epi16(m3, m1);                    // add
		m2=_mm256_srli_epi16(m3, 7);            // shift right logical with b

		//and with mask to keep just 0,6,12,18,24
		output3 = _mm256_and_si256(m2,mask);


		//2nd col iteration
		//multiply with the mask
		m0=_mm256_maddubs_epi16(r2,c0_sh1);
		m1=_mm256_maddubs_epi16(r3,c1_sh1);
		m2=_mm256_maddubs_epi16(r4,c2_sh1);
		m3=_mm256_maddubs_epi16(r0,c1_sh1);
		m4=_mm256_maddubs_epi16(r1,c0_sh1);

		//vertical add
		m0=_mm256_add_epi16(m0,m1);
		m2=_mm256_add_epi16(m2,m3);
		m0=_mm256_add_epi16(m0,m2);
		m0=_mm256_add_epi16(m0,m4);

		//hozizontal additions
		//hadd(0:5)   and store filt[row[col]
		//hadd(6:11)   and store filt[row[col+8]
		//hadd(12:17) and store filt[row[col+14]
		//hadd(18:23) and store filt[row[col+20]
		//hadd(24:30) and store filt[row[col+26]

		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
		m4=_mm256_and_si256(m0,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m3 = _mm256_mulhi_epu16(m2, f);             // multiply high unsigned words
		m1 = _mm256_sub_epi16(m2, m3);                     // subtract
		m1 = _mm256_srli_epi16(m1, 16);             // shift right logical with w
		m3 = _mm256_add_epi16(m3, m1);                    // add
		m2=_mm256_srli_epi16(m3, 7);            // shift right logical with b

		//and with mask to keep just 0,6,12,18,24
		m2 = _mm256_and_si256(m2,mask);
		m2 = _mm256_slli_si256(m2,1);
		output3 = _mm256_add_epi8(output3,m2);


                 //3rd col iteration
		//multiply with the mask
		m0=_mm256_maddubs_epi16(r2,c0_sh2);
		m1=_mm256_maddubs_epi16(r3,c1_sh2);
		m2=_mm256_maddubs_epi16(r4,c2_sh2);
		m3=_mm256_maddubs_epi16(r0,c1_sh2);
		m4=_mm256_maddubs_epi16(r1,c0_sh2);

		//vertical add
		m0=_mm256_add_epi16(m0,m1);
		m2=_mm256_add_epi16(m2,m3);
		m0=_mm256_add_epi16(m0,m2);
		m0=_mm256_add_epi16(m0,m4);

		//hozizontal additions
		//hadd(0:5)   and store filt[row[col]
		//hadd(6:11)   and store filt[row[col+8]
		//hadd(12:17) and store filt[row[col+14]
		//hadd(18:23) and store filt[row[col+20]
		//hadd(24:30) and store filt[row[col+26]

		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
		m4=_mm256_and_si256(m2,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m3 = _mm256_mulhi_epu16(m2, f);             // multiply high unsigned words
		m1 = _mm256_sub_epi16(m2, m3);                     // subtract
		m1 = _mm256_srli_epi16(m1, 16);             // shift right logical with w
		m3 = _mm256_add_epi16(m3, m1);                    // add
		m2=_mm256_srli_epi16(m3, 7);            // shift right logical with b

		//and with mask to keep just 2,8,14,20,26
		m2 = _mm256_and_si256(m2,mask2);
		output3 = _mm256_add_epi8(output3,m2);


	//------------------row+3
		//r0=_mm256_loadu_si256( (__m256i *) &frame1[row-2][col-2]);
		//r1=_mm256_loadu_si256( (__m256i *) &frame1[row-1][col-2]);
		//r2=_mm256_loadu_si256( (__m256i *) &frame1[row][col-2]);
		//r3=_mm256_loadu_si256( (__m256i *) &frame1[row+1][col-2]);
		//r4=_mm256_loadu_si256( (__m256i *) &frame1[row+2][col-2]);
		r2=_mm256_loadu_si256( (__m256i *) &frame1[row+5][col-2]);

		//multiply with the mask
		m0=_mm256_maddubs_epi16(r3,c0);
		m1=_mm256_maddubs_epi16(r4,c1);
		m2=_mm256_maddubs_epi16(r0,c2);
		m3=_mm256_maddubs_epi16(r1,c1);
		m4=_mm256_maddubs_epi16(r2,c0);

		//vertical add
		m0=_mm256_add_epi16(m0,m1);
		m2=_mm256_add_epi16(m2,m3);
		m0=_mm256_add_epi16(m0,m2);
		m0=_mm256_add_epi16(m0,m4);

		//hozizontal additions
		//hadd(0:5)   and store filt[row[col]
		//hadd(6:11)   and store filt[row[col+8]
		//hadd(12:17) and store filt[row[col+14]
		//hadd(18:23) and store filt[row[col+20]
		//hadd(24:30) and store filt[row[col+26]

		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
		m4=_mm256_and_si256(m0,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m3 = _mm256_mulhi_epu16(m2, f);             // multiply high unsigned words
		m1 = _mm256_sub_epi16(m2, m3);                     // subtract
		m1 = _mm256_srli_epi16(m1, 16);             // shift right logical with w
		m3 = _mm256_add_epi16(m3, m1);                    // add
		m2=_mm256_srli_epi16(m3, 7);            // shift right logical with b

		//and with mask to keep just 0,6,12,18,24
		output4 = _mm256_and_si256(m2,mask);


		//2nd col iteration
		//multiply with the mask
		m0=_mm256_maddubs_epi16(r3,c0_sh1);
		m1=_mm256_maddubs_epi16(r4,c1_sh1);
		m2=_mm256_maddubs_epi16(r0,c2_sh1);
		m3=_mm256_maddubs_epi16(r1,c1_sh1);
		m4=_mm256_maddubs_epi16(r2,c0_sh1);

		//vertical add
		m0=_mm256_add_epi16(m0,m1);
		m2=_mm256_add_epi16(m2,m3);
		m0=_mm256_add_epi16(m0,m2);
		m0=_mm256_add_epi16(m0,m4);

		//hozizontal additions
		//hadd(0:5)   and store filt[row[col]
		//hadd(6:11)   and store filt[row[col+8]
		//hadd(12:17) and store filt[row[col+14]
		//hadd(18:23) and store filt[row[col+20]
		//hadd(24:30) and store filt[row[col+26]

		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
		m4=_mm256_and_si256(m0,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m3 = _mm256_mulhi_epu16(m2, f);             // multiply high unsigned words
		m1 = _mm256_sub_epi16(m2, m3);                     // subtract
		m1 = _mm256_srli_epi16(m1, 16);             // shift right logical with w
		m3 = _mm256_add_epi16(m3, m1);                    // add
		m2=_mm256_srli_epi16(m3, 7);            // shift right logical with b

		//and with mask to keep just 0,6,12,18,24
		m2 = _mm256_and_si256(m2,mask);
		m2 = _mm256_slli_si256(m2,1);
		output4 = _mm256_add_epi8(output4,m2);


                 //3rd col iteration
		//multiply with the mask
		m0=_mm256_maddubs_epi16(r3,c0_sh2);
		m1=_mm256_maddubs_epi16(r4,c1_sh2);
		m2=_mm256_maddubs_epi16(r0,c2_sh2);
		m3=_mm256_maddubs_epi16(r1,c1_sh2);
		m4=_mm256_maddubs_epi16(r2,c0_sh2);

		//vertical add
		m0=_mm256_add_epi16(m0,m1);
		m2=_mm256_add_epi16(m2,m3);
		m0=_mm256_add_epi16(m0,m2);
		m0=_mm256_add_epi16(m0,m4);

		//hozizontal additions
		//hadd(0:5)   and store filt[row[col]
		//hadd(6:11)   and store filt[row[col+8]
		//hadd(12:17) and store filt[row[col+14]
		//hadd(18:23) and store filt[row[col+20]
		//hadd(24:30) and store filt[row[col+26]

		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
		m4=_mm256_and_si256(m2,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m3 = _mm256_mulhi_epu16(m2, f);             // multiply high unsigned words
		m1 = _mm256_sub_epi16(m2, m3);                     // subtract
		m1 = _mm256_srli_epi16(m1, 16);             // shift right logical with w
		m3 = _mm256_add_epi16(m3, m1);                    // add
		m2=_mm256_srli_epi16(m3, 7);            // shift right logical with b

		//and with mask to keep just 2,8,14,20,26
		m2 = _mm256_and_si256(m2,mask2);
		output4 = _mm256_add_epi8(output4,m2);


		}
		else{

		//4th col iteration
		//load the 5 rows
		r0=_mm256_loadu_si256( (__m256i *) &frame1[row-2][col+3-2]);
		r1=_mm256_loadu_si256( (__m256i *) &frame1[row-1][col+3-2]);
		r2=_mm256_loadu_si256( (__m256i *) &frame1[row][col+3-2]);
		r3=_mm256_loadu_si256( (__m256i *) &frame1[row+1][col+3-2]);
		r4=_mm256_loadu_si256( (__m256i *) &frame1[row+2][col+3-2]);

		//multiply with the mask
		m0=_mm256_maddubs_epi16(r0,c0);
		m1=_mm256_maddubs_epi16(r1,c1);
		m2=_mm256_maddubs_epi16(r2,c2);
		m3=_mm256_maddubs_epi16(r3,c1);
		m4=_mm256_maddubs_epi16(r4,c0);

		//vertical add
		m0=_mm256_add_epi16(m0,m1);
		m2=_mm256_add_epi16(m2,m3);
		m0=_mm256_add_epi16(m0,m2);
		m0=_mm256_add_epi16(m0,m4);

		//hozizontal additions
		//hadd(0:5)   and store filt[row[col]
		//hadd(6:11)   and store filt[row[col+8]
		//hadd(12:17) and store filt[row[col+14]
		//hadd(18:23) and store filt[row[col+20]
		//hadd(24:30) and store filt[row[col+26]

		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
		m4=_mm256_and_si256(m0,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m3 = _mm256_mulhi_epu16(m2, f);             // multiply high unsigned words
		m1 = _mm256_sub_epi16(m2, m3);                     // subtract
		m1 = _mm256_srli_epi16(m1, 16);             // shift right logical with w
		m3 = _mm256_add_epi16(m3, m1);                    // add
		m2=_mm256_srli_epi16(m3, 7);            // shift right logical with b

		//and with mask to keep just 0,6,12,18,24
		m2 = _mm256_and_si256(m2,mask);
		m2 = _mm256_slli_si256(m2,3);
		output = _mm256_add_epi8(output,m2);


		//5th col iteration
		//multiply with the mask
		m0=_mm256_maddubs_epi16(r0,c0_sh1);
		m1=_mm256_maddubs_epi16(r1,c1_sh1);
		m2=_mm256_maddubs_epi16(r2,c2_sh1);
		m3=_mm256_maddubs_epi16(r3,c1_sh1);
		m4=_mm256_maddubs_epi16(r4,c0_sh1);

		//vertical add
		m0=_mm256_add_epi16(m0,m1);
		m2=_mm256_add_epi16(m2,m3);
		m0=_mm256_add_epi16(m0,m2);
		m0=_mm256_add_epi16(m0,m4);

		//hozizontal additions
		//hadd(0:5)   and store filt[row[col]
		//hadd(6:11)   and store filt[row[col+8]
		//hadd(12:17) and store filt[row[col+14]
		//hadd(18:23) and store filt[row[col+20]
		//hadd(24:30) and store filt[row[col+26]

		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
		m4=_mm256_and_si256(m0,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m3 = _mm256_mulhi_epu16(m2, f);             // multiply high unsigned words
		m1 = _mm256_sub_epi16(m2, m3);                     // subtract
		m1 = _mm256_srli_epi16(m1, 16);             // shift right logical with w
		m3 = _mm256_add_epi16(m3, m1);                    // add
		m2=_mm256_srli_epi16(m3, 7);            // shift right logical with b

		//and with mask to keep just 0,6,12,18,24
		m2 = _mm256_and_si256(m2,mask);
		m1 = _mm256_slli_si256(m2,4);
		output = _mm256_add_epi8(output,m1);

		//output = _mm256_insert_epi8(output,_mm256_extract_epi8(m2,12),16);
		m2=_mm256_and_si256(m2,mask4);
		m2=_mm256_permute2f128_si256(m2,m2,1);
		m2=_mm256_srli_si256(m2,12);
		output=_mm256_add_epi8(output,m2);


                 //6th col iteration
		//multiply with the mask
		m0=_mm256_maddubs_epi16(r0,c0_sh2);
		m1=_mm256_maddubs_epi16(r1,c1_sh2);
		m2=_mm256_maddubs_epi16(r2,c2_sh2);
		m3=_mm256_maddubs_epi16(r3,c1_sh2);
		m4=_mm256_maddubs_epi16(r4,c0_sh2);

		//vertical add
		m0=_mm256_add_epi16(m0,m1);
		m2=_mm256_add_epi16(m2,m3);
		m0=_mm256_add_epi16(m0,m2);
		m0=_mm256_add_epi16(m0,m4);

		//hozizontal additions
		//hadd(0:5)   and store filt[row[col]
		//hadd(6:11)   and store filt[row[col+8]
		//hadd(12:17) and store filt[row[col+14]
		//hadd(18:23) and store filt[row[col+20]
		//hadd(24:30) and store filt[row[col+26]

		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);
		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
		m4=_mm256_and_si256(m2,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m3 = _mm256_mulhi_epu16(m2, f);             // multiply high unsigned words
		m1 = _mm256_sub_epi16(m2, m3);                     // subtract
		m1 = _mm256_srli_epi16(m1, 16);             // shift right logical with w
		m3 = _mm256_add_epi16(m3, m1);                    // add
		m2=_mm256_srli_epi16(m3, 7);            // shift right logical with b

		//and with mask to keep just 2,8,14,20,26
		m2 = _mm256_and_si256(m2,mask2);
		m1 = _mm256_slli_si256(m2,3);
		output = _mm256_add_epi8(output,m1);

		//output = _mm256_insert_epi8(output,_mm256_extract_epi8(m2,14),17);
		m2=_mm256_and_si256(m2,mask5);
		m2=_mm256_permute2f128_si256(m2,m2,1);
		m2=_mm256_srli_si256(m2,13);
		output=_mm256_add_epi8(output,m2);

		_mm256_storeu_si256( (__m256i *) &filt[row][col],output);

//----------------row+1

		//4th col iteration
		//load the 5 rows
		//r0=_mm256_loadu_si256( (__m256i *) &frame1[row-2][col+3-2]);
		//r1=_mm256_loadu_si256( (__m256i *) &frame1[row-1][col+3-2]);
		//r2=_mm256_loadu_si256( (__m256i *) &frame1[row][col+3-2]);
		//r3=_mm256_loadu_si256( (__m256i *) &frame1[row+1][col+3-2]);
		//r4=_mm256_loadu_si256( (__m256i *) &frame1[row+2][col+3-2]);
		r0=_mm256_loadu_si256( (__m256i *) &frame1[row+3][col+3-2]);

		//multiply with the mask
		m0=_mm256_maddubs_epi16(r1,c0);
		m1=_mm256_maddubs_epi16(r2,c1);
		m2=_mm256_maddubs_epi16(r3,c2);
		m3=_mm256_maddubs_epi16(r4,c1);
		m4=_mm256_maddubs_epi16(r0,c0);

		//vertical add
		m0=_mm256_add_epi16(m0,m1);
		m2=_mm256_add_epi16(m2,m3);
		m0=_mm256_add_epi16(m0,m2);
		m0=_mm256_add_epi16(m0,m4);

		//hozizontal additions
		//hadd(0:5)   and store filt[row[col]
		//hadd(6:11)   and store filt[row[col+8]
		//hadd(12:17) and store filt[row[col+14]
		//hadd(18:23) and store filt[row[col+20]
		//hadd(24:30) and store filt[row[col+26]

		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
		m4=_mm256_and_si256(m0,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m3 = _mm256_mulhi_epu16(m2, f);             // multiply high unsigned words
		m1 = _mm256_sub_epi16(m2, m3);                     // subtract
		m1 = _mm256_srli_epi16(m1, 16);             // shift right logical with w
		m3 = _mm256_add_epi16(m3, m1);                    // add
		m2=_mm256_srli_epi16(m3, 7);            // shift right logical with b

		//and with mask to keep just 0,6,12,18,24
		m2 = _mm256_and_si256(m2,mask);
		m2 = _mm256_slli_si256(m2,3);
		output2 = _mm256_add_epi8(output2,m2);


		//5th col iteration
		//multiply with the mask
		m0=_mm256_maddubs_epi16(r1,c0_sh1);
		m1=_mm256_maddubs_epi16(r2,c1_sh1);
		m2=_mm256_maddubs_epi16(r3,c2_sh1);
		m3=_mm256_maddubs_epi16(r4,c1_sh1);
		m4=_mm256_maddubs_epi16(r0,c0_sh1);

		//vertical add
		m0=_mm256_add_epi16(m0,m1);
		m2=_mm256_add_epi16(m2,m3);
		m0=_mm256_add_epi16(m0,m2);
		m0=_mm256_add_epi16(m0,m4);

		//hozizontal additions
		//hadd(0:5)   and store filt[row[col]
		//hadd(6:11)   and store filt[row[col+8]
		//hadd(12:17) and store filt[row[col+14]
		//hadd(18:23) and store filt[row[col+20]
		//hadd(24:30) and store filt[row[col+26]

		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
		m4=_mm256_and_si256(m0,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m3 = _mm256_mulhi_epu16(m2, f);             // multiply high unsigned words
		m1 = _mm256_sub_epi16(m2, m3);                     // subtract
		m1 = _mm256_srli_epi16(m1, 16);             // shift right logical with w
		m3 = _mm256_add_epi16(m3, m1);                    // add
		m2=_mm256_srli_epi16(m3, 7);            // shift right logical with b

		//and with mask to keep just 0,6,12,18,24
		m2 = _mm256_and_si256(m2,mask);
		m1 = _mm256_slli_si256(m2,4);
		output2 = _mm256_add_epi8(output2,m1);

		//output = _mm256_insert_epi8(output,_mm256_extract_epi8(m2,12),16);
		m2=_mm256_and_si256(m2,mask4);
		m2=_mm256_permute2f128_si256(m2,m2,1);
		m2=_mm256_srli_si256(m2,12);
		output2=_mm256_add_epi8(output2,m2);


                 //6th col iteration
		//multiply with the mask
		m0=_mm256_maddubs_epi16(r1,c0_sh2);
		m1=_mm256_maddubs_epi16(r2,c1_sh2);
		m2=_mm256_maddubs_epi16(r3,c2_sh2);
		m3=_mm256_maddubs_epi16(r4,c1_sh2);
		m4=_mm256_maddubs_epi16(r0,c0_sh2);

		//vertical add
		m0=_mm256_add_epi16(m0,m1);
		m2=_mm256_add_epi16(m2,m3);
		m0=_mm256_add_epi16(m0,m2);
		m0=_mm256_add_epi16(m0,m4);

		//hozizontal additions
		//hadd(0:5)   and store filt[row[col]
		//hadd(6:11)   and store filt[row[col+8]
		//hadd(12:17) and store filt[row[col+14]
		//hadd(18:23) and store filt[row[col+20]
		//hadd(24:30) and store filt[row[col+26]

		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);
		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
		m4=_mm256_and_si256(m2,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m3 = _mm256_mulhi_epu16(m2, f);             // multiply high unsigned words
		m1 = _mm256_sub_epi16(m2, m3);                     // subtract
		m1 = _mm256_srli_epi16(m1, 16);             // shift right logical with w
		m3 = _mm256_add_epi16(m3, m1);                    // add
		m2=_mm256_srli_epi16(m3, 7);            // shift right logical with b

		//and with mask to keep just 2,8,14,20,26
		m2 = _mm256_and_si256(m2,mask2);
		m1 = _mm256_slli_si256(m2,3);
		output2 = _mm256_add_epi8(output2,m1);

		//output = _mm256_insert_epi8(output,_mm256_extract_epi8(m2,14),17);
		m2=_mm256_and_si256(m2,mask5);
		m2=_mm256_permute2f128_si256(m2,m2,1);
		m2=_mm256_srli_si256(m2,13);
		output2=_mm256_add_epi8(output2,m2);

		_mm256_storeu_si256( (__m256i *) &filt[row+1][col],output2);

//----------------row+2

		//4th col iteration
		//load the 5 rows
		//r0=_mm256_loadu_si256( (__m256i *) &frame1[row-2][col+3-2]);
		//r1=_mm256_loadu_si256( (__m256i *) &frame1[row-1][col+3-2]);
		//r2=_mm256_loadu_si256( (__m256i *) &frame1[row][col+3-2]);
		//r3=_mm256_loadu_si256( (__m256i *) &frame1[row+1][col+3-2]);
		//r4=_mm256_loadu_si256( (__m256i *) &frame1[row+2][col+3-2]);
		r1=_mm256_loadu_si256( (__m256i *) &frame1[row+4][col+3-2]);

		//multiply with the mask
		m0=_mm256_maddubs_epi16(r2,c0);
		m1=_mm256_maddubs_epi16(r3,c1);
		m2=_mm256_maddubs_epi16(r4,c2);
		m3=_mm256_maddubs_epi16(r0,c1);
		m4=_mm256_maddubs_epi16(r1,c0);

		//vertical add
		m0=_mm256_add_epi16(m0,m1);
		m2=_mm256_add_epi16(m2,m3);
		m0=_mm256_add_epi16(m0,m2);
		m0=_mm256_add_epi16(m0,m4);

		//hozizontal additions
		//hadd(0:5)   and store filt[row[col]
		//hadd(6:11)   and store filt[row[col+8]
		//hadd(12:17) and store filt[row[col+14]
		//hadd(18:23) and store filt[row[col+20]
		//hadd(24:30) and store filt[row[col+26]

		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
		m4=_mm256_and_si256(m0,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m3 = _mm256_mulhi_epu16(m2, f);             // multiply high unsigned words
		m1 = _mm256_sub_epi16(m2, m3);                     // subtract
		m1 = _mm256_srli_epi16(m1, 16);             // shift right logical with w
		m3 = _mm256_add_epi16(m3, m1);                    // add
		m2=_mm256_srli_epi16(m3, 7);            // shift right logical with b

		//and with mask to keep just 0,6,12,18,24
		m2 = _mm256_and_si256(m2,mask);
		m2 = _mm256_slli_si256(m2,3);
		output3 = _mm256_add_epi8(output3,m2);


		//5th col iteration
		//multiply with the mask
		m0=_mm256_maddubs_epi16(r2,c0_sh1);
		m1=_mm256_maddubs_epi16(r3,c1_sh1);
		m2=_mm256_maddubs_epi16(r4,c2_sh1);
		m3=_mm256_maddubs_epi16(r0,c1_sh1);
		m4=_mm256_maddubs_epi16(r1,c0_sh1);

		//vertical add
		m0=_mm256_add_epi16(m0,m1);
		m2=_mm256_add_epi16(m2,m3);
		m0=_mm256_add_epi16(m0,m2);
		m0=_mm256_add_epi16(m0,m4);

		//hozizontal additions
		//hadd(0:5)   and store filt[row[col]
		//hadd(6:11)   and store filt[row[col+8]
		//hadd(12:17) and store filt[row[col+14]
		//hadd(18:23) and store filt[row[col+20]
		//hadd(24:30) and store filt[row[col+26]

		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
		m4=_mm256_and_si256(m0,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m3 = _mm256_mulhi_epu16(m2, f);             // multiply high unsigned words
		m1 = _mm256_sub_epi16(m2, m3);                     // subtract
		m1 = _mm256_srli_epi16(m1, 16);             // shift right logical with w
		m3 = _mm256_add_epi16(m3, m1);                    // add
		m2=_mm256_srli_epi16(m3, 7);            // shift right logical with b

		//and with mask to keep just 0,6,12,18,24
		m2 = _mm256_and_si256(m2,mask);
		m1 = _mm256_slli_si256(m2,4);
		output3 = _mm256_add_epi8(output3,m1);

		//output = _mm256_insert_epi8(output,_mm256_extract_epi8(m2,12),16);
		m2=_mm256_and_si256(m2,mask4);
		m2=_mm256_permute2f128_si256(m2,m2,1);
		m2=_mm256_srli_si256(m2,12);
		output3=_mm256_add_epi8(output3,m2);


                 //6th col iteration
		//multiply with the mask
		m0=_mm256_maddubs_epi16(r2,c0_sh2);
		m1=_mm256_maddubs_epi16(r3,c1_sh2);
		m2=_mm256_maddubs_epi16(r4,c2_sh2);
		m3=_mm256_maddubs_epi16(r0,c1_sh2);
		m4=_mm256_maddubs_epi16(r1,c0_sh2);

		//vertical add
		m0=_mm256_add_epi16(m0,m1);
		m2=_mm256_add_epi16(m2,m3);
		m0=_mm256_add_epi16(m0,m2);
		m0=_mm256_add_epi16(m0,m4);

		//hozizontal additions
		//hadd(0:5)   and store filt[row[col]
		//hadd(6:11)   and store filt[row[col+8]
		//hadd(12:17) and store filt[row[col+14]
		//hadd(18:23) and store filt[row[col+20]
		//hadd(24:30) and store filt[row[col+26]

		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);
		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
		m4=_mm256_and_si256(m2,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m3 = _mm256_mulhi_epu16(m2, f);             // multiply high unsigned words
		m1 = _mm256_sub_epi16(m2, m3);                     // subtract
		m1 = _mm256_srli_epi16(m1, 16);             // shift right logical with w
		m3 = _mm256_add_epi16(m3, m1);                    // add
		m2=_mm256_srli_epi16(m3, 7);            // shift right logical with b

		//and with mask to keep just 2,8,14,20,26
		m2 = _mm256_and_si256(m2,mask2);
		m1 = _mm256_slli_si256(m2,3);
		output3 = _mm256_add_epi8(output3,m1);

		//output = _mm256_insert_epi8(output,_mm256_extract_epi8(m2,14),17);
		m2=_mm256_and_si256(m2,mask5);
		m2=_mm256_permute2f128_si256(m2,m2,1);
		m2=_mm256_srli_si256(m2,13);
		output3=_mm256_add_epi8(output3,m2);

		_mm256_storeu_si256( (__m256i *) &filt[row+2][col],output3);


//----------------row+3

		//4th col iteration
		//load the 5 rows
		//r0=_mm256_loadu_si256( (__m256i *) &frame1[row-2][col+3-2]);
		//r1=_mm256_loadu_si256( (__m256i *) &frame1[row-1][col+3-2]);
		//r2=_mm256_loadu_si256( (__m256i *) &frame1[row][col+3-2]);
		//r3=_mm256_loadu_si256( (__m256i *) &frame1[row+1][col+3-2]);
		//r4=_mm256_loadu_si256( (__m256i *) &frame1[row+2][col+3-2]);
		r2=_mm256_loadu_si256( (__m256i *) &frame1[row+5][col+3-2]);

		//multiply with the mask
		m0=_mm256_maddubs_epi16(r3,c0);
		m1=_mm256_maddubs_epi16(r4,c1);
		m2=_mm256_maddubs_epi16(r0,c2);
		m3=_mm256_maddubs_epi16(r1,c1);
		m4=_mm256_maddubs_epi16(r2,c0);

		//vertical add
		m0=_mm256_add_epi16(m0,m1);
		m2=_mm256_add_epi16(m2,m3);
		m0=_mm256_add_epi16(m0,m2);
		m0=_mm256_add_epi16(m0,m4);

		//hozizontal additions
		//hadd(0:5)   and store filt[row[col]
		//hadd(6:11)   and store filt[row[col+8]
		//hadd(12:17) and store filt[row[col+14]
		//hadd(18:23) and store filt[row[col+20]
		//hadd(24:30) and store filt[row[col+26]

		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
		m4=_mm256_and_si256(m0,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m3 = _mm256_mulhi_epu16(m2, f);             // multiply high unsigned words
		m1 = _mm256_sub_epi16(m2, m3);                     // subtract
		m1 = _mm256_srli_epi16(m1, 16);             // shift right logical with w
		m3 = _mm256_add_epi16(m3, m1);                    // add
		m2=_mm256_srli_epi16(m3, 7);            // shift right logical with b

		//and with mask to keep just 0,6,12,18,24
		m2 = _mm256_and_si256(m2,mask);
		m2 = _mm256_slli_si256(m2,3);
		output4 = _mm256_add_epi8(output4,m2);


		//5th col iteration
		//multiply with the mask
		m0=_mm256_maddubs_epi16(r3,c0_sh1);
		m1=_mm256_maddubs_epi16(r4,c1_sh1);
		m2=_mm256_maddubs_epi16(r0,c2_sh1);
		m3=_mm256_maddubs_epi16(r1,c1_sh1);
		m4=_mm256_maddubs_epi16(r2,c0_sh1);

		//vertical add
		m0=_mm256_add_epi16(m0,m1);
		m2=_mm256_add_epi16(m2,m3);
		m0=_mm256_add_epi16(m0,m2);
		m0=_mm256_add_epi16(m0,m4);

		//hozizontal additions
		//hadd(0:5)   and store filt[row[col]
		//hadd(6:11)   and store filt[row[col+8]
		//hadd(12:17) and store filt[row[col+14]
		//hadd(18:23) and store filt[row[col+20]
		//hadd(24:30) and store filt[row[col+26]

		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
		m4=_mm256_and_si256(m0,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m3 = _mm256_mulhi_epu16(m2, f);             // multiply high unsigned words
		m1 = _mm256_sub_epi16(m2, m3);                     // subtract
		m1 = _mm256_srli_epi16(m1, 16);             // shift right logical with w
		m3 = _mm256_add_epi16(m3, m1);                    // add
		m2=_mm256_srli_epi16(m3, 7);            // shift right logical with b

		//and with mask to keep just 0,6,12,18,24
		m2 = _mm256_and_si256(m2,mask);
		m1 = _mm256_slli_si256(m2,4);
		output4 = _mm256_add_epi8(output4,m1);

		//output = _mm256_insert_epi8(output,_mm256_extract_epi8(m2,12),16);
		m2=_mm256_and_si256(m2,mask4);
		m2=_mm256_permute2f128_si256(m2,m2,1);
		m2=_mm256_srli_si256(m2,12);
		output4=_mm256_add_epi8(output4,m2);


                 //6th col iteration
		//multiply with the mask
		m0=_mm256_maddubs_epi16(r3,c0_sh2);
		m1=_mm256_maddubs_epi16(r4,c1_sh2);
		m2=_mm256_maddubs_epi16(r0,c2_sh2);
		m3=_mm256_maddubs_epi16(r1,c1_sh2);
		m4=_mm256_maddubs_epi16(r2,c0_sh2);

		//vertical add
		m0=_mm256_add_epi16(m0,m1);
		m2=_mm256_add_epi16(m2,m3);
		m0=_mm256_add_epi16(m0,m2);
		m0=_mm256_add_epi16(m0,m4);

		//hozizontal additions
		//hadd(0:5)   and store filt[row[col]
		//hadd(6:11)   and store filt[row[col+8]
		//hadd(12:17) and store filt[row[col+14]
		//hadd(18:23) and store filt[row[col+20]
		//hadd(24:30) and store filt[row[col+26]

		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);
		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
		m4=_mm256_and_si256(m2,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m3 = _mm256_mulhi_epu16(m2, f);             // multiply high unsigned words
		m1 = _mm256_sub_epi16(m2, m3);                     // subtract
		m1 = _mm256_srli_epi16(m1, 16);             // shift right logical with w
		m3 = _mm256_add_epi16(m3, m1);                    // add
		m2=_mm256_srli_epi16(m3, 7);            // shift right logical with b

		//and with mask to keep just 2,8,14,20,26
		m2 = _mm256_and_si256(m2,mask2);
		m1 = _mm256_slli_si256(m2,3);
		output4 = _mm256_add_epi8(output4,m1);

		//output = _mm256_insert_epi8(output,_mm256_extract_epi8(m2,14),17);
		m2=_mm256_and_si256(m2,mask5);
		m2=_mm256_permute2f128_si256(m2,m2,1);
		m2=_mm256_srli_si256(m2,13);
		output4=_mm256_add_epi8(output4,m2);

		_mm256_storeu_si256( (__m256i *) &filt[row+3][col],output4);
		}
		  }
		}
		//padding code. The last three iterations  ABOVE get outside of the array bounds. The last three col iterations read outside but the garbage values are multiplied by zeros (last three mask zeros). From now on, I must include another mask with extra zeros.
//It is faster to read outside of the array's bounds and then fill the right values. there is an insert command that inserts a value to the vector


}

}//end of parallel


}

// (x/divisor) is transformed into ((x * ceil(f) ) >> w+b) by using the following algorithm. Since the divisor does not change I apply the following procedure just once
const unsigned int prepare_for_division(const unsigned short int divisor){
/*
 * * Mathematical formula, used for unsigned division with fixed divisor:
* (From Terje Mathisen, unpublished)
* x = dividend
* d = divisor
* w = integer word size, bits
* b = floor(log2(d)) = bit_scan_reverse(d)
* f = 2^(w+b) / d                                [exact division]
* If f is an integer then d is a power of 2 then go to case A
* If the fractional part of f is < 0.5 then go to case B
* If the fractional part of f is > 0.5 then go to case C
* Case A:  [shift only]
* result = x >> b
* Case B:  [round down f and compensate by adding one to x]
* result = ((x+1)*floor(f)) >> (w+b)             [high part of unsigned multiplication with 2w bits]
* Case C:  [round up f, no compensation for rounding error]
* result = (x*ceil(f)) >> (w+b)                  [high part of unsigned multiplication with 2w bits]
*
 */
__m256i f_vec;
unsigned short int tmp;

const unsigned int w=16; //integer word size in bits of the division operands
b = (unsigned int) floorf(log2f(divisor));
float f=powf(2,w+b)/divisor;
int integer_part_f = (int) f;
float float_part_f = f - integer_part_f;

if (float_part_f < 0.0001){ //if f==0.0
	return 1; //case A
}
else if (float_part_f < 0.5){
	tmp=(unsigned short int) floorf(f);
	f_vec = _mm256_set1_epi16(tmp);
	_mm256_store_si256( (__m256i *) &f_vector[0],f_vec);
	return 2; //case B
}
else{
	tmp=(unsigned short int) ceilf(f);
	f_vec = _mm256_set1_epi16(tmp);
	_mm256_store_si256( (__m256i *) &f_vector[0],f_vec);
	return 3; //case C
}


}


//now division of r2/159 follows
__m256i division(const unsigned int division_case, __m256i m2, const __m256i f){
	__m256i m1,m3;

	if (division_case==1) { //case A
		return (_mm256_srli_epi16(m2, b));            // shift right logical with b
	}
	else if (division_case==2) { //case B
		m2 = _mm256_add_epi16(m2, _mm256_set1_epi16(1)); //m2=m2+1

		m3 = _mm256_mulhi_epu16(m2, f);             // multiply high unsigned words
		m1 = _mm256_sub_epi16(m2, m3);                     // subtract
		m1 = _mm256_srli_epi16(m1, 16);             // shift right logical with w
		m3 = _mm256_add_epi16(m3, m1);                    // add
		return (_mm256_srli_epi16(m3, b));            // shift right logical with b
	}
	else {//case C
		m3 = _mm256_mulhi_epu16(m2, f);             // multiply high unsigned words
		m1 = _mm256_sub_epi16(m2, m3);                     // subtract
		m1 = _mm256_srli_epi16(m1, 16);             // shift right logical with w
		m3 = _mm256_add_epi16(m3, m1);                    // add
		return (_mm256_srli_epi16(m3, b));            // shift right logical with b
	}

}



//this is the new Gaussian_Blur_AVX_ver4_plus_less_load_1_store()
//this program reduces the number of times the input image is read. I read 6 times consecutive locations and then jump forward. I can read once and use for 4 times (thus read input 2 times). It is the same if I read once and use for 3 times.

//for the general case (generate pixel 0,1), the 1st iteration of col loop needs different masks (starting from 5,4,2,0,...then starting from 4,5,4,2,0,...) as well as the last iteration of col loop (ending to 2,4,5). In the end of col loop, I need if conditions according to the N%30 value.

void Gaussian_Blur_optimized_5x5(unsigned char **frame1,unsigned char **filt,const unsigned int M, const unsigned int N, const unsigned int divisor){


	//load coefficients
	const __m256i c0=_mm256_load_si256( (__m256i *) &gaussian_filter_5x5[0][0]);
	const __m256i c1=_mm256_load_si256( (__m256i *) &gaussian_filter_5x5[1][0]);
	const __m256i c2=_mm256_load_si256( (__m256i *) &gaussian_filter_5x5[2][0]);

	const __m256i c0_sh1=_mm256_load_si256( (__m256i *) &gaussian_filter_5x5[3][0]);
	const __m256i c1_sh1=_mm256_load_si256( (__m256i *) &gaussian_filter_5x5[4][0]);
	const __m256i c2_sh1=_mm256_load_si256( (__m256i *) &gaussian_filter_5x5[5][0]);

	const __m256i c0_sh2=_mm256_load_si256( (__m256i *) &gaussian_filter_5x5[6][0]);
	const __m256i c1_sh2=_mm256_load_si256( (__m256i *) &gaussian_filter_5x5[7][0]);
	const __m256i c2_sh2=_mm256_load_si256( (__m256i *) &gaussian_filter_5x5[8][0]);


	//const __m256i f  = _mm256_set_epi16(52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759);
	const __m256i mask  = _mm256_set_epi8(0,0,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255);
	const __m256i mask2  = _mm256_set_epi8(0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0);
	const __m256i mask3  = _mm256_set_epi16(0,0,0,0,0,0,0,65535,0,0,0,0,0,0,0,0);
	const __m256i mask4  = _mm256_set_epi8(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,255,0,0,0,0,0,0,0,0,0,0,0,0);
	const __m256i mask5  = _mm256_set_epi8(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0);

	const __m256i mask_prelude  = _mm256_set_epi8(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0);

	const unsigned int REMINDER_ITERATIONS =  (M-((((M-32)/30)*30)+30)); //M-(last_col_value+30)
	//printf("\n%d",REMINDER_ITERATIONS);


	const unsigned int division_case=prepare_for_division(divisor); //determine which is the division case (A, B or C)
	const __m256i f = _mm256_load_si256( (__m256i *) &f_vector[0]);// initialize the division vector



#pragma omp parallel
{

unsigned int row,col;
register __m256i r0,r1,r2,r3,r4,m0,m1,m2,m3,m4,output;
__m256i output_row0,output_row1;//these are for processing row #0 and #1 only.
__m256i m0_prelude_row0,m0_prelude_row1;

//MORE EFFICIENT WAY TO DEAL WITH MANY CONSTANTS?

/*---------------------- Gaussian Blur ---------------------------------*/

    #pragma omp for schedule(static)
	for (row = 2; row < N-2; row++) {

		if (row==2){//in this case I calculate filt[0][:] and filt[1][:] too. No extra loads or multiplications are required for this
			  for (col = 0; col <= M-32; col+=30){

				  if (col==0){//this is a special case as the mask gets outside of the array (it is like adding two zeros in the beginning of frame[][]

						//load the 5 rows
						r0=_mm256_loadu_si256( (__m256i *) &frame1[row-2][0]);
						r1=_mm256_loadu_si256( (__m256i *) &frame1[row-1][0]);
						r2=_mm256_loadu_si256( (__m256i *) &frame1[row][0]);
						r3=_mm256_loadu_si256( (__m256i *) &frame1[row+1][0]);
						r4=_mm256_loadu_si256( (__m256i *) &frame1[row+2][0]);

				  			//START - extra code needed for prelude
				  					m0=_mm256_slli_si256(r0,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
				  					m1=_mm256_slli_si256(r1,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
				  					m2=_mm256_slli_si256(r2,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
				  					m3=_mm256_slli_si256(r3,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
				  					m4=_mm256_slli_si256(r4,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning

				  					r0=_mm256_and_si256(r0,mask_prelude);
				  					r0=_mm256_permute2f128_si256(r0,r0,1);
				  					r0=_mm256_srli_si256(r0,14);//shift 14 elements
				  					r0=_mm256_add_epi16(m0,r0);

				  					r1=_mm256_and_si256(r1,mask_prelude);
				  					r1=_mm256_permute2f128_si256(r1,r1,1);
				  					r1=_mm256_srli_si256(r1,14);//shift 14 elements
				  					r1=_mm256_add_epi16(m1,r1);

				  					r2=_mm256_and_si256(r2,mask_prelude);
				  					r2=_mm256_permute2f128_si256(r2,r2,1);
				  					r2=_mm256_srli_si256(r2,14);//shift 14 elements
				  					r2=_mm256_add_epi16(m2,r2);

				  					r3=_mm256_and_si256(r3,mask_prelude);
				  					r3=_mm256_permute2f128_si256(r3,r3,1);
				  					r3=_mm256_srli_si256(r3,14);//shift 14 elements
				  					r3=_mm256_add_epi16(m3,r3);

				  					r4=_mm256_and_si256(r4,mask_prelude);
				  					r4=_mm256_permute2f128_si256(r4,r4,1);
				  					r4=_mm256_srli_si256(r4,14);//shift 14 elements
				  					r4=_mm256_add_epi16(m4,r4);

				  			//END - extra code needed for prelude
				  		}
				  else {
						//load the 5 rows
						r0=_mm256_loadu_si256( (__m256i *) &frame1[row-2][col-2]);
						r1=_mm256_loadu_si256( (__m256i *) &frame1[row-1][col-2]);
						r2=_mm256_loadu_si256( (__m256i *) &frame1[row][col-2]);
						r3=_mm256_loadu_si256( (__m256i *) &frame1[row+1][col-2]);
						r4=_mm256_loadu_si256( (__m256i *) &frame1[row+2][col-2]);
				  }

				//col iteration computes output pixels of 2,8,14,20,26
				// col+1 iteration computes output pixels of 3,9,15,21,27
				// col+2 iteration computes output pixels of 4,10,16,22,28
				// col+3 iteration computes output pixels of 5,11,17,23,29
				// col+4 iteration computes output pixels of 6,12,18,24,30
				// col+5 iteration computes output pixels of 7,13,19,25,31
				//afterwards, col2 becomes 32 and repeat the above process

				//1st col iteration

				  //--------------row=2
				//multiply with the mask
				m0=_mm256_maddubs_epi16(r0,c0);
				m1=_mm256_maddubs_epi16(r1,c1);
				m2=_mm256_maddubs_epi16(r2,c2);
				m3=_mm256_maddubs_epi16(r3,c1);
				m4=_mm256_maddubs_epi16(r4,c0);

				//vertical add
				m0=_mm256_add_epi16(m0,m1);
				m0=_mm256_add_epi16(m0,m2);
				m0=_mm256_add_epi16(m0,m3);
				m0=_mm256_add_epi16(m0,m4);


				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
				m4=_mm256_and_si256(m0,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

				m2=_mm256_add_epi16(m2,m4);

				//now division of m2/divisor follows
				m2=division(division_case,m2,f);

				//and with mask to keep just 0,6,12,18,24
				output = _mm256_and_si256(m2,mask);

				//--------------row=0
				//multiply with the mask
				m0=_mm256_maddubs_epi16(r0,c2);
				m1=_mm256_maddubs_epi16(r1,c1);
				m2=_mm256_maddubs_epi16(r2,c0);

				//vertical add
				m0=_mm256_add_epi16(m0,m1);
				m0=_mm256_add_epi16(m0,m2);


				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
				m4=_mm256_and_si256(m0,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

				m2=_mm256_add_epi16(m2,m4);

				//now division of m2/divisor follows
				m2=division(division_case,m2,f);

				//and with mask to keep just 0,6,12,18,24
				output_row0 = _mm256_and_si256(m2,mask);

				//--------------row=1
				//multiply with the mask
				m0=_mm256_maddubs_epi16(r0,c1);
				m1=_mm256_maddubs_epi16(r1,c2);
				m2=_mm256_maddubs_epi16(r2,c1);
				m3=_mm256_maddubs_epi16(r3,c0);

				//vertical add
				m0=_mm256_add_epi16(m0,m1);
				m0=_mm256_add_epi16(m0,m2);
				m0=_mm256_add_epi16(m0,m3);

				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
				m4=_mm256_and_si256(m0,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

				m2=_mm256_add_epi16(m2,m4);

				//now division of m2/divisor follows
				m2=division(division_case,m2,f);

				//and with mask to keep just 0,6,12,18,24
				output_row1 = _mm256_and_si256(m2,mask);

				//2nd col iteration
				//multiply with the mask

				//----row=2
				m0=_mm256_maddubs_epi16(r0,c0_sh1);
				m1=_mm256_maddubs_epi16(r1,c1_sh1);
				m2=_mm256_maddubs_epi16(r2,c2_sh1);
				m3=_mm256_maddubs_epi16(r3,c1_sh1);
				m4=_mm256_maddubs_epi16(r4,c0_sh1);

				//vertical add
				m0=_mm256_add_epi16(m0,m1);
				m0=_mm256_add_epi16(m0,m2);
				m0=_mm256_add_epi16(m0,m3);
				m0=_mm256_add_epi16(m0,m4);


				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
				m4=_mm256_and_si256(m0,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
				m2=_mm256_add_epi16(m2,m4);

				//now division of m2/divisor follows
				m2=division(division_case,m2,f);

				//and with mask to keep just 0,6,12,18,24
				m2 = _mm256_and_si256(m2,mask);
				m2 = _mm256_slli_si256(m2,1);
				output = _mm256_add_epi8(output,m2);

				//----row=0
				m0=_mm256_maddubs_epi16(r0,c2_sh1);
				m1=_mm256_maddubs_epi16(r1,c1_sh1);
				m2=_mm256_maddubs_epi16(r2,c0_sh1);

				//vertical add
				m0=_mm256_add_epi16(m0,m1);
				m0=_mm256_add_epi16(m0,m2);


				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
				m4=_mm256_and_si256(m0,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
				m2=_mm256_add_epi16(m2,m4);

				//now division of m2/divisor follows
				m2=division(division_case,m2,f);

				//and with mask to keep just 0,6,12,18,24
				m2 = _mm256_and_si256(m2,mask);
				m2 = _mm256_slli_si256(m2,1);
				output_row0 = _mm256_add_epi8(output_row0,m2);

				//----row=1
				m0=_mm256_maddubs_epi16(r0,c1_sh1);
				m1=_mm256_maddubs_epi16(r1,c2_sh1);
				m2=_mm256_maddubs_epi16(r2,c1_sh1);
				m3=_mm256_maddubs_epi16(r3,c0_sh1);

				//vertical add
				m0=_mm256_add_epi16(m0,m1);
				m0=_mm256_add_epi16(m0,m2);
				m0=_mm256_add_epi16(m0,m3);


				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
				m4=_mm256_and_si256(m0,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
				m2=_mm256_add_epi16(m2,m4);

				//now division of m2/divisor follows
				m2=division(division_case,m2,f);

				//and with mask to keep just 0,6,12,18,24
				m2 = _mm256_and_si256(m2,mask);
				m2 = _mm256_slli_si256(m2,1);
				output_row1 = _mm256_add_epi8(output_row1,m2);

		                 //3rd col iteration
				//---row=2
				//multiply with the mask
				m0=_mm256_maddubs_epi16(r0,c0_sh2);
				m1=_mm256_maddubs_epi16(r1,c1_sh2);
				m2=_mm256_maddubs_epi16(r2,c2_sh2);
				m3=_mm256_maddubs_epi16(r3,c1_sh2);
				m4=_mm256_maddubs_epi16(r4,c0_sh2);

				//vertical add
				m0=_mm256_add_epi16(m0,m1);
				m0=_mm256_add_epi16(m0,m2);
				m0=_mm256_add_epi16(m0,m3);
				m0=_mm256_add_epi16(m0,m4);


				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
				m4=_mm256_and_si256(m2,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

				m2=_mm256_add_epi16(m2,m4);

				//now division of m2/divisor follows
				m2=division(division_case,m2,f);

				//and with mask to keep just 2,8,14,20,26
				m2 = _mm256_and_si256(m2,mask2);
				output = _mm256_add_epi8(output,m2);

				//---row=0
				//multiply with the mask

				m0=_mm256_maddubs_epi16(r0,c2_sh2);
				m1=_mm256_maddubs_epi16(r1,c1_sh2);
				m2=_mm256_maddubs_epi16(r2,c0_sh2);

				//vertical add
				m0=_mm256_add_epi16(m0,m1);
				m0=_mm256_add_epi16(m0,m2);


				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
				m4=_mm256_and_si256(m2,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

				m2=_mm256_add_epi16(m2,m4);

				//now division of m2/divisor follows
				m2=division(division_case,m2,f);

				//and with mask to keep just 2,8,14,20,26
				m2 = _mm256_and_si256(m2,mask2);
				output_row0 = _mm256_add_epi8(output_row0,m2);


				//---row=1
				//multiply with the mask

				m0=_mm256_maddubs_epi16(r0,c1_sh2);
				m1=_mm256_maddubs_epi16(r1,c2_sh2);
				m2=_mm256_maddubs_epi16(r2,c1_sh2);
				m3=_mm256_maddubs_epi16(r3,c0_sh2);

				//vertical add
				m0=_mm256_add_epi16(m0,m1);
				m0=_mm256_add_epi16(m0,m2);
				m0=_mm256_add_epi16(m0,m3);

				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
				m4=_mm256_and_si256(m2,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

				m2=_mm256_add_epi16(m2,m4);

				//now division of m2/divisor follows
				m2=division(division_case,m2,f);

				//and with mask to keep just 2,8,14,20,26
				m2 = _mm256_and_si256(m2,mask2);
				output_row1 = _mm256_add_epi8(output_row1,m2);

				//4th col iteration

				//load the 5 rows
				r0=_mm256_loadu_si256( (__m256i *) &frame1[row-2][col+3-2]);
				r1=_mm256_loadu_si256( (__m256i *) &frame1[row-1][col+3-2]);
				r2=_mm256_loadu_si256( (__m256i *) &frame1[row][col+3-2]);
				r3=_mm256_loadu_si256( (__m256i *) &frame1[row+1][col+3-2]);
				r4=_mm256_loadu_si256( (__m256i *) &frame1[row+2][col+3-2]);

				//----row=2
				//multiply with the mask
				m0=_mm256_maddubs_epi16(r0,c0);
				m1=_mm256_maddubs_epi16(r1,c1);
				m2=_mm256_maddubs_epi16(r2,c2);
				m3=_mm256_maddubs_epi16(r3,c1);
				m4=_mm256_maddubs_epi16(r4,c0);

				//vertical add
				m0=_mm256_add_epi16(m0,m1);
				m0=_mm256_add_epi16(m0,m2);
				m0=_mm256_add_epi16(m0,m3);
				m0=_mm256_add_epi16(m0,m4);


				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
				m4=_mm256_and_si256(m0,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

				m2=_mm256_add_epi16(m2,m4);

				//now division of m2/divisor follows
				m2=division(division_case,m2,f);

				//and with mask to keep just 0,6,12,18,24
				m2 = _mm256_and_si256(m2,mask);
				m2 = _mm256_slli_si256(m2,3);
				output = _mm256_add_epi8(output,m2);

				//----row=0
				//multiply with the mask
				m0=_mm256_maddubs_epi16(r0,c2);
				m1=_mm256_maddubs_epi16(r1,c1);
				m2=_mm256_maddubs_epi16(r2,c0);

				//vertical add
				m0=_mm256_add_epi16(m0,m1);
				m0=_mm256_add_epi16(m0,m2);


				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
				m4=_mm256_and_si256(m0,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

				m2=_mm256_add_epi16(m2,m4);

				//now division of m2/divisor follows
				m2=division(division_case,m2,f);

				//and with mask to keep just 0,6,12,18,24
				m2 = _mm256_and_si256(m2,mask);
				m2 = _mm256_slli_si256(m2,3);
				output_row0 = _mm256_add_epi8(output_row0,m2);

				//----row=1
				//multiply with the mask
				m0=_mm256_maddubs_epi16(r0,c1);
				m1=_mm256_maddubs_epi16(r1,c2);
				m2=_mm256_maddubs_epi16(r2,c1);
				m3=_mm256_maddubs_epi16(r3,c0);

				//vertical add
				m0=_mm256_add_epi16(m0,m1);
				m0=_mm256_add_epi16(m0,m2);
				m0=_mm256_add_epi16(m0,m3);


				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
				m4=_mm256_and_si256(m0,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

				m2=_mm256_add_epi16(m2,m4);

				//now division of m2/divisor follows
				m2=division(division_case,m2,f);

				//and with mask to keep just 0,6,12,18,24
				m2 = _mm256_and_si256(m2,mask);
				m2 = _mm256_slli_si256(m2,3);
				output_row1 = _mm256_add_epi8(output_row1,m2);

				//5th col iteration
				//----row=2
				//multiply with the mask
				m0=_mm256_maddubs_epi16(r0,c0_sh1);
				m1=_mm256_maddubs_epi16(r1,c1_sh1);
				m2=_mm256_maddubs_epi16(r2,c2_sh1);
				m3=_mm256_maddubs_epi16(r3,c1_sh1);
				m4=_mm256_maddubs_epi16(r4,c0_sh1);

				//vertical add
				m0=_mm256_add_epi16(m0,m1);
				m0=_mm256_add_epi16(m0,m2);
				m0=_mm256_add_epi16(m0,m3);
				m0=_mm256_add_epi16(m0,m4);


				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
				m4=_mm256_and_si256(m0,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

				m2=_mm256_add_epi16(m2,m4);

				//now division of m2/divisor follows
				m2=division(division_case,m2,f);

				//and with mask to keep just 0,6,12,18,24
				m2 = _mm256_and_si256(m2,mask);
				m1 = _mm256_slli_si256(m2,4);
				output = _mm256_add_epi8(output,m1);

				//output = _mm256_insert_epi8(output,_mm256_extract_epi8(m2,12),16);
				m2=_mm256_and_si256(m2,mask4);
				m2=_mm256_permute2f128_si256(m2,m2,1);
				m2=_mm256_srli_si256(m2,12);
				output=_mm256_add_epi8(output,m2);

				//----row=0
				//multiply with the mask
				m0=_mm256_maddubs_epi16(r0,c2_sh1);
				m1=_mm256_maddubs_epi16(r1,c1_sh1);
				m2=_mm256_maddubs_epi16(r2,c0_sh1);

				//vertical add
				m0=_mm256_add_epi16(m0,m1);
				m0=_mm256_add_epi16(m0,m2);


				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
				m4=_mm256_and_si256(m0,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

				m2=_mm256_add_epi16(m2,m4);

				//now division of m2/divisor follows
				m2=division(division_case,m2,f);

				//and with mask to keep just 0,6,12,18,24
				m2 = _mm256_and_si256(m2,mask);
				m1 = _mm256_slli_si256(m2,4);
				output_row0 = _mm256_add_epi8(output_row0,m1);

				//output = _mm256_insert_epi8(output,_mm256_extract_epi8(m2,12),16);
				m2=_mm256_and_si256(m2,mask4);
				m2=_mm256_permute2f128_si256(m2,m2,1);
				m2=_mm256_srli_si256(m2,12);
				output_row0=_mm256_add_epi8(output_row0,m2);

				//----row=1
				//multiply with the mask

				m0=_mm256_maddubs_epi16(r0,c1_sh1);
				m1=_mm256_maddubs_epi16(r1,c2_sh1);
				m2=_mm256_maddubs_epi16(r2,c1_sh1);
				m3=_mm256_maddubs_epi16(r3,c0_sh1);

				//vertical add
				m0=_mm256_add_epi16(m0,m1);
				m0=_mm256_add_epi16(m0,m2);
				m0=_mm256_add_epi16(m0,m3);


				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
				m4=_mm256_and_si256(m0,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

				m2=_mm256_add_epi16(m2,m4);

				//now division of m2/divisor follows
				m2=division(division_case,m2,f);

				//and with mask to keep just 0,6,12,18,24
				m2 = _mm256_and_si256(m2,mask);
				m1 = _mm256_slli_si256(m2,4);
				output_row1 = _mm256_add_epi8(output_row1,m1);

				//output = _mm256_insert_epi8(output,_mm256_extract_epi8(m2,12),16);
				m2=_mm256_and_si256(m2,mask4);
				m2=_mm256_permute2f128_si256(m2,m2,1);
				m2=_mm256_srli_si256(m2,12);
				output_row1=_mm256_add_epi8(output_row1,m2);

		                 //6th col iteration
				//---row=2
				//multiply with the mask
				m0=_mm256_maddubs_epi16(r0,c0_sh2);
				m1=_mm256_maddubs_epi16(r1,c1_sh2);
				m2=_mm256_maddubs_epi16(r2,c2_sh2);
				m3=_mm256_maddubs_epi16(r3,c1_sh2);
				m4=_mm256_maddubs_epi16(r4,c0_sh2);

				//vertical add
				m0=_mm256_add_epi16(m0,m1);
				m0=_mm256_add_epi16(m0,m2);
				m0=_mm256_add_epi16(m0,m3);
				m0=_mm256_add_epi16(m0,m4);


				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);
				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
				m4=_mm256_and_si256(m2,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

				m2=_mm256_add_epi16(m2,m4);

				//now division of m2/divisor follows
				m2=division(division_case,m2,f);

				//and with mask to keep just 2,8,14,20,26
				m2 = _mm256_and_si256(m2,mask2);
				m1 = _mm256_slli_si256(m2,3);
				output = _mm256_add_epi8(output,m1);

				//output = _mm256_insert_epi8(output,_mm256_extract_epi8(m2,14),17);
				m2=_mm256_and_si256(m2,mask5);
				m2=_mm256_permute2f128_si256(m2,m2,1);
				m2=_mm256_srli_si256(m2,13);
				output=_mm256_add_epi8(output,m2);

				_mm256_storeu_si256( (__m256i *) &filt[row][col],output);


				//---row=0
				//multiply with the mask

				m0=_mm256_maddubs_epi16(r0,c2_sh2);
				m1=_mm256_maddubs_epi16(r1,c1_sh2);
				m2=_mm256_maddubs_epi16(r2,c0_sh2);

				//vertical add
				m0=_mm256_add_epi16(m0,m1);
				m0=_mm256_add_epi16(m0,m2);


				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);
				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
				m4=_mm256_and_si256(m2,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

				m2=_mm256_add_epi16(m2,m4);

				//now division of m2/divisor follows
				m2=division(division_case,m2,f);

				//and with mask to keep just 2,8,14,20,26
				m2 = _mm256_and_si256(m2,mask2);
				m1 = _mm256_slli_si256(m2,3);
				output_row0 = _mm256_add_epi8(output_row0,m1);

				//output = _mm256_insert_epi8(output,_mm256_extract_epi8(m2,14),17);
				m2=_mm256_and_si256(m2,mask5);
				m2=_mm256_permute2f128_si256(m2,m2,1);
				m2=_mm256_srli_si256(m2,13);
				output_row0=_mm256_add_epi8(output_row0,m2);

				_mm256_storeu_si256( (__m256i *) &filt[0][col],output_row0);

				//---row=1
				//multiply with the mask

				m0=_mm256_maddubs_epi16(r0,c1_sh2);
				m1=_mm256_maddubs_epi16(r1,c2_sh2);
				m2=_mm256_maddubs_epi16(r2,c1_sh2);
				m3=_mm256_maddubs_epi16(r3,c0_sh2);

				//vertical add
				m0=_mm256_add_epi16(m0,m1);
				m0=_mm256_add_epi16(m0,m2);
				m0=_mm256_add_epi16(m0,m3);


				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);
				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
				m4=_mm256_and_si256(m2,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

				m2=_mm256_add_epi16(m2,m4);

				//now division of m2/divisor follows
				m2=division(division_case,m2,f);

				//and with mask to keep just 2,8,14,20,26
				m2 = _mm256_and_si256(m2,mask2);
				m1 = _mm256_slli_si256(m2,3);
				output_row1 = _mm256_add_epi8(output_row1,m1);

				//output = _mm256_insert_epi8(output,_mm256_extract_epi8(m2,14),17);
				m2=_mm256_and_si256(m2,mask5);
				m2=_mm256_permute2f128_si256(m2,m2,1);
				m2=_mm256_srli_si256(m2,13);
				output_row1=_mm256_add_epi8(output_row1,m2);

				_mm256_storeu_si256( (__m256i *) &filt[1][col],output_row1);
				}

			  if (REMINDER_ITERATIONS>=16)
				  loop_reminder_first_rows_high_reminder_values(frame1,filt,M,N,col,REMINDER_ITERATIONS,division_case,c0,c1,c2,c0_sh1,c1_sh1,c2_sh1,c0_sh2,c1_sh2,c2_sh2,f,divisor);
			  else
			    loop_reminder_first_rows_low_reminder_values(frame1,filt,M,N,col,REMINDER_ITERATIONS,division_case,c0,c1,c2,c0_sh1,c1_sh1,c2_sh1,c0_sh2,c1_sh2,c2_sh2,f);

		}

		else if (row==N-3){//in this case I calculate filt[N-2][:] and filt[N-1][:] too. Below row0 refers to row=N-2 and row1 refers to row=N-1
			for (col = 0; col <= M-32; col+=30){
						 //last col value that does not read outside of the array bounds is (col<M-29)

							  if (col==0){

									//load the 5 rows
									r0=_mm256_loadu_si256( (__m256i *) &frame1[row-2][0]);
									r1=_mm256_loadu_si256( (__m256i *) &frame1[row-1][0]);
									r2=_mm256_loadu_si256( (__m256i *) &frame1[row][0]);
									r3=_mm256_loadu_si256( (__m256i *) &frame1[row+1][0]);
									r4=_mm256_loadu_si256( (__m256i *) &frame1[row+2][0]);

							  			//START - extra code needed for prelude
							  					m0=_mm256_slli_si256(r0,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
							  					m1=_mm256_slli_si256(r1,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
							  					m2=_mm256_slli_si256(r2,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
							  					m3=_mm256_slli_si256(r3,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
							  					m4=_mm256_slli_si256(r4,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning

							  					r0=_mm256_and_si256(r0,mask_prelude);
							  					r0=_mm256_permute2f128_si256(r0,r0,1);
							  					r0=_mm256_srli_si256(r0,14);//shift 14 elements
							  					r0=_mm256_add_epi16(m0,r0);

							  					r1=_mm256_and_si256(r1,mask_prelude);
							  					r1=_mm256_permute2f128_si256(r1,r1,1);
							  					r1=_mm256_srli_si256(r1,14);//shift 14 elements
							  					r1=_mm256_add_epi16(m1,r1);

							  					r2=_mm256_and_si256(r2,mask_prelude);
							  					r2=_mm256_permute2f128_si256(r2,r2,1);
							  					r2=_mm256_srli_si256(r2,14);//shift 14 elements
							  					r2=_mm256_add_epi16(m2,r2);

							  					r3=_mm256_and_si256(r3,mask_prelude);
							  					r3=_mm256_permute2f128_si256(r3,r3,1);
							  					r3=_mm256_srli_si256(r3,14);//shift 14 elements
							  					r3=_mm256_add_epi16(m3,r3);

							  					r4=_mm256_and_si256(r4,mask_prelude);
							  					r4=_mm256_permute2f128_si256(r4,r4,1);
							  					r4=_mm256_srli_si256(r4,14);//shift 14 elements
							  					r4=_mm256_add_epi16(m4,r4);

							  			//END - extra code needed for prelude
							  		}
							  else {
									//load the 5 rows
									r0=_mm256_loadu_si256( (__m256i *) &frame1[row-2][col-2]);
									r1=_mm256_loadu_si256( (__m256i *) &frame1[row-1][col-2]);
									r2=_mm256_loadu_si256( (__m256i *) &frame1[row][col-2]);
									r3=_mm256_loadu_si256( (__m256i *) &frame1[row+1][col-2]);
									r4=_mm256_loadu_si256( (__m256i *) &frame1[row+2][col-2]);
							  }

							//col iteration computes output pixels of 2,8,14,20,26
							// col+1 iteration computes output pixels of 3,9,15,21,27
							// col+2 iteration computes output pixels of 4,10,16,22,28
							// col+3 iteration computes output pixels of 5,11,17,23,29
							// col+4 iteration computes output pixels of 6,12,18,24,30
							// col+5 iteration computes output pixels of 7,13,19,25,31
							//afterwards, col2 becomes 32 and repeat the above process

							//1st col iteration
							 //--------------row=2

							//multiply with the mask
							m0=_mm256_maddubs_epi16(r0,c0);
							m1=_mm256_maddubs_epi16(r1,c1);
							m2=_mm256_maddubs_epi16(r2,c2);
							m3=_mm256_maddubs_epi16(r3,c1);
							m4=_mm256_maddubs_epi16(r4,c0);

							//vertical add
							m4=_mm256_add_epi16(m4,m3);
							m4=_mm256_add_epi16(m4,m2);
							m4=_mm256_add_epi16(m4,m1);
							m0=_mm256_add_epi16(m4,m0);

							m1=_mm256_srli_si256(m0,2);
							m2=_mm256_add_epi16(m1,m0);

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m2);

							//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
							m4=_mm256_and_si256(m0,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

							m2=_mm256_add_epi16(m2,m4);

							//now division of m2/divisor follows
							m2=division(division_case,m2,f);

							//and with mask to keep just 0,6,12,18,24
							output = _mm256_and_si256(m2,mask);

							//--------------row=0
							//multiply with the mask
							m1=_mm256_maddubs_epi16(r1,c0);
							m2=_mm256_maddubs_epi16(r2,c1);
							m3=_mm256_maddubs_epi16(r3,c2);
							m4=_mm256_maddubs_epi16(r4,c1);

							//vertical add
							m4=_mm256_add_epi16(m4,m3);
							m4=_mm256_add_epi16(m4,m2);
							m4=_mm256_add_epi16(m4,m1); m0_prelude_row0=m4;

							m1=_mm256_srli_si256(m0_prelude_row0,2);
							m2=_mm256_add_epi16(m1,m0_prelude_row0);

							m1=_mm256_srli_si256(m0_prelude_row0,4);
							m2=_mm256_add_epi16(m1,m2);

							//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
							m4=_mm256_and_si256(m0_prelude_row0,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

							m2=_mm256_add_epi16(m2,m4);

							//now division of m2/divisor follows
							m2=division(division_case,m2,f);

							//and with mask to keep just 0,6,12,18,24
							output_row0 = _mm256_and_si256(m2,mask);

							//--------------row=1
							//multiply with the mask
							m2=_mm256_maddubs_epi16(r2,c0);
							m3=_mm256_maddubs_epi16(r3,c1);
							m4=_mm256_maddubs_epi16(r4,c2);


							//vertical add
							m4=_mm256_add_epi16(m4,m3);
							m4=_mm256_add_epi16(m4,m2);m0_prelude_row1=m4;



							m1=_mm256_srli_si256(m0_prelude_row1,2);
							m2=_mm256_add_epi16(m1,m0_prelude_row1);

							m1=_mm256_srli_si256(m0_prelude_row1,4);
							m2=_mm256_add_epi16(m1,m2);

							//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
							m4=_mm256_and_si256(m0_prelude_row1,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

							m2=_mm256_add_epi16(m2,m4);

							//now division of m2/divisor follows
							m2=division(division_case,m2,f);

							//and with mask to keep just 0,6,12,18,24
							output_row1 = _mm256_and_si256(m2,mask);

							//2nd col iteration
							//----row=2

							//multiply with the mask
							m0=_mm256_maddubs_epi16(r0,c0_sh1);
							m1=_mm256_maddubs_epi16(r1,c1_sh1);
							m2=_mm256_maddubs_epi16(r2,c2_sh1);
							m3=_mm256_maddubs_epi16(r3,c1_sh1);
							m4=_mm256_maddubs_epi16(r4,c0_sh1);

							//vertical add
							m4=_mm256_add_epi16(m4,m3);
							m4=_mm256_add_epi16(m4,m2);
							m4=_mm256_add_epi16(m4,m1);
							m0=_mm256_add_epi16(m4,m0);


							m1=_mm256_srli_si256(m0,2);
							m2=_mm256_add_epi16(m1,m0);

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m2);

							//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
							m4=_mm256_and_si256(m0,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
							m2=_mm256_add_epi16(m2,m4);

							//now division of m2/divisor follows
							m2=division(division_case,m2,f);

							//and with mask to keep just 0,6,12,18,24
							m2 = _mm256_and_si256(m2,mask);
							m2 = _mm256_slli_si256(m2,1);
							output = _mm256_add_epi8(output,m2);

							//----row=0
							//multiply with the mask
							m1=_mm256_maddubs_epi16(r1,c0_sh1);
							m2=_mm256_maddubs_epi16(r2,c1_sh1);
							m3=_mm256_maddubs_epi16(r3,c2_sh1);
							m4=_mm256_maddubs_epi16(r4,c1_sh1);


							//vertical add
							m4=_mm256_add_epi16(m4,m3);
							m4=_mm256_add_epi16(m4,m2);
							m4=_mm256_add_epi16(m4,m1);m0_prelude_row0=m4;


							m1=_mm256_srli_si256(m0_prelude_row0,2);
							m2=_mm256_add_epi16(m1,m0_prelude_row0);

							m1=_mm256_srli_si256(m0_prelude_row0,4);
							m2=_mm256_add_epi16(m1,m2);

							//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
							m4=_mm256_and_si256(m0_prelude_row0,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
							m2=_mm256_add_epi16(m2,m4);

							//now division of m2/divisor follows
							m2=division(division_case,m2,f);

							//and with mask to keep just 0,6,12,18,24
							m2 = _mm256_and_si256(m2,mask);
							m2 = _mm256_slli_si256(m2,1);
							output_row0 = _mm256_add_epi8(output_row0,m2);

							//----row=1
							//multiply with the mask
							m2=_mm256_maddubs_epi16(r2,c0_sh1);
							m3=_mm256_maddubs_epi16(r3,c1_sh1);
							m4=_mm256_maddubs_epi16(r4,c2_sh1);


							//vertical add
							m4=_mm256_add_epi16(m4,m3);
							m4=_mm256_add_epi16(m4,m2);m0_prelude_row1=m4;


							m1=_mm256_srli_si256(m0_prelude_row1,2);
							m2=_mm256_add_epi16(m1,m0_prelude_row1);

							m1=_mm256_srli_si256(m0_prelude_row1,4);
							m2=_mm256_add_epi16(m1,m2);

							//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
							m4=_mm256_and_si256(m0_prelude_row1,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
							m2=_mm256_add_epi16(m2,m4);

							//now division of m2/divisor follows
							m2=division(division_case,m2,f);

							//and with mask to keep just 0,6,12,18,24
							m2 = _mm256_and_si256(m2,mask);
							m2 = _mm256_slli_si256(m2,1);
							output_row1 = _mm256_add_epi8(output_row1,m2);

					                 //3rd col iteration
							//---row=2
							//multiply with the mask
							m0=_mm256_maddubs_epi16(r0,c0_sh2);
							m1=_mm256_maddubs_epi16(r1,c1_sh2);
							m2=_mm256_maddubs_epi16(r2,c2_sh2);
							m3=_mm256_maddubs_epi16(r3,c1_sh2);
							m4=_mm256_maddubs_epi16(r4,c0_sh2);

							//vertical add
							m4=_mm256_add_epi16(m4,m3);
							m4=_mm256_add_epi16(m4,m2);
							m4=_mm256_add_epi16(m4,m1);
							m0=_mm256_add_epi16(m4,m0);


							m1=_mm256_srli_si256(m0,2);
							m2=_mm256_add_epi16(m1,m0);

							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
							m4=_mm256_and_si256(m2,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m2);

							//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

							m2=_mm256_add_epi16(m2,m4);

							//now division of m2/divisor follows
							m2=division(division_case,m2,f);

							//and with mask to keep just 2,8,14,20,26
							m2 = _mm256_and_si256(m2,mask2);
							output = _mm256_add_epi8(output,m2);

							//---row=0
							//multiply with the mask
							m1=_mm256_maddubs_epi16(r1,c0_sh2);
							m2=_mm256_maddubs_epi16(r2,c1_sh2);
							m3=_mm256_maddubs_epi16(r3,c2_sh2);
							m4=_mm256_maddubs_epi16(r4,c1_sh2);


							//vertical add
							m4=_mm256_add_epi16(m4,m3);
							m4=_mm256_add_epi16(m4,m2);
							m4=_mm256_add_epi16(m4,m1);m0_prelude_row0=m4;

							m1=_mm256_srli_si256(m0_prelude_row0,2);
							m2=_mm256_add_epi16(m1,m0_prelude_row0);

							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
							m4=_mm256_and_si256(m2,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

							m1=_mm256_srli_si256(m0_prelude_row0,4);
							m2=_mm256_add_epi16(m1,m2);

							//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

							m2=_mm256_add_epi16(m2,m4);

							//now division of m2/divisor follows
							m2=division(division_case,m2,f);

							//and with mask to keep just 2,8,14,20,26
							m2 = _mm256_and_si256(m2,mask2);
							output_row0 = _mm256_add_epi8(output_row0,m2);


							//---row=1
							//multiply with the mask
							m2=_mm256_maddubs_epi16(r2,c0_sh2);
							m3=_mm256_maddubs_epi16(r3,c1_sh2);
							m4=_mm256_maddubs_epi16(r4,c2_sh2);


							//vertical add
							m4=_mm256_add_epi16(m4,m3);
							m4=_mm256_add_epi16(m4,m2);m0_prelude_row1=m4;


							m1=_mm256_srli_si256(m0_prelude_row1,2);
							m2=_mm256_add_epi16(m1,m0_prelude_row1);

							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
							m4=_mm256_and_si256(m2,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

							m1=_mm256_srli_si256(m0_prelude_row1,4);
							m2=_mm256_add_epi16(m1,m2);

							//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

							m2=_mm256_add_epi16(m2,m4);

							//now division of m2/divisor follows
							m2=division(division_case,m2,f);

							//and with mask to keep just 2,8,14,20,26
							m2 = _mm256_and_si256(m2,mask2);
							output_row1 = _mm256_add_epi8(output_row1,m2);

							//4th col iteration
							//load the 5 rows
							r0=_mm256_loadu_si256( (__m256i *) &frame1[row-2][col+3-2]);
							r1=_mm256_loadu_si256( (__m256i *) &frame1[row-1][col+3-2]);
							r2=_mm256_loadu_si256( (__m256i *) &frame1[row][col+3-2]);
							r3=_mm256_loadu_si256( (__m256i *) &frame1[row+1][col+3-2]);
							r4=_mm256_loadu_si256( (__m256i *) &frame1[row+2][col+3-2]);

							//----row=2
							//multiply with the mask
							m0=_mm256_maddubs_epi16(r0,c0);
							m1=_mm256_maddubs_epi16(r1,c1);
							m2=_mm256_maddubs_epi16(r2,c2);
							m3=_mm256_maddubs_epi16(r3,c1);
							m4=_mm256_maddubs_epi16(r4,c0);

							//vertical add
							m4=_mm256_add_epi16(m4,m3);
							m4=_mm256_add_epi16(m4,m2);
							m4=_mm256_add_epi16(m4,m1);
							m0=_mm256_add_epi16(m4,m0);


							m1=_mm256_srli_si256(m0,2);
							m2=_mm256_add_epi16(m1,m0);

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m2);

							//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
							m4=_mm256_and_si256(m0,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

							m2=_mm256_add_epi16(m2,m4);

							//now division of m2/divisor follows
							m2=division(division_case,m2,f);

							//and with mask to keep just 0,6,12,18,24
							m2 = _mm256_and_si256(m2,mask);
							m2 = _mm256_slli_si256(m2,3);
							output = _mm256_add_epi8(output,m2);

							//----row=0
							//multiply with the mask
							m1=_mm256_maddubs_epi16(r1,c0);
							m2=_mm256_maddubs_epi16(r2,c1);
							m3=_mm256_maddubs_epi16(r3,c2);
							m4=_mm256_maddubs_epi16(r4,c1);

							//vertical add
							m4=_mm256_add_epi16(m4,m3);
							m4=_mm256_add_epi16(m4,m2);
							m4=_mm256_add_epi16(m4,m1);m0_prelude_row0=m4;


							m1=_mm256_srli_si256(m0_prelude_row0,2);
							m2=_mm256_add_epi16(m1,m0_prelude_row0);

							m1=_mm256_srli_si256(m0_prelude_row0,4);
							m2=_mm256_add_epi16(m1,m2);

							//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
							m4=_mm256_and_si256(m0_prelude_row0,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

							m2=_mm256_add_epi16(m2,m4);

							//now division of m2/divisor follows
							m2=division(division_case,m2,f);

							//and with mask to keep just 0,6,12,18,24
							m2 = _mm256_and_si256(m2,mask);
							m2 = _mm256_slli_si256(m2,3);
							output_row0 = _mm256_add_epi8(output_row0,m2);

							//----row=1
							//multiply with the mask
							m2=_mm256_maddubs_epi16(r2,c0);
							m3=_mm256_maddubs_epi16(r3,c1);
							m4=_mm256_maddubs_epi16(r4,c2);


							//vertical add
							m4=_mm256_add_epi16(m4,m3);
							m4=_mm256_add_epi16(m4,m2);m0_prelude_row1=m4;


							m1=_mm256_srli_si256(m0_prelude_row1,2);
							m2=_mm256_add_epi16(m1,m0_prelude_row1);

							m1=_mm256_srli_si256(m0_prelude_row1,4);
							m2=_mm256_add_epi16(m1,m2);

							//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
							m4=_mm256_and_si256(m0_prelude_row1,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

							m2=_mm256_add_epi16(m2,m4);

							//now division of m2/divisor follows
							m2=division(division_case,m2,f);

							//and with mask to keep just 0,6,12,18,24
							m2 = _mm256_and_si256(m2,mask);
							m2 = _mm256_slli_si256(m2,3);
							output_row1 = _mm256_add_epi8(output_row1,m2);

							//5th col iteration
							//----row=2
							//multiply with the mask
							m0=_mm256_maddubs_epi16(r0,c0_sh1);
							m1=_mm256_maddubs_epi16(r1,c1_sh1);
							m2=_mm256_maddubs_epi16(r2,c2_sh1);
							m3=_mm256_maddubs_epi16(r3,c1_sh1);
							m4=_mm256_maddubs_epi16(r4,c0_sh1);

							//vertical add
							m4=_mm256_add_epi16(m4,m3);
							m4=_mm256_add_epi16(m4,m2);
							m4=_mm256_add_epi16(m4,m1);
							m0=_mm256_add_epi16(m4,m0);


							m1=_mm256_srli_si256(m0,2);
							m2=_mm256_add_epi16(m1,m0);

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m2);

							//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
							m4=_mm256_and_si256(m0,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

							m2=_mm256_add_epi16(m2,m4);

							//now division of m2/divisor follows
							m2=division(division_case,m2,f);

							//and with mask to keep just 0,6,12,18,24
							m2 = _mm256_and_si256(m2,mask);
							m1 = _mm256_slli_si256(m2,4);
							output = _mm256_add_epi8(output,m1);

							//output = _mm256_insert_epi8(output,_mm256_extract_epi8(m2,12),16);
							m2=_mm256_and_si256(m2,mask4);
							m2=_mm256_permute2f128_si256(m2,m2,1);
							m2=_mm256_srli_si256(m2,12);
							output=_mm256_add_epi8(output,m2);

							//----row=0
							//multiply with the mask
							m1=_mm256_maddubs_epi16(r1,c0_sh1);
							m2=_mm256_maddubs_epi16(r2,c1_sh1);
							m3=_mm256_maddubs_epi16(r3,c2_sh1);
							m4=_mm256_maddubs_epi16(r4,c1_sh1);


							//vertical add
							m4=_mm256_add_epi16(m4,m3);
							m4=_mm256_add_epi16(m4,m2);
							m4=_mm256_add_epi16(m4,m1);m0_prelude_row0=m4;


							m1=_mm256_srli_si256(m0_prelude_row0,2);
							m2=_mm256_add_epi16(m1,m0_prelude_row0);

							m1=_mm256_srli_si256(m0_prelude_row0,4);
							m2=_mm256_add_epi16(m1,m2);

							//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
							m4=_mm256_and_si256(m0_prelude_row0,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

							m2=_mm256_add_epi16(m2,m4);

							//now division of m2/divisor follows
							m2=division(division_case,m2,f);

							//and with mask to keep just 0,6,12,18,24
							m2 = _mm256_and_si256(m2,mask);
							m1 = _mm256_slli_si256(m2,4);
							output_row0 = _mm256_add_epi8(output_row0,m1);

							//output = _mm256_insert_epi8(output,_mm256_extract_epi8(m2,12),16);
							m2=_mm256_and_si256(m2,mask4);
							m2=_mm256_permute2f128_si256(m2,m2,1);
							m2=_mm256_srli_si256(m2,12);
							output_row0=_mm256_add_epi8(output_row0,m2);

							//----row=1
							//multiply with the mask
							m2=_mm256_maddubs_epi16(r2,c0_sh1);
							m3=_mm256_maddubs_epi16(r3,c1_sh1);
							m4=_mm256_maddubs_epi16(r4,c2_sh1);


							//vertical add
							m4=_mm256_add_epi16(m4,m3);
							m4=_mm256_add_epi16(m4,m2);m0_prelude_row1=m4;


							m1=_mm256_srli_si256(m0_prelude_row1,2);
							m2=_mm256_add_epi16(m1,m0_prelude_row1);

							m1=_mm256_srli_si256(m0_prelude_row1,4);
							m2=_mm256_add_epi16(m1,m2);

							//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
							m4=_mm256_and_si256(m0_prelude_row1,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

							m2=_mm256_add_epi16(m2,m4);

							//now division of m2/divisor follows
							m2=division(division_case,m2,f);

							//and with mask to keep just 0,6,12,18,24
							m2 = _mm256_and_si256(m2,mask);
							m1 = _mm256_slli_si256(m2,4);
							output_row1 = _mm256_add_epi8(output_row1,m1);

							//output = _mm256_insert_epi8(output,_mm256_extract_epi8(m2,12),16);
							m2=_mm256_and_si256(m2,mask4);
							m2=_mm256_permute2f128_si256(m2,m2,1);
							m2=_mm256_srli_si256(m2,12);
							output_row1=_mm256_add_epi8(output_row1,m2);

					                 //6th col iteration
							//---row=2
							//multiply with the mask
							m0=_mm256_maddubs_epi16(r0,c0_sh2);
							m1=_mm256_maddubs_epi16(r1,c1_sh2);
							m2=_mm256_maddubs_epi16(r2,c2_sh2);
							m3=_mm256_maddubs_epi16(r3,c1_sh2);
							m4=_mm256_maddubs_epi16(r4,c0_sh2);

							//vertical add
							m4=_mm256_add_epi16(m4,m3);
							m4=_mm256_add_epi16(m4,m2);
							m4=_mm256_add_epi16(m4,m1);
							m0=_mm256_add_epi16(m4,m0);


							m1=_mm256_srli_si256(m0,2);
							m2=_mm256_add_epi16(m1,m0);
							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
							m4=_mm256_and_si256(m2,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m2);

							//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

							m2=_mm256_add_epi16(m2,m4);

							//now division of m2/divisor follows
							m2=division(division_case,m2,f);

							//and with mask to keep just 2,8,14,20,26
							m2 = _mm256_and_si256(m2,mask2);
							m1 = _mm256_slli_si256(m2,3);
							output = _mm256_add_epi8(output,m1);

							//output = _mm256_insert_epi8(output,_mm256_extract_epi8(m2,14),17);
							m2=_mm256_and_si256(m2,mask5);
							m2=_mm256_permute2f128_si256(m2,m2,1);
							m2=_mm256_srli_si256(m2,13);
							output=_mm256_add_epi8(output,m2);

							_mm256_storeu_si256( (__m256i *) &filt[row][col],output);


							//---row=0
							//multiply with the mask
							m1=_mm256_maddubs_epi16(r1,c0_sh2);
							m2=_mm256_maddubs_epi16(r2,c1_sh2);
							m3=_mm256_maddubs_epi16(r3,c2_sh2);
							m4=_mm256_maddubs_epi16(r4,c1_sh2);


							//vertical add
							m4=_mm256_add_epi16(m4,m3);
							m4=_mm256_add_epi16(m4,m2);
							m4=_mm256_add_epi16(m4,m1);m0_prelude_row0=m4;


							m1=_mm256_srli_si256(m0_prelude_row0,2);
							m2=_mm256_add_epi16(m1,m0_prelude_row0);
							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
							m4=_mm256_and_si256(m2,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

							m1=_mm256_srli_si256(m0_prelude_row0,4);
							m2=_mm256_add_epi16(m1,m2);

							//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

							m2=_mm256_add_epi16(m2,m4);

							//now division of m2/divisor follows
							m2=division(division_case,m2,f);

							//and with mask to keep just 2,8,14,20,26
							m2 = _mm256_and_si256(m2,mask2);
							m1 = _mm256_slli_si256(m2,3);
							output_row0 = _mm256_add_epi8(output_row0,m1);

							//output = _mm256_insert_epi8(output,_mm256_extract_epi8(m2,14),17);
							m2=_mm256_and_si256(m2,mask5);
							m2=_mm256_permute2f128_si256(m2,m2,1);
							m2=_mm256_srli_si256(m2,13);
							output_row0=_mm256_add_epi8(output_row0,m2);

							_mm256_storeu_si256( (__m256i *) &filt[N-2][col],output_row0);

							//---row=1
							//multiply with the mask
							m2=_mm256_maddubs_epi16(r2,c0_sh2);
							m3=_mm256_maddubs_epi16(r3,c1_sh2);
							m4=_mm256_maddubs_epi16(r4,c2_sh2);


							//vertical add
							m4=_mm256_add_epi16(m4,m3);
							m4=_mm256_add_epi16(m4,m2);m0_prelude_row1=m4;

							m1=_mm256_srli_si256(m0_prelude_row1,2);
							m2=_mm256_add_epi16(m1,m0_prelude_row1);
							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
							m4=_mm256_and_si256(m2,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

							m1=_mm256_srli_si256(m0_prelude_row1,4);
							m2=_mm256_add_epi16(m1,m2);

							//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

							m2=_mm256_add_epi16(m2,m4);

							//now division of m2/divisor follows
							m2=division(division_case,m2,f);

							//and with mask to keep just 2,8,14,20,26
							m2 = _mm256_and_si256(m2,mask2);
							m1 = _mm256_slli_si256(m2,3);
							output_row1 = _mm256_add_epi8(output_row1,m1);

							//output = _mm256_insert_epi8(output,_mm256_extract_epi8(m2,14),17);
							m2=_mm256_and_si256(m2,mask5);
							m2=_mm256_permute2f128_si256(m2,m2,1);
							m2=_mm256_srli_si256(m2,13);
							output_row1=_mm256_add_epi8(output_row1,m2);

							_mm256_storeu_si256( (__m256i *) &filt[N-1][col],output_row1);
							}

			if (REMINDER_ITERATIONS>=16)
				loop_reminder_last_rows_high_reminder_values(frame1,filt,M,N,col,REMINDER_ITERATIONS,division_case,c0,c1,c2,c0_sh1,c1_sh1,c2_sh1,c0_sh2,c1_sh2,c2_sh2,f,divisor);
			else
				loop_reminder_last_rows_low_reminder_values(frame1,filt,M,N,col,REMINDER_ITERATIONS,division_case,c0,c1,c2,c0_sh1,c1_sh1,c2_sh1,c0_sh2,c1_sh2,c2_sh2,f);

					}
	else {


	  for (col = 0; col <= M-32; col+=30){
	 //last col value that does not read outside of the array bounds is (col<M-29)

		  if (col==0){

				//load the 5 rows
				r0=_mm256_loadu_si256( (__m256i *) &frame1[row-2][0]);
				r1=_mm256_loadu_si256( (__m256i *) &frame1[row-1][0]);
				r2=_mm256_loadu_si256( (__m256i *) &frame1[row][0]);
				r3=_mm256_loadu_si256( (__m256i *) &frame1[row+1][0]);
				r4=_mm256_loadu_si256( (__m256i *) &frame1[row+2][0]);

		  			//START - extra code needed for prelude
		  					m0=_mm256_slli_si256(r0,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
		  					m1=_mm256_slli_si256(r1,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
		  					m2=_mm256_slli_si256(r2,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
		  					m3=_mm256_slli_si256(r3,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
		  					m4=_mm256_slli_si256(r4,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning

		  					r0=_mm256_and_si256(r0,mask_prelude);
		  					r0=_mm256_permute2f128_si256(r0,r0,1);
		  					r0=_mm256_srli_si256(r0,14);//shift 14 elements
		  					r0=_mm256_add_epi16(m0,r0);

		  					r1=_mm256_and_si256(r1,mask_prelude);
		  					r1=_mm256_permute2f128_si256(r1,r1,1);
		  					r1=_mm256_srli_si256(r1,14);//shift 14 elements
		  					r1=_mm256_add_epi16(m1,r1);

		  					r2=_mm256_and_si256(r2,mask_prelude);
		  					r2=_mm256_permute2f128_si256(r2,r2,1);
		  					r2=_mm256_srli_si256(r2,14);//shift 14 elements
		  					r2=_mm256_add_epi16(m2,r2);

		  					r3=_mm256_and_si256(r3,mask_prelude);
		  					r3=_mm256_permute2f128_si256(r3,r3,1);
		  					r3=_mm256_srli_si256(r3,14);//shift 14 elements
		  					r3=_mm256_add_epi16(m3,r3);

		  					r4=_mm256_and_si256(r4,mask_prelude);
		  					r4=_mm256_permute2f128_si256(r4,r4,1);
		  					r4=_mm256_srli_si256(r4,14);//shift 14 elements
		  					r4=_mm256_add_epi16(m4,r4);

		  			//END - extra code needed for prelude
		  		}
		  else {
				//load the 5 rows
				r0=_mm256_loadu_si256( (__m256i *) &frame1[row-2][col-2]);
				r1=_mm256_loadu_si256( (__m256i *) &frame1[row-1][col-2]);
				r2=_mm256_loadu_si256( (__m256i *) &frame1[row][col-2]);
				r3=_mm256_loadu_si256( (__m256i *) &frame1[row+1][col-2]);
				r4=_mm256_loadu_si256( (__m256i *) &frame1[row+2][col-2]);
		  }

		//col iteration computes output pixels of 2,8,14,20,26
		// col+1 iteration computes output pixels of 3,9,15,21,27
		// col+2 iteration computes output pixels of 4,10,16,22,28
		// col+3 iteration computes output pixels of 5,11,17,23,29
		// col+4 iteration computes output pixels of 6,12,18,24,30
		// col+5 iteration computes output pixels of 7,13,19,25,31
		//afterwards, col2 becomes 32 and repeat the above process

		//1st col iteration


		//multiply with the mask
		m0=_mm256_maddubs_epi16(r0,c0);
		m1=_mm256_maddubs_epi16(r1,c1);
		m2=_mm256_maddubs_epi16(r2,c2);
		m3=_mm256_maddubs_epi16(r3,c1);
		m4=_mm256_maddubs_epi16(r4,c0);

		//vertical add
		m0=_mm256_add_epi16(m0,m1);
		m2=_mm256_add_epi16(m2,m3);
		m0=_mm256_add_epi16(m0,m2);
		m0=_mm256_add_epi16(m0,m4);

		//hozizontal additions
		//hadd(0:5)   and store filt[row[col]
		//hadd(6:11)   and store filt[row[col+8]
		//hadd(12:17) and store filt[row[col+14]
		//hadd(18:23) and store filt[row[col+20]
		//hadd(24:30) and store filt[row[col+26]

		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
		m4=_mm256_and_si256(m0,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

		m2=_mm256_add_epi16(m2,m4);

		//now division of m2/divisor follows
		m2=division(division_case,m2,f);


		//and with mask to keep just 0,6,12,18,24
		output = _mm256_and_si256(m2,mask);
		/*
		filt[row][col] = (unsigned char) _mm256_extract_epi16(m2,0);
		filt[row][col+6] = (unsigned char) _mm256_extract_epi16(m2,3);
		filt[row][col+12] = (unsigned char) _mm256_extract_epi16(m2,6);
		filt[row][col+18] = (unsigned char) _mm256_extract_epi16(m2,9);
		filt[row][col+24] = (unsigned char) _mm256_extract_epi16(m2,12);*/

		//2nd col iteration
		//multiply with the mask
		m0=_mm256_maddubs_epi16(r0,c0_sh1);
		m1=_mm256_maddubs_epi16(r1,c1_sh1);
		m2=_mm256_maddubs_epi16(r2,c2_sh1);
		m3=_mm256_maddubs_epi16(r3,c1_sh1);
		m4=_mm256_maddubs_epi16(r4,c0_sh1);

		//vertical add
		m0=_mm256_add_epi16(m0,m1);
		m2=_mm256_add_epi16(m2,m3);
		m0=_mm256_add_epi16(m0,m2);
		m0=_mm256_add_epi16(m0,m4);

		//hozizontal additions
		//hadd(0:5)   and store filt[row[col]
		//hadd(6:11)   and store filt[row[col+8]
		//hadd(12:17) and store filt[row[col+14]
		//hadd(18:23) and store filt[row[col+20]
		//hadd(24:30) and store filt[row[col+26]

		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
		m4=_mm256_and_si256(m0,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m2=division(division_case,m2,f);


		//and with mask to keep just 0,6,12,18,24
		m2 = _mm256_and_si256(m2,mask);
		m2 = _mm256_slli_si256(m2,1);
		output = _mm256_add_epi8(output,m2);
		/*
		filt[row][col+1] = (unsigned char) _mm256_extract_epi16(m2,0);
		filt[row][col+1+6] = (unsigned char) _mm256_extract_epi16(m2,3);
		filt[row][col+1+12] = (unsigned char) _mm256_extract_epi16(m2,6);
		filt[row][col+1+18] = (unsigned char) _mm256_extract_epi16(m2,9);
		filt[row][col+1+24] = (unsigned char) _mm256_extract_epi16(m2,12);*/

                 //3rd col iteration
		//multiply with the mask
		m0=_mm256_maddubs_epi16(r0,c0_sh2);
		m1=_mm256_maddubs_epi16(r1,c1_sh2);
		m2=_mm256_maddubs_epi16(r2,c2_sh2);
		m3=_mm256_maddubs_epi16(r3,c1_sh2);
		m4=_mm256_maddubs_epi16(r4,c0_sh2);

		//vertical add
		m0=_mm256_add_epi16(m0,m1);
		m2=_mm256_add_epi16(m2,m3);
		m0=_mm256_add_epi16(m0,m2);
		m0=_mm256_add_epi16(m0,m4);

		//hozizontal additions
		//hadd(0:5)   and store filt[row[col]
		//hadd(6:11)   and store filt[row[col+8]
		//hadd(12:17) and store filt[row[col+14]
		//hadd(18:23) and store filt[row[col+20]
		//hadd(24:30) and store filt[row[col+26]

		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
		m4=_mm256_and_si256(m2,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m2=division(division_case,m2,f);


		//and with mask to keep just 2,8,14,20,26
		m2 = _mm256_and_si256(m2,mask2);
		output = _mm256_add_epi8(output,m2);
		/*
		filt[row][col+2] = (unsigned char) _mm256_extract_epi16(m2,1);
		filt[row][col+2+6] = (unsigned char) _mm256_extract_epi16(m2,4);
		filt[row][col+2+12] = (unsigned char) _mm256_extract_epi16(m2,7);
		filt[row][col+2+18] = (unsigned char) _mm256_extract_epi16(m2,10);
		filt[row][col+2+24] = (unsigned char) _mm256_extract_epi16(m2,13);*/


		//4th col iteration
		//load the 5 rows
		r0=_mm256_loadu_si256( (__m256i *) &frame1[row-2][col+3-2]);
		r1=_mm256_loadu_si256( (__m256i *) &frame1[row-1][col+3-2]);
		r2=_mm256_loadu_si256( (__m256i *) &frame1[row][col+3-2]);
		r3=_mm256_loadu_si256( (__m256i *) &frame1[row+1][col+3-2]);
		r4=_mm256_loadu_si256( (__m256i *) &frame1[row+2][col+3-2]);

		//multiply with the mask
		m0=_mm256_maddubs_epi16(r0,c0);
		m1=_mm256_maddubs_epi16(r1,c1);
		m2=_mm256_maddubs_epi16(r2,c2);
		m3=_mm256_maddubs_epi16(r3,c1);
		m4=_mm256_maddubs_epi16(r4,c0);

		//vertical add
		m0=_mm256_add_epi16(m0,m1);
		m2=_mm256_add_epi16(m2,m3);
		m0=_mm256_add_epi16(m0,m2);
		m0=_mm256_add_epi16(m0,m4);

		//hozizontal additions
		//hadd(0:5)   and store filt[row[col]
		//hadd(6:11)   and store filt[row[col+8]
		//hadd(12:17) and store filt[row[col+14]
		//hadd(18:23) and store filt[row[col+20]
		//hadd(24:30) and store filt[row[col+26]

		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
		m4=_mm256_and_si256(m0,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m2=division(division_case,m2,f);


		//and with mask to keep just 0,6,12,18,24
		m2 = _mm256_and_si256(m2,mask);
		m2 = _mm256_slli_si256(m2,3);
		output = _mm256_add_epi8(output,m2);
		/*
		filt[row][col+3] = (unsigned char) _mm256_extract_epi16(m2,0);
		filt[row][col+3+6] = (unsigned char) _mm256_extract_epi16(m2,3);
		filt[row][col+3+12] = (unsigned char) _mm256_extract_epi16(m2,6);
		filt[row][col+3+18] = (unsigned char) _mm256_extract_epi16(m2,9);
		filt[row][col+3+24] = (unsigned char) _mm256_extract_epi16(m2,12);*/

		//5th col iteration
		//multiply with the mask
		m0=_mm256_maddubs_epi16(r0,c0_sh1);
		m1=_mm256_maddubs_epi16(r1,c1_sh1);
		m2=_mm256_maddubs_epi16(r2,c2_sh1);
		m3=_mm256_maddubs_epi16(r3,c1_sh1);
		m4=_mm256_maddubs_epi16(r4,c0_sh1);

		//vertical add
		m0=_mm256_add_epi16(m0,m1);
		m2=_mm256_add_epi16(m2,m3);
		m0=_mm256_add_epi16(m0,m2);
		m0=_mm256_add_epi16(m0,m4);

		//hozizontal additions
		//hadd(0:5)   and store filt[row[col]
		//hadd(6:11)   and store filt[row[col+8]
		//hadd(12:17) and store filt[row[col+14]
		//hadd(18:23) and store filt[row[col+20]
		//hadd(24:30) and store filt[row[col+26]

		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
		m4=_mm256_and_si256(m0,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m2=division(division_case,m2,f);

		//and with mask to keep just 0,6,12,18,24
		m2 = _mm256_and_si256(m2,mask);
		m1 = _mm256_slli_si256(m2,4);
		output = _mm256_add_epi8(output,m1);

		//output = _mm256_insert_epi8(output,_mm256_extract_epi8(m2,12),16);
		m2=_mm256_and_si256(m2,mask4);
		m2=_mm256_permute2f128_si256(m2,m2,1);
		m2=_mm256_srli_si256(m2,12);
		output=_mm256_add_epi8(output,m2);

		/*
		filt[row][col+4] = (unsigned char) _mm256_extract_epi16(m2,0);
		filt[row][col+4+6] = (unsigned char) _mm256_extract_epi16(m2,3);
		filt[row][col+4+12] = (unsigned char) _mm256_extract_epi16(m2,6);
		filt[row][col+4+18] = (unsigned char) _mm256_extract_epi16(m2,9);
		filt[row][col+4+24] = (unsigned char) _mm256_extract_epi16(m2,12);*/

                 //6th col iteration
		//multiply with the mask
		m0=_mm256_maddubs_epi16(r0,c0_sh2);
		m1=_mm256_maddubs_epi16(r1,c1_sh2);
		m2=_mm256_maddubs_epi16(r2,c2_sh2);
		m3=_mm256_maddubs_epi16(r3,c1_sh2);
		m4=_mm256_maddubs_epi16(r4,c0_sh2);

		//vertical add
		m0=_mm256_add_epi16(m0,m1);
		m2=_mm256_add_epi16(m2,m3);
		m0=_mm256_add_epi16(m0,m2);
		m0=_mm256_add_epi16(m0,m4);

		//hozizontal additions
		//hadd(0:5)   and store filt[row[col]
		//hadd(6:11)   and store filt[row[col+8]
		//hadd(12:17) and store filt[row[col+14]
		//hadd(18:23) and store filt[row[col+20]
		//hadd(24:30) and store filt[row[col+26]

		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);
		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
		m4=_mm256_and_si256(m2,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m2=division(division_case,m2,f);

		//and with mask to keep just 2,8,14,20,26
		m2 = _mm256_and_si256(m2,mask2);
		m1 = _mm256_slli_si256(m2,3);
		output = _mm256_add_epi8(output,m1);

		//output = _mm256_insert_epi8(output,_mm256_extract_epi8(m2,14),17);
		m2=_mm256_and_si256(m2,mask5);
		m2=_mm256_permute2f128_si256(m2,m2,1);
		m2=_mm256_srli_si256(m2,13);
		output=_mm256_add_epi8(output,m2);

		_mm256_storeu_si256( (__m256i *) &filt[row][col],output);

		//extract insert
		/*
		filt[row][col+5] = (unsigned char) _mm256_extract_epi16(m2,1);
		filt[row][col+5+6] = (unsigned char) _mm256_extract_epi16(m2,4);
		filt[row][col+5+12] = (unsigned char) _mm256_extract_epi16(m2,7);
		filt[row][col+5+18] = (unsigned char) _mm256_extract_epi16(m2,10);
		filt[row][col+5+24] = (unsigned char) _mm256_extract_epi16(m2,13);*/
		}

        if (REMINDER_ITERATIONS>=16)
        	loop_reminder_high_reminder_values(frame1,filt,M,N,row,col,REMINDER_ITERATIONS,division_case,c0,c1,c2,c0_sh1,c1_sh1,c2_sh1,c0_sh2,c1_sh2,c2_sh2,f,divisor);
        else
        	loop_reminder_low_reminder_values(frame1,filt,M,N,row,col,REMINDER_ITERATIONS,division_case,c0,c1,c2,c0_sh1,c1_sh1,c2_sh1,c0_sh2,c1_sh2,c2_sh2,f);
		//padding code. The last three iterations  ABOVE get outside of the array bounds. The last three col iterations read outside but the garbage values are multiplied by zeros (last three mask zeros). From now on, I must include another mask with extra zeros.
//It is faster to read outside of the array's bounds and then fill the right values. there is an insert command that inserts a value to the vector
//TOMORROW: USE Gaussian_Blur_AVX_ver4_plus_less_load ROUTINE FOR LOOP REMINDER. LOAD OUTSIDE OF THE ARRAY AND THEN ZERO THE VALUES NEEDED.

		}
}

}//end of parallel


}


/*this routine computes the remaining filt[][col] iterations. Their number ranges from 2 to 31 col iterations.
To compute the last two col iterations, I must add two zeros in the end of the input image.
Load is performed twice, one from col-2 and another from col-2+3. Thus, I need two extra elements in the beginning


*/
//for loop reminder<16 only
int loop_reminder_low_reminder_values(unsigned char **frame1,unsigned char **filt,const unsigned int M, const unsigned int N,const unsigned int row, const unsigned int col, const unsigned int REMINDER_ITERATIONS,const unsigned int division_case,const __m256i c0,const __m256i c1,const __m256i c2,const __m256i c0_sh1,const __m256i c1_sh1,const __m256i c2_sh1,const __m256i c0_sh2,const __m256i c1_sh2,const __m256i c2_sh2, const __m256i f ){

register	__m256i r0,r1,r2,r3,r4,m0,m1,m2,m3,m4;


	//const __m256i f  = _mm256_set_epi16(52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759);


 __m256i reminder_mask1,reminder_mask2;

if (REMINDER_ITERATIONS == 0){
	return 0; //no loop reminder is needed
}

	reminder_mask1=_mm256_load_si256( (__m256i *) &reminder_msk1[REMINDER_ITERATIONS-1][0]);
	reminder_mask2=_mm256_load_si256( (__m256i *) &reminder_msk2[REMINDER_ITERATIONS-1][0]);




	 //1st col iteration
	//load the 5 rows
	r0=_mm256_loadu_si256( (__m256i *) &frame1[row-2][col-2]);
	r1=_mm256_loadu_si256( (__m256i *) &frame1[row-1][col-2]);
	r2=_mm256_loadu_si256( (__m256i *) &frame1[row][col-2]);
	r3=_mm256_loadu_si256( (__m256i *) &frame1[row+1][col-2]);
	r4=_mm256_loadu_si256( (__m256i *) &frame1[row+2][col-2]);

	/*
	 * The above load operations load outside of the array bounds; these elements are filled with zeros just after
	 * Furthermore, I add two extra zeros in the end to compute col=N-2 and col=N-1. The last value of col is N-1, not N
	 */

	//AND r0-r4 with reminder_mask
	r0=_mm256_and_si256(r0,reminder_mask1);
	r1=_mm256_and_si256(r1,reminder_mask1);
	r2=_mm256_and_si256(r2,reminder_mask1);
	r3=_mm256_and_si256(r3,reminder_mask1);
	r4=_mm256_and_si256(r4,reminder_mask1);

	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c0);
	m1=_mm256_maddubs_epi16(r1,c1);
	m2=_mm256_maddubs_epi16(r2,c2);
	m3=_mm256_maddubs_epi16(r3,c1);
	m4=_mm256_maddubs_epi16(r4,c0);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m2=_mm256_add_epi16(m2,m3);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m4);

	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi
	m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m2=_mm256_add_epi16(m2,m4);

	//now division of m2/divisor follows
	m2=division(division_case,m2,f);


if (REMINDER_ITERATIONS > 12){
	filt[row][col] = (unsigned char) _mm256_extract_epi16(m2,0);
	filt[row][col+6] = (unsigned char) _mm256_extract_epi16(m2,3);
	filt[row][col+12] = (unsigned char) _mm256_extract_epi16(m2,6);
}
else if (REMINDER_ITERATIONS > 6){
	filt[row][col] = (unsigned char) _mm256_extract_epi16(m2,0);
	filt[row][col+6] = (unsigned char) _mm256_extract_epi16(m2,3);
}
else if (REMINDER_ITERATIONS > 0)
	filt[row][col] = (unsigned char) _mm256_extract_epi16(m2,0);

/*
if (REMINDER_ITERATIONS > 18)
	filt[row][col+18] = (unsigned char) _mm256_extract_epi16(m2,9);

if (REMINDER_ITERATIONS > 24)
	filt[row][col+24] = (unsigned char) _mm256_extract_epi16(m2,12);
*/


if (REMINDER_ITERATIONS ==1)
	return 0;


    //2nd col iteration

	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c0_sh1);
	m1=_mm256_maddubs_epi16(r1,c1_sh1);
	m2=_mm256_maddubs_epi16(r2,c2_sh1);
	m3=_mm256_maddubs_epi16(r3,c1_sh1);
	m4=_mm256_maddubs_epi16(r4,c0_sh1);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m2=_mm256_add_epi16(m2,m3);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m4);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi
	m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m2=_mm256_add_epi16(m2,m4);

	//now division of m2/divisor follows
	m2=division(division_case,m2,f);




if (REMINDER_ITERATIONS > 13){
	filt[row][col+1] = (unsigned char) _mm256_extract_epi16(m2,0);
	filt[row][col+6+1] = (unsigned char) _mm256_extract_epi16(m2,3);
	filt[row][col+12+1] = (unsigned char) _mm256_extract_epi16(m2,6);
}
else if (REMINDER_ITERATIONS > 7){
	filt[row][col+1] = (unsigned char) _mm256_extract_epi16(m2,0);
	filt[row][col+6+1] = (unsigned char) _mm256_extract_epi16(m2,3);
}
else if (REMINDER_ITERATIONS > 1)
	filt[row][col+1] = (unsigned char) _mm256_extract_epi16(m2,0);

/*
if (REMINDER_ITERATIONS > 19)
	filt[row][col+18+1] = (unsigned char) _mm256_extract_epi16(m2,9);

if (REMINDER_ITERATIONS > 25)
	filt[row][col+24+1] = (unsigned char) _mm256_extract_epi16(m2,12);
*/


if (REMINDER_ITERATIONS ==2)
	return 0;


     //3rd col iteration

	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c0_sh2);
	m1=_mm256_maddubs_epi16(r1,c1_sh2);
	m2=_mm256_maddubs_epi16(r2,c2_sh2);
	m3=_mm256_maddubs_epi16(r3,c1_sh2);
	m4=_mm256_maddubs_epi16(r4,c0_sh2);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m2=_mm256_add_epi16(m2,m3);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m4);

	//hozizontal additions
	//hadd(0:5)   and store filt[row[col]
	//hadd(6:11)   and store filt[row[col+8]
	//hadd(12:17) and store filt[row[col+14]
	//hadd(18:23) and store filt[row[col+20]
	//hadd(24:30) and store filt[row[col+26]

	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);
	m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

	m2=_mm256_add_epi16(m2,m4);

	//now division of m2/divisor follows
	m2=division(division_case,m2,f);



if (REMINDER_ITERATIONS > 14){
	filt[row][col+2] = (unsigned char) _mm256_extract_epi16(m2,1);
	filt[row][col+6+2] = (unsigned char) _mm256_extract_epi16(m2,4);
	filt[row][col+12+2] = (unsigned char) _mm256_extract_epi16(m2,7);
}
else if (REMINDER_ITERATIONS > 8){
	filt[row][col+2] = (unsigned char) _mm256_extract_epi16(m2,1);
	filt[row][col+6+2] = (unsigned char) _mm256_extract_epi16(m2,4);
}
else if (REMINDER_ITERATIONS > 2)
	filt[row][col+2] = (unsigned char) _mm256_extract_epi16(m2,1);


/*
if (REMINDER_ITERATIONS > 20)
	filt[row][col+18+2] = (unsigned char) _mm256_extract_epi16(m2,10);

if (REMINDER_ITERATIONS > 26)
	filt[row][col+24+2] = (unsigned char) _mm256_extract_epi16(m2,13);
*/

if (REMINDER_ITERATIONS ==3){
	return 0;
}

	 //4th col iteration
	//load the 5 rows
	r0=_mm256_loadu_si256( (__m256i *) &frame1[row-2][col-2+3]);
	r1=_mm256_loadu_si256( (__m256i *) &frame1[row-1][col-2+3]);
	r2=_mm256_loadu_si256( (__m256i *) &frame1[row][col-2+3]);
	r3=_mm256_loadu_si256( (__m256i *) &frame1[row+1][col-2+3]);
	r4=_mm256_loadu_si256( (__m256i *) &frame1[row+2][col-2+3]);

	/*
	 * The above load operations load outside of the array bounds; these elements are filled with zeros just after
	 * Furthermore, I add two extra zeros in the end to compute col=N-2 and col=N-1. The last value of col is N-1, not N
	 */

	//AND r0-r4 with reminder_mask
	r0=_mm256_and_si256(r0,reminder_mask2);
	r1=_mm256_and_si256(r1,reminder_mask2);
	r2=_mm256_and_si256(r2,reminder_mask2);
	r3=_mm256_and_si256(r3,reminder_mask2);
	r4=_mm256_and_si256(r4,reminder_mask2);

	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c0);
	m1=_mm256_maddubs_epi16(r1,c1);
	m2=_mm256_maddubs_epi16(r2,c2);
	m3=_mm256_maddubs_epi16(r3,c1);
	m4=_mm256_maddubs_epi16(r4,c0);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m2=_mm256_add_epi16(m2,m3);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m4);

	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi
	m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m2=_mm256_add_epi16(m2,m4);

	//now division of m2/divisor follows
	m2=division(division_case,m2,f);



if (REMINDER_ITERATIONS > 9){
	filt[row][col+3] = (unsigned char) _mm256_extract_epi16(m2,0);
	filt[row][col+6+3] = (unsigned char) _mm256_extract_epi16(m2,3);
}
else if (REMINDER_ITERATIONS > 3)
	filt[row][col+3] = (unsigned char) _mm256_extract_epi16(m2,0);
/*
if (REMINDER_ITERATIONS > 15)
	filt[row][col+12+3] = (unsigned char) _mm256_extract_epi16(m2,6);

if (REMINDER_ITERATIONS > 21)
	filt[row][col+18+3] = (unsigned char) _mm256_extract_epi16(m2,9);

if (REMINDER_ITERATIONS > 27)
	filt[row][col+24+3] = (unsigned char) _mm256_extract_epi16(m2,12);
*/


if (REMINDER_ITERATIONS ==4)
	return 0;


   //2nd col iteration

	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c0_sh1);
	m1=_mm256_maddubs_epi16(r1,c1_sh1);
	m2=_mm256_maddubs_epi16(r2,c2_sh1);
	m3=_mm256_maddubs_epi16(r3,c1_sh1);
	m4=_mm256_maddubs_epi16(r4,c0_sh1);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m2=_mm256_add_epi16(m2,m3);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m4);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi
	m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m2=_mm256_add_epi16(m2,m4);

	//now division of m2/divisor follows
	m2=division(division_case,m2,f);




if (REMINDER_ITERATIONS > 10){
	filt[row][col+1+3] = (unsigned char) _mm256_extract_epi16(m2,0);
	filt[row][col+6+1+3] = (unsigned char) _mm256_extract_epi16(m2,3);
}
else if (REMINDER_ITERATIONS > 4)
	filt[row][col+1+3] = (unsigned char) _mm256_extract_epi16(m2,0);

/*
if (REMINDER_ITERATIONS > 16)
	filt[row][col+12+1+3] = (unsigned char) _mm256_extract_epi16(m2,6);

if (REMINDER_ITERATIONS > 22)
	filt[row][col+18+1+3] = (unsigned char) _mm256_extract_epi16(m2,9);

if (REMINDER_ITERATIONS > 28)
	filt[row][col+24+1+3] = (unsigned char) _mm256_extract_epi16(m2,12);
*/


if (REMINDER_ITERATIONS ==5)
	return 0;


    //3rd col iteration

	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c0_sh2);
	m1=_mm256_maddubs_epi16(r1,c1_sh2);
	m2=_mm256_maddubs_epi16(r2,c2_sh2);
	m3=_mm256_maddubs_epi16(r3,c1_sh2);
	m4=_mm256_maddubs_epi16(r4,c0_sh2);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m2=_mm256_add_epi16(m2,m3);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m4);

	//hozizontal additions
	//hadd(0:5)   and store filt[row[col]
	//hadd(6:11)   and store filt[row[col+8]
	//hadd(12:17) and store filt[row[col+14]
	//hadd(18:23) and store filt[row[col+20]
	//hadd(24:30) and store filt[row[col+26]

	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);
	m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

	m2=_mm256_add_epi16(m2,m4);

	//now division of m2/divisor follows
	m2=division(division_case,m2,f);



if (REMINDER_ITERATIONS > 11){
	filt[row][col+2+3] = (unsigned char) _mm256_extract_epi16(m2,1);
	filt[row][col+6+2+3] = (unsigned char) _mm256_extract_epi16(m2,4);
}
else if (REMINDER_ITERATIONS > 5)
	filt[row][col+2+3] = (unsigned char) _mm256_extract_epi16(m2,1);
/*
if (REMINDER_ITERATIONS > 17)
	filt[row][col+12+2+3] = (unsigned char) _mm256_extract_epi16(m2,7);

if (REMINDER_ITERATIONS > 23)
	filt[row][col+18+2+3] = (unsigned char) _mm256_extract_epi16(m2,10);

if (REMINDER_ITERATIONS > 29)
	filt[row][col+24+2+3] = (unsigned char) _mm256_extract_epi16(m2,13);
*/
/*
if (REMINDER_ITERATIONS == 31){

	int newPixel = 0;
	int col2=M-1;
	for (int rowOffset=-2; rowOffset<=2; rowOffset++) {
		for (int colOffset=-2; colOffset<=2; colOffset++) {

		   if ( ((row+rowOffset)<N) && ((col2+colOffset)<M) && ((row+rowOffset)>=0) && ((col2+colOffset)>=0) )
              newPixel += frame1[row+rowOffset][col2+colOffset] * gaussianMask[2 + rowOffset][2 + colOffset];

		      }
	        }
filt[row][M-1] = (unsigned char) (newPixel / 159);
}
*/
return 0;

}


//in this case, row=2 along row=0,1 are computed
//REMINDER_ITERATIONS<16
int loop_reminder_first_rows_low_reminder_values(unsigned char **frame1,unsigned char **filt,const unsigned int M, const unsigned int N, const unsigned int col,const unsigned int REMINDER_ITERATIONS,const unsigned int division_case,const __m256i c0,const __m256i c1,const __m256i c2,const __m256i c0_sh1,const __m256i c1_sh1,const __m256i c2_sh1,const __m256i c0_sh2,const __m256i c1_sh2,const __m256i c2_sh2, const __m256i f ){

register	__m256i r0,r1,r2,r3,r4,m0,m1,m2,m3,m4;


		//const __m256i f  = _mm256_set_epi16(52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759);


		 __m256i reminder_mask1,reminder_mask2;

if (REMINDER_ITERATIONS == 0){
	return 0; //no loop reminder is needed
}

reminder_mask1=_mm256_load_si256( (__m256i *) &reminder_msk1[REMINDER_ITERATIONS-1][0]);
reminder_mask2=_mm256_load_si256( (__m256i *) &reminder_msk2[REMINDER_ITERATIONS-1][0]);




	 //1st col iteration
	//load the 5 rows
	r0=_mm256_loadu_si256( (__m256i *) &frame1[0][col-2]);
	r1=_mm256_loadu_si256( (__m256i *) &frame1[1][col-2]);
	r2=_mm256_loadu_si256( (__m256i *) &frame1[2][col-2]);
	r3=_mm256_loadu_si256( (__m256i *) &frame1[3][col-2]);
	r4=_mm256_loadu_si256( (__m256i *) &frame1[4][col-2]);

	/*
	 * The above load operations load outside of the array bounds; these elements are filled with zeros just after
	 * Furthermore, I add two extra zeros in the end to compute col=N-2 and col=N-1. The last value of col is N-1, not N
	 */

	//AND r0-r4 with reminder_mask
	r0=_mm256_and_si256(r0,reminder_mask1);
	r1=_mm256_and_si256(r1,reminder_mask1);
	r2=_mm256_and_si256(r2,reminder_mask1);
	r3=_mm256_and_si256(r3,reminder_mask1);
	r4=_mm256_and_si256(r4,reminder_mask1);

	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c0);
	m1=_mm256_maddubs_epi16(r1,c1);
	m2=_mm256_maddubs_epi16(r2,c2);
	m3=_mm256_maddubs_epi16(r3,c1);
	m4=_mm256_maddubs_epi16(r4,c0);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m3);
	m0=_mm256_add_epi16(m0,m4);

	//----row=2
	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi
	m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m2=_mm256_add_epi16(m2,m4);

	//now division of m2/divisor follows
	m2=division(division_case,m2,f);


if (REMINDER_ITERATIONS > 12){
	filt[2][col] = (unsigned char) _mm256_extract_epi16(m2,0);
	filt[2][col+6] = (unsigned char) _mm256_extract_epi16(m2,3);
	filt[2][col+12] = (unsigned char) _mm256_extract_epi16(m2,6);
}
else if (REMINDER_ITERATIONS > 6){
	filt[2][col] = (unsigned char) _mm256_extract_epi16(m2,0);
	filt[2][col+6] = (unsigned char) _mm256_extract_epi16(m2,3);
}
else if (REMINDER_ITERATIONS > 0){
	filt[2][col] = (unsigned char) _mm256_extract_epi16(m2,0);
}


	//----row=0
	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c2);
	m1=_mm256_maddubs_epi16(r1,c1);
	m2=_mm256_maddubs_epi16(r2,c0);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m0=_mm256_add_epi16(m0,m2);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi
	m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m2=_mm256_add_epi16(m2,m4);

	//now division of m2/divisor follows
	m2=division(division_case,m2,f);



if (REMINDER_ITERATIONS > 12){
	filt[0][col] = (unsigned char) _mm256_extract_epi16(m2,0);
	filt[0][col+6] = (unsigned char) _mm256_extract_epi16(m2,3);
	filt[0][col+12] = (unsigned char) _mm256_extract_epi16(m2,6);
}
else if (REMINDER_ITERATIONS > 6){
	filt[0][col] = (unsigned char) _mm256_extract_epi16(m2,0);
	filt[0][col+6] = (unsigned char) _mm256_extract_epi16(m2,3);
}
else if (REMINDER_ITERATIONS > 0){
	filt[0][col] = (unsigned char) _mm256_extract_epi16(m2,0);
}


	//----row=1
	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c1);
	m1=_mm256_maddubs_epi16(r1,c2);
	m2=_mm256_maddubs_epi16(r2,c1);
	m3=_mm256_maddubs_epi16(r3,c0);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m3);

	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi
	m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m2=_mm256_add_epi16(m2,m4);

	//now division of m2/divisor follows
	m2=division(division_case,m2,f);


 if (REMINDER_ITERATIONS > 12){
	filt[1][col] = (unsigned char) _mm256_extract_epi16(m2,0);
	filt[1][col+6] = (unsigned char) _mm256_extract_epi16(m2,3);
	filt[1][col+12] = (unsigned char) _mm256_extract_epi16(m2,6);
}
else if (REMINDER_ITERATIONS > 6){
	filt[1][col] = (unsigned char) _mm256_extract_epi16(m2,0);
	filt[1][col+6] = (unsigned char) _mm256_extract_epi16(m2,3);
}
else if (REMINDER_ITERATIONS > 0){
	filt[1][col] = (unsigned char) _mm256_extract_epi16(m2,0);
}



if (REMINDER_ITERATIONS ==1)
	return 0;


    //2nd col iteration

	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c0_sh1);
	m1=_mm256_maddubs_epi16(r1,c1_sh1);
	m2=_mm256_maddubs_epi16(r2,c2_sh1);
	m3=_mm256_maddubs_epi16(r3,c1_sh1);
	m4=_mm256_maddubs_epi16(r4,c0_sh1);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m3);
	m0=_mm256_add_epi16(m0,m4);

    //--row=2
	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi
	m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m2=_mm256_add_epi16(m2,m4);

	//now division of m2/divisor follows
	m2=division(division_case,m2,f);


if (REMINDER_ITERATIONS > 13){
	filt[2][col+1] = (unsigned char) _mm256_extract_epi16(m2,0);
	filt[2][col+6+1] = (unsigned char) _mm256_extract_epi16(m2,3);
	filt[2][col+12+1] = (unsigned char) _mm256_extract_epi16(m2,6);
}
else if (REMINDER_ITERATIONS > 7){
	filt[2][col+1] = (unsigned char) _mm256_extract_epi16(m2,0);
	filt[2][col+6+1] = (unsigned char) _mm256_extract_epi16(m2,3);
}
else if (REMINDER_ITERATIONS > 1){
	filt[2][col+1] = (unsigned char) _mm256_extract_epi16(m2,0);
}



	   //--row=0
	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c2_sh1);
	m1=_mm256_maddubs_epi16(r1,c1_sh1);
	m2=_mm256_maddubs_epi16(r2,c0_sh1);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m0=_mm256_add_epi16(m0,m2);


		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi
		m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
		m2=_mm256_add_epi16(m2,m4);

		//now division of m2/divisor follows
		m2=division(division_case,m2,f);



if (REMINDER_ITERATIONS > 13){
		filt[0][col+1] = (unsigned char) _mm256_extract_epi16(m2,0);
		filt[0][col+6+1] = (unsigned char) _mm256_extract_epi16(m2,3);
		filt[0][col+12+1] = (unsigned char) _mm256_extract_epi16(m2,6);
	}
	else if (REMINDER_ITERATIONS > 7){
		filt[0][col+1] = (unsigned char) _mm256_extract_epi16(m2,0);
		filt[0][col+6+1] = (unsigned char) _mm256_extract_epi16(m2,3);
	}
	else if (REMINDER_ITERATIONS > 1){
		filt[0][col+1] = (unsigned char) _mm256_extract_epi16(m2,0);
	}

		   //--row=1
		//multiply with the mask
		m0=_mm256_maddubs_epi16(r0,c1_sh1);
		m1=_mm256_maddubs_epi16(r1,c2_sh1);
		m2=_mm256_maddubs_epi16(r2,c1_sh1);
		m3=_mm256_maddubs_epi16(r3,c0_sh1);

		//vertical add
		m0=_mm256_add_epi16(m0,m1);
		m0=_mm256_add_epi16(m0,m2);
		m0=_mm256_add_epi16(m0,m3);

			m1=_mm256_srli_si256(m0,2);
			m2=_mm256_add_epi16(m1,m0);

			m1=_mm256_srli_si256(m0,4);
			m2=_mm256_add_epi16(m1,m2);

			//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi
			m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
			m2=_mm256_add_epi16(m2,m4);

			//now division of m2/divisor follows
			m2=division(division_case,m2,f);



if (REMINDER_ITERATIONS > 13){
			filt[1][col+1] = (unsigned char) _mm256_extract_epi16(m2,0);
			filt[1][col+6+1] = (unsigned char) _mm256_extract_epi16(m2,3);
			filt[1][col+12+1] = (unsigned char) _mm256_extract_epi16(m2,6);
		}
		else if (REMINDER_ITERATIONS > 7){
			filt[1][col+1] = (unsigned char) _mm256_extract_epi16(m2,0);
			filt[1][col+6+1] = (unsigned char) _mm256_extract_epi16(m2,3);
		}
		else if (REMINDER_ITERATIONS > 1){
			filt[1][col+1] = (unsigned char) _mm256_extract_epi16(m2,0);
		}

if (REMINDER_ITERATIONS ==2)
	return 0;


     //3rd col iteration

	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c0_sh2);
	m1=_mm256_maddubs_epi16(r1,c1_sh2);
	m2=_mm256_maddubs_epi16(r2,c2_sh2);
	m3=_mm256_maddubs_epi16(r3,c1_sh2);
	m4=_mm256_maddubs_epi16(r4,c0_sh2);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m3);
	m0=_mm256_add_epi16(m0,m4);

    //---row=2
	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);
	m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

	m2=_mm256_add_epi16(m2,m4);

	//now division of m2/divisor follows
	m2=division(division_case,m2,f);


if (REMINDER_ITERATIONS > 14){
	filt[2][col+2] = (unsigned char) _mm256_extract_epi16(m2,1);
	filt[2][col+6+2] = (unsigned char) _mm256_extract_epi16(m2,4);
	filt[2][col+12+2] = (unsigned char) _mm256_extract_epi16(m2,7);
}
else if (REMINDER_ITERATIONS > 8){
	filt[2][col+2] = (unsigned char) _mm256_extract_epi16(m2,1);
	filt[2][col+6+2] = (unsigned char) _mm256_extract_epi16(m2,4);
}
else if (REMINDER_ITERATIONS > 2){
	filt[2][col+2] = (unsigned char) _mm256_extract_epi16(m2,1);
}

	   //---row=0
	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c2_sh2);
	m1=_mm256_maddubs_epi16(r1,c1_sh2);
	m2=_mm256_maddubs_epi16(r2,c0_sh2);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m0=_mm256_add_epi16(m0,m2);


		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);
		m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

		m2=_mm256_add_epi16(m2,m4);

		//now division of m2/divisor follows
		m2=division(division_case,m2,f);

		if (REMINDER_ITERATIONS > 14){
			filt[0][col+2] = (unsigned char) _mm256_extract_epi16(m2,1);
			filt[0][col+6+2] = (unsigned char) _mm256_extract_epi16(m2,4);
			filt[0][col+12+2] = (unsigned char) _mm256_extract_epi16(m2,7);
		}
		else if (REMINDER_ITERATIONS > 8){
			filt[0][col+2] = (unsigned char) _mm256_extract_epi16(m2,1);
			filt[0][col+6+2] = (unsigned char) _mm256_extract_epi16(m2,4);
		}
		else if (REMINDER_ITERATIONS > 2){
			filt[0][col+2] = (unsigned char) _mm256_extract_epi16(m2,1);
		}

		   //---row=1
		//multiply with the mask
		m0=_mm256_maddubs_epi16(r0,c1_sh2);
		m1=_mm256_maddubs_epi16(r1,c2_sh2);
		m2=_mm256_maddubs_epi16(r2,c1_sh2);
		m3=_mm256_maddubs_epi16(r3,c0_sh2);

		//vertical add
		m0=_mm256_add_epi16(m0,m1);
		m0=_mm256_add_epi16(m0,m2);
		m0=_mm256_add_epi16(m0,m3);

			m1=_mm256_srli_si256(m0,2);
			m2=_mm256_add_epi16(m1,m0);
			m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);

			m1=_mm256_srli_si256(m0,4);
			m2=_mm256_add_epi16(m1,m2);

			//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

			m2=_mm256_add_epi16(m2,m4);

			//now division of m2/divisor follows
			m2=division(division_case,m2,f);

			if (REMINDER_ITERATIONS > 14){
				filt[1][col+2] = (unsigned char) _mm256_extract_epi16(m2,1);
				filt[1][col+6+2] = (unsigned char) _mm256_extract_epi16(m2,4);
				filt[1][col+12+2] = (unsigned char) _mm256_extract_epi16(m2,7);
			}
			else if (REMINDER_ITERATIONS > 8){
				filt[1][col+2] = (unsigned char) _mm256_extract_epi16(m2,1);
				filt[1][col+6+2] = (unsigned char) _mm256_extract_epi16(m2,4);
			}
			else if (REMINDER_ITERATIONS > 2){
				filt[1][col+2] = (unsigned char) _mm256_extract_epi16(m2,1);
			}

if (REMINDER_ITERATIONS ==3){
	return 0;
}

	 //4th col iteration
	//load the 5 rows
	r0=_mm256_loadu_si256( (__m256i *) &frame1[0][col-2+3]);
	r1=_mm256_loadu_si256( (__m256i *) &frame1[1][col-2+3]);
	r2=_mm256_loadu_si256( (__m256i *) &frame1[2][col-2+3]);
	r3=_mm256_loadu_si256( (__m256i *) &frame1[3][col-2+3]);
	r4=_mm256_loadu_si256( (__m256i *) &frame1[4][col-2+3]);

	/*
	 * The above load operations load outside of the array bounds; these elements are filled with zeros just after
	 * Furthermore, I add two extra zeros in the end to compute col=N-2 and col=N-1. The last value of col is N-1, not N
	 */

	//AND r0-r4 with reminder_mask
	r0=_mm256_and_si256(r0,reminder_mask2);
	r1=_mm256_and_si256(r1,reminder_mask2);
	r2=_mm256_and_si256(r2,reminder_mask2);
	r3=_mm256_and_si256(r3,reminder_mask2);
	r4=_mm256_and_si256(r4,reminder_mask2);

	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c0);
	m1=_mm256_maddubs_epi16(r1,c1);
	m2=_mm256_maddubs_epi16(r2,c2);
	m3=_mm256_maddubs_epi16(r3,c1);
	m4=_mm256_maddubs_epi16(r4,c0);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m3);
	m0=_mm256_add_epi16(m0,m4);

	//----row=2
	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi
	m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m2=_mm256_add_epi16(m2,m4);

	//now division of m2/divisor follows
	m2=division(division_case,m2,f);


if (REMINDER_ITERATIONS > 9){
	filt[2][col+3] = (unsigned char) _mm256_extract_epi16(m2,0);
	filt[2][col+6+3] = (unsigned char) _mm256_extract_epi16(m2,3);
}
else if (REMINDER_ITERATIONS > 3){
	filt[2][col+3] = (unsigned char) _mm256_extract_epi16(m2,0);
}


	//----row=0
	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c2);
	m1=_mm256_maddubs_epi16(r1,c1);
	m2=_mm256_maddubs_epi16(r2,c0);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m0=_mm256_add_epi16(m0,m2);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi
	m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m2=_mm256_add_epi16(m2,m4);

	//now division of m2/divisor follows
	m2=division(division_case,m2,f);

   if (REMINDER_ITERATIONS > 9){
		filt[0][col+3] = (unsigned char) _mm256_extract_epi16(m2,0);
		filt[0][col+6+3] = (unsigned char) _mm256_extract_epi16(m2,3);
	}
	else if (REMINDER_ITERATIONS > 3){
		filt[0][col+3] = (unsigned char) _mm256_extract_epi16(m2,0);
	}

	//----row=1
	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c1);
	m1=_mm256_maddubs_epi16(r1,c2);
	m2=_mm256_maddubs_epi16(r2,c1);
	m3=_mm256_maddubs_epi16(r3,c0);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m3);

	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi
	m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m2=_mm256_add_epi16(m2,m4);

	//now division of m2/divisor follows
	m2=division(division_case,m2,f);

   if (REMINDER_ITERATIONS > 9){
		filt[1][col+3] = (unsigned char) _mm256_extract_epi16(m2,0);
		filt[1][col+6+3] = (unsigned char) _mm256_extract_epi16(m2,3);
	}
	else if (REMINDER_ITERATIONS > 3){
		filt[1][col+3] = (unsigned char) _mm256_extract_epi16(m2,0);
	}

if (REMINDER_ITERATIONS ==4)
	return 0;


   //5th col iteration

	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c0_sh1);
	m1=_mm256_maddubs_epi16(r1,c1_sh1);
	m2=_mm256_maddubs_epi16(r2,c2_sh1);
	m3=_mm256_maddubs_epi16(r3,c1_sh1);
	m4=_mm256_maddubs_epi16(r4,c0_sh1);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m3);
	m0=_mm256_add_epi16(m0,m4);

   //----row=2
	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi
	m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m2=_mm256_add_epi16(m2,m4);

	//now division of m2/divisor follows
	m2=division(division_case,m2,f);



if (REMINDER_ITERATIONS > 10){
	filt[2][col+1+3] = (unsigned char) _mm256_extract_epi16(m2,0);
	filt[2][col+6+1+3] = (unsigned char) _mm256_extract_epi16(m2,3);
}
else if (REMINDER_ITERATIONS > 4){
	filt[2][col+1+3] = (unsigned char) _mm256_extract_epi16(m2,0);
}
	   //----row=0
	//multiply with the mask

	m0=_mm256_maddubs_epi16(r0,c2_sh1);
	m1=_mm256_maddubs_epi16(r1,c1_sh1);
	m2=_mm256_maddubs_epi16(r2,c0_sh1);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m0=_mm256_add_epi16(m0,m2);


		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi
		m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
		m2=_mm256_add_epi16(m2,m4);

		//now division of m2/divisor follows
		m2=division(division_case,m2,f);


       if (REMINDER_ITERATIONS > 10){
			filt[0][col+1+3] = (unsigned char) _mm256_extract_epi16(m2,0);
			filt[0][col+6+1+3] = (unsigned char) _mm256_extract_epi16(m2,3);
		}
		else if (REMINDER_ITERATIONS > 4){
			filt[0][col+1+3] = (unsigned char) _mm256_extract_epi16(m2,0);
		}

		   //----row=1
		//multiply with the mask
		m0=_mm256_maddubs_epi16(r0,c1_sh1);
		m1=_mm256_maddubs_epi16(r1,c2_sh1);
		m2=_mm256_maddubs_epi16(r2,c1_sh1);
		m3=_mm256_maddubs_epi16(r3,c0_sh1);

		//vertical add
		m0=_mm256_add_epi16(m0,m1);
		m0=_mm256_add_epi16(m0,m2);
		m0=_mm256_add_epi16(m0,m3);

			m1=_mm256_srli_si256(m0,2);
			m2=_mm256_add_epi16(m1,m0);

			m1=_mm256_srli_si256(m0,4);
			m2=_mm256_add_epi16(m1,m2);

			//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi
			m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
			m2=_mm256_add_epi16(m2,m4);

			//now division of m2/divisor follows
			m2=division(division_case,m2,f);


			if (REMINDER_ITERATIONS > 10){
				filt[1][col+1+3] = (unsigned char) _mm256_extract_epi16(m2,0);
				filt[1][col+6+1+3] = (unsigned char) _mm256_extract_epi16(m2,3);
			}
			else if (REMINDER_ITERATIONS > 4){
				filt[1][col+1+3] = (unsigned char) _mm256_extract_epi16(m2,0);
			}

if (REMINDER_ITERATIONS ==5)
	return 0;


    //6th col iteration

	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c0_sh2);
	m1=_mm256_maddubs_epi16(r1,c1_sh2);
	m2=_mm256_maddubs_epi16(r2,c2_sh2);
	m3=_mm256_maddubs_epi16(r3,c1_sh2);
	m4=_mm256_maddubs_epi16(r4,c0_sh2);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m3);
	m0=_mm256_add_epi16(m0,m4);

   //----row=2
	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);
	m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

	m2=_mm256_add_epi16(m2,m4);

	//now division of m2/divisor follows
	m2=division(division_case,m2,f);



if (REMINDER_ITERATIONS > 11){
	filt[2][col+2+3] = (unsigned char) _mm256_extract_epi16(m2,1);
	filt[2][col+6+2+3] = (unsigned char) _mm256_extract_epi16(m2,4);
}
else if (REMINDER_ITERATIONS > 5){
	filt[2][col+2+3] = (unsigned char) _mm256_extract_epi16(m2,1);
}

	   //----row=0
	//multiply with the mask

	m0=_mm256_maddubs_epi16(r0,c2_sh2);
	m1=_mm256_maddubs_epi16(r1,c1_sh2);
	m2=_mm256_maddubs_epi16(r2,c0_sh2);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m0=_mm256_add_epi16(m0,m2);


		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);
		m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

		m2=_mm256_add_epi16(m2,m4);

		//now division of m2/divisor follows
		m2=division(division_case,m2,f);

       if (REMINDER_ITERATIONS > 11){
			filt[0][col+2+3] = (unsigned char) _mm256_extract_epi16(m2,1);
			filt[0][col+6+2+3] = (unsigned char) _mm256_extract_epi16(m2,4);
		}
		else if (REMINDER_ITERATIONS > 5){
			filt[0][col+2+3] = (unsigned char) _mm256_extract_epi16(m2,1);
		}

		   //----row=1
		//multiply with the mask
		m0=_mm256_maddubs_epi16(r0,c1_sh2);
		m1=_mm256_maddubs_epi16(r1,c2_sh2);
		m2=_mm256_maddubs_epi16(r2,c1_sh2);
		m3=_mm256_maddubs_epi16(r3,c0_sh2);

		//vertical add
		m0=_mm256_add_epi16(m0,m1);
		m0=_mm256_add_epi16(m0,m2);
		m0=_mm256_add_epi16(m0,m3);

			m1=_mm256_srli_si256(m0,2);
			m2=_mm256_add_epi16(m1,m0);
			m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);

			m1=_mm256_srli_si256(m0,4);
			m2=_mm256_add_epi16(m1,m2);

			//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

			m2=_mm256_add_epi16(m2,m4);

			//now division of m2/divisor follows
			m2=division(division_case,m2,f);

        if (REMINDER_ITERATIONS > 11){
				filt[1][col+2+3] = (unsigned char) _mm256_extract_epi16(m2,1);
				filt[1][col+6+2+3] = (unsigned char) _mm256_extract_epi16(m2,4);
			}
			else if (REMINDER_ITERATIONS > 5){
				filt[1][col+2+3] = (unsigned char) _mm256_extract_epi16(m2,1);
			}


	return 0;
}


//in this case, row=N-3 along row=N-2,row=N-1 are computed
//m0_row0 is for N-2
//m0_row1 is for N-1
//REMINDER_ITERATIONS<16 only
int loop_reminder_last_rows_low_reminder_values(unsigned char **frame1,unsigned char **filt,const unsigned int M, const unsigned int N, const unsigned int col,const unsigned int REMINDER_ITERATIONS,const unsigned int division_case,const __m256i c0,const __m256i c1,const __m256i c2,const __m256i c0_sh1,const __m256i c1_sh1,const __m256i c2_sh1,const __m256i c0_sh2,const __m256i c1_sh2,const __m256i c2_sh2, const __m256i f ){

register	__m256i r0,r1,r2,r3,r4,m0,m1,m2,m3,m4;

//const __m256i f  = _mm256_set_epi16(52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759);
 __m256i reminder_mask1,reminder_mask2;



if (REMINDER_ITERATIONS == 0){
	return 0; //no loop reminder is needed
}

reminder_mask1=_mm256_load_si256( (__m256i *) &reminder_msk1[REMINDER_ITERATIONS-1][0]);
reminder_mask2=_mm256_load_si256( (__m256i *) &reminder_msk2[REMINDER_ITERATIONS-1][0]);




	 //1st col iteration
	//load the 5 rows
	r0=_mm256_loadu_si256( (__m256i *) &frame1[N-5][col-2]);
	r1=_mm256_loadu_si256( (__m256i *) &frame1[N-4][col-2]);
	r2=_mm256_loadu_si256( (__m256i *) &frame1[N-3][col-2]);
	r3=_mm256_loadu_si256( (__m256i *) &frame1[N-2][col-2]);
	r4=_mm256_loadu_si256( (__m256i *) &frame1[N-1][col-2]);

	/*
	 * The above load operations load outside of the array bounds; these elements are filled with zeros just after
	 * Furthermore, I add two extra zeros in the end to compute col=N-2 and col=N-1. The last value of col is N-1, not N
	 */

	//AND r0-r4 with reminder_mask
	r0=_mm256_and_si256(r0,reminder_mask1);
	r1=_mm256_and_si256(r1,reminder_mask1);
	r2=_mm256_and_si256(r2,reminder_mask1);
	r3=_mm256_and_si256(r3,reminder_mask1);
	r4=_mm256_and_si256(r4,reminder_mask1);

	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c0);
	m1=_mm256_maddubs_epi16(r1,c1);
	m2=_mm256_maddubs_epi16(r2,c2);
	m3=_mm256_maddubs_epi16(r3,c1);
	m4=_mm256_maddubs_epi16(r4,c0);

	//vertical add
	m4=_mm256_add_epi16(m4,m3);
	m4=_mm256_add_epi16(m4,m2);
	m4=_mm256_add_epi16(m4,m1);
	m0=_mm256_add_epi16(m4,m0);

	//----row=2
	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi
	m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m2=_mm256_add_epi16(m2,m4);

	//now division of r2/159 follows
	m2=division(division_case,m2,f);


if (REMINDER_ITERATIONS > 12){
	filt[N-3][col] = (unsigned char) _mm256_extract_epi16(m2,0);
	filt[N-3][col+6] = (unsigned char) _mm256_extract_epi16(m2,3);
	filt[N-3][col+12] = (unsigned char) _mm256_extract_epi16(m2,6);
}
else if (REMINDER_ITERATIONS > 6){
	filt[N-3][col] = (unsigned char) _mm256_extract_epi16(m2,0);
	filt[N-3][col+6] = (unsigned char) _mm256_extract_epi16(m2,3);
}
else if (REMINDER_ITERATIONS > 0){
	filt[N-3][col] = (unsigned char) _mm256_extract_epi16(m2,0);
}

	//----row=0
	//multiply with the mask
	m1=_mm256_maddubs_epi16(r1,c0);
	m2=_mm256_maddubs_epi16(r2,c1);
	m3=_mm256_maddubs_epi16(r3,c2);
	m4=_mm256_maddubs_epi16(r4,c1);

	//vertical add
	m4=_mm256_add_epi16(m4,m3);
	m4=_mm256_add_epi16(m4,m2);
	m0=_mm256_add_epi16(m4,m1);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi
	m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m2=_mm256_add_epi16(m2,m4);

	//now division of r2/159 follows
	m2=division(division_case,m2,f);

	if (REMINDER_ITERATIONS > 12){
		filt[N-2][col] = (unsigned char) _mm256_extract_epi16(m2,0);
		filt[N-2][col+6] = (unsigned char) _mm256_extract_epi16(m2,3);
		filt[N-2][col+12] = (unsigned char) _mm256_extract_epi16(m2,6);
	}
	else if (REMINDER_ITERATIONS > 6){
		filt[N-2][col] = (unsigned char) _mm256_extract_epi16(m2,0);
		filt[N-2][col+6] = (unsigned char) _mm256_extract_epi16(m2,3);
	}
	else if (REMINDER_ITERATIONS > 0){
		filt[N-2][col] = (unsigned char) _mm256_extract_epi16(m2,0);
	}

	//----row=1
	//multiply with the mask
	m2=_mm256_maddubs_epi16(r2,c0);
	m3=_mm256_maddubs_epi16(r3,c1);
	m4=_mm256_maddubs_epi16(r4,c2);


	//vertical add
	m4=_mm256_add_epi16(m4,m3);
	m0=_mm256_add_epi16(m4,m2);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi
	m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m2=_mm256_add_epi16(m2,m4);

	//now division of r2/159 follows
	m2=division(division_case,m2,f);

	if (REMINDER_ITERATIONS > 12){
		filt[N-1][col] = (unsigned char) _mm256_extract_epi16(m2,0);
		filt[N-1][col+6] = (unsigned char) _mm256_extract_epi16(m2,3);
		filt[N-1][col+12] = (unsigned char) _mm256_extract_epi16(m2,6);
	}
	else if (REMINDER_ITERATIONS > 6){
		filt[N-1][col] = (unsigned char) _mm256_extract_epi16(m2,0);
		filt[N-1][col+6] = (unsigned char) _mm256_extract_epi16(m2,3);
	}
	else if (REMINDER_ITERATIONS > 0){
		filt[N-1][col] = (unsigned char) _mm256_extract_epi16(m2,0);
	}

if (REMINDER_ITERATIONS ==1)
	return 0;


    //2nd col iteration

	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c0_sh1);
	m1=_mm256_maddubs_epi16(r1,c1_sh1);
	m2=_mm256_maddubs_epi16(r2,c2_sh1);
	m3=_mm256_maddubs_epi16(r3,c1_sh1);
	m4=_mm256_maddubs_epi16(r4,c0_sh1);

	//vertical add
	m4=_mm256_add_epi16(m4,m3);
	m4=_mm256_add_epi16(m4,m2);
	m4=_mm256_add_epi16(m4,m1);
	m0=_mm256_add_epi16(m4,m0);

    //--row=2
	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi
	m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m2=_mm256_add_epi16(m2,m4);

	//now division of r2/159 follows
	m2=division(division_case,m2,f);




if (REMINDER_ITERATIONS > 13){
	filt[N-3][col+1] = (unsigned char) _mm256_extract_epi16(m2,0);
	filt[N-3][col+6+1] = (unsigned char) _mm256_extract_epi16(m2,3);
	filt[N-3][col+12+1] = (unsigned char) _mm256_extract_epi16(m2,6);
}
else if (REMINDER_ITERATIONS > 7){
	filt[N-3][col+1] = (unsigned char) _mm256_extract_epi16(m2,0);
	filt[N-3][col+6+1] = (unsigned char) _mm256_extract_epi16(m2,3);
}
else if (REMINDER_ITERATIONS > 1){
	filt[N-3][col+1] = (unsigned char) _mm256_extract_epi16(m2,0);
}

	   //--row=0
	//multiply with the mask
	m1=_mm256_maddubs_epi16(r1,c0_sh1);
	m2=_mm256_maddubs_epi16(r2,c1_sh1);
	m3=_mm256_maddubs_epi16(r3,c2_sh1);
	m4=_mm256_maddubs_epi16(r4,c1_sh1);


	//vertical add
	m4=_mm256_add_epi16(m4,m3);
	m4=_mm256_add_epi16(m4,m2);
	m0=_mm256_add_epi16(m4,m1);


		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi
		m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m2=division(division_case,m2,f);


		if (REMINDER_ITERATIONS > 13){
			filt[N-2][col+1] = (unsigned char) _mm256_extract_epi16(m2,0);
			filt[N-2][col+6+1] = (unsigned char) _mm256_extract_epi16(m2,3);
			filt[N-2][col+12+1] = (unsigned char) _mm256_extract_epi16(m2,6);
		}
		else if (REMINDER_ITERATIONS > 7){
			filt[N-2][col+1] = (unsigned char) _mm256_extract_epi16(m2,0);
			filt[N-2][col+6+1] = (unsigned char) _mm256_extract_epi16(m2,3);
		}
		else if (REMINDER_ITERATIONS > 1){
			filt[N-2][col+1] = (unsigned char) _mm256_extract_epi16(m2,0);
		}

		   //--row=1
		//multiply with the mask
		m2=_mm256_maddubs_epi16(r2,c0_sh1);
		m3=_mm256_maddubs_epi16(r3,c1_sh1);
		m4=_mm256_maddubs_epi16(r4,c2_sh1);


		//vertical add
		m4=_mm256_add_epi16(m4,m3);
		m0=_mm256_add_epi16(m4,m2);


			m1=_mm256_srli_si256(m0,2);
			m2=_mm256_add_epi16(m1,m0);

			m1=_mm256_srli_si256(m0,4);
			m2=_mm256_add_epi16(m1,m2);

			//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi
			m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
			m2=_mm256_add_epi16(m2,m4);

			//now division of r2/159 follows
			m2=division(division_case,m2,f);


			if (REMINDER_ITERATIONS > 13){
				filt[N-1][col+1] = (unsigned char) _mm256_extract_epi16(m2,0);
				filt[N-1][col+6+1] = (unsigned char) _mm256_extract_epi16(m2,3);
				filt[N-1][col+12+1] = (unsigned char) _mm256_extract_epi16(m2,6);
			}
			else if (REMINDER_ITERATIONS > 7){
				filt[N-1][col+1] = (unsigned char) _mm256_extract_epi16(m2,0);
				filt[N-1][col+6+1] = (unsigned char) _mm256_extract_epi16(m2,3);
			}
			else if (REMINDER_ITERATIONS > 1){
				filt[N-1][col+1] = (unsigned char) _mm256_extract_epi16(m2,0);
			}

if (REMINDER_ITERATIONS ==2)
	return 0;


     //3rd col iteration

	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c0_sh2);
	m1=_mm256_maddubs_epi16(r1,c1_sh2);
	m2=_mm256_maddubs_epi16(r2,c2_sh2);
	m3=_mm256_maddubs_epi16(r3,c1_sh2);
	m4=_mm256_maddubs_epi16(r4,c0_sh2);

	//vertical add
	m4=_mm256_add_epi16(m4,m3);
	m4=_mm256_add_epi16(m4,m2);
	m4=_mm256_add_epi16(m4,m1);
	m0=_mm256_add_epi16(m4,m0);

    //---row=2
	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);
	m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

	m2=_mm256_add_epi16(m2,m4);

	//now division of r2/159 follows
	m2=division(division_case,m2,f);



if (REMINDER_ITERATIONS > 14){
	filt[N-3][col+2] = (unsigned char) _mm256_extract_epi16(m2,1);
	filt[N-3][col+6+2] = (unsigned char) _mm256_extract_epi16(m2,4);
	filt[N-3][col+12+2] = (unsigned char) _mm256_extract_epi16(m2,7);
}
else if (REMINDER_ITERATIONS > 8){
	filt[N-3][col+2] = (unsigned char) _mm256_extract_epi16(m2,1);
	filt[N-3][col+6+2] = (unsigned char) _mm256_extract_epi16(m2,4);
}
else if (REMINDER_ITERATIONS > 2){
	filt[N-3][col+2] = (unsigned char) _mm256_extract_epi16(m2,1);
}

	   //---row=0
	//multiply with the mask
	m1=_mm256_maddubs_epi16(r1,c0_sh2);
	m2=_mm256_maddubs_epi16(r2,c1_sh2);
	m3=_mm256_maddubs_epi16(r3,c2_sh2);
	m4=_mm256_maddubs_epi16(r4,c1_sh2);


	//vertical add
	m4=_mm256_add_epi16(m4,m3);
	m4=_mm256_add_epi16(m4,m2);
	m0=_mm256_add_epi16(m4,m1);


		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);
		m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m2=division(division_case,m2,f);

		if (REMINDER_ITERATIONS > 14){
			filt[N-2][col+2] = (unsigned char) _mm256_extract_epi16(m2,1);
			filt[N-2][col+6+2] = (unsigned char) _mm256_extract_epi16(m2,4);
			filt[N-2][col+12+2] = (unsigned char) _mm256_extract_epi16(m2,7);
		}
		else if (REMINDER_ITERATIONS > 8){
			filt[N-2][col+2] = (unsigned char) _mm256_extract_epi16(m2,1);
			filt[N-2][col+6+2] = (unsigned char) _mm256_extract_epi16(m2,4);
		}
		else if (REMINDER_ITERATIONS > 2){
			filt[N-2][col+2] = (unsigned char) _mm256_extract_epi16(m2,1);
		}

		   //---row=1
		//multiply with the mask
		m2=_mm256_maddubs_epi16(r2,c0_sh2);
		m3=_mm256_maddubs_epi16(r3,c1_sh2);
		m4=_mm256_maddubs_epi16(r4,c2_sh2);


		//vertical add
		m4=_mm256_add_epi16(m4,m3);
		m0=_mm256_add_epi16(m4,m2);


			m1=_mm256_srli_si256(m0,2);
			m2=_mm256_add_epi16(m1,m0);
			m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);

			m1=_mm256_srli_si256(m0,4);
			m2=_mm256_add_epi16(m1,m2);

			//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

			m2=_mm256_add_epi16(m2,m4);

			//now division of r2/159 follows
			m2=division(division_case,m2,f);

			if (REMINDER_ITERATIONS > 14){
				filt[N-1][col+2] = (unsigned char) _mm256_extract_epi16(m2,1);
				filt[N-1][col+6+2] = (unsigned char) _mm256_extract_epi16(m2,4);
				filt[N-1][col+12+2] = (unsigned char) _mm256_extract_epi16(m2,7);
			}
			else if (REMINDER_ITERATIONS > 8){
				filt[N-1][col+2] = (unsigned char) _mm256_extract_epi16(m2,1);
				filt[N-1][col+6+2] = (unsigned char) _mm256_extract_epi16(m2,4);
			}
			else if (REMINDER_ITERATIONS > 2){
				filt[N-1][col+2] = (unsigned char) _mm256_extract_epi16(m2,1);
			}

if (REMINDER_ITERATIONS ==3){
	return 0;
}

	 //4th col iteration
	//load the 5 rows
	r0=_mm256_loadu_si256( (__m256i *) &frame1[N-5][col-2+3]);
	r1=_mm256_loadu_si256( (__m256i *) &frame1[N-4][col-2+3]);
	r2=_mm256_loadu_si256( (__m256i *) &frame1[N-3][col-2+3]);
	r3=_mm256_loadu_si256( (__m256i *) &frame1[N-2][col-2+3]);
	r4=_mm256_loadu_si256( (__m256i *) &frame1[N-1][col-2+3]);

	/*
	 * The above load operations load outside of the array bounds; these elements are filled with zeros just after
	 * Furthermore, I add two extra zeros in the end to compute col=N-2 and col=N-1. The last value of col is N-1, not N
	 */

	//AND r0-r4 with reminder_mask
	r0=_mm256_and_si256(r0,reminder_mask2);
	r1=_mm256_and_si256(r1,reminder_mask2);
	r2=_mm256_and_si256(r2,reminder_mask2);
	r3=_mm256_and_si256(r3,reminder_mask2);
	r4=_mm256_and_si256(r4,reminder_mask2);

	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c0);
	m1=_mm256_maddubs_epi16(r1,c1);
	m2=_mm256_maddubs_epi16(r2,c2);
	m3=_mm256_maddubs_epi16(r3,c1);
	m4=_mm256_maddubs_epi16(r4,c0);

	//vertical add
	m4=_mm256_add_epi16(m4,m3);
	m4=_mm256_add_epi16(m4,m2);
	m4=_mm256_add_epi16(m4,m1);
	m0=_mm256_add_epi16(m4,m0);

	//----row=2
	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi
	m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m2=_mm256_add_epi16(m2,m4);

	//now division of r2/159 follows
	m2=division(division_case,m2,f);



if (REMINDER_ITERATIONS > 15){
	filt[N-3][col+3] = (unsigned char) _mm256_extract_epi16(m2,0);
	filt[N-3][col+6+3] = (unsigned char) _mm256_extract_epi16(m2,3);
	filt[N-3][col+12+3] = (unsigned char) _mm256_extract_epi16(m2,6);
}
else if (REMINDER_ITERATIONS > 9){
	filt[N-3][col+3] = (unsigned char) _mm256_extract_epi16(m2,0);
	filt[N-3][col+6+3] = (unsigned char) _mm256_extract_epi16(m2,3);
}
else if (REMINDER_ITERATIONS > 3){
	filt[N-3][col+3] = (unsigned char) _mm256_extract_epi16(m2,0);
}

	//----row=0
	//multiply with the mask
	m1=_mm256_maddubs_epi16(r1,c0);
	m2=_mm256_maddubs_epi16(r2,c1);
	m3=_mm256_maddubs_epi16(r3,c2);
	m4=_mm256_maddubs_epi16(r4,c1);


	//vertical add
	m4=_mm256_add_epi16(m4,m3);
	m4=_mm256_add_epi16(m4,m2);
	m0=_mm256_add_epi16(m4,m1);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi
	m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m2=_mm256_add_epi16(m2,m4);

	//now division of r2/159 follows
	m2=division(division_case,m2,f);

	if (REMINDER_ITERATIONS > 15){
		filt[N-2][col+3] = (unsigned char) _mm256_extract_epi16(m2,0);
		filt[N-2][col+6+3] = (unsigned char) _mm256_extract_epi16(m2,3);
		filt[N-2][col+12+3] = (unsigned char) _mm256_extract_epi16(m2,6);
	}
	else if (REMINDER_ITERATIONS > 9){
		filt[N-2][col+3] = (unsigned char) _mm256_extract_epi16(m2,0);
		filt[N-2][col+6+3] = (unsigned char) _mm256_extract_epi16(m2,3);
	}
	else if (REMINDER_ITERATIONS > 3){
		filt[N-2][col+3] = (unsigned char) _mm256_extract_epi16(m2,0);
	}

	//----row=1
	//multiply with the mask
	m2=_mm256_maddubs_epi16(r2,c0);
	m3=_mm256_maddubs_epi16(r3,c1);
	m4=_mm256_maddubs_epi16(r4,c2);


	//vertical add
	m4=_mm256_add_epi16(m4,m3);
	m0=_mm256_add_epi16(m4,m2);

	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi
	m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m2=_mm256_add_epi16(m2,m4);

	//now division of r2/159 follows
	m2=division(division_case,m2,f);

	if (REMINDER_ITERATIONS > 15){
		filt[N-1][col+3] = (unsigned char) _mm256_extract_epi16(m2,0);
		filt[N-1][col+6+3] = (unsigned char) _mm256_extract_epi16(m2,3);
		filt[N-1][col+12+3] = (unsigned char) _mm256_extract_epi16(m2,6);
	}
	else if (REMINDER_ITERATIONS > 9){
		filt[N-1][col+3] = (unsigned char) _mm256_extract_epi16(m2,0);
		filt[N-1][col+6+3] = (unsigned char) _mm256_extract_epi16(m2,3);
	}
	else if (REMINDER_ITERATIONS > 3){
		filt[N-1][col+3] = (unsigned char) _mm256_extract_epi16(m2,0);
	}

if (REMINDER_ITERATIONS ==4){
	return 0;
}

   //5th col iteration

	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c0_sh1);
	m1=_mm256_maddubs_epi16(r1,c1_sh1);
	m2=_mm256_maddubs_epi16(r2,c2_sh1);
	m3=_mm256_maddubs_epi16(r3,c1_sh1);
	m4=_mm256_maddubs_epi16(r4,c0_sh1);

	//vertical add
	m4=_mm256_add_epi16(m4,m3);
	m4=_mm256_add_epi16(m4,m2);
	m4=_mm256_add_epi16(m4,m1);
	m0=_mm256_add_epi16(m4,m0);

   //----row=2
	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi
	m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m2=_mm256_add_epi16(m2,m4);

	//now division of r2/159 follows
	m2=division(division_case,m2,f);



if (REMINDER_ITERATIONS > 10){
	filt[N-3][col+1+3] = (unsigned char) _mm256_extract_epi16(m2,0);
	filt[N-3][col+6+1+3] = (unsigned char) _mm256_extract_epi16(m2,3);
}
else if (REMINDER_ITERATIONS > 4){
	filt[N-3][col+1+3] = (unsigned char) _mm256_extract_epi16(m2,0);
}

	   //----row=0
	//multiply with the mask
	m1=_mm256_maddubs_epi16(r1,c0_sh1);
	m2=_mm256_maddubs_epi16(r2,c1_sh1);
	m3=_mm256_maddubs_epi16(r3,c2_sh1);
	m4=_mm256_maddubs_epi16(r4,c1_sh1);


	//vertical add
	m4=_mm256_add_epi16(m4,m3);
	m4=_mm256_add_epi16(m4,m2);
	m0=_mm256_add_epi16(m4,m1);


		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi
		m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m2=division(division_case,m2,f);


		if (REMINDER_ITERATIONS > 10){
			filt[N-2][col+1+3] = (unsigned char) _mm256_extract_epi16(m2,0);
			filt[N-2][col+6+1+3] = (unsigned char) _mm256_extract_epi16(m2,3);
		}
		else if (REMINDER_ITERATIONS > 4){
			filt[N-2][col+1+3] = (unsigned char) _mm256_extract_epi16(m2,0);
		}

		   //----row=1
		//multiply with the mask
		m2=_mm256_maddubs_epi16(r2,c0_sh1);
		m3=_mm256_maddubs_epi16(r3,c1_sh1);
		m4=_mm256_maddubs_epi16(r4,c2_sh1);


		//vertical add
		m4=_mm256_add_epi16(m4,m3);
		m0=_mm256_add_epi16(m4,m2);


			m1=_mm256_srli_si256(m0,2);
			m2=_mm256_add_epi16(m1,m0);

			m1=_mm256_srli_si256(m0,4);
			m2=_mm256_add_epi16(m1,m2);

			//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi
			m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
			m2=_mm256_add_epi16(m2,m4);

			//now division of r2/159 follows
			m2=division(division_case,m2,f);


			if (REMINDER_ITERATIONS > 10){
				filt[N-1][col+1+3] = (unsigned char) _mm256_extract_epi16(m2,0);
				filt[N-1][col+6+1+3] = (unsigned char) _mm256_extract_epi16(m2,3);
			}
			else if (REMINDER_ITERATIONS > 4){
				filt[N-1][col+1+3] = (unsigned char) _mm256_extract_epi16(m2,0);
			}

if (REMINDER_ITERATIONS ==5){
	return 0;
}

    //6th col iteration

	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c0_sh2);
	m1=_mm256_maddubs_epi16(r1,c1_sh2);
	m2=_mm256_maddubs_epi16(r2,c2_sh2);
	m3=_mm256_maddubs_epi16(r3,c1_sh2);
	m4=_mm256_maddubs_epi16(r4,c0_sh2);

	//vertical add
	m4=_mm256_add_epi16(m4,m3);
	m4=_mm256_add_epi16(m4,m2);
	m4=_mm256_add_epi16(m4,m1);
	m0=_mm256_add_epi16(m4,m0);

   //----row=2
	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);
	m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

	m2=_mm256_add_epi16(m2,m4);

	//now division of r2/159 follows
	m2=division(division_case,m2,f);


if (REMINDER_ITERATIONS > 11){
	filt[N-3][col+2+3] = (unsigned char) _mm256_extract_epi16(m2,1);
	filt[N-3][col+6+2+3] = (unsigned char) _mm256_extract_epi16(m2,4);
}
else if (REMINDER_ITERATIONS > 5){
	filt[N-3][col+2+3] = (unsigned char) _mm256_extract_epi16(m2,1);
}



	   //----row=0
	//multiply with the mask
	m1=_mm256_maddubs_epi16(r1,c0_sh2);
	m2=_mm256_maddubs_epi16(r2,c1_sh2);
	m3=_mm256_maddubs_epi16(r3,c2_sh2);
	m4=_mm256_maddubs_epi16(r4,c1_sh2);


	//vertical add
	m4=_mm256_add_epi16(m4,m3);
	m4=_mm256_add_epi16(m4,m2);
	m0=_mm256_add_epi16(m4,m1);


		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);
		m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m2=division(division_case,m2,f);

		if (REMINDER_ITERATIONS > 11){
			filt[N-2][col+2+3] = (unsigned char) _mm256_extract_epi16(m2,1);
			filt[N-2][col+6+2+3] = (unsigned char) _mm256_extract_epi16(m2,4);
		}
		else if (REMINDER_ITERATIONS > 5){
			filt[N-2][col+2+3] = (unsigned char) _mm256_extract_epi16(m2,1);
		}



		   //----row=1
		//multiply with the mask
		m2=_mm256_maddubs_epi16(r2,c0_sh2);
		m3=_mm256_maddubs_epi16(r3,c1_sh2);
		m4=_mm256_maddubs_epi16(r4,c2_sh2);


		//vertical add
		m4=_mm256_add_epi16(m4,m3);
		m0=_mm256_add_epi16(m4,m2);


			m1=_mm256_srli_si256(m0,2);
			m2=_mm256_add_epi16(m1,m0);
			m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);

			m1=_mm256_srli_si256(m0,4);
			m2=_mm256_add_epi16(m1,m2);

			//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

			m2=_mm256_add_epi16(m2,m4);

			//now division of r2/159 follows
			m2=division(division_case,m2,f);

			if (REMINDER_ITERATIONS > 11){
				filt[N-1][col+2+3] = (unsigned char) _mm256_extract_epi16(m2,1);
				filt[N-1][col+6+2+3] = (unsigned char) _mm256_extract_epi16(m2,4);
			}
			else if (REMINDER_ITERATIONS > 5){
				filt[N-1][col+2+3] = (unsigned char) _mm256_extract_epi16(m2,1);
			}



	return 0;
}


//for REMINDER_ITERATIONS >=16 only
int loop_reminder_high_reminder_values(unsigned char **frame1,unsigned char **filt,const unsigned int M, const unsigned int N,const unsigned int row, const unsigned int col, const unsigned int REMINDER_ITERATIONS,const unsigned int division_case,const __m256i c0,const __m256i c1,const __m256i c2,const __m256i c0_sh1,const __m256i c1_sh1,const __m256i c2_sh1,const __m256i c0_sh2,const __m256i c1_sh2,const __m256i c2_sh2, const __m256i f, const unsigned int divisor ){

register	__m256i r0,r1,r2,r3,r4,m0,m1,m2,m3,m4,output;



		//const __m256i f  = _mm256_set_epi16(52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759);
		const __m256i mask  = _mm256_set_epi8(0,0,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255);
		const __m256i mask2  = _mm256_set_epi8(0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0);
		const __m256i mask3  = _mm256_set_epi16(0,0,0,0,0,0,0,65535,0,0,0,0,0,0,0,0);
		const __m256i mask4  = _mm256_set_epi8(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,255,0,0,0,0,0,0,0,0,0,0,0,0);
		const __m256i mask5  = _mm256_set_epi8(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0);

 __m256i reminder_mask1,reminder_mask2;


	reminder_mask1=_mm256_load_si256( (__m256i *) &reminder_msk1[REMINDER_ITERATIONS-1][0]);
	reminder_mask2=_mm256_load_si256( (__m256i *) &reminder_msk2[REMINDER_ITERATIONS-1][0]);




	 //1st col iteration
	//load the 5 rows
	r0=_mm256_loadu_si256( (__m256i *) &frame1[row-2][col-2]);
	r1=_mm256_loadu_si256( (__m256i *) &frame1[row-1][col-2]);
	r2=_mm256_loadu_si256( (__m256i *) &frame1[row][col-2]);
	r3=_mm256_loadu_si256( (__m256i *) &frame1[row+1][col-2]);
	r4=_mm256_loadu_si256( (__m256i *) &frame1[row+2][col-2]);

	/*
	 * The above load operations load outside of the array bounds; these elements are filled with zeros just after
	 * Furthermore, I add two extra zeros in the end to compute col=N-2 and col=N-1. The last value of col is N-1, not N
	 */

	//AND r0-r4 with reminder_mask
	r0=_mm256_and_si256(r0,reminder_mask1);
	r1=_mm256_and_si256(r1,reminder_mask1);
	r2=_mm256_and_si256(r2,reminder_mask1);
	r3=_mm256_and_si256(r3,reminder_mask1);
	r4=_mm256_and_si256(r4,reminder_mask1);

	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c0);
	m1=_mm256_maddubs_epi16(r1,c1);
	m2=_mm256_maddubs_epi16(r2,c2);
	m3=_mm256_maddubs_epi16(r3,c1);
	m4=_mm256_maddubs_epi16(r4,c0);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m2=_mm256_add_epi16(m2,m3);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m4);

	//hozizontal additions
	//hadd(0:5)   and store filt[row[col]
	//hadd(6:11)   and store filt[row[col+8]
	//hadd(12:17) and store filt[row[col+14]
	//hadd(18:23) and store filt[row[col+20]
	//hadd(24:30) and store filt[row[col+26]

	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m4=_mm256_and_si256(m0,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

	m2=_mm256_add_epi16(m2,m4);

	//now division of r2/159 follows
	m2=division(division_case,m2,f);

	//and with mask to keep just 0,6,12,18,24
	output = _mm256_and_si256(m2,mask);
	/*
	filt[row][col] = (unsigned char) _mm256_extract_epi16(m2,0);
	filt[row][col+6] = (unsigned char) _mm256_extract_epi16(m2,3);
	filt[row][col+12] = (unsigned char) _mm256_extract_epi16(m2,6);
	filt[row][col+18] = (unsigned char) _mm256_extract_epi16(m2,9);
	filt[row][col+24] = (unsigned char) _mm256_extract_epi16(m2,12);*/

	//2nd col iteration
	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c0_sh1);
	m1=_mm256_maddubs_epi16(r1,c1_sh1);
	m2=_mm256_maddubs_epi16(r2,c2_sh1);
	m3=_mm256_maddubs_epi16(r3,c1_sh1);
	m4=_mm256_maddubs_epi16(r4,c0_sh1);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m2=_mm256_add_epi16(m2,m3);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m4);

	//hozizontal additions
	//hadd(0:5)   and store filt[row[col]
	//hadd(6:11)   and store filt[row[col+8]
	//hadd(12:17) and store filt[row[col+14]
	//hadd(18:23) and store filt[row[col+20]
	//hadd(24:30) and store filt[row[col+26]

	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m4=_mm256_and_si256(m0,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
	m2=_mm256_add_epi16(m2,m4);

	//now division of r2/159 follows
	m2=division(division_case,m2,f);

	//and with mask to keep just 0,6,12,18,24
	m2 = _mm256_and_si256(m2,mask);
	m2 = _mm256_slli_si256(m2,1);
	output = _mm256_add_epi8(output,m2);
	/*
	filt[row][col+1] = (unsigned char) _mm256_extract_epi16(m2,0);
	filt[row][col+1+6] = (unsigned char) _mm256_extract_epi16(m2,3);
	filt[row][col+1+12] = (unsigned char) _mm256_extract_epi16(m2,6);
	filt[row][col+1+18] = (unsigned char) _mm256_extract_epi16(m2,9);
	filt[row][col+1+24] = (unsigned char) _mm256_extract_epi16(m2,12);*/

             //3rd col iteration
	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c0_sh2);
	m1=_mm256_maddubs_epi16(r1,c1_sh2);
	m2=_mm256_maddubs_epi16(r2,c2_sh2);
	m3=_mm256_maddubs_epi16(r3,c1_sh2);
	m4=_mm256_maddubs_epi16(r4,c0_sh2);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m2=_mm256_add_epi16(m2,m3);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m4);

	//hozizontal additions
	//hadd(0:5)   and store filt[row[col]
	//hadd(6:11)   and store filt[row[col+8]
	//hadd(12:17) and store filt[row[col+14]
	//hadd(18:23) and store filt[row[col+20]
	//hadd(24:30) and store filt[row[col+26]

	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
	m4=_mm256_and_si256(m2,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

	m2=_mm256_add_epi16(m2,m4);

	//now division of r2/159 follows
	m2=division(division_case,m2,f);

	//and with mask to keep just 2,8,14,20,26
	m2 = _mm256_and_si256(m2,mask2);
	output = _mm256_add_epi8(output,m2);
	/*
	filt[row][col+2] = (unsigned char) _mm256_extract_epi16(m2,1);
	filt[row][col+2+6] = (unsigned char) _mm256_extract_epi16(m2,4);
	filt[row][col+2+12] = (unsigned char) _mm256_extract_epi16(m2,7);
	filt[row][col+2+18] = (unsigned char) _mm256_extract_epi16(m2,10);
	filt[row][col+2+24] = (unsigned char) _mm256_extract_epi16(m2,13);*/


	//4th col iteration
	//load the 5 rows
	r0=_mm256_loadu_si256( (__m256i *) &frame1[row-2][col+3-2]);
	r1=_mm256_loadu_si256( (__m256i *) &frame1[row-1][col+3-2]);
	r2=_mm256_loadu_si256( (__m256i *) &frame1[row][col+3-2]);
	r3=_mm256_loadu_si256( (__m256i *) &frame1[row+1][col+3-2]);
	r4=_mm256_loadu_si256( (__m256i *) &frame1[row+2][col+3-2]);

	//AND r0-r4 with reminder_mask
	r0=_mm256_and_si256(r0,reminder_mask2);
	r1=_mm256_and_si256(r1,reminder_mask2);
	r2=_mm256_and_si256(r2,reminder_mask2);
	r3=_mm256_and_si256(r3,reminder_mask2);
	r4=_mm256_and_si256(r4,reminder_mask2);

	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c0);
	m1=_mm256_maddubs_epi16(r1,c1);
	m2=_mm256_maddubs_epi16(r2,c2);
	m3=_mm256_maddubs_epi16(r3,c1);
	m4=_mm256_maddubs_epi16(r4,c0);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m2=_mm256_add_epi16(m2,m3);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m4);

	//hozizontal additions
	//hadd(0:5)   and store filt[row[col]
	//hadd(6:11)   and store filt[row[col+8]
	//hadd(12:17) and store filt[row[col+14]
	//hadd(18:23) and store filt[row[col+20]
	//hadd(24:30) and store filt[row[col+26]

	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m4=_mm256_and_si256(m0,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

	m2=_mm256_add_epi16(m2,m4);

	//now division of r2/159 follows
	m2=division(division_case,m2,f);

	//and with mask to keep just 0,6,12,18,24
	m2 = _mm256_and_si256(m2,mask);
	m2 = _mm256_slli_si256(m2,3);
	output = _mm256_add_epi8(output,m2);
	/*
	filt[row][col+3] = (unsigned char) _mm256_extract_epi16(m2,0);
	filt[row][col+3+6] = (unsigned char) _mm256_extract_epi16(m2,3);
	filt[row][col+3+12] = (unsigned char) _mm256_extract_epi16(m2,6);
	filt[row][col+3+18] = (unsigned char) _mm256_extract_epi16(m2,9);
	filt[row][col+3+24] = (unsigned char) _mm256_extract_epi16(m2,12);*/

	//5th col iteration
	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c0_sh1);
	m1=_mm256_maddubs_epi16(r1,c1_sh1);
	m2=_mm256_maddubs_epi16(r2,c2_sh1);
	m3=_mm256_maddubs_epi16(r3,c1_sh1);
	m4=_mm256_maddubs_epi16(r4,c0_sh1);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m2=_mm256_add_epi16(m2,m3);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m4);

	//hozizontal additions
	//hadd(0:5)   and store filt[row[col]
	//hadd(6:11)   and store filt[row[col+8]
	//hadd(12:17) and store filt[row[col+14]
	//hadd(18:23) and store filt[row[col+20]
	//hadd(24:30) and store filt[row[col+26]

	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m4=_mm256_and_si256(m0,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

	m2=_mm256_add_epi16(m2,m4);

	//now division of r2/159 follows
	m2=division(division_case,m2,f);

	//and with mask to keep just 0,6,12,18,24
	m2 = _mm256_and_si256(m2,mask);
	m1 = _mm256_slli_si256(m2,4);
	output = _mm256_add_epi8(output,m1);

	//output = _mm256_insert_epi8(output,_mm256_extract_epi8(m2,12),16);
	m2=_mm256_and_si256(m2,mask4);
	m2=_mm256_permute2f128_si256(m2,m2,1);
	m2=_mm256_srli_si256(m2,12);
	output=_mm256_add_epi8(output,m2);

	/*
	filt[row][col+4] = (unsigned char) _mm256_extract_epi16(m2,0);
	filt[row][col+4+6] = (unsigned char) _mm256_extract_epi16(m2,3);
	filt[row][col+4+12] = (unsigned char) _mm256_extract_epi16(m2,6);
	filt[row][col+4+18] = (unsigned char) _mm256_extract_epi16(m2,9);
	filt[row][col+4+24] = (unsigned char) _mm256_extract_epi16(m2,12);*/

             //6th col iteration
	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c0_sh2);
	m1=_mm256_maddubs_epi16(r1,c1_sh2);
	m2=_mm256_maddubs_epi16(r2,c2_sh2);
	m3=_mm256_maddubs_epi16(r3,c1_sh2);
	m4=_mm256_maddubs_epi16(r4,c0_sh2);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m2=_mm256_add_epi16(m2,m3);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m4);

	//hozizontal additions
	//hadd(0:5)   and store filt[row[col]
	//hadd(6:11)   and store filt[row[col+8]
	//hadd(12:17) and store filt[row[col+14]
	//hadd(18:23) and store filt[row[col+20]
	//hadd(24:30) and store filt[row[col+26]

	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
	m4=_mm256_and_si256(m2,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

	m2=_mm256_add_epi16(m2,m4);

	//now division of r2/159 follows
	m2=division(division_case,m2,f);

	//and with mask to keep just 2,8,14,20,26
	m2 = _mm256_and_si256(m2,mask2);
	m1 = _mm256_slli_si256(m2,3);
	output = _mm256_add_epi8(output,m1);

	//output = _mm256_insert_epi8(output,_mm256_extract_epi8(m2,14),17);
	m2=_mm256_and_si256(m2,mask5);
	m2=_mm256_permute2f128_si256(m2,m2,1);
	m2=_mm256_srli_si256(m2,13);
	output=_mm256_add_epi8(output,m2);

	//_mm256_storeu_si256( (__m256i *) &filt[row][col],output);
	_mm_storeu_si128( (__m128i *) &filt[row][col],_mm256_extractf128_si256(output, 0)); //store low 128bit - 16pixels

	switch (REMINDER_ITERATIONS){
	case 16:
	  break;
	case 17:
		filt[row][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		  break;
	case 18:
		filt[row][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[row][col+17] = (unsigned char) _mm256_extract_epi8(output,17);
		  break;
	case 19:
		filt[row][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[row][col+17] = (unsigned char) _mm256_extract_epi8(output,17);
		filt[row][col+18] = (unsigned char) _mm256_extract_epi8(output,18);
		  break;
	case 20:
		filt[row][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[row][col+17] = (unsigned char) _mm256_extract_epi8(output,17);
		filt[row][col+18] = (unsigned char) _mm256_extract_epi8(output,18);
		filt[row][col+19] = (unsigned char) _mm256_extract_epi8(output,19);
		  break;
	case 21:
		filt[row][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[row][col+17] = (unsigned char) _mm256_extract_epi8(output,17);
		filt[row][col+18] = (unsigned char) _mm256_extract_epi8(output,18);
		filt[row][col+19] = (unsigned char) _mm256_extract_epi8(output,19);
		filt[row][col+20] = (unsigned char) _mm256_extract_epi8(output,20);
		  break;
	case 22:
		filt[row][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[row][col+17] = (unsigned char) _mm256_extract_epi8(output,17);
		filt[row][col+18] = (unsigned char) _mm256_extract_epi8(output,18);
		filt[row][col+19] = (unsigned char) _mm256_extract_epi8(output,19);
		filt[row][col+20] = (unsigned char) _mm256_extract_epi8(output,20);
		filt[row][col+21] = (unsigned char) _mm256_extract_epi8(output,21);
		  break;
	case 23:
		filt[row][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[row][col+17] = (unsigned char) _mm256_extract_epi8(output,17);
		filt[row][col+18] = (unsigned char) _mm256_extract_epi8(output,18);
		filt[row][col+19] = (unsigned char) _mm256_extract_epi8(output,19);
		filt[row][col+20] = (unsigned char) _mm256_extract_epi8(output,20);
		filt[row][col+21] = (unsigned char) _mm256_extract_epi8(output,21);
		filt[row][col+22] = (unsigned char) _mm256_extract_epi8(output,22);
		  break;
	case 24:
		//_mm_storeu_si64( (__m128i *) &filt[row][col+16],_mm256_extractf128_si256(output, 0)); //store low 128bit - 16pixels
		filt[row][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[row][col+17] = (unsigned char) _mm256_extract_epi8(output,17);
		filt[row][col+18] = (unsigned char) _mm256_extract_epi8(output,18);
		filt[row][col+19] = (unsigned char) _mm256_extract_epi8(output,19);
		filt[row][col+20] = (unsigned char) _mm256_extract_epi8(output,20);
		filt[row][col+21] = (unsigned char) _mm256_extract_epi8(output,21);
		filt[row][col+22] = (unsigned char) _mm256_extract_epi8(output,22);
		filt[row][col+23] = (unsigned char) _mm256_extract_epi8(output,23);
		  break;
	case 25:
		filt[row][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[row][col+17] = (unsigned char) _mm256_extract_epi8(output,17);
		filt[row][col+18] = (unsigned char) _mm256_extract_epi8(output,18);
		filt[row][col+19] = (unsigned char) _mm256_extract_epi8(output,19);
		filt[row][col+20] = (unsigned char) _mm256_extract_epi8(output,20);
		filt[row][col+21] = (unsigned char) _mm256_extract_epi8(output,21);
		filt[row][col+22] = (unsigned char) _mm256_extract_epi8(output,22);
		filt[row][col+23] = (unsigned char) _mm256_extract_epi8(output,23);
		filt[row][col+24] = (unsigned char) _mm256_extract_epi8(output,24);
		  break;
	case 26:
		filt[row][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[row][col+17] = (unsigned char) _mm256_extract_epi8(output,17);
		filt[row][col+18] = (unsigned char) _mm256_extract_epi8(output,18);
		filt[row][col+19] = (unsigned char) _mm256_extract_epi8(output,19);
		filt[row][col+20] = (unsigned char) _mm256_extract_epi8(output,20);
		filt[row][col+21] = (unsigned char) _mm256_extract_epi8(output,21);
		filt[row][col+22] = (unsigned char) _mm256_extract_epi8(output,22);
		filt[row][col+23] = (unsigned char) _mm256_extract_epi8(output,23);
		filt[row][col+24] = (unsigned char) _mm256_extract_epi8(output,24);
		filt[row][col+25] = (unsigned char) _mm256_extract_epi8(output,25);
		  break;
	case 27:
		filt[row][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[row][col+17] = (unsigned char) _mm256_extract_epi8(output,17);
		filt[row][col+18] = (unsigned char) _mm256_extract_epi8(output,18);
		filt[row][col+19] = (unsigned char) _mm256_extract_epi8(output,19);
		filt[row][col+20] = (unsigned char) _mm256_extract_epi8(output,20);
		filt[row][col+21] = (unsigned char) _mm256_extract_epi8(output,21);
		filt[row][col+22] = (unsigned char) _mm256_extract_epi8(output,22);
		filt[row][col+23] = (unsigned char) _mm256_extract_epi8(output,23);
		filt[row][col+24] = (unsigned char) _mm256_extract_epi8(output,24);
		filt[row][col+25] = (unsigned char) _mm256_extract_epi8(output,25);
		filt[row][col+26] = (unsigned char) _mm256_extract_epi8(output,26);
		  break;
	case 28:
		filt[row][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[row][col+17] = (unsigned char) _mm256_extract_epi8(output,17);
		filt[row][col+18] = (unsigned char) _mm256_extract_epi8(output,18);
		filt[row][col+19] = (unsigned char) _mm256_extract_epi8(output,19);
		filt[row][col+20] = (unsigned char) _mm256_extract_epi8(output,20);
		filt[row][col+21] = (unsigned char) _mm256_extract_epi8(output,21);
		filt[row][col+22] = (unsigned char) _mm256_extract_epi8(output,22);
		filt[row][col+23] = (unsigned char) _mm256_extract_epi8(output,23);
		filt[row][col+24] = (unsigned char) _mm256_extract_epi8(output,24);
		filt[row][col+25] = (unsigned char) _mm256_extract_epi8(output,25);
		filt[row][col+26] = (unsigned char) _mm256_extract_epi8(output,26);
		filt[row][col+27] = (unsigned char) _mm256_extract_epi8(output,27);
		  break;
	case 29:
		filt[row][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[row][col+17] = (unsigned char) _mm256_extract_epi8(output,17);
		filt[row][col+18] = (unsigned char) _mm256_extract_epi8(output,18);
		filt[row][col+19] = (unsigned char) _mm256_extract_epi8(output,19);
		filt[row][col+20] = (unsigned char) _mm256_extract_epi8(output,20);
		filt[row][col+21] = (unsigned char) _mm256_extract_epi8(output,21);
		filt[row][col+22] = (unsigned char) _mm256_extract_epi8(output,22);
		filt[row][col+23] = (unsigned char) _mm256_extract_epi8(output,23);
		filt[row][col+24] = (unsigned char) _mm256_extract_epi8(output,24);
		filt[row][col+25] = (unsigned char) _mm256_extract_epi8(output,25);
		filt[row][col+26] = (unsigned char) _mm256_extract_epi8(output,26);
		filt[row][col+27] = (unsigned char) _mm256_extract_epi8(output,27);
		filt[row][col+28] = (unsigned char) _mm256_extract_epi8(output,28);
		  break;
	case 30:
		filt[row][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[row][col+17] = (unsigned char) _mm256_extract_epi8(output,17);
		filt[row][col+18] = (unsigned char) _mm256_extract_epi8(output,18);
		filt[row][col+19] = (unsigned char) _mm256_extract_epi8(output,19);
		filt[row][col+20] = (unsigned char) _mm256_extract_epi8(output,20);
		filt[row][col+21] = (unsigned char) _mm256_extract_epi8(output,21);
		filt[row][col+22] = (unsigned char) _mm256_extract_epi8(output,22);
		filt[row][col+23] = (unsigned char) _mm256_extract_epi8(output,23);
		filt[row][col+24] = (unsigned char) _mm256_extract_epi8(output,24);
		filt[row][col+25] = (unsigned char) _mm256_extract_epi8(output,25);
		filt[row][col+26] = (unsigned char) _mm256_extract_epi8(output,26);
		filt[row][col+27] = (unsigned char) _mm256_extract_epi8(output,27);
		filt[row][col+28] = (unsigned char) _mm256_extract_epi8(output,28);
		filt[row][col+29] = (unsigned char) _mm256_extract_epi8(output,29);
		  break;
	case 31:
		filt[row][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[row][col+17] = (unsigned char) _mm256_extract_epi8(output,17);
		filt[row][col+18] = (unsigned char) _mm256_extract_epi8(output,18);
		filt[row][col+19] = (unsigned char) _mm256_extract_epi8(output,19);
		filt[row][col+20] = (unsigned char) _mm256_extract_epi8(output,20);
		filt[row][col+21] = (unsigned char) _mm256_extract_epi8(output,21);
		filt[row][col+22] = (unsigned char) _mm256_extract_epi8(output,22);
		filt[row][col+23] = (unsigned char) _mm256_extract_epi8(output,23);
		filt[row][col+24] = (unsigned char) _mm256_extract_epi8(output,24);
		filt[row][col+25] = (unsigned char) _mm256_extract_epi8(output,25);
		filt[row][col+26] = (unsigned char) _mm256_extract_epi8(output,26);
		filt[row][col+27] = (unsigned char) _mm256_extract_epi8(output,27);
		filt[row][col+28] = (unsigned char) _mm256_extract_epi8(output,28);
		filt[row][col+29] = (unsigned char) _mm256_extract_epi8(output,29);

		int newPixel = 0;
		for (int rowOffset=-2; rowOffset<=2; rowOffset++) {
			for (int colOffset=-2; colOffset<=2; colOffset++) {

			   if ( ((row+rowOffset)<N) && ((M-1+colOffset)<M) && ((row+rowOffset)>=0) && ((M-1+colOffset)>=0) )
	              newPixel += frame1[row+rowOffset][M-1+colOffset] * gaussianMask[2 + rowOffset][2 + colOffset];

			      }
		        }
	filt[row][M-1] = (unsigned char) (newPixel / divisor);

		  break;
	default:
		printf("\n something went wrong");
	}

return 0;

}



//in this case, row=2 along row=0,1 are computed
int loop_reminder_first_rows_high_reminder_values(unsigned char **frame1,unsigned char **filt,const unsigned int M, const unsigned int N, const unsigned int col, const unsigned int REMINDER_ITERATIONS,const unsigned int division_case,const __m256i c0,const __m256i c1,const __m256i c2,const __m256i c0_sh1,const __m256i c1_sh1,const __m256i c2_sh1,const __m256i c0_sh2,const __m256i c1_sh2,const __m256i c2_sh2, const __m256i f,const unsigned int divisor ){

register	__m256i r0,r1,r2,r3,r4,m0,m1,m2,m3,m4,output,output_row0,output_row1;


	//const __m256i f  = _mm256_set_epi16(52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759);
	const __m256i mask  = _mm256_set_epi8(0,0,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255);
	const __m256i mask2  = _mm256_set_epi8(0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0);
	const __m256i mask3  = _mm256_set_epi16(0,0,0,0,0,0,0,65535,0,0,0,0,0,0,0,0);
	const __m256i mask4  = _mm256_set_epi8(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,255,0,0,0,0,0,0,0,0,0,0,0,0);
	const __m256i mask5  = _mm256_set_epi8(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0);


		 __m256i reminder_mask1,reminder_mask2;



reminder_mask1=_mm256_load_si256( (__m256i *) &reminder_msk1[REMINDER_ITERATIONS-1][0]);
reminder_mask2=_mm256_load_si256( (__m256i *) &reminder_msk2[REMINDER_ITERATIONS-1][0]);




	 //1st col iteration
	//load the 5 rows
	r0=_mm256_loadu_si256( (__m256i *) &frame1[0][col-2]);
	r1=_mm256_loadu_si256( (__m256i *) &frame1[1][col-2]);
	r2=_mm256_loadu_si256( (__m256i *) &frame1[2][col-2]);
	r3=_mm256_loadu_si256( (__m256i *) &frame1[3][col-2]);
	r4=_mm256_loadu_si256( (__m256i *) &frame1[4][col-2]);

	/*
	 * The above load operations load outside of the array bounds; these elements are filled with zeros just after
	 * Furthermore, I add two extra zeros in the end to compute col=N-2 and col=N-1. The last value of col is N-1, not N
	 */

	//AND r0-r4 with reminder_mask
	r0=_mm256_and_si256(r0,reminder_mask1);
	r1=_mm256_and_si256(r1,reminder_mask1);
	r2=_mm256_and_si256(r2,reminder_mask1);
	r3=_mm256_and_si256(r3,reminder_mask1);
	r4=_mm256_and_si256(r4,reminder_mask1);

	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c0);
	m1=_mm256_maddubs_epi16(r1,c1);
	m2=_mm256_maddubs_epi16(r2,c2);
	m3=_mm256_maddubs_epi16(r3,c1);
	m4=_mm256_maddubs_epi16(r4,c0);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m3);
	m0=_mm256_add_epi16(m0,m4);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m4=_mm256_and_si256(m0,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

	m2=_mm256_add_epi16(m2,m4);

	//now division of r2/159 follows
	m2=division(division_case,m2,f);

	//and with mask to keep just 0,6,12,18,24
	output = _mm256_and_si256(m2,mask);

	//--------------row=0
	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c2);
	m1=_mm256_maddubs_epi16(r1,c1);
	m2=_mm256_maddubs_epi16(r2,c0);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m0=_mm256_add_epi16(m0,m2);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m4=_mm256_and_si256(m0,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

	m2=_mm256_add_epi16(m2,m4);

	//now division of r2/159 follows
	m2=division(division_case,m2,f);

	//and with mask to keep just 0,6,12,18,24
	output_row0 = _mm256_and_si256(m2,mask);

	//--------------row=1
	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c1);
	m1=_mm256_maddubs_epi16(r1,c2);
	m2=_mm256_maddubs_epi16(r2,c1);
	m3=_mm256_maddubs_epi16(r3,c0);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m3);

	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m4=_mm256_and_si256(m0,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

	m2=_mm256_add_epi16(m2,m4);

	//now division of r2/159 follows
	m2=division(division_case,m2,f);

	//and with mask to keep just 0,6,12,18,24
	output_row1 = _mm256_and_si256(m2,mask);

	//2nd col iteration
	//multiply with the mask

	//----row=2
	m0=_mm256_maddubs_epi16(r0,c0_sh1);
	m1=_mm256_maddubs_epi16(r1,c1_sh1);
	m2=_mm256_maddubs_epi16(r2,c2_sh1);
	m3=_mm256_maddubs_epi16(r3,c1_sh1);
	m4=_mm256_maddubs_epi16(r4,c0_sh1);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m3);
	m0=_mm256_add_epi16(m0,m4);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m4=_mm256_and_si256(m0,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
	m2=_mm256_add_epi16(m2,m4);

	//now division of r2/159 follows
	m2=division(division_case,m2,f);

	//and with mask to keep just 0,6,12,18,24
	m2 = _mm256_and_si256(m2,mask);
	m2 = _mm256_slli_si256(m2,1);
	output = _mm256_add_epi8(output,m2);

	//----row=0
	m0=_mm256_maddubs_epi16(r0,c2_sh1);
	m1=_mm256_maddubs_epi16(r1,c1_sh1);
	m2=_mm256_maddubs_epi16(r2,c0_sh1);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m0=_mm256_add_epi16(m0,m2);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m4=_mm256_and_si256(m0,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
	m2=_mm256_add_epi16(m2,m4);

	//now division of r2/159 follows
	m2=division(division_case,m2,f);

	//and with mask to keep just 0,6,12,18,24
	m2 = _mm256_and_si256(m2,mask);
	m2 = _mm256_slli_si256(m2,1);
	output_row0 = _mm256_add_epi8(output_row0,m2);

	//----row=1
	m0=_mm256_maddubs_epi16(r0,c1_sh1);
	m1=_mm256_maddubs_epi16(r1,c2_sh1);
	m2=_mm256_maddubs_epi16(r2,c1_sh1);
	m3=_mm256_maddubs_epi16(r3,c0_sh1);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m3);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m4=_mm256_and_si256(m0,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
	m2=_mm256_add_epi16(m2,m4);

	//now division of r2/159 follows
	m2=division(division_case,m2,f);

	//and with mask to keep just 0,6,12,18,24
	m2 = _mm256_and_si256(m2,mask);
	m2 = _mm256_slli_si256(m2,1);
	output_row1 = _mm256_add_epi8(output_row1,m2);

             //3rd col iteration
	//---row=2
	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c0_sh2);
	m1=_mm256_maddubs_epi16(r1,c1_sh2);
	m2=_mm256_maddubs_epi16(r2,c2_sh2);
	m3=_mm256_maddubs_epi16(r3,c1_sh2);
	m4=_mm256_maddubs_epi16(r4,c0_sh2);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m3);
	m0=_mm256_add_epi16(m0,m4);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
	m4=_mm256_and_si256(m2,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

	m2=_mm256_add_epi16(m2,m4);

	//now division of r2/159 follows
	m2=division(division_case,m2,f);

	//and with mask to keep just 2,8,14,20,26
	m2 = _mm256_and_si256(m2,mask2);
	output = _mm256_add_epi8(output,m2);

	//---row=0
	//multiply with the mask

	m0=_mm256_maddubs_epi16(r0,c2_sh2);
	m1=_mm256_maddubs_epi16(r1,c1_sh2);
	m2=_mm256_maddubs_epi16(r2,c0_sh2);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m0=_mm256_add_epi16(m0,m2);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
	m4=_mm256_and_si256(m2,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

	m2=_mm256_add_epi16(m2,m4);

	//now division of r2/159 follows
	m2=division(division_case,m2,f);

	//and with mask to keep just 2,8,14,20,26
	m2 = _mm256_and_si256(m2,mask2);
	output_row0 = _mm256_add_epi8(output_row0,m2);


	//---row=1
	//multiply with the mask

	m0=_mm256_maddubs_epi16(r0,c1_sh2);
	m1=_mm256_maddubs_epi16(r1,c2_sh2);
	m2=_mm256_maddubs_epi16(r2,c1_sh2);
	m3=_mm256_maddubs_epi16(r3,c0_sh2);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m3);

	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
	m4=_mm256_and_si256(m2,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

	m2=_mm256_add_epi16(m2,m4);

	//now division of r2/159 follows
	m2=division(division_case,m2,f);

	//and with mask to keep just 2,8,14,20,26
	m2 = _mm256_and_si256(m2,mask2);
	output_row1 = _mm256_add_epi8(output_row1,m2);

	//4th col iteration

	//load the 5 rows
	r0=_mm256_loadu_si256( (__m256i *) &frame1[0][col+3-2]);
	r1=_mm256_loadu_si256( (__m256i *) &frame1[1][col+3-2]);
	r2=_mm256_loadu_si256( (__m256i *) &frame1[2][col+3-2]);
	r3=_mm256_loadu_si256( (__m256i *) &frame1[3][col+3-2]);
	r4=_mm256_loadu_si256( (__m256i *) &frame1[4][col+3-2]);

	//AND r0-r4 with reminder_mask
	r0=_mm256_and_si256(r0,reminder_mask2);
	r1=_mm256_and_si256(r1,reminder_mask2);
	r2=_mm256_and_si256(r2,reminder_mask2);
	r3=_mm256_and_si256(r3,reminder_mask2);
	r4=_mm256_and_si256(r4,reminder_mask2);

	//----row=2
	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c0);
	m1=_mm256_maddubs_epi16(r1,c1);
	m2=_mm256_maddubs_epi16(r2,c2);
	m3=_mm256_maddubs_epi16(r3,c1);
	m4=_mm256_maddubs_epi16(r4,c0);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m3);
	m0=_mm256_add_epi16(m0,m4);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m4=_mm256_and_si256(m0,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

	m2=_mm256_add_epi16(m2,m4);

	//now division of r2/159 follows
	m2=division(division_case,m2,f);

	//and with mask to keep just 0,6,12,18,24
	m2 = _mm256_and_si256(m2,mask);
	m2 = _mm256_slli_si256(m2,3);
	output = _mm256_add_epi8(output,m2);

	//----row=0
	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c2);
	m1=_mm256_maddubs_epi16(r1,c1);
	m2=_mm256_maddubs_epi16(r2,c0);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m0=_mm256_add_epi16(m0,m2);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m4=_mm256_and_si256(m0,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

	m2=_mm256_add_epi16(m2,m4);

	//now division of r2/159 follows
	m2=division(division_case,m2,f);

	//and with mask to keep just 0,6,12,18,24
	m2 = _mm256_and_si256(m2,mask);
	m2 = _mm256_slli_si256(m2,3);
	output_row0 = _mm256_add_epi8(output_row0,m2);

	//----row=1
	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c1);
	m1=_mm256_maddubs_epi16(r1,c2);
	m2=_mm256_maddubs_epi16(r2,c1);
	m3=_mm256_maddubs_epi16(r3,c0);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m3);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m4=_mm256_and_si256(m0,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

	m2=_mm256_add_epi16(m2,m4);

	//now division of r2/159 follows
	m2=division(division_case,m2,f);

	//and with mask to keep just 0,6,12,18,24
	m2 = _mm256_and_si256(m2,mask);
	m2 = _mm256_slli_si256(m2,3);
	output_row1 = _mm256_add_epi8(output_row1,m2);

	//5th col iteration
	//----row=2
	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c0_sh1);
	m1=_mm256_maddubs_epi16(r1,c1_sh1);
	m2=_mm256_maddubs_epi16(r2,c2_sh1);
	m3=_mm256_maddubs_epi16(r3,c1_sh1);
	m4=_mm256_maddubs_epi16(r4,c0_sh1);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m3);
	m0=_mm256_add_epi16(m0,m4);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m4=_mm256_and_si256(m0,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

	m2=_mm256_add_epi16(m2,m4);

	//now division of r2/159 follows
	m2=division(division_case,m2,f);

	//and with mask to keep just 0,6,12,18,24
	m2 = _mm256_and_si256(m2,mask);
	m1 = _mm256_slli_si256(m2,4);
	output = _mm256_add_epi8(output,m1);

	//output = _mm256_insert_epi8(output,_mm256_extract_epi8(m2,12),16);
	m2=_mm256_and_si256(m2,mask4);
	m2=_mm256_permute2f128_si256(m2,m2,1);
	m2=_mm256_srli_si256(m2,12);
	output=_mm256_add_epi8(output,m2);

	//----row=0
	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c2_sh1);
	m1=_mm256_maddubs_epi16(r1,c1_sh1);
	m2=_mm256_maddubs_epi16(r2,c0_sh1);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m0=_mm256_add_epi16(m0,m2);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m4=_mm256_and_si256(m0,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

	m2=_mm256_add_epi16(m2,m4);

	//now division of r2/159 follows
	m2=division(division_case,m2,f);

	//and with mask to keep just 0,6,12,18,24
	m2 = _mm256_and_si256(m2,mask);
	m1 = _mm256_slli_si256(m2,4);
	output_row0 = _mm256_add_epi8(output_row0,m1);

	//output = _mm256_insert_epi8(output,_mm256_extract_epi8(m2,12),16);
	m2=_mm256_and_si256(m2,mask4);
	m2=_mm256_permute2f128_si256(m2,m2,1);
	m2=_mm256_srli_si256(m2,12);
	output_row0=_mm256_add_epi8(output_row0,m2);

	//----row=1
	//multiply with the mask

	m0=_mm256_maddubs_epi16(r0,c1_sh1);
	m1=_mm256_maddubs_epi16(r1,c2_sh1);
	m2=_mm256_maddubs_epi16(r2,c1_sh1);
	m3=_mm256_maddubs_epi16(r3,c0_sh1);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m3);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m4=_mm256_and_si256(m0,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

	m2=_mm256_add_epi16(m2,m4);

	//now division of r2/159 follows
	m2=division(division_case,m2,f);

	//and with mask to keep just 0,6,12,18,24
	m2 = _mm256_and_si256(m2,mask);
	m1 = _mm256_slli_si256(m2,4);
	output_row1 = _mm256_add_epi8(output_row1,m1);

	//output = _mm256_insert_epi8(output,_mm256_extract_epi8(m2,12),16);
	m2=_mm256_and_si256(m2,mask4);
	m2=_mm256_permute2f128_si256(m2,m2,1);
	m2=_mm256_srli_si256(m2,12);
	output_row1=_mm256_add_epi8(output_row1,m2);

             //6th col iteration
	//---row=2
	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c0_sh2);
	m1=_mm256_maddubs_epi16(r1,c1_sh2);
	m2=_mm256_maddubs_epi16(r2,c2_sh2);
	m3=_mm256_maddubs_epi16(r3,c1_sh2);
	m4=_mm256_maddubs_epi16(r4,c0_sh2);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m3);
	m0=_mm256_add_epi16(m0,m4);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
	m4=_mm256_and_si256(m2,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

	m2=_mm256_add_epi16(m2,m4);

	//now division of r2/159 follows
	m2=division(division_case,m2,f);

	//and with mask to keep just 2,8,14,20,26
	m2 = _mm256_and_si256(m2,mask2);
	m1 = _mm256_slli_si256(m2,3);
	output = _mm256_add_epi8(output,m1);

	//output = _mm256_insert_epi8(output,_mm256_extract_epi8(m2,14),17);
	m2=_mm256_and_si256(m2,mask5);
	m2=_mm256_permute2f128_si256(m2,m2,1);
	m2=_mm256_srli_si256(m2,13);
	output=_mm256_add_epi8(output,m2);

	//_mm256_storeu_si256( (__m256i *) &filt[row][col],output);


	//---row=0
	//multiply with the mask

	m0=_mm256_maddubs_epi16(r0,c2_sh2);
	m1=_mm256_maddubs_epi16(r1,c1_sh2);
	m2=_mm256_maddubs_epi16(r2,c0_sh2);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m0=_mm256_add_epi16(m0,m2);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
	m4=_mm256_and_si256(m2,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

	m2=_mm256_add_epi16(m2,m4);

	//now division of r2/159 follows
	m2=division(division_case,m2,f);

	//and with mask to keep just 2,8,14,20,26
	m2 = _mm256_and_si256(m2,mask2);
	m1 = _mm256_slli_si256(m2,3);
	output_row0 = _mm256_add_epi8(output_row0,m1);

	//output = _mm256_insert_epi8(output,_mm256_extract_epi8(m2,14),17);
	m2=_mm256_and_si256(m2,mask5);
	m2=_mm256_permute2f128_si256(m2,m2,1);
	m2=_mm256_srli_si256(m2,13);
	output_row0=_mm256_add_epi8(output_row0,m2);

	//_mm256_storeu_si256( (__m256i *) &filt[0][col],output_row0);

	//---row=1
	//multiply with the mask

	m0=_mm256_maddubs_epi16(r0,c1_sh2);
	m1=_mm256_maddubs_epi16(r1,c2_sh2);
	m2=_mm256_maddubs_epi16(r2,c1_sh2);
	m3=_mm256_maddubs_epi16(r3,c0_sh2);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m3);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
	m4=_mm256_and_si256(m2,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

	m2=_mm256_add_epi16(m2,m4);

	//now division of r2/159 follows
	m2=division(division_case,m2,f);

	//and with mask to keep just 2,8,14,20,26
	m2 = _mm256_and_si256(m2,mask2);
	m1 = _mm256_slli_si256(m2,3);
	output_row1 = _mm256_add_epi8(output_row1,m1);

	//output = _mm256_insert_epi8(output,_mm256_extract_epi8(m2,14),17);
	m2=_mm256_and_si256(m2,mask5);
	m2=_mm256_permute2f128_si256(m2,m2,1);
	m2=_mm256_srli_si256(m2,13);
	output_row1=_mm256_add_epi8(output_row1,m2);

	//_mm256_storeu_si256( (__m256i *) &filt[row][col],output);
	_mm_storeu_si128( (__m128i *) &filt[2][col],_mm256_extractf128_si256(output, 0)); //store low 128bit - 16pixels
	_mm_storeu_si128( (__m128i *) &filt[0][col],_mm256_extractf128_si256(output_row0, 0)); //store low 128bit - 16pixels
	_mm_storeu_si128( (__m128i *) &filt[1][col],_mm256_extractf128_si256(output_row1, 0)); //store low 128bit - 16pixels

	switch (REMINDER_ITERATIONS){
	case 16:
	  break;
	case 17:
		filt[2][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[0][col+16] = (unsigned char) _mm256_extract_epi8(output_row0,16);
		filt[1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1,16);
		  break;
	case 18:
		filt[2][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[2][col+17] = (unsigned char) _mm256_extract_epi8(output,17);

		filt[0][col+16] = (unsigned char) _mm256_extract_epi8(output_row0,16);
		filt[0][col+17] = (unsigned char) _mm256_extract_epi8(output_row0,17);

		filt[1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1,16);
		filt[1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1,17);
		  break;
	case 19:
		filt[2][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[2][col+17] = (unsigned char) _mm256_extract_epi8(output,17);
		filt[2][col+18] = (unsigned char) _mm256_extract_epi8(output,18);

		filt[0][col+16] = (unsigned char) _mm256_extract_epi8(output_row0,16);
		filt[0][col+17] = (unsigned char) _mm256_extract_epi8(output_row0,17);
		filt[0][col+18] = (unsigned char) _mm256_extract_epi8(output_row0,18);

		filt[1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1,16);
		filt[1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1,17);
		filt[1][col+18] = (unsigned char) _mm256_extract_epi8(output_row1,18);
		  break;
	case 20:
		filt[2][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[2][col+17] = (unsigned char) _mm256_extract_epi8(output,17);
		filt[2][col+18] = (unsigned char) _mm256_extract_epi8(output,18);
		filt[2][col+19] = (unsigned char) _mm256_extract_epi8(output,19);

		filt[0][col+16] = (unsigned char) _mm256_extract_epi8(output_row0,16);
		filt[0][col+17] = (unsigned char) _mm256_extract_epi8(output_row0,17);
		filt[0][col+18] = (unsigned char) _mm256_extract_epi8(output_row0,18);
		filt[0][col+19] = (unsigned char) _mm256_extract_epi8(output_row0,19);

		filt[1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1,16);
		filt[1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1,17);
		filt[1][col+18] = (unsigned char) _mm256_extract_epi8(output_row1,18);
		filt[1][col+19] = (unsigned char) _mm256_extract_epi8(output_row1,19);
		  break;
	case 21:
		filt[2][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[2][col+17] = (unsigned char) _mm256_extract_epi8(output,17);
		filt[2][col+18] = (unsigned char) _mm256_extract_epi8(output,18);
		filt[2][col+19] = (unsigned char) _mm256_extract_epi8(output,19);
		filt[2][col+20] = (unsigned char) _mm256_extract_epi8(output,20);
		filt[0][col+16] = (unsigned char) _mm256_extract_epi8(output_row0,16);
		filt[0][col+17] = (unsigned char) _mm256_extract_epi8(output_row0,17);
		filt[0][col+18] = (unsigned char) _mm256_extract_epi8(output_row0,18);
		filt[0][col+19] = (unsigned char) _mm256_extract_epi8(output_row0,19);
		filt[0][col+20] = (unsigned char) _mm256_extract_epi8(output_row0,20);
		filt[1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1,16);
		filt[1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1,17);
		filt[1][col+18] = (unsigned char) _mm256_extract_epi8(output_row1,18);
		filt[1][col+19] = (unsigned char) _mm256_extract_epi8(output_row1,19);
		filt[1][col+20] = (unsigned char) _mm256_extract_epi8(output_row1,20);
		  break;
	case 22:
		filt[2][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[2][col+17] = (unsigned char) _mm256_extract_epi8(output,17);
		filt[2][col+18] = (unsigned char) _mm256_extract_epi8(output,18);
		filt[2][col+19] = (unsigned char) _mm256_extract_epi8(output,19);
		filt[2][col+20] = (unsigned char) _mm256_extract_epi8(output,20);
		filt[2][col+21] = (unsigned char) _mm256_extract_epi8(output,21);
		filt[0][col+16] = (unsigned char) _mm256_extract_epi8(output_row0,16);
		filt[0][col+17] = (unsigned char) _mm256_extract_epi8(output_row0,17);
		filt[0][col+18] = (unsigned char) _mm256_extract_epi8(output_row0,18);
		filt[0][col+19] = (unsigned char) _mm256_extract_epi8(output_row0,19);
		filt[0][col+20] = (unsigned char) _mm256_extract_epi8(output_row0,20);
		filt[0][col+21] = (unsigned char) _mm256_extract_epi8(output_row0,21);
		filt[1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1,16);
		filt[1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1,17);
		filt[1][col+18] = (unsigned char) _mm256_extract_epi8(output_row1,18);
		filt[1][col+19] = (unsigned char) _mm256_extract_epi8(output_row1,19);
		filt[1][col+20] = (unsigned char) _mm256_extract_epi8(output_row1,20);
		filt[1][col+21] = (unsigned char) _mm256_extract_epi8(output_row1,21);
		  break;
	case 23:
		filt[2][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[2][col+17] = (unsigned char) _mm256_extract_epi8(output,17);
		filt[2][col+18] = (unsigned char) _mm256_extract_epi8(output,18);
		filt[2][col+19] = (unsigned char) _mm256_extract_epi8(output,19);
		filt[2][col+20] = (unsigned char) _mm256_extract_epi8(output,20);
		filt[2][col+21] = (unsigned char) _mm256_extract_epi8(output,21);
		filt[2][col+22] = (unsigned char) _mm256_extract_epi8(output,22);

		filt[0][col+16] = (unsigned char) _mm256_extract_epi8(output_row0,16);
		filt[0][col+17] = (unsigned char) _mm256_extract_epi8(output_row0,17);
		filt[0][col+18] = (unsigned char) _mm256_extract_epi8(output_row0,18);
		filt[0][col+19] = (unsigned char) _mm256_extract_epi8(output_row0,19);
		filt[0][col+20] = (unsigned char) _mm256_extract_epi8(output_row0,20);
		filt[0][col+21] = (unsigned char) _mm256_extract_epi8(output_row0,21);
		filt[0][col+22] = (unsigned char) _mm256_extract_epi8(output_row0,22);

		filt[1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1,16);
		filt[1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1,17);
		filt[1][col+18] = (unsigned char) _mm256_extract_epi8(output_row1,18);
		filt[1][col+19] = (unsigned char) _mm256_extract_epi8(output_row1,19);
		filt[1][col+20] = (unsigned char) _mm256_extract_epi8(output_row1,20);
		filt[1][col+21] = (unsigned char) _mm256_extract_epi8(output_row1,21);
		filt[1][col+22] = (unsigned char) _mm256_extract_epi8(output_row1,22);

		  break;
	case 24:
		filt[2][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[2][col+17] = (unsigned char) _mm256_extract_epi8(output,17);
		filt[2][col+18] = (unsigned char) _mm256_extract_epi8(output,18);
		filt[2][col+19] = (unsigned char) _mm256_extract_epi8(output,19);
		filt[2][col+20] = (unsigned char) _mm256_extract_epi8(output,20);
		filt[2][col+21] = (unsigned char) _mm256_extract_epi8(output,21);
		filt[2][col+22] = (unsigned char) _mm256_extract_epi8(output,22);
		filt[2][col+23] = (unsigned char) _mm256_extract_epi8(output,23);

		filt[0][col+16] = (unsigned char) _mm256_extract_epi8(output_row0,16);
		filt[0][col+17] = (unsigned char) _mm256_extract_epi8(output_row0,17);
		filt[0][col+18] = (unsigned char) _mm256_extract_epi8(output_row0,18);
		filt[0][col+19] = (unsigned char) _mm256_extract_epi8(output_row0,19);
		filt[0][col+20] = (unsigned char) _mm256_extract_epi8(output_row0,20);
		filt[0][col+21] = (unsigned char) _mm256_extract_epi8(output_row0,21);
		filt[0][col+22] = (unsigned char) _mm256_extract_epi8(output_row0,22);
		filt[0][col+23] = (unsigned char) _mm256_extract_epi8(output_row0,23);

		filt[1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1,16);
		filt[1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1,17);
		filt[1][col+18] = (unsigned char) _mm256_extract_epi8(output_row1,18);
		filt[1][col+19] = (unsigned char) _mm256_extract_epi8(output_row1,19);
		filt[1][col+20] = (unsigned char) _mm256_extract_epi8(output_row1,20);
		filt[1][col+21] = (unsigned char) _mm256_extract_epi8(output_row1,21);
		filt[1][col+22] = (unsigned char) _mm256_extract_epi8(output_row1,22);
		filt[1][col+23] = (unsigned char) _mm256_extract_epi8(output_row1,23);

		  break;
	case 25:
		filt[2][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[2][col+17] = (unsigned char) _mm256_extract_epi8(output,17);
		filt[2][col+18] = (unsigned char) _mm256_extract_epi8(output,18);
		filt[2][col+19] = (unsigned char) _mm256_extract_epi8(output,19);
		filt[2][col+20] = (unsigned char) _mm256_extract_epi8(output,20);
		filt[2][col+21] = (unsigned char) _mm256_extract_epi8(output,21);
		filt[2][col+22] = (unsigned char) _mm256_extract_epi8(output,22);
		filt[2][col+23] = (unsigned char) _mm256_extract_epi8(output,23);
		filt[2][col+24] = (unsigned char) _mm256_extract_epi8(output,24);

		filt[0][col+16] = (unsigned char) _mm256_extract_epi8(output_row0,16);
		filt[0][col+17] = (unsigned char) _mm256_extract_epi8(output_row0,17);
		filt[0][col+18] = (unsigned char) _mm256_extract_epi8(output_row0,18);
		filt[0][col+19] = (unsigned char) _mm256_extract_epi8(output_row0,19);
		filt[0][col+20] = (unsigned char) _mm256_extract_epi8(output_row0,20);
		filt[0][col+21] = (unsigned char) _mm256_extract_epi8(output_row0,21);
		filt[0][col+22] = (unsigned char) _mm256_extract_epi8(output_row0,22);
		filt[0][col+23] = (unsigned char) _mm256_extract_epi8(output_row0,23);
		filt[0][col+24] = (unsigned char) _mm256_extract_epi8(output_row0,24);

		filt[1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1,16);
		filt[1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1,17);
		filt[1][col+18] = (unsigned char) _mm256_extract_epi8(output_row1,18);
		filt[1][col+19] = (unsigned char) _mm256_extract_epi8(output_row1,19);
		filt[1][col+20] = (unsigned char) _mm256_extract_epi8(output_row1,20);
		filt[1][col+21] = (unsigned char) _mm256_extract_epi8(output_row1,21);
		filt[1][col+22] = (unsigned char) _mm256_extract_epi8(output_row1,22);
		filt[1][col+23] = (unsigned char) _mm256_extract_epi8(output_row1,23);
		filt[1][col+24] = (unsigned char) _mm256_extract_epi8(output_row1,24);
		  break;
	case 26:
		filt[2][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[2][col+17] = (unsigned char) _mm256_extract_epi8(output,17);
		filt[2][col+18] = (unsigned char) _mm256_extract_epi8(output,18);
		filt[2][col+19] = (unsigned char) _mm256_extract_epi8(output,19);
		filt[2][col+20] = (unsigned char) _mm256_extract_epi8(output,20);
		filt[2][col+21] = (unsigned char) _mm256_extract_epi8(output,21);
		filt[2][col+22] = (unsigned char) _mm256_extract_epi8(output,22);
		filt[2][col+23] = (unsigned char) _mm256_extract_epi8(output,23);
		filt[2][col+24] = (unsigned char) _mm256_extract_epi8(output,24);
		filt[2][col+25] = (unsigned char) _mm256_extract_epi8(output,25);

		filt[0][col+16] = (unsigned char) _mm256_extract_epi8(output_row0,16);
		filt[0][col+17] = (unsigned char) _mm256_extract_epi8(output_row0,17);
		filt[0][col+18] = (unsigned char) _mm256_extract_epi8(output_row0,18);
		filt[0][col+19] = (unsigned char) _mm256_extract_epi8(output_row0,19);
		filt[0][col+20] = (unsigned char) _mm256_extract_epi8(output_row0,20);
		filt[0][col+21] = (unsigned char) _mm256_extract_epi8(output_row0,21);
		filt[0][col+22] = (unsigned char) _mm256_extract_epi8(output_row0,22);
		filt[0][col+23] = (unsigned char) _mm256_extract_epi8(output_row0,23);
		filt[0][col+24] = (unsigned char) _mm256_extract_epi8(output_row0,24);
		filt[0][col+25] = (unsigned char) _mm256_extract_epi8(output_row0,25);

		filt[1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1,16);
		filt[1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1,17);
		filt[1][col+18] = (unsigned char) _mm256_extract_epi8(output_row1,18);
		filt[1][col+19] = (unsigned char) _mm256_extract_epi8(output_row1,19);
		filt[1][col+20] = (unsigned char) _mm256_extract_epi8(output_row1,20);
		filt[1][col+21] = (unsigned char) _mm256_extract_epi8(output_row1,21);
		filt[1][col+22] = (unsigned char) _mm256_extract_epi8(output_row1,22);
		filt[1][col+23] = (unsigned char) _mm256_extract_epi8(output_row1,23);
		filt[1][col+24] = (unsigned char) _mm256_extract_epi8(output_row1,24);
		filt[1][col+25] = (unsigned char) _mm256_extract_epi8(output_row1,25);
		  break;
	case 27:
		filt[2][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[2][col+17] = (unsigned char) _mm256_extract_epi8(output,17);
		filt[2][col+18] = (unsigned char) _mm256_extract_epi8(output,18);
		filt[2][col+19] = (unsigned char) _mm256_extract_epi8(output,19);
		filt[2][col+20] = (unsigned char) _mm256_extract_epi8(output,20);
		filt[2][col+21] = (unsigned char) _mm256_extract_epi8(output,21);
		filt[2][col+22] = (unsigned char) _mm256_extract_epi8(output,22);
		filt[2][col+23] = (unsigned char) _mm256_extract_epi8(output,23);
		filt[2][col+24] = (unsigned char) _mm256_extract_epi8(output,24);
		filt[2][col+25] = (unsigned char) _mm256_extract_epi8(output,25);
		filt[2][col+26] = (unsigned char) _mm256_extract_epi8(output,26);

		filt[0][col+16] = (unsigned char) _mm256_extract_epi8(output_row0,16);
		filt[0][col+17] = (unsigned char) _mm256_extract_epi8(output_row0,17);
		filt[0][col+18] = (unsigned char) _mm256_extract_epi8(output_row0,18);
		filt[0][col+19] = (unsigned char) _mm256_extract_epi8(output_row0,19);
		filt[0][col+20] = (unsigned char) _mm256_extract_epi8(output_row0,20);
		filt[0][col+21] = (unsigned char) _mm256_extract_epi8(output_row0,21);
		filt[0][col+22] = (unsigned char) _mm256_extract_epi8(output_row0,22);
		filt[0][col+23] = (unsigned char) _mm256_extract_epi8(output_row0,23);
		filt[0][col+24] = (unsigned char) _mm256_extract_epi8(output_row0,24);
		filt[0][col+25] = (unsigned char) _mm256_extract_epi8(output_row0,25);
		filt[0][col+26] = (unsigned char) _mm256_extract_epi8(output_row0,26);

		filt[1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1,16);
		filt[1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1,17);
		filt[1][col+18] = (unsigned char) _mm256_extract_epi8(output_row1,18);
		filt[1][col+19] = (unsigned char) _mm256_extract_epi8(output_row1,19);
		filt[1][col+20] = (unsigned char) _mm256_extract_epi8(output_row1,20);
		filt[1][col+21] = (unsigned char) _mm256_extract_epi8(output_row1,21);
		filt[1][col+22] = (unsigned char) _mm256_extract_epi8(output_row1,22);
		filt[1][col+23] = (unsigned char) _mm256_extract_epi8(output_row1,23);
		filt[1][col+24] = (unsigned char) _mm256_extract_epi8(output_row1,24);
		filt[1][col+25] = (unsigned char) _mm256_extract_epi8(output_row1,25);
		filt[1][col+26] = (unsigned char) _mm256_extract_epi8(output_row1,26);
		  break;
	case 28:
		filt[2][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[2][col+17] = (unsigned char) _mm256_extract_epi8(output,17);
		filt[2][col+18] = (unsigned char) _mm256_extract_epi8(output,18);
		filt[2][col+19] = (unsigned char) _mm256_extract_epi8(output,19);
		filt[2][col+20] = (unsigned char) _mm256_extract_epi8(output,20);
		filt[2][col+21] = (unsigned char) _mm256_extract_epi8(output,21);
		filt[2][col+22] = (unsigned char) _mm256_extract_epi8(output,22);
		filt[2][col+23] = (unsigned char) _mm256_extract_epi8(output,23);
		filt[2][col+24] = (unsigned char) _mm256_extract_epi8(output,24);
		filt[2][col+25] = (unsigned char) _mm256_extract_epi8(output,25);
		filt[2][col+26] = (unsigned char) _mm256_extract_epi8(output,26);
		filt[2][col+27] = (unsigned char) _mm256_extract_epi8(output,27);

		filt[0][col+16] = (unsigned char) _mm256_extract_epi8(output_row0,16);
		filt[0][col+17] = (unsigned char) _mm256_extract_epi8(output_row0,17);
		filt[0][col+18] = (unsigned char) _mm256_extract_epi8(output_row0,18);
		filt[0][col+19] = (unsigned char) _mm256_extract_epi8(output_row0,19);
		filt[0][col+20] = (unsigned char) _mm256_extract_epi8(output_row0,20);
		filt[0][col+21] = (unsigned char) _mm256_extract_epi8(output_row0,21);
		filt[0][col+22] = (unsigned char) _mm256_extract_epi8(output_row0,22);
		filt[0][col+23] = (unsigned char) _mm256_extract_epi8(output_row0,23);
		filt[0][col+24] = (unsigned char) _mm256_extract_epi8(output_row0,24);
		filt[0][col+25] = (unsigned char) _mm256_extract_epi8(output_row0,25);
		filt[0][col+26] = (unsigned char) _mm256_extract_epi8(output_row0,26);
		filt[0][col+27] = (unsigned char) _mm256_extract_epi8(output_row0,27);

		filt[1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1,16);
		filt[1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1,17);
		filt[1][col+18] = (unsigned char) _mm256_extract_epi8(output_row1,18);
		filt[1][col+19] = (unsigned char) _mm256_extract_epi8(output_row1,19);
		filt[1][col+20] = (unsigned char) _mm256_extract_epi8(output_row1,20);
		filt[1][col+21] = (unsigned char) _mm256_extract_epi8(output_row1,21);
		filt[1][col+22] = (unsigned char) _mm256_extract_epi8(output_row1,22);
		filt[1][col+23] = (unsigned char) _mm256_extract_epi8(output_row1,23);
		filt[1][col+24] = (unsigned char) _mm256_extract_epi8(output_row1,24);
		filt[1][col+25] = (unsigned char) _mm256_extract_epi8(output_row1,25);
		filt[1][col+26] = (unsigned char) _mm256_extract_epi8(output_row1,26);
		filt[1][col+27] = (unsigned char) _mm256_extract_epi8(output_row1,27);
		  break;
	case 29:
		filt[2][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[2][col+17] = (unsigned char) _mm256_extract_epi8(output,17);
		filt[2][col+18] = (unsigned char) _mm256_extract_epi8(output,18);
		filt[2][col+19] = (unsigned char) _mm256_extract_epi8(output,19);
		filt[2][col+20] = (unsigned char) _mm256_extract_epi8(output,20);
		filt[2][col+21] = (unsigned char) _mm256_extract_epi8(output,21);
		filt[2][col+22] = (unsigned char) _mm256_extract_epi8(output,22);
		filt[2][col+23] = (unsigned char) _mm256_extract_epi8(output,23);
		filt[2][col+24] = (unsigned char) _mm256_extract_epi8(output,24);
		filt[2][col+25] = (unsigned char) _mm256_extract_epi8(output,25);
		filt[2][col+26] = (unsigned char) _mm256_extract_epi8(output,26);
		filt[2][col+27] = (unsigned char) _mm256_extract_epi8(output,27);
		filt[2][col+28] = (unsigned char) _mm256_extract_epi8(output,28);

		filt[0][col+16] = (unsigned char) _mm256_extract_epi8(output_row0,16);
		filt[0][col+17] = (unsigned char) _mm256_extract_epi8(output_row0,17);
		filt[0][col+18] = (unsigned char) _mm256_extract_epi8(output_row0,18);
		filt[0][col+19] = (unsigned char) _mm256_extract_epi8(output_row0,19);
		filt[0][col+20] = (unsigned char) _mm256_extract_epi8(output_row0,20);
		filt[0][col+21] = (unsigned char) _mm256_extract_epi8(output_row0,21);
		filt[0][col+22] = (unsigned char) _mm256_extract_epi8(output_row0,22);
		filt[0][col+23] = (unsigned char) _mm256_extract_epi8(output_row0,23);
		filt[0][col+24] = (unsigned char) _mm256_extract_epi8(output_row0,24);
		filt[0][col+25] = (unsigned char) _mm256_extract_epi8(output_row0,25);
		filt[0][col+26] = (unsigned char) _mm256_extract_epi8(output_row0,26);
		filt[0][col+27] = (unsigned char) _mm256_extract_epi8(output_row0,27);
		filt[0][col+28] = (unsigned char) _mm256_extract_epi8(output_row0,28);

		filt[1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1,16);
		filt[1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1,17);
		filt[1][col+18] = (unsigned char) _mm256_extract_epi8(output_row1,18);
		filt[1][col+19] = (unsigned char) _mm256_extract_epi8(output_row1,19);
		filt[1][col+20] = (unsigned char) _mm256_extract_epi8(output_row1,20);
		filt[1][col+21] = (unsigned char) _mm256_extract_epi8(output_row1,21);
		filt[1][col+22] = (unsigned char) _mm256_extract_epi8(output_row1,22);
		filt[1][col+23] = (unsigned char) _mm256_extract_epi8(output_row1,23);
		filt[1][col+24] = (unsigned char) _mm256_extract_epi8(output_row1,24);
		filt[1][col+25] = (unsigned char) _mm256_extract_epi8(output_row1,25);
		filt[1][col+26] = (unsigned char) _mm256_extract_epi8(output_row1,26);
		filt[1][col+27] = (unsigned char) _mm256_extract_epi8(output_row1,27);
		filt[1][col+28] = (unsigned char) _mm256_extract_epi8(output_row1,28);
		  break;
	case 30:
		filt[2][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[2][col+17] = (unsigned char) _mm256_extract_epi8(output,17);
		filt[2][col+18] = (unsigned char) _mm256_extract_epi8(output,18);
		filt[2][col+19] = (unsigned char) _mm256_extract_epi8(output,19);
		filt[2][col+20] = (unsigned char) _mm256_extract_epi8(output,20);
		filt[2][col+21] = (unsigned char) _mm256_extract_epi8(output,21);
		filt[2][col+22] = (unsigned char) _mm256_extract_epi8(output,22);
		filt[2][col+23] = (unsigned char) _mm256_extract_epi8(output,23);
		filt[2][col+24] = (unsigned char) _mm256_extract_epi8(output,24);
		filt[2][col+25] = (unsigned char) _mm256_extract_epi8(output,25);
		filt[2][col+26] = (unsigned char) _mm256_extract_epi8(output,26);
		filt[2][col+27] = (unsigned char) _mm256_extract_epi8(output,27);
		filt[2][col+28] = (unsigned char) _mm256_extract_epi8(output,28);
		filt[2][col+29] = (unsigned char) _mm256_extract_epi8(output,29);

		filt[0][col+16] = (unsigned char) _mm256_extract_epi8(output_row0,16);
		filt[0][col+17] = (unsigned char) _mm256_extract_epi8(output_row0,17);
		filt[0][col+18] = (unsigned char) _mm256_extract_epi8(output_row0,18);
		filt[0][col+19] = (unsigned char) _mm256_extract_epi8(output_row0,19);
		filt[0][col+20] = (unsigned char) _mm256_extract_epi8(output_row0,20);
		filt[0][col+21] = (unsigned char) _mm256_extract_epi8(output_row0,21);
		filt[0][col+22] = (unsigned char) _mm256_extract_epi8(output_row0,22);
		filt[0][col+23] = (unsigned char) _mm256_extract_epi8(output_row0,23);
		filt[0][col+24] = (unsigned char) _mm256_extract_epi8(output_row0,24);
		filt[0][col+25] = (unsigned char) _mm256_extract_epi8(output_row0,25);
		filt[0][col+26] = (unsigned char) _mm256_extract_epi8(output_row0,26);
		filt[0][col+27] = (unsigned char) _mm256_extract_epi8(output_row0,27);
		filt[0][col+28] = (unsigned char) _mm256_extract_epi8(output_row0,28);
		filt[0][col+29] = (unsigned char) _mm256_extract_epi8(output_row0,29);

		filt[1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1,16);
		filt[1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1,17);
		filt[1][col+18] = (unsigned char) _mm256_extract_epi8(output_row1,18);
		filt[1][col+19] = (unsigned char) _mm256_extract_epi8(output_row1,19);
		filt[1][col+20] = (unsigned char) _mm256_extract_epi8(output_row1,20);
		filt[1][col+21] = (unsigned char) _mm256_extract_epi8(output_row1,21);
		filt[1][col+22] = (unsigned char) _mm256_extract_epi8(output_row1,22);
		filt[1][col+23] = (unsigned char) _mm256_extract_epi8(output_row1,23);
		filt[1][col+24] = (unsigned char) _mm256_extract_epi8(output_row1,24);
		filt[1][col+25] = (unsigned char) _mm256_extract_epi8(output_row1,25);
		filt[1][col+26] = (unsigned char) _mm256_extract_epi8(output_row1,26);
		filt[1][col+27] = (unsigned char) _mm256_extract_epi8(output_row1,27);
		filt[1][col+28] = (unsigned char) _mm256_extract_epi8(output_row1,28);
		filt[1][col+29] = (unsigned char) _mm256_extract_epi8(output_row1,29);
		  break;
	case 31:
		filt[2][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[2][col+17] = (unsigned char) _mm256_extract_epi8(output,17);
		filt[2][col+18] = (unsigned char) _mm256_extract_epi8(output,18);
		filt[2][col+19] = (unsigned char) _mm256_extract_epi8(output,19);
		filt[2][col+20] = (unsigned char) _mm256_extract_epi8(output,20);
		filt[2][col+21] = (unsigned char) _mm256_extract_epi8(output,21);
		filt[2][col+22] = (unsigned char) _mm256_extract_epi8(output,22);
		filt[2][col+23] = (unsigned char) _mm256_extract_epi8(output,23);
		filt[2][col+24] = (unsigned char) _mm256_extract_epi8(output,24);
		filt[2][col+25] = (unsigned char) _mm256_extract_epi8(output,25);
		filt[2][col+26] = (unsigned char) _mm256_extract_epi8(output,26);
		filt[2][col+27] = (unsigned char) _mm256_extract_epi8(output,27);
		filt[2][col+28] = (unsigned char) _mm256_extract_epi8(output,28);
		filt[2][col+29] = (unsigned char) _mm256_extract_epi8(output,29);

		filt[0][col+16] = (unsigned char) _mm256_extract_epi8(output_row0,16);
		filt[0][col+17] = (unsigned char) _mm256_extract_epi8(output_row0,17);
		filt[0][col+18] = (unsigned char) _mm256_extract_epi8(output_row0,18);
		filt[0][col+19] = (unsigned char) _mm256_extract_epi8(output_row0,19);
		filt[0][col+20] = (unsigned char) _mm256_extract_epi8(output_row0,20);
		filt[0][col+21] = (unsigned char) _mm256_extract_epi8(output_row0,21);
		filt[0][col+22] = (unsigned char) _mm256_extract_epi8(output_row0,22);
		filt[0][col+23] = (unsigned char) _mm256_extract_epi8(output_row0,23);
		filt[0][col+24] = (unsigned char) _mm256_extract_epi8(output_row0,24);
		filt[0][col+25] = (unsigned char) _mm256_extract_epi8(output_row0,25);
		filt[0][col+26] = (unsigned char) _mm256_extract_epi8(output_row0,26);
		filt[0][col+27] = (unsigned char) _mm256_extract_epi8(output_row0,27);
		filt[0][col+28] = (unsigned char) _mm256_extract_epi8(output_row0,28);
		filt[0][col+29] = (unsigned char) _mm256_extract_epi8(output_row0,29);

		filt[1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1,16);
		filt[1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1,17);
		filt[1][col+18] = (unsigned char) _mm256_extract_epi8(output_row1,18);
		filt[1][col+19] = (unsigned char) _mm256_extract_epi8(output_row1,19);
		filt[1][col+20] = (unsigned char) _mm256_extract_epi8(output_row1,20);
		filt[1][col+21] = (unsigned char) _mm256_extract_epi8(output_row1,21);
		filt[1][col+22] = (unsigned char) _mm256_extract_epi8(output_row1,22);
		filt[1][col+23] = (unsigned char) _mm256_extract_epi8(output_row1,23);
		filt[1][col+24] = (unsigned char) _mm256_extract_epi8(output_row1,24);
		filt[1][col+25] = (unsigned char) _mm256_extract_epi8(output_row1,25);
		filt[1][col+26] = (unsigned char) _mm256_extract_epi8(output_row1,26);
		filt[1][col+27] = (unsigned char) _mm256_extract_epi8(output_row1,27);
		filt[1][col+28] = (unsigned char) _mm256_extract_epi8(output_row1,28);
		filt[1][col+29] = (unsigned char) _mm256_extract_epi8(output_row1,29);

		int newPixel;
		for (int row=0;row<=2;row++){
		 newPixel = 0;
		for (int rowOffset=-2; rowOffset<=2; rowOffset++) {
			for (int colOffset=-2; colOffset<=2; colOffset++) {

			   if ( ((row+rowOffset)<N) && ((M-1+colOffset)<M) && ((row+rowOffset)>=0) && ((M-1+colOffset)>=0) )
	              newPixel += frame1[row+rowOffset][M-1+colOffset] * gaussianMask[2 + rowOffset][2 + colOffset];

			      }
		        }
	filt[row][M-1] = (unsigned char) (newPixel / divisor);
		}
		  break;
	default:
		printf("\n something went wrong");
	}


	return 0;
}


//in this case, row=N-3 along row=N-2,row=N-1 are computed
//m0_row0 is for N-2
//m0_row1 is for N-1
int loop_reminder_last_rows_high_reminder_values(unsigned char **frame1,unsigned char **filt,const unsigned int M, const unsigned int N, const unsigned int col,const unsigned int REMINDER_ITERATIONS,const unsigned int division_case,const __m256i c0,const __m256i c1,const __m256i c2,const __m256i c0_sh1,const __m256i c1_sh1,const __m256i c2_sh1,const __m256i c0_sh2,const __m256i c1_sh2,const __m256i c2_sh2, const __m256i f,const unsigned int divisor ){

register	__m256i r0,r1,r2,r3,r4,m0,m1,m2,m3,m4,output,output_row0,output_row1,m0_prelude_row0,m0_prelude_row1;


		//const __m256i f  = _mm256_set_epi16(52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759);
		const __m256i mask  = _mm256_set_epi8(0,0,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255);
		const __m256i mask2  = _mm256_set_epi8(0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0);
		const __m256i mask3  = _mm256_set_epi16(0,0,0,0,0,0,0,65535,0,0,0,0,0,0,0,0);
		const __m256i mask4  = _mm256_set_epi8(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,255,0,0,0,0,0,0,0,0,0,0,0,0);
		const __m256i mask5  = _mm256_set_epi8(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
		 __m256i reminder_mask1,reminder_mask2;


reminder_mask1=_mm256_load_si256( (__m256i *) &reminder_msk1[REMINDER_ITERATIONS-1][0]);
reminder_mask2=_mm256_load_si256( (__m256i *) &reminder_msk2[REMINDER_ITERATIONS-1][0]);




	 //1st col iteration
	//load the 5 rows
	r0=_mm256_loadu_si256( (__m256i *) &frame1[N-5][col-2]);
	r1=_mm256_loadu_si256( (__m256i *) &frame1[N-4][col-2]);
	r2=_mm256_loadu_si256( (__m256i *) &frame1[N-3][col-2]);
	r3=_mm256_loadu_si256( (__m256i *) &frame1[N-2][col-2]);
	r4=_mm256_loadu_si256( (__m256i *) &frame1[N-1][col-2]);

	/*
	 * The above load operations load outside of the array bounds; these elements are filled with zeros just after
	 * Furthermore, I add two extra zeros in the end to compute col=N-2 and col=N-1. The last value of col is N-1, not N
	 */

	//AND r0-r4 with reminder_mask
	r0=_mm256_and_si256(r0,reminder_mask1);
	r1=_mm256_and_si256(r1,reminder_mask1);
	r2=_mm256_and_si256(r2,reminder_mask1);
	r3=_mm256_and_si256(r3,reminder_mask1);
	r4=_mm256_and_si256(r4,reminder_mask1);

	//multiply with the mask
		m0=_mm256_maddubs_epi16(r0,c0);
		m1=_mm256_maddubs_epi16(r1,c1);
		m2=_mm256_maddubs_epi16(r2,c2);
		m3=_mm256_maddubs_epi16(r3,c1);
		m4=_mm256_maddubs_epi16(r4,c0);

		//vertical add
		m4=_mm256_add_epi16(m4,m3);
		m4=_mm256_add_epi16(m4,m2);
		m4=_mm256_add_epi16(m4,m1);
		m0=_mm256_add_epi16(m4,m0);

		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
		m4=_mm256_and_si256(m0,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m2=division(division_case,m2,f);

		//and with mask to keep just 0,6,12,18,24
		output = _mm256_and_si256(m2,mask);

		//--------------row=0
		//multiply with the mask
		m1=_mm256_maddubs_epi16(r1,c0);
		m2=_mm256_maddubs_epi16(r2,c1);
		m3=_mm256_maddubs_epi16(r3,c2);
		m4=_mm256_maddubs_epi16(r4,c1);

		//vertical add
		m4=_mm256_add_epi16(m4,m3);
		m4=_mm256_add_epi16(m4,m2);
		m4=_mm256_add_epi16(m4,m1); m0_prelude_row0=m4;

		m1=_mm256_srli_si256(m0_prelude_row0,2);
		m2=_mm256_add_epi16(m1,m0_prelude_row0);

		m1=_mm256_srli_si256(m0_prelude_row0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
		m4=_mm256_and_si256(m0_prelude_row0,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m2=division(division_case,m2,f);

		//and with mask to keep just 0,6,12,18,24
		output_row0 = _mm256_and_si256(m2,mask);

		//--------------row=1
		//multiply with the mask
		m2=_mm256_maddubs_epi16(r2,c0);
		m3=_mm256_maddubs_epi16(r3,c1);
		m4=_mm256_maddubs_epi16(r4,c2);


		//vertical add
		m4=_mm256_add_epi16(m4,m3);
		m4=_mm256_add_epi16(m4,m2);m0_prelude_row1=m4;



		m1=_mm256_srli_si256(m0_prelude_row1,2);
		m2=_mm256_add_epi16(m1,m0_prelude_row1);

		m1=_mm256_srli_si256(m0_prelude_row1,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
		m4=_mm256_and_si256(m0_prelude_row1,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m2=division(division_case,m2,f);

		//and with mask to keep just 0,6,12,18,24
		output_row1 = _mm256_and_si256(m2,mask);

		//2nd col iteration
		//----row=2

		//multiply with the mask
		m0=_mm256_maddubs_epi16(r0,c0_sh1);
		m1=_mm256_maddubs_epi16(r1,c1_sh1);
		m2=_mm256_maddubs_epi16(r2,c2_sh1);
		m3=_mm256_maddubs_epi16(r3,c1_sh1);
		m4=_mm256_maddubs_epi16(r4,c0_sh1);

		//vertical add
		m4=_mm256_add_epi16(m4,m3);
		m4=_mm256_add_epi16(m4,m2);
		m4=_mm256_add_epi16(m4,m1);
		m0=_mm256_add_epi16(m4,m0);


		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
		m4=_mm256_and_si256(m0,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m2=division(division_case,m2,f);

		//and with mask to keep just 0,6,12,18,24
		m2 = _mm256_and_si256(m2,mask);
		m2 = _mm256_slli_si256(m2,1);
		output = _mm256_add_epi8(output,m2);

		//----row=0
		//multiply with the mask
		m1=_mm256_maddubs_epi16(r1,c0_sh1);
		m2=_mm256_maddubs_epi16(r2,c1_sh1);
		m3=_mm256_maddubs_epi16(r3,c2_sh1);
		m4=_mm256_maddubs_epi16(r4,c1_sh1);


		//vertical add
		m4=_mm256_add_epi16(m4,m3);
		m4=_mm256_add_epi16(m4,m2);
		m4=_mm256_add_epi16(m4,m1);m0_prelude_row0=m4;


		m1=_mm256_srli_si256(m0_prelude_row0,2);
		m2=_mm256_add_epi16(m1,m0_prelude_row0);

		m1=_mm256_srli_si256(m0_prelude_row0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
		m4=_mm256_and_si256(m0_prelude_row0,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m2=division(division_case,m2,f);

		//and with mask to keep just 0,6,12,18,24
		m2 = _mm256_and_si256(m2,mask);
		m2 = _mm256_slli_si256(m2,1);
		output_row0 = _mm256_add_epi8(output_row0,m2);

		//----row=1
		//multiply with the mask
		m2=_mm256_maddubs_epi16(r2,c0_sh1);
		m3=_mm256_maddubs_epi16(r3,c1_sh1);
		m4=_mm256_maddubs_epi16(r4,c2_sh1);


		//vertical add
		m4=_mm256_add_epi16(m4,m3);
		m4=_mm256_add_epi16(m4,m2);m0_prelude_row1=m4;


		m1=_mm256_srli_si256(m0_prelude_row1,2);
		m2=_mm256_add_epi16(m1,m0_prelude_row1);

		m1=_mm256_srli_si256(m0_prelude_row1,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
		m4=_mm256_and_si256(m0_prelude_row1,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		//now division of r2/159 follows
		m2=division(division_case,m2,f);

		//and with mask to keep just 0,6,12,18,24
		m2 = _mm256_and_si256(m2,mask);
		m2 = _mm256_slli_si256(m2,1);
		output_row1 = _mm256_add_epi8(output_row1,m2);

                 //3rd col iteration
		//---row=2
		//multiply with the mask
		m0=_mm256_maddubs_epi16(r0,c0_sh2);
		m1=_mm256_maddubs_epi16(r1,c1_sh2);
		m2=_mm256_maddubs_epi16(r2,c2_sh2);
		m3=_mm256_maddubs_epi16(r3,c1_sh2);
		m4=_mm256_maddubs_epi16(r4,c0_sh2);

		//vertical add
		m4=_mm256_add_epi16(m4,m3);
		m4=_mm256_add_epi16(m4,m2);
		m4=_mm256_add_epi16(m4,m1);
		m0=_mm256_add_epi16(m4,m0);


		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
		m4=_mm256_and_si256(m2,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m2=division(division_case,m2,f);

		//and with mask to keep just 2,8,14,20,26
		m2 = _mm256_and_si256(m2,mask2);
		output = _mm256_add_epi8(output,m2);

		//---row=0
		//multiply with the mask
		m1=_mm256_maddubs_epi16(r1,c0_sh2);
		m2=_mm256_maddubs_epi16(r2,c1_sh2);
		m3=_mm256_maddubs_epi16(r3,c2_sh2);
		m4=_mm256_maddubs_epi16(r4,c1_sh2);


		//vertical add
		m4=_mm256_add_epi16(m4,m3);
		m4=_mm256_add_epi16(m4,m2);
		m4=_mm256_add_epi16(m4,m1);m0_prelude_row0=m4;

		m1=_mm256_srli_si256(m0_prelude_row0,2);
		m2=_mm256_add_epi16(m1,m0_prelude_row0);

		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
		m4=_mm256_and_si256(m2,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

		m1=_mm256_srli_si256(m0_prelude_row0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m2=division(division_case,m2,f);

		//and with mask to keep just 2,8,14,20,26
		m2 = _mm256_and_si256(m2,mask2);
		output_row0 = _mm256_add_epi8(output_row0,m2);


		//---row=1
		//multiply with the mask
		m2=_mm256_maddubs_epi16(r2,c0_sh2);
		m3=_mm256_maddubs_epi16(r3,c1_sh2);
		m4=_mm256_maddubs_epi16(r4,c2_sh2);


		//vertical add
		m4=_mm256_add_epi16(m4,m3);
		m4=_mm256_add_epi16(m4,m2);m0_prelude_row1=m4;


		m1=_mm256_srli_si256(m0_prelude_row1,2);
		m2=_mm256_add_epi16(m1,m0_prelude_row1);

		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
		m4=_mm256_and_si256(m2,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

		m1=_mm256_srli_si256(m0_prelude_row1,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m2=division(division_case,m2,f);

		//and with mask to keep just 2,8,14,20,26
		m2 = _mm256_and_si256(m2,mask2);
		output_row1 = _mm256_add_epi8(output_row1,m2);

		//4th col iteration
		//load the 5 rows
		r0=_mm256_loadu_si256( (__m256i *) &frame1[N-5][col+3-2]);
		r1=_mm256_loadu_si256( (__m256i *) &frame1[N-4][col+3-2]);
		r2=_mm256_loadu_si256( (__m256i *) &frame1[N-3][col+3-2]);
		r3=_mm256_loadu_si256( (__m256i *) &frame1[N-2][col+3-2]);
		r4=_mm256_loadu_si256( (__m256i *) &frame1[N-1][col+3-2]);

		//AND r0-r4 with reminder_mask
		r0=_mm256_and_si256(r0,reminder_mask2);
		r1=_mm256_and_si256(r1,reminder_mask2);
		r2=_mm256_and_si256(r2,reminder_mask2);
		r3=_mm256_and_si256(r3,reminder_mask2);
		r4=_mm256_and_si256(r4,reminder_mask2);

		//----row=2
		//multiply with the mask
		m0=_mm256_maddubs_epi16(r0,c0);
		m1=_mm256_maddubs_epi16(r1,c1);
		m2=_mm256_maddubs_epi16(r2,c2);
		m3=_mm256_maddubs_epi16(r3,c1);
		m4=_mm256_maddubs_epi16(r4,c0);

		//vertical add
		m4=_mm256_add_epi16(m4,m3);
		m4=_mm256_add_epi16(m4,m2);
		m4=_mm256_add_epi16(m4,m1);
		m0=_mm256_add_epi16(m4,m0);


		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
		m4=_mm256_and_si256(m0,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m2=division(division_case,m2,f);

		//and with mask to keep just 0,6,12,18,24
		m2 = _mm256_and_si256(m2,mask);
		m2 = _mm256_slli_si256(m2,3);
		output = _mm256_add_epi8(output,m2);

		//----row=0
		//multiply with the mask
		m1=_mm256_maddubs_epi16(r1,c0);
		m2=_mm256_maddubs_epi16(r2,c1);
		m3=_mm256_maddubs_epi16(r3,c2);
		m4=_mm256_maddubs_epi16(r4,c1);

		//vertical add
		m4=_mm256_add_epi16(m4,m3);
		m4=_mm256_add_epi16(m4,m2);
		m4=_mm256_add_epi16(m4,m1);m0_prelude_row0=m4;


		m1=_mm256_srli_si256(m0_prelude_row0,2);
		m2=_mm256_add_epi16(m1,m0_prelude_row0);

		m1=_mm256_srli_si256(m0_prelude_row0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
		m4=_mm256_and_si256(m0_prelude_row0,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m2=division(division_case,m2,f);

		//and with mask to keep just 0,6,12,18,24
		m2 = _mm256_and_si256(m2,mask);
		m2 = _mm256_slli_si256(m2,3);
		output_row0 = _mm256_add_epi8(output_row0,m2);

		//----row=1
		//multiply with the mask
		m2=_mm256_maddubs_epi16(r2,c0);
		m3=_mm256_maddubs_epi16(r3,c1);
		m4=_mm256_maddubs_epi16(r4,c2);


		//vertical add
		m4=_mm256_add_epi16(m4,m3);
		m4=_mm256_add_epi16(m4,m2);m0_prelude_row1=m4;


		m1=_mm256_srli_si256(m0_prelude_row1,2);
		m2=_mm256_add_epi16(m1,m0_prelude_row1);

		m1=_mm256_srli_si256(m0_prelude_row1,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
		m4=_mm256_and_si256(m0_prelude_row1,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m2=division(division_case,m2,f);

		//and with mask to keep just 0,6,12,18,24
		m2 = _mm256_and_si256(m2,mask);
		m2 = _mm256_slli_si256(m2,3);
		output_row1 = _mm256_add_epi8(output_row1,m2);

		//5th col iteration
		//----row=2
		//multiply with the mask
		m0=_mm256_maddubs_epi16(r0,c0_sh1);
		m1=_mm256_maddubs_epi16(r1,c1_sh1);
		m2=_mm256_maddubs_epi16(r2,c2_sh1);
		m3=_mm256_maddubs_epi16(r3,c1_sh1);
		m4=_mm256_maddubs_epi16(r4,c0_sh1);

		//vertical add
		m4=_mm256_add_epi16(m4,m3);
		m4=_mm256_add_epi16(m4,m2);
		m4=_mm256_add_epi16(m4,m1);
		m0=_mm256_add_epi16(m4,m0);


		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
		m4=_mm256_and_si256(m0,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m2=division(division_case,m2,f);

		//and with mask to keep just 0,6,12,18,24
		m2 = _mm256_and_si256(m2,mask);
		m1 = _mm256_slli_si256(m2,4);
		output = _mm256_add_epi8(output,m1);

		//output = _mm256_insert_epi8(output,_mm256_extract_epi8(m2,12),16);
		m2=_mm256_and_si256(m2,mask4);
		m2=_mm256_permute2f128_si256(m2,m2,1);
		m2=_mm256_srli_si256(m2,12);
		output=_mm256_add_epi8(output,m2);

		//----row=0
		//multiply with the mask
		m1=_mm256_maddubs_epi16(r1,c0_sh1);
		m2=_mm256_maddubs_epi16(r2,c1_sh1);
		m3=_mm256_maddubs_epi16(r3,c2_sh1);
		m4=_mm256_maddubs_epi16(r4,c1_sh1);


		//vertical add
		m4=_mm256_add_epi16(m4,m3);
		m4=_mm256_add_epi16(m4,m2);
		m4=_mm256_add_epi16(m4,m1);m0_prelude_row0=m4;


		m1=_mm256_srli_si256(m0_prelude_row0,2);
		m2=_mm256_add_epi16(m1,m0_prelude_row0);

		m1=_mm256_srli_si256(m0_prelude_row0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
		m4=_mm256_and_si256(m0_prelude_row0,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m2=division(division_case,m2,f);

		//and with mask to keep just 0,6,12,18,24
		m2 = _mm256_and_si256(m2,mask);
		m1 = _mm256_slli_si256(m2,4);
		output_row0 = _mm256_add_epi8(output_row0,m1);

		//output = _mm256_insert_epi8(output,_mm256_extract_epi8(m2,12),16);
		m2=_mm256_and_si256(m2,mask4);
		m2=_mm256_permute2f128_si256(m2,m2,1);
		m2=_mm256_srli_si256(m2,12);
		output_row0=_mm256_add_epi8(output_row0,m2);

		//----row=1
		//multiply with the mask
		m2=_mm256_maddubs_epi16(r2,c0_sh1);
		m3=_mm256_maddubs_epi16(r3,c1_sh1);
		m4=_mm256_maddubs_epi16(r4,c2_sh1);


		//vertical add
		m4=_mm256_add_epi16(m4,m3);
		m4=_mm256_add_epi16(m4,m2);m0_prelude_row1=m4;


		m1=_mm256_srli_si256(m0_prelude_row1,2);
		m2=_mm256_add_epi16(m1,m0_prelude_row1);

		m1=_mm256_srli_si256(m0_prelude_row1,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
		m4=_mm256_and_si256(m0_prelude_row1,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m2=division(division_case,m2,f);

		//and with mask to keep just 0,6,12,18,24
		m2 = _mm256_and_si256(m2,mask);
		m1 = _mm256_slli_si256(m2,4);
		output_row1 = _mm256_add_epi8(output_row1,m1);

		//output = _mm256_insert_epi8(output,_mm256_extract_epi8(m2,12),16);
		m2=_mm256_and_si256(m2,mask4);
		m2=_mm256_permute2f128_si256(m2,m2,1);
		m2=_mm256_srli_si256(m2,12);
		output_row1=_mm256_add_epi8(output_row1,m2);

                 //6th col iteration
		//---row=2
		//multiply with the mask
		m0=_mm256_maddubs_epi16(r0,c0_sh2);
		m1=_mm256_maddubs_epi16(r1,c1_sh2);
		m2=_mm256_maddubs_epi16(r2,c2_sh2);
		m3=_mm256_maddubs_epi16(r3,c1_sh2);
		m4=_mm256_maddubs_epi16(r4,c0_sh2);

		//vertical add
		m4=_mm256_add_epi16(m4,m3);
		m4=_mm256_add_epi16(m4,m2);
		m4=_mm256_add_epi16(m4,m1);
		m0=_mm256_add_epi16(m4,m0);


		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);
		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
		m4=_mm256_and_si256(m2,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m2=division(division_case,m2,f);

		//and with mask to keep just 2,8,14,20,26
		m2 = _mm256_and_si256(m2,mask2);
		m1 = _mm256_slli_si256(m2,3);
		output = _mm256_add_epi8(output,m1);

		//output = _mm256_insert_epi8(output,_mm256_extract_epi8(m2,14),17);
		m2=_mm256_and_si256(m2,mask5);
		m2=_mm256_permute2f128_si256(m2,m2,1);
		m2=_mm256_srli_si256(m2,13);
		output=_mm256_add_epi8(output,m2);

		//_mm256_storeu_si256( (__m256i *) &filt[row][col],output);


		//---row=0
		//multiply with the mask
		m1=_mm256_maddubs_epi16(r1,c0_sh2);
		m2=_mm256_maddubs_epi16(r2,c1_sh2);
		m3=_mm256_maddubs_epi16(r3,c2_sh2);
		m4=_mm256_maddubs_epi16(r4,c1_sh2);


		//vertical add
		m4=_mm256_add_epi16(m4,m3);
		m4=_mm256_add_epi16(m4,m2);
		m4=_mm256_add_epi16(m4,m1);m0_prelude_row0=m4;


		m1=_mm256_srli_si256(m0_prelude_row0,2);
		m2=_mm256_add_epi16(m1,m0_prelude_row0);
		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
		m4=_mm256_and_si256(m2,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

		m1=_mm256_srli_si256(m0_prelude_row0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m2=division(division_case,m2,f);

		//and with mask to keep just 2,8,14,20,26
		m2 = _mm256_and_si256(m2,mask2);
		m1 = _mm256_slli_si256(m2,3);
		output_row0 = _mm256_add_epi8(output_row0,m1);

		//output = _mm256_insert_epi8(output,_mm256_extract_epi8(m2,14),17);
		m2=_mm256_and_si256(m2,mask5);
		m2=_mm256_permute2f128_si256(m2,m2,1);
		m2=_mm256_srli_si256(m2,13);
		output_row0=_mm256_add_epi8(output_row0,m2);

		//_mm256_storeu_si256( (__m256i *) &filt[N-2][col],output_row0);

		//---row=1
		//multiply with the mask
		m2=_mm256_maddubs_epi16(r2,c0_sh2);
		m3=_mm256_maddubs_epi16(r3,c1_sh2);
		m4=_mm256_maddubs_epi16(r4,c2_sh2);


		//vertical add
		m4=_mm256_add_epi16(m4,m3);
		m4=_mm256_add_epi16(m4,m2);m0_prelude_row1=m4;

		m1=_mm256_srli_si256(m0_prelude_row1,2);
		m2=_mm256_add_epi16(m1,m0_prelude_row1);
		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
		m4=_mm256_and_si256(m2,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

		m1=_mm256_srli_si256(m0_prelude_row1,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m2=division(division_case,m2,f);

		//and with mask to keep just 2,8,14,20,26
		m2 = _mm256_and_si256(m2,mask2);
		m1 = _mm256_slli_si256(m2,3);
		output_row1 = _mm256_add_epi8(output_row1,m1);

		//output = _mm256_insert_epi8(output,_mm256_extract_epi8(m2,14),17);
		m2=_mm256_and_si256(m2,mask5);
		m2=_mm256_permute2f128_si256(m2,m2,1);
		m2=_mm256_srli_si256(m2,13);
		output_row1=_mm256_add_epi8(output_row1,m2);

		//_mm256_storeu_si256( (__m256i *) &filt[N-1][col],output_row1);

	//_mm256_storeu_si256( (__m256i *) &filt[row][col],output);
	_mm_storeu_si128( (__m128i *) &filt[N-3][col],_mm256_extractf128_si256(output, 0)); //store low 128bit - 16pixels
	_mm_storeu_si128( (__m128i *) &filt[N-2][col],_mm256_extractf128_si256(output_row0, 0)); //store low 128bit - 16pixels
	_mm_storeu_si128( (__m128i *) &filt[N-1][col],_mm256_extractf128_si256(output_row1, 0)); //store low 128bit - 16pixels

	switch (REMINDER_ITERATIONS){
	case 16:
	  break;
	case 17:
		filt[N-3][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[N-2][col+16] = (unsigned char) _mm256_extract_epi8(output_row0,16);
		filt[N-1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1,16);
		  break;
	case 18:
		filt[N-3][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[N-3][col+17] = (unsigned char) _mm256_extract_epi8(output,17);

		filt[N-2][col+16] = (unsigned char) _mm256_extract_epi8(output_row0,16);
		filt[N-2][col+17] = (unsigned char) _mm256_extract_epi8(output_row0,17);

		filt[N-1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1,16);
		filt[N-1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1,17);
		  break;
	case 19:
		filt[N-3][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[N-3][col+17] = (unsigned char) _mm256_extract_epi8(output,17);
		filt[N-3][col+18] = (unsigned char) _mm256_extract_epi8(output,18);

		filt[N-2][col+16] = (unsigned char) _mm256_extract_epi8(output_row0,16);
		filt[N-2][col+17] = (unsigned char) _mm256_extract_epi8(output_row0,17);
		filt[N-2][col+18] = (unsigned char) _mm256_extract_epi8(output_row0,18);

		filt[N-1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1,16);
		filt[N-1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1,17);
		filt[N-1][col+18] = (unsigned char) _mm256_extract_epi8(output_row1,18);
		  break;
	case 20:
		filt[N-3][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[N-3][col+17] = (unsigned char) _mm256_extract_epi8(output,17);
		filt[N-3][col+18] = (unsigned char) _mm256_extract_epi8(output,18);
		filt[N-3][col+19] = (unsigned char) _mm256_extract_epi8(output,19);

		filt[N-2][col+16] = (unsigned char) _mm256_extract_epi8(output_row0,16);
		filt[N-2][col+17] = (unsigned char) _mm256_extract_epi8(output_row0,17);
		filt[N-2][col+18] = (unsigned char) _mm256_extract_epi8(output_row0,18);
		filt[N-2][col+19] = (unsigned char) _mm256_extract_epi8(output_row0,19);

		filt[N-1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1,16);
		filt[N-1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1,17);
		filt[N-1][col+18] = (unsigned char) _mm256_extract_epi8(output_row1,18);
		filt[N-1][col+19] = (unsigned char) _mm256_extract_epi8(output_row1,19);
		  break;
	case 21:
		filt[N-3][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[N-3][col+17] = (unsigned char) _mm256_extract_epi8(output,17);
		filt[N-3][col+18] = (unsigned char) _mm256_extract_epi8(output,18);
		filt[N-3][col+19] = (unsigned char) _mm256_extract_epi8(output,19);
		filt[N-3][col+20] = (unsigned char) _mm256_extract_epi8(output,20);
		filt[N-2][col+16] = (unsigned char) _mm256_extract_epi8(output_row0,16);
		filt[N-2][col+17] = (unsigned char) _mm256_extract_epi8(output_row0,17);
		filt[N-2][col+18] = (unsigned char) _mm256_extract_epi8(output_row0,18);
		filt[N-2][col+19] = (unsigned char) _mm256_extract_epi8(output_row0,19);
		filt[N-2][col+20] = (unsigned char) _mm256_extract_epi8(output_row0,20);
		filt[N-1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1,16);
		filt[N-1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1,17);
		filt[N-1][col+18] = (unsigned char) _mm256_extract_epi8(output_row1,18);
		filt[N-1][col+19] = (unsigned char) _mm256_extract_epi8(output_row1,19);
		filt[N-1][col+20] = (unsigned char) _mm256_extract_epi8(output_row1,20);
		  break;
	case 22:
		filt[N-3][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[N-3][col+17] = (unsigned char) _mm256_extract_epi8(output,17);
		filt[N-3][col+18] = (unsigned char) _mm256_extract_epi8(output,18);
		filt[N-3][col+19] = (unsigned char) _mm256_extract_epi8(output,19);
		filt[N-3][col+20] = (unsigned char) _mm256_extract_epi8(output,20);
		filt[N-3][col+21] = (unsigned char) _mm256_extract_epi8(output,21);
		filt[N-2][col+16] = (unsigned char) _mm256_extract_epi8(output_row0,16);
		filt[N-2][col+17] = (unsigned char) _mm256_extract_epi8(output_row0,17);
		filt[N-2][col+18] = (unsigned char) _mm256_extract_epi8(output_row0,18);
		filt[N-2][col+19] = (unsigned char) _mm256_extract_epi8(output_row0,19);
		filt[N-2][col+20] = (unsigned char) _mm256_extract_epi8(output_row0,20);
		filt[N-2][col+21] = (unsigned char) _mm256_extract_epi8(output_row0,21);
		filt[N-1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1,16);
		filt[N-1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1,17);
		filt[N-1][col+18] = (unsigned char) _mm256_extract_epi8(output_row1,18);
		filt[N-1][col+19] = (unsigned char) _mm256_extract_epi8(output_row1,19);
		filt[N-1][col+20] = (unsigned char) _mm256_extract_epi8(output_row1,20);
		filt[N-1][col+21] = (unsigned char) _mm256_extract_epi8(output_row1,21);
		  break;
	case 23:
		filt[N-3][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[N-3][col+17] = (unsigned char) _mm256_extract_epi8(output,17);
		filt[N-3][col+18] = (unsigned char) _mm256_extract_epi8(output,18);
		filt[N-3][col+19] = (unsigned char) _mm256_extract_epi8(output,19);
		filt[N-3][col+20] = (unsigned char) _mm256_extract_epi8(output,20);
		filt[N-3][col+21] = (unsigned char) _mm256_extract_epi8(output,21);
		filt[N-3][col+22] = (unsigned char) _mm256_extract_epi8(output,22);

		filt[N-2][col+16] = (unsigned char) _mm256_extract_epi8(output_row0,16);
		filt[N-2][col+17] = (unsigned char) _mm256_extract_epi8(output_row0,17);
		filt[N-2][col+18] = (unsigned char) _mm256_extract_epi8(output_row0,18);
		filt[N-2][col+19] = (unsigned char) _mm256_extract_epi8(output_row0,19);
		filt[N-2][col+20] = (unsigned char) _mm256_extract_epi8(output_row0,20);
		filt[N-2][col+21] = (unsigned char) _mm256_extract_epi8(output_row0,21);
		filt[N-2][col+22] = (unsigned char) _mm256_extract_epi8(output_row0,22);

		filt[N-1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1,16);
		filt[N-1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1,17);
		filt[N-1][col+18] = (unsigned char) _mm256_extract_epi8(output_row1,18);
		filt[N-1][col+19] = (unsigned char) _mm256_extract_epi8(output_row1,19);
		filt[N-1][col+20] = (unsigned char) _mm256_extract_epi8(output_row1,20);
		filt[N-1][col+21] = (unsigned char) _mm256_extract_epi8(output_row1,21);
		filt[N-1][col+22] = (unsigned char) _mm256_extract_epi8(output_row1,22);

		  break;
	case 24:
		filt[N-3][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[N-3][col+17] = (unsigned char) _mm256_extract_epi8(output,17);
		filt[N-3][col+18] = (unsigned char) _mm256_extract_epi8(output,18);
		filt[N-3][col+19] = (unsigned char) _mm256_extract_epi8(output,19);
		filt[N-3][col+20] = (unsigned char) _mm256_extract_epi8(output,20);
		filt[N-3][col+21] = (unsigned char) _mm256_extract_epi8(output,21);
		filt[N-3][col+22] = (unsigned char) _mm256_extract_epi8(output,22);
		filt[N-3][col+23] = (unsigned char) _mm256_extract_epi8(output,23);

		filt[N-2][col+16] = (unsigned char) _mm256_extract_epi8(output_row0,16);
		filt[N-2][col+17] = (unsigned char) _mm256_extract_epi8(output_row0,17);
		filt[N-2][col+18] = (unsigned char) _mm256_extract_epi8(output_row0,18);
		filt[N-2][col+19] = (unsigned char) _mm256_extract_epi8(output_row0,19);
		filt[N-2][col+20] = (unsigned char) _mm256_extract_epi8(output_row0,20);
		filt[N-2][col+21] = (unsigned char) _mm256_extract_epi8(output_row0,21);
		filt[N-2][col+22] = (unsigned char) _mm256_extract_epi8(output_row0,22);
		filt[N-2][col+23] = (unsigned char) _mm256_extract_epi8(output_row0,23);

		filt[N-1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1,16);
		filt[N-1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1,17);
		filt[N-1][col+18] = (unsigned char) _mm256_extract_epi8(output_row1,18);
		filt[N-1][col+19] = (unsigned char) _mm256_extract_epi8(output_row1,19);
		filt[N-1][col+20] = (unsigned char) _mm256_extract_epi8(output_row1,20);
		filt[N-1][col+21] = (unsigned char) _mm256_extract_epi8(output_row1,21);
		filt[N-1][col+22] = (unsigned char) _mm256_extract_epi8(output_row1,22);
		filt[N-1][col+23] = (unsigned char) _mm256_extract_epi8(output_row1,23);

		  break;
	case 25:
		filt[N-3][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[N-3][col+17] = (unsigned char) _mm256_extract_epi8(output,17);
		filt[N-3][col+18] = (unsigned char) _mm256_extract_epi8(output,18);
		filt[N-3][col+19] = (unsigned char) _mm256_extract_epi8(output,19);
		filt[N-3][col+20] = (unsigned char) _mm256_extract_epi8(output,20);
		filt[N-3][col+21] = (unsigned char) _mm256_extract_epi8(output,21);
		filt[N-3][col+22] = (unsigned char) _mm256_extract_epi8(output,22);
		filt[N-3][col+23] = (unsigned char) _mm256_extract_epi8(output,23);
		filt[N-3][col+24] = (unsigned char) _mm256_extract_epi8(output,24);

		filt[N-2][col+16] = (unsigned char) _mm256_extract_epi8(output_row0,16);
		filt[N-2][col+17] = (unsigned char) _mm256_extract_epi8(output_row0,17);
		filt[N-2][col+18] = (unsigned char) _mm256_extract_epi8(output_row0,18);
		filt[N-2][col+19] = (unsigned char) _mm256_extract_epi8(output_row0,19);
		filt[N-2][col+20] = (unsigned char) _mm256_extract_epi8(output_row0,20);
		filt[N-2][col+21] = (unsigned char) _mm256_extract_epi8(output_row0,21);
		filt[N-2][col+22] = (unsigned char) _mm256_extract_epi8(output_row0,22);
		filt[N-2][col+23] = (unsigned char) _mm256_extract_epi8(output_row0,23);
		filt[N-2][col+24] = (unsigned char) _mm256_extract_epi8(output_row0,24);

		filt[N-1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1,16);
		filt[N-1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1,17);
		filt[N-1][col+18] = (unsigned char) _mm256_extract_epi8(output_row1,18);
		filt[N-1][col+19] = (unsigned char) _mm256_extract_epi8(output_row1,19);
		filt[N-1][col+20] = (unsigned char) _mm256_extract_epi8(output_row1,20);
		filt[N-1][col+21] = (unsigned char) _mm256_extract_epi8(output_row1,21);
		filt[N-1][col+22] = (unsigned char) _mm256_extract_epi8(output_row1,22);
		filt[N-1][col+23] = (unsigned char) _mm256_extract_epi8(output_row1,23);
		filt[N-1][col+24] = (unsigned char) _mm256_extract_epi8(output_row1,24);
		  break;
	case 26:
		filt[N-3][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[N-3][col+17] = (unsigned char) _mm256_extract_epi8(output,17);
		filt[N-3][col+18] = (unsigned char) _mm256_extract_epi8(output,18);
		filt[N-3][col+19] = (unsigned char) _mm256_extract_epi8(output,19);
		filt[N-3][col+20] = (unsigned char) _mm256_extract_epi8(output,20);
		filt[N-3][col+21] = (unsigned char) _mm256_extract_epi8(output,21);
		filt[N-3][col+22] = (unsigned char) _mm256_extract_epi8(output,22);
		filt[N-3][col+23] = (unsigned char) _mm256_extract_epi8(output,23);
		filt[N-3][col+24] = (unsigned char) _mm256_extract_epi8(output,24);
		filt[N-3][col+25] = (unsigned char) _mm256_extract_epi8(output,25);

		filt[N-2][col+16] = (unsigned char) _mm256_extract_epi8(output_row0,16);
		filt[N-2][col+17] = (unsigned char) _mm256_extract_epi8(output_row0,17);
		filt[N-2][col+18] = (unsigned char) _mm256_extract_epi8(output_row0,18);
		filt[N-2][col+19] = (unsigned char) _mm256_extract_epi8(output_row0,19);
		filt[N-2][col+20] = (unsigned char) _mm256_extract_epi8(output_row0,20);
		filt[N-2][col+21] = (unsigned char) _mm256_extract_epi8(output_row0,21);
		filt[N-2][col+22] = (unsigned char) _mm256_extract_epi8(output_row0,22);
		filt[N-2][col+23] = (unsigned char) _mm256_extract_epi8(output_row0,23);
		filt[N-2][col+24] = (unsigned char) _mm256_extract_epi8(output_row0,24);
		filt[N-2][col+25] = (unsigned char) _mm256_extract_epi8(output_row0,25);

		filt[N-1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1,16);
		filt[N-1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1,17);
		filt[N-1][col+18] = (unsigned char) _mm256_extract_epi8(output_row1,18);
		filt[N-1][col+19] = (unsigned char) _mm256_extract_epi8(output_row1,19);
		filt[N-1][col+20] = (unsigned char) _mm256_extract_epi8(output_row1,20);
		filt[N-1][col+21] = (unsigned char) _mm256_extract_epi8(output_row1,21);
		filt[N-1][col+22] = (unsigned char) _mm256_extract_epi8(output_row1,22);
		filt[N-1][col+23] = (unsigned char) _mm256_extract_epi8(output_row1,23);
		filt[N-1][col+24] = (unsigned char) _mm256_extract_epi8(output_row1,24);
		filt[N-1][col+25] = (unsigned char) _mm256_extract_epi8(output_row1,25);
		  break;
	case 27:
		filt[N-3][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[N-3][col+17] = (unsigned char) _mm256_extract_epi8(output,17);
		filt[N-3][col+18] = (unsigned char) _mm256_extract_epi8(output,18);
		filt[N-3][col+19] = (unsigned char) _mm256_extract_epi8(output,19);
		filt[N-3][col+20] = (unsigned char) _mm256_extract_epi8(output,20);
		filt[N-3][col+21] = (unsigned char) _mm256_extract_epi8(output,21);
		filt[N-3][col+22] = (unsigned char) _mm256_extract_epi8(output,22);
		filt[N-3][col+23] = (unsigned char) _mm256_extract_epi8(output,23);
		filt[N-3][col+24] = (unsigned char) _mm256_extract_epi8(output,24);
		filt[N-3][col+25] = (unsigned char) _mm256_extract_epi8(output,25);
		filt[N-3][col+26] = (unsigned char) _mm256_extract_epi8(output,26);

		filt[N-2][col+16] = (unsigned char) _mm256_extract_epi8(output_row0,16);
		filt[N-2][col+17] = (unsigned char) _mm256_extract_epi8(output_row0,17);
		filt[N-2][col+18] = (unsigned char) _mm256_extract_epi8(output_row0,18);
		filt[N-2][col+19] = (unsigned char) _mm256_extract_epi8(output_row0,19);
		filt[N-2][col+20] = (unsigned char) _mm256_extract_epi8(output_row0,20);
		filt[N-2][col+21] = (unsigned char) _mm256_extract_epi8(output_row0,21);
		filt[N-2][col+22] = (unsigned char) _mm256_extract_epi8(output_row0,22);
		filt[N-2][col+23] = (unsigned char) _mm256_extract_epi8(output_row0,23);
		filt[N-2][col+24] = (unsigned char) _mm256_extract_epi8(output_row0,24);
		filt[N-2][col+25] = (unsigned char) _mm256_extract_epi8(output_row0,25);
		filt[N-2][col+26] = (unsigned char) _mm256_extract_epi8(output_row0,26);

		filt[N-1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1,16);
		filt[N-1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1,17);
		filt[N-1][col+18] = (unsigned char) _mm256_extract_epi8(output_row1,18);
		filt[N-1][col+19] = (unsigned char) _mm256_extract_epi8(output_row1,19);
		filt[N-1][col+20] = (unsigned char) _mm256_extract_epi8(output_row1,20);
		filt[N-1][col+21] = (unsigned char) _mm256_extract_epi8(output_row1,21);
		filt[N-1][col+22] = (unsigned char) _mm256_extract_epi8(output_row1,22);
		filt[N-1][col+23] = (unsigned char) _mm256_extract_epi8(output_row1,23);
		filt[N-1][col+24] = (unsigned char) _mm256_extract_epi8(output_row1,24);
		filt[N-1][col+25] = (unsigned char) _mm256_extract_epi8(output_row1,25);
		filt[N-1][col+26] = (unsigned char) _mm256_extract_epi8(output_row1,26);
		  break;
	case 28:
		filt[N-3][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[N-3][col+17] = (unsigned char) _mm256_extract_epi8(output,17);
		filt[N-3][col+18] = (unsigned char) _mm256_extract_epi8(output,18);
		filt[N-3][col+19] = (unsigned char) _mm256_extract_epi8(output,19);
		filt[N-3][col+20] = (unsigned char) _mm256_extract_epi8(output,20);
		filt[N-3][col+21] = (unsigned char) _mm256_extract_epi8(output,21);
		filt[N-3][col+22] = (unsigned char) _mm256_extract_epi8(output,22);
		filt[N-3][col+23] = (unsigned char) _mm256_extract_epi8(output,23);
		filt[N-3][col+24] = (unsigned char) _mm256_extract_epi8(output,24);
		filt[N-3][col+25] = (unsigned char) _mm256_extract_epi8(output,25);
		filt[N-3][col+26] = (unsigned char) _mm256_extract_epi8(output,26);
		filt[N-3][col+27] = (unsigned char) _mm256_extract_epi8(output,27);

		filt[N-2][col+16] = (unsigned char) _mm256_extract_epi8(output_row0,16);
		filt[N-2][col+17] = (unsigned char) _mm256_extract_epi8(output_row0,17);
		filt[N-2][col+18] = (unsigned char) _mm256_extract_epi8(output_row0,18);
		filt[N-2][col+19] = (unsigned char) _mm256_extract_epi8(output_row0,19);
		filt[N-2][col+20] = (unsigned char) _mm256_extract_epi8(output_row0,20);
		filt[N-2][col+21] = (unsigned char) _mm256_extract_epi8(output_row0,21);
		filt[N-2][col+22] = (unsigned char) _mm256_extract_epi8(output_row0,22);
		filt[N-2][col+23] = (unsigned char) _mm256_extract_epi8(output_row0,23);
		filt[N-2][col+24] = (unsigned char) _mm256_extract_epi8(output_row0,24);
		filt[N-2][col+25] = (unsigned char) _mm256_extract_epi8(output_row0,25);
		filt[N-2][col+26] = (unsigned char) _mm256_extract_epi8(output_row0,26);
		filt[N-2][col+27] = (unsigned char) _mm256_extract_epi8(output_row0,27);

		filt[N-1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1,16);
		filt[N-1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1,17);
		filt[N-1][col+18] = (unsigned char) _mm256_extract_epi8(output_row1,18);
		filt[N-1][col+19] = (unsigned char) _mm256_extract_epi8(output_row1,19);
		filt[N-1][col+20] = (unsigned char) _mm256_extract_epi8(output_row1,20);
		filt[N-1][col+21] = (unsigned char) _mm256_extract_epi8(output_row1,21);
		filt[N-1][col+22] = (unsigned char) _mm256_extract_epi8(output_row1,22);
		filt[N-1][col+23] = (unsigned char) _mm256_extract_epi8(output_row1,23);
		filt[N-1][col+24] = (unsigned char) _mm256_extract_epi8(output_row1,24);
		filt[N-1][col+25] = (unsigned char) _mm256_extract_epi8(output_row1,25);
		filt[N-1][col+26] = (unsigned char) _mm256_extract_epi8(output_row1,26);
		filt[N-1][col+27] = (unsigned char) _mm256_extract_epi8(output_row1,27);
		  break;
	case 29:
		filt[N-3][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[N-3][col+17] = (unsigned char) _mm256_extract_epi8(output,17);
		filt[N-3][col+18] = (unsigned char) _mm256_extract_epi8(output,18);
		filt[N-3][col+19] = (unsigned char) _mm256_extract_epi8(output,19);
		filt[N-3][col+20] = (unsigned char) _mm256_extract_epi8(output,20);
		filt[N-3][col+21] = (unsigned char) _mm256_extract_epi8(output,21);
		filt[N-3][col+22] = (unsigned char) _mm256_extract_epi8(output,22);
		filt[N-3][col+23] = (unsigned char) _mm256_extract_epi8(output,23);
		filt[N-3][col+24] = (unsigned char) _mm256_extract_epi8(output,24);
		filt[N-3][col+25] = (unsigned char) _mm256_extract_epi8(output,25);
		filt[N-3][col+26] = (unsigned char) _mm256_extract_epi8(output,26);
		filt[N-3][col+27] = (unsigned char) _mm256_extract_epi8(output,27);
		filt[N-3][col+28] = (unsigned char) _mm256_extract_epi8(output,28);

		filt[N-2][col+16] = (unsigned char) _mm256_extract_epi8(output_row0,16);
		filt[N-2][col+17] = (unsigned char) _mm256_extract_epi8(output_row0,17);
		filt[N-2][col+18] = (unsigned char) _mm256_extract_epi8(output_row0,18);
		filt[N-2][col+19] = (unsigned char) _mm256_extract_epi8(output_row0,19);
		filt[N-2][col+20] = (unsigned char) _mm256_extract_epi8(output_row0,20);
		filt[N-2][col+21] = (unsigned char) _mm256_extract_epi8(output_row0,21);
		filt[N-2][col+22] = (unsigned char) _mm256_extract_epi8(output_row0,22);
		filt[N-2][col+23] = (unsigned char) _mm256_extract_epi8(output_row0,23);
		filt[N-2][col+24] = (unsigned char) _mm256_extract_epi8(output_row0,24);
		filt[N-2][col+25] = (unsigned char) _mm256_extract_epi8(output_row0,25);
		filt[N-2][col+26] = (unsigned char) _mm256_extract_epi8(output_row0,26);
		filt[N-2][col+27] = (unsigned char) _mm256_extract_epi8(output_row0,27);
		filt[N-2][col+28] = (unsigned char) _mm256_extract_epi8(output_row0,28);

		filt[N-1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1,16);
		filt[N-1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1,17);
		filt[N-1][col+18] = (unsigned char) _mm256_extract_epi8(output_row1,18);
		filt[N-1][col+19] = (unsigned char) _mm256_extract_epi8(output_row1,19);
		filt[N-1][col+20] = (unsigned char) _mm256_extract_epi8(output_row1,20);
		filt[N-1][col+21] = (unsigned char) _mm256_extract_epi8(output_row1,21);
		filt[N-1][col+22] = (unsigned char) _mm256_extract_epi8(output_row1,22);
		filt[N-1][col+23] = (unsigned char) _mm256_extract_epi8(output_row1,23);
		filt[N-1][col+24] = (unsigned char) _mm256_extract_epi8(output_row1,24);
		filt[N-1][col+25] = (unsigned char) _mm256_extract_epi8(output_row1,25);
		filt[N-1][col+26] = (unsigned char) _mm256_extract_epi8(output_row1,26);
		filt[N-1][col+27] = (unsigned char) _mm256_extract_epi8(output_row1,27);
		filt[N-1][col+28] = (unsigned char) _mm256_extract_epi8(output_row1,28);
		  break;
	case 30:
		filt[N-3][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[N-3][col+17] = (unsigned char) _mm256_extract_epi8(output,17);
		filt[N-3][col+18] = (unsigned char) _mm256_extract_epi8(output,18);
		filt[N-3][col+19] = (unsigned char) _mm256_extract_epi8(output,19);
		filt[N-3][col+20] = (unsigned char) _mm256_extract_epi8(output,20);
		filt[N-3][col+21] = (unsigned char) _mm256_extract_epi8(output,21);
		filt[N-3][col+22] = (unsigned char) _mm256_extract_epi8(output,22);
		filt[N-3][col+23] = (unsigned char) _mm256_extract_epi8(output,23);
		filt[N-3][col+24] = (unsigned char) _mm256_extract_epi8(output,24);
		filt[N-3][col+25] = (unsigned char) _mm256_extract_epi8(output,25);
		filt[N-3][col+26] = (unsigned char) _mm256_extract_epi8(output,26);
		filt[N-3][col+27] = (unsigned char) _mm256_extract_epi8(output,27);
		filt[N-3][col+28] = (unsigned char) _mm256_extract_epi8(output,28);
		filt[N-3][col+29] = (unsigned char) _mm256_extract_epi8(output,29);

		filt[N-2][col+16] = (unsigned char) _mm256_extract_epi8(output_row0,16);
		filt[N-2][col+17] = (unsigned char) _mm256_extract_epi8(output_row0,17);
		filt[N-2][col+18] = (unsigned char) _mm256_extract_epi8(output_row0,18);
		filt[N-2][col+19] = (unsigned char) _mm256_extract_epi8(output_row0,19);
		filt[N-2][col+20] = (unsigned char) _mm256_extract_epi8(output_row0,20);
		filt[N-2][col+21] = (unsigned char) _mm256_extract_epi8(output_row0,21);
		filt[N-2][col+22] = (unsigned char) _mm256_extract_epi8(output_row0,22);
		filt[N-2][col+23] = (unsigned char) _mm256_extract_epi8(output_row0,23);
		filt[N-2][col+24] = (unsigned char) _mm256_extract_epi8(output_row0,24);
		filt[N-2][col+25] = (unsigned char) _mm256_extract_epi8(output_row0,25);
		filt[N-2][col+26] = (unsigned char) _mm256_extract_epi8(output_row0,26);
		filt[N-2][col+27] = (unsigned char) _mm256_extract_epi8(output_row0,27);
		filt[N-2][col+28] = (unsigned char) _mm256_extract_epi8(output_row0,28);
		filt[N-2][col+29] = (unsigned char) _mm256_extract_epi8(output_row0,29);

		filt[N-1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1,16);
		filt[N-1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1,17);
		filt[N-1][col+18] = (unsigned char) _mm256_extract_epi8(output_row1,18);
		filt[N-1][col+19] = (unsigned char) _mm256_extract_epi8(output_row1,19);
		filt[N-1][col+20] = (unsigned char) _mm256_extract_epi8(output_row1,20);
		filt[N-1][col+21] = (unsigned char) _mm256_extract_epi8(output_row1,21);
		filt[N-1][col+22] = (unsigned char) _mm256_extract_epi8(output_row1,22);
		filt[N-1][col+23] = (unsigned char) _mm256_extract_epi8(output_row1,23);
		filt[N-1][col+24] = (unsigned char) _mm256_extract_epi8(output_row1,24);
		filt[N-1][col+25] = (unsigned char) _mm256_extract_epi8(output_row1,25);
		filt[N-1][col+26] = (unsigned char) _mm256_extract_epi8(output_row1,26);
		filt[N-1][col+27] = (unsigned char) _mm256_extract_epi8(output_row1,27);
		filt[N-1][col+28] = (unsigned char) _mm256_extract_epi8(output_row1,28);
		filt[N-1][col+29] = (unsigned char) _mm256_extract_epi8(output_row1,29);
		  break;
	case 31:
		filt[N-3][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[N-3][col+17] = (unsigned char) _mm256_extract_epi8(output,17);
		filt[N-3][col+18] = (unsigned char) _mm256_extract_epi8(output,18);
		filt[N-3][col+19] = (unsigned char) _mm256_extract_epi8(output,19);
		filt[N-3][col+20] = (unsigned char) _mm256_extract_epi8(output,20);
		filt[N-3][col+21] = (unsigned char) _mm256_extract_epi8(output,21);
		filt[N-3][col+22] = (unsigned char) _mm256_extract_epi8(output,22);
		filt[N-3][col+23] = (unsigned char) _mm256_extract_epi8(output,23);
		filt[N-3][col+24] = (unsigned char) _mm256_extract_epi8(output,24);
		filt[N-3][col+25] = (unsigned char) _mm256_extract_epi8(output,25);
		filt[N-3][col+26] = (unsigned char) _mm256_extract_epi8(output,26);
		filt[N-3][col+27] = (unsigned char) _mm256_extract_epi8(output,27);
		filt[N-3][col+28] = (unsigned char) _mm256_extract_epi8(output,28);
		filt[N-3][col+29] = (unsigned char) _mm256_extract_epi8(output,29);

		filt[N-2][col+16] = (unsigned char) _mm256_extract_epi8(output_row0,16);
		filt[N-2][col+17] = (unsigned char) _mm256_extract_epi8(output_row0,17);
		filt[N-2][col+18] = (unsigned char) _mm256_extract_epi8(output_row0,18);
		filt[N-2][col+19] = (unsigned char) _mm256_extract_epi8(output_row0,19);
		filt[N-2][col+20] = (unsigned char) _mm256_extract_epi8(output_row0,20);
		filt[N-2][col+21] = (unsigned char) _mm256_extract_epi8(output_row0,21);
		filt[N-2][col+22] = (unsigned char) _mm256_extract_epi8(output_row0,22);
		filt[N-2][col+23] = (unsigned char) _mm256_extract_epi8(output_row0,23);
		filt[N-2][col+24] = (unsigned char) _mm256_extract_epi8(output_row0,24);
		filt[N-2][col+25] = (unsigned char) _mm256_extract_epi8(output_row0,25);
		filt[N-2][col+26] = (unsigned char) _mm256_extract_epi8(output_row0,26);
		filt[N-2][col+27] = (unsigned char) _mm256_extract_epi8(output_row0,27);
		filt[N-2][col+28] = (unsigned char) _mm256_extract_epi8(output_row0,28);
		filt[N-2][col+29] = (unsigned char) _mm256_extract_epi8(output_row0,29);

		filt[N-1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1,16);
		filt[N-1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1,17);
		filt[N-1][col+18] = (unsigned char) _mm256_extract_epi8(output_row1,18);
		filt[N-1][col+19] = (unsigned char) _mm256_extract_epi8(output_row1,19);
		filt[N-1][col+20] = (unsigned char) _mm256_extract_epi8(output_row1,20);
		filt[N-1][col+21] = (unsigned char) _mm256_extract_epi8(output_row1,21);
		filt[N-1][col+22] = (unsigned char) _mm256_extract_epi8(output_row1,22);
		filt[N-1][col+23] = (unsigned char) _mm256_extract_epi8(output_row1,23);
		filt[N-1][col+24] = (unsigned char) _mm256_extract_epi8(output_row1,24);
		filt[N-1][col+25] = (unsigned char) _mm256_extract_epi8(output_row1,25);
		filt[N-1][col+26] = (unsigned char) _mm256_extract_epi8(output_row1,26);
		filt[N-1][col+27] = (unsigned char) _mm256_extract_epi8(output_row1,27);
		filt[N-1][col+28] = (unsigned char) _mm256_extract_epi8(output_row1,28);
		filt[N-1][col+29] = (unsigned char) _mm256_extract_epi8(output_row1,29);

		int newPixel;
		for (int row=N-3;row<N;row++){
		 newPixel = 0;
		for (int rowOffset=-2; rowOffset<=2; rowOffset++) {
			for (int colOffset=-2; colOffset<=2; colOffset++) {

			   if ( ((row+rowOffset)<N) && ((M-1+colOffset)<M) && ((row+rowOffset)>=0) && ((M-1+colOffset)>=0) )
	              newPixel += frame1[row+rowOffset][M-1+colOffset] * gaussianMask[2 + rowOffset][2 + colOffset];

			      }
		        }
	filt[row][M-1] = (unsigned char) (newPixel / divisor);
		}
		  break;
	default:
		printf("\n something went wrong");
	}

	return 0;
}







void Gaussian_Blur_optimized_5x5_step28(unsigned char **frame1,unsigned char **filt,const unsigned int M, const unsigned int N, const unsigned int divisor){


	//load coefficients
	const __m256i c0=_mm256_load_si256( (__m256i *) &gaussian_filter_5x5_test[0][0]);
	const __m256i c1=_mm256_load_si256( (__m256i *) &gaussian_filter_5x5_test[1][0]);
	const __m256i c2=_mm256_load_si256( (__m256i *) &gaussian_filter_5x5_test[2][0]);

	const __m256i c0_sh1=_mm256_load_si256( (__m256i *) &gaussian_filter_5x5_test[3][0]);
	const __m256i c1_sh1=_mm256_load_si256( (__m256i *) &gaussian_filter_5x5_test[4][0]);
	const __m256i c2_sh1=_mm256_load_si256( (__m256i *) &gaussian_filter_5x5_test[5][0]);

	const __m256i c0_sh2=_mm256_load_si256( (__m256i *) &gaussian_filter_5x5_test[6][0]);
	const __m256i c1_sh2=_mm256_load_si256( (__m256i *) &gaussian_filter_5x5_test[7][0]);
	const __m256i c2_sh2=_mm256_load_si256( (__m256i *) &gaussian_filter_5x5_test[8][0]);

	const __m256i c0_sh3=_mm256_load_si256( (__m256i *) &gaussian_filter_5x5_test[9][0]);
	const __m256i c1_sh3=_mm256_load_si256( (__m256i *) &gaussian_filter_5x5_test[10][0]);
	const __m256i c2_sh3=_mm256_load_si256( (__m256i *) &gaussian_filter_5x5_test[11][0]);

	const __m256i c0_sh4=_mm256_load_si256( (__m256i *) &gaussian_filter_5x5_test[12][0]);
	const __m256i c1_sh4=_mm256_load_si256( (__m256i *) &gaussian_filter_5x5_test[13][0]);
	const __m256i c2_sh4=_mm256_load_si256( (__m256i *) &gaussian_filter_5x5_test[14][0]);

	const __m256i c0_sh5=_mm256_load_si256( (__m256i *) &gaussian_filter_5x5_test[15][0]);
	const __m256i c1_sh5=_mm256_load_si256( (__m256i *) &gaussian_filter_5x5_test[16][0]);
	const __m256i c2_sh5=_mm256_load_si256( (__m256i *) &gaussian_filter_5x5_test[17][0]);


	//const __m256i f  = _mm256_set_epi16(52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759);
	const __m256i mask  = _mm256_set_epi8(0,0,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255);
	const __m256i mask2  = _mm256_set_epi8(0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0);
	const __m256i mask6  = _mm256_set_epi8(0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0);

	const __m256i mask3  = _mm256_set_epi16(0,0,0,0,0,0,0,65535,0,0,0,0,0,0,0,0);

	const __m256i mask_prelude  = _mm256_set_epi8(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0);

	const unsigned int REMINDER_ITERATIONS =  (M-((((M-32)/28)*28)+28)); //M-(last_col_value+28)
//	printf("\n%d",REMINDER_ITERATIONS);


	const unsigned int division_case=prepare_for_division(divisor); //determine which is the division case (A, B or C)
	const __m256i f = _mm256_load_si256( (__m256i *) &f_vector[0]);// initialize the division vector



#pragma omp parallel
{

unsigned int row,col;
register __m256i r0,r1,r2,r3,r4,m0,m1,m2,m3,m4,output;
__m256i output_row0,output_row1;//these are for processing row #0 and #1 only.
__m256i m0_prelude_row0,m0_prelude_row1;

//MORE EFFICIENT WAY TO DEAL WITH MANY CONSTANTS?

/*---------------------- Gaussian Blur ---------------------------------*/

    #pragma omp for schedule(static)
	for (row = 2; row < N-2; row++) {

		if (row==2){//in this case I calculate filt[0][:] and filt[1][:] too. No extra loads or multiplications are required for this
			  for (col = 0; col <= M-32; col+=28){

				  if (col==0){//this is a special case as the mask gets outside of the array (it is like adding two zeros in the beginning of frame[][]

						//load the 5 rows
						r0=_mm256_loadu_si256( (__m256i *) &frame1[row-2][0]);
						r1=_mm256_loadu_si256( (__m256i *) &frame1[row-1][0]);
						r2=_mm256_loadu_si256( (__m256i *) &frame1[row][0]);
						r3=_mm256_loadu_si256( (__m256i *) &frame1[row+1][0]);
						r4=_mm256_loadu_si256( (__m256i *) &frame1[row+2][0]);

				  			//START - extra code needed for prelude
				  					m0=_mm256_slli_si256(r0,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
				  					m1=_mm256_slli_si256(r1,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
				  					m2=_mm256_slli_si256(r2,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
				  					m3=_mm256_slli_si256(r3,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
				  					m4=_mm256_slli_si256(r4,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning

				  					r0=_mm256_and_si256(r0,mask_prelude);
				  					r0=_mm256_permute2f128_si256(r0,r0,1);
				  					r0=_mm256_srli_si256(r0,14);//shift 14 elements
				  					r0=_mm256_add_epi16(m0,r0);

				  					r1=_mm256_and_si256(r1,mask_prelude);
				  					r1=_mm256_permute2f128_si256(r1,r1,1);
				  					r1=_mm256_srli_si256(r1,14);//shift 14 elements
				  					r1=_mm256_add_epi16(m1,r1);

				  					r2=_mm256_and_si256(r2,mask_prelude);
				  					r2=_mm256_permute2f128_si256(r2,r2,1);
				  					r2=_mm256_srli_si256(r2,14);//shift 14 elements
				  					r2=_mm256_add_epi16(m2,r2);

				  					r3=_mm256_and_si256(r3,mask_prelude);
				  					r3=_mm256_permute2f128_si256(r3,r3,1);
				  					r3=_mm256_srli_si256(r3,14);//shift 14 elements
				  					r3=_mm256_add_epi16(m3,r3);

				  					r4=_mm256_and_si256(r4,mask_prelude);
				  					r4=_mm256_permute2f128_si256(r4,r4,1);
				  					r4=_mm256_srli_si256(r4,14);//shift 14 elements
				  					r4=_mm256_add_epi16(m4,r4);

				  			//END - extra code needed for prelude
				  		}
				  else {
						//load the 5 rows
						r0=_mm256_loadu_si256( (__m256i *) &frame1[row-2][col-2]);
						r1=_mm256_loadu_si256( (__m256i *) &frame1[row-1][col-2]);
						r2=_mm256_loadu_si256( (__m256i *) &frame1[row][col-2]);
						r3=_mm256_loadu_si256( (__m256i *) &frame1[row+1][col-2]);
						r4=_mm256_loadu_si256( (__m256i *) &frame1[row+2][col-2]);
				  }

				//col iteration computes output pixels of 2,8,14,20,26
				// col+1 iteration computes output pixels of 3,9,15,21,27
				// col+2 iteration computes output pixels of 4,10,16,22,28
				// col+3 iteration computes output pixels of 5,11,17,23,29
				// col+4 iteration computes output pixels of 6,12,18,24,30
				// col+5 iteration computes output pixels of 7,13,19,25,31
				//afterwards, col2 becomes 32 and repeat the above process

				//1st col iteration

				  //--------------row=2
				//multiply with the mask
				m0=_mm256_maddubs_epi16(r0,c0);
				m1=_mm256_maddubs_epi16(r1,c1);
				m2=_mm256_maddubs_epi16(r2,c2);
				m3=_mm256_maddubs_epi16(r3,c1);
				m4=_mm256_maddubs_epi16(r4,c0);

				//vertical add
				m0=_mm256_add_epi16(m0,m1);
				m0=_mm256_add_epi16(m0,m2);
				m0=_mm256_add_epi16(m0,m3);
				m0=_mm256_add_epi16(m0,m4);


				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
				m4=_mm256_and_si256(m0,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

				m2=_mm256_add_epi16(m2,m4);

				//now division of m2/divisor follows
				m2=division(division_case,m2,f);

				//and with mask to keep just 0,6,12,18,24
				output = _mm256_and_si256(m2,mask);

				//--------------row=0
				//multiply with the mask
				m0=_mm256_maddubs_epi16(r0,c2);
				m1=_mm256_maddubs_epi16(r1,c1);
				m2=_mm256_maddubs_epi16(r2,c0);

				//vertical add
				m0=_mm256_add_epi16(m0,m1);
				m0=_mm256_add_epi16(m0,m2);


				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
				m4=_mm256_and_si256(m0,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

				m2=_mm256_add_epi16(m2,m4);

				//now division of m2/divisor follows
				m2=division(division_case,m2,f);

				//and with mask to keep just 0,6,12,18,24
				output_row0 = _mm256_and_si256(m2,mask);

				//--------------row=1
				//multiply with the mask
				m0=_mm256_maddubs_epi16(r0,c1);
				m1=_mm256_maddubs_epi16(r1,c2);
				m2=_mm256_maddubs_epi16(r2,c1);
				m3=_mm256_maddubs_epi16(r3,c0);

				//vertical add
				m0=_mm256_add_epi16(m0,m1);
				m0=_mm256_add_epi16(m0,m2);
				m0=_mm256_add_epi16(m0,m3);

				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
				m4=_mm256_and_si256(m0,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

				m2=_mm256_add_epi16(m2,m4);

				//now division of m2/divisor follows
				m2=division(division_case,m2,f);

				//and with mask to keep just 0,6,12,18,24
				output_row1 = _mm256_and_si256(m2,mask);

				//2nd col iteration
				//multiply with the mask

				//----row=2
				m0=_mm256_maddubs_epi16(r0,c0_sh1);
				m1=_mm256_maddubs_epi16(r1,c1_sh1);
				m2=_mm256_maddubs_epi16(r2,c2_sh1);
				m3=_mm256_maddubs_epi16(r3,c1_sh1);
				m4=_mm256_maddubs_epi16(r4,c0_sh1);

				//vertical add
				m0=_mm256_add_epi16(m0,m1);
				m0=_mm256_add_epi16(m0,m2);
				m0=_mm256_add_epi16(m0,m3);
				m0=_mm256_add_epi16(m0,m4);


				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
				m4=_mm256_and_si256(m0,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
				m2=_mm256_add_epi16(m2,m4);

				//now division of m2/divisor follows
				m2=division(division_case,m2,f);

				//and with mask to keep just 0,6,12,18,24
				m2 = _mm256_and_si256(m2,mask);
				m2 = _mm256_slli_si256(m2,1);
				output = _mm256_add_epi8(output,m2);

				//----row=0
				m0=_mm256_maddubs_epi16(r0,c2_sh1);
				m1=_mm256_maddubs_epi16(r1,c1_sh1);
				m2=_mm256_maddubs_epi16(r2,c0_sh1);

				//vertical add
				m0=_mm256_add_epi16(m0,m1);
				m0=_mm256_add_epi16(m0,m2);


				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
				m4=_mm256_and_si256(m0,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
				m2=_mm256_add_epi16(m2,m4);

				//now division of m2/divisor follows
				m2=division(division_case,m2,f);

				//and with mask to keep just 0,6,12,18,24
				m2 = _mm256_and_si256(m2,mask);
				m2 = _mm256_slli_si256(m2,1);
				output_row0 = _mm256_add_epi8(output_row0,m2);

				//----row=1
				m0=_mm256_maddubs_epi16(r0,c1_sh1);
				m1=_mm256_maddubs_epi16(r1,c2_sh1);
				m2=_mm256_maddubs_epi16(r2,c1_sh1);
				m3=_mm256_maddubs_epi16(r3,c0_sh1);

				//vertical add
				m0=_mm256_add_epi16(m0,m1);
				m0=_mm256_add_epi16(m0,m2);
				m0=_mm256_add_epi16(m0,m3);


				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
				m4=_mm256_and_si256(m0,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
				m2=_mm256_add_epi16(m2,m4);

				//now division of m2/divisor follows
				m2=division(division_case,m2,f);

				//and with mask to keep just 0,6,12,18,24
				m2 = _mm256_and_si256(m2,mask);
				m2 = _mm256_slli_si256(m2,1);
				output_row1 = _mm256_add_epi8(output_row1,m2);

		                 //3rd col iteration
				//---row=2
				//multiply with the mask
				m0=_mm256_maddubs_epi16(r0,c0_sh2);
				m1=_mm256_maddubs_epi16(r1,c1_sh2);
				m2=_mm256_maddubs_epi16(r2,c2_sh2);
				m3=_mm256_maddubs_epi16(r3,c1_sh2);
				m4=_mm256_maddubs_epi16(r4,c0_sh2);

				//vertical add
				m0=_mm256_add_epi16(m0,m1);
				m0=_mm256_add_epi16(m0,m2);
				m0=_mm256_add_epi16(m0,m3);
				m0=_mm256_add_epi16(m0,m4);


				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
				m4=_mm256_and_si256(m2,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

				m2=_mm256_add_epi16(m2,m4);

				//now division of m2/divisor follows
				m2=division(division_case,m2,f);

				//and with mask to keep just 2,8,14,20,26
				m2 = _mm256_and_si256(m2,mask2);
				output = _mm256_add_epi8(output,m2);

				//---row=0
				//multiply with the mask

				m0=_mm256_maddubs_epi16(r0,c2_sh2);
				m1=_mm256_maddubs_epi16(r1,c1_sh2);
				m2=_mm256_maddubs_epi16(r2,c0_sh2);

				//vertical add
				m0=_mm256_add_epi16(m0,m1);
				m0=_mm256_add_epi16(m0,m2);


				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
				m4=_mm256_and_si256(m2,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

				m2=_mm256_add_epi16(m2,m4);

				//now division of m2/divisor follows
				m2=division(division_case,m2,f);

				//and with mask to keep just 2,8,14,20,26
				m2 = _mm256_and_si256(m2,mask2);
				output_row0 = _mm256_add_epi8(output_row0,m2);


				//---row=1
				//multiply with the mask

				m0=_mm256_maddubs_epi16(r0,c1_sh2);
				m1=_mm256_maddubs_epi16(r1,c2_sh2);
				m2=_mm256_maddubs_epi16(r2,c1_sh2);
				m3=_mm256_maddubs_epi16(r3,c0_sh2);

				//vertical add
				m0=_mm256_add_epi16(m0,m1);
				m0=_mm256_add_epi16(m0,m2);
				m0=_mm256_add_epi16(m0,m3);

				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
				m4=_mm256_and_si256(m2,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

				m2=_mm256_add_epi16(m2,m4);

				//now division of m2/divisor follows
				m2=division(division_case,m2,f);

				//and with mask to keep just 2,8,14,20,26
				m2 = _mm256_and_si256(m2,mask2);
				output_row1 = _mm256_add_epi8(output_row1,m2);

				//4th col iteration

				//4th col iteration

				//multiply with the mask
				m0=_mm256_maddubs_epi16(r0,c0_sh3);
				m1=_mm256_maddubs_epi16(r1,c1_sh3);
				m2=_mm256_maddubs_epi16(r2,c2_sh3);
				m3=_mm256_maddubs_epi16(r3,c1_sh3);
				m4=_mm256_maddubs_epi16(r4,c0_sh3);

				//vertical add
				m0=_mm256_add_epi16(m0,m1);
				m2=_mm256_add_epi16(m2,m3);
				m0=_mm256_add_epi16(m0,m2);
				m0=_mm256_add_epi16(m0,m4);

				//hozizontal additions
				//hadd(3:8)
				//hadd(9:14)
				//hadd(15:20)
				//hadd(21:26)
				//hadd(27:31)
				//result after division will be in 2,8,14,20,26

				m1=_mm256_srli_si256(m0,2);
				m4=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m4);

				//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
				m4=_mm256_and_si256(m4,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

				m2=_mm256_add_epi16(m2,m4);

				//now division of r2/159 follows
				m2=division(division_case,m2,f);


				//and with mask to keep just 0,6,12,18,24
				m2 = _mm256_and_si256(m2,mask2);
				m2 = _mm256_slli_si256(m2,1);
				output = _mm256_add_epi8(output,m2);

				//row0
				//multiply with the mask
								m0=_mm256_maddubs_epi16(r0,c2_sh3);
								m1=_mm256_maddubs_epi16(r1,c1_sh3);
								m2=_mm256_maddubs_epi16(r2,c0_sh3);


								//vertical add
								m0=_mm256_add_epi16(m0,m1);
								m0=_mm256_add_epi16(m0,m2);


								m1=_mm256_srli_si256(m0,2);
								m4=_mm256_add_epi16(m1,m0);

								m1=_mm256_srli_si256(m0,4);
								m2=_mm256_add_epi16(m1,m4);

								//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
								//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
								m4=_mm256_and_si256(m4,mask3);
								m4=_mm256_permute2f128_si256(m4,m4,1);
								m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

								m2=_mm256_add_epi16(m2,m4);

								//now division of r2/159 follows
								m2=division(division_case,m2,f);


								//and with mask to keep just 0,6,12,18,24
								m2 = _mm256_and_si256(m2,mask2);
								m2 = _mm256_slli_si256(m2,1);
								output_row0 = _mm256_add_epi8(output_row0,m2);


								//-----------row1
								//multiply with the mask
												m0=_mm256_maddubs_epi16(r0,c1_sh3);
												m1=_mm256_maddubs_epi16(r1,c2_sh3);
												m2=_mm256_maddubs_epi16(r2,c1_sh3);
												m3=_mm256_maddubs_epi16(r3,c0_sh3);

												//vertical add
												m0=_mm256_add_epi16(m0,m1);
												m0=_mm256_add_epi16(m0,m2);
												m0=_mm256_add_epi16(m0,m3);

												m1=_mm256_srli_si256(m0,2);
												m4=_mm256_add_epi16(m1,m0);

												m1=_mm256_srli_si256(m0,4);
												m2=_mm256_add_epi16(m1,m4);

												//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
												//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
												m4=_mm256_and_si256(m4,mask3);
												m4=_mm256_permute2f128_si256(m4,m4,1);
												m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

												m2=_mm256_add_epi16(m2,m4);

												//now division of r2/159 follows
												m2=division(division_case,m2,f);


												//and with mask to keep just 0,6,12,18,24
												m2 = _mm256_and_si256(m2,mask2);
												m2 = _mm256_slli_si256(m2,1);
												output_row1 = _mm256_add_epi8(output_row1,m2);



				//5th col iteration
				//multiply with the mask
				m0=_mm256_maddubs_epi16(r0,c0_sh4);
				m1=_mm256_maddubs_epi16(r1,c1_sh4);
				m2=_mm256_maddubs_epi16(r2,c2_sh4);
				m3=_mm256_maddubs_epi16(r3,c1_sh4);
				m4=_mm256_maddubs_epi16(r4,c0_sh4);

				//vertical add
				m0=_mm256_add_epi16(m0,m1);
				m2=_mm256_add_epi16(m2,m3);
				m0=_mm256_add_epi16(m0,m2);
				m0=_mm256_add_epi16(m0,m4);

				//hozizontal additions
				//hadd(4:9)
				//hadd(10:15)
				//hadd(16:21)
				//hadd(22:27)
				//result after division will be in 4,10,16,22

				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);


				//now division of r2/159 follows
				m2=division(division_case,m2,f);

				//and with mask to keep just 0,6,12,18,24
				m2 = _mm256_and_si256(m2,mask6);
				//m1 = _mm256_slli_si256(m2,4);
				output = _mm256_add_epi8(output,m2);

				//row0
				//multiply with the mask
				m0=_mm256_maddubs_epi16(r0,c2_sh4);
				m1=_mm256_maddubs_epi16(r1,c1_sh4);
				m2=_mm256_maddubs_epi16(r2,c0_sh4);


				//vertical add
				m0=_mm256_add_epi16(m0,m1);
				m0=_mm256_add_epi16(m0,m2);


				//hozizontal additions
				//hadd(4:9)
				//hadd(10:15)
				//hadd(16:21)
				//hadd(22:27)
				//result after division will be in 4,10,16,22

				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);


				//now division of r2/159 follows
				m2=division(division_case,m2,f);

				//and with mask to keep just 0,6,12,18,24
				m2 = _mm256_and_si256(m2,mask6);
				//m1 = _mm256_slli_si256(m2,4);
				output_row0 = _mm256_add_epi8(output_row0,m2);

				//row1
				//multiply with the mask
				m0=_mm256_maddubs_epi16(r0,c1_sh4);
				m1=_mm256_maddubs_epi16(r1,c2_sh4);
				m2=_mm256_maddubs_epi16(r2,c1_sh4);
				m3=_mm256_maddubs_epi16(r3,c0_sh4);


				//vertical add
				m0=_mm256_add_epi16(m0,m1);
				m0=_mm256_add_epi16(m0,m2);
				m0=_mm256_add_epi16(m0,m3);


				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);


				//now division of r2/159 follows
				m2=division(division_case,m2,f);

				//and with mask to keep just 0,6,12,18,24
				m2 = _mm256_and_si256(m2,mask6);
				//m1 = _mm256_slli_si256(m2,4);
				output_row1 = _mm256_add_epi8(output_row1,m2);


		                 //6th col iteration
				//multiply with the mask
				m0=_mm256_maddubs_epi16(r0,c0_sh5);
				m1=_mm256_maddubs_epi16(r1,c1_sh5);
				m2=_mm256_maddubs_epi16(r2,c2_sh5);
				m3=_mm256_maddubs_epi16(r3,c1_sh5);
				m4=_mm256_maddubs_epi16(r4,c0_sh5);

				//vertical add
				m0=_mm256_add_epi16(m0,m1);
				m2=_mm256_add_epi16(m2,m3);
				m0=_mm256_add_epi16(m0,m2);
				m0=_mm256_add_epi16(m0,m4);

				//hozizontal additions
				//hadd(5:10)
				//hadd(11:16)
				//hadd(17:22)
				//hadd(23:28)
				//result after division will be in 4,10,16,22

				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//now division of r2/159 follows
				m2=division(division_case,m2,f);

				//and with mask to keep just 2,8,14,20,26
				m2 = _mm256_and_si256(m2,mask6);
				m1 = _mm256_slli_si256(m2,1);
				output = _mm256_add_epi8(output,m1);
				_mm256_storeu_si256( (__m256i *) &filt[row][col],output);

				//row0
				//multiply with the mask
				m0=_mm256_maddubs_epi16(r0,c2_sh5);
				m1=_mm256_maddubs_epi16(r1,c1_sh5);
				m2=_mm256_maddubs_epi16(r2,c0_sh5);

				//vertical add
				m0=_mm256_add_epi16(m0,m1);
				m0=_mm256_add_epi16(m0,m2);


				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//now division of r2/159 follows
				m2=division(division_case,m2,f);

				//and with mask to keep just 2,8,14,20,26
				m2 = _mm256_and_si256(m2,mask6);
				m1 = _mm256_slli_si256(m2,1);
				output_row0 = _mm256_add_epi8(output_row0,m1);
				_mm256_storeu_si256( (__m256i *) &filt[0][col],output_row0);

				//row1

				//multiply with the mask
				m0=_mm256_maddubs_epi16(r0,c1_sh5);
				m1=_mm256_maddubs_epi16(r1,c2_sh5);
				m2=_mm256_maddubs_epi16(r2,c1_sh5);
				m3=_mm256_maddubs_epi16(r3,c0_sh5);

				//vertical add
				m0=_mm256_add_epi16(m0,m1);
				m0=_mm256_add_epi16(m0,m2);
				m0=_mm256_add_epi16(m0,m3);


				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//now division of r2/159 follows
				m2=division(division_case,m2,f);

				//and with mask to keep just 2,8,14,20,26
				m2 = _mm256_and_si256(m2,mask6);
				m1 = _mm256_slli_si256(m2,1);
				output_row1 = _mm256_add_epi8(output_row1,m1);

				_mm256_storeu_si256( (__m256i *) &filt[1][col],output_row1);


				}

			  if (REMINDER_ITERATIONS>=16)
				  loop_reminder_first_rows_high_reminder_values(frame1,filt,M,N,col,REMINDER_ITERATIONS,division_case,c0,c1,c2,c0_sh1,c1_sh1,c2_sh1,c0_sh2,c1_sh2,c2_sh2,f,divisor);
			  else
			    loop_reminder_first_rows_low_reminder_values(frame1,filt,M,N,col,REMINDER_ITERATIONS,division_case,c0,c1,c2,c0_sh1,c1_sh1,c2_sh1,c0_sh2,c1_sh2,c2_sh2,f);

		}

		else if (row==N-3){//in this case I calculate filt[N-2][:] and filt[N-1][:] too. Below row0 refers to row=N-2 and row1 refers to row=N-1
			for (col = 0; col <= M-32; col+=28){
						 //last col value that does not read outside of the array bounds is (col<M-29)

							  if (col==0){

									//load the 5 rows
									r0=_mm256_loadu_si256( (__m256i *) &frame1[row-2][0]);
									r1=_mm256_loadu_si256( (__m256i *) &frame1[row-1][0]);
									r2=_mm256_loadu_si256( (__m256i *) &frame1[row][0]);
									r3=_mm256_loadu_si256( (__m256i *) &frame1[row+1][0]);
									r4=_mm256_loadu_si256( (__m256i *) &frame1[row+2][0]);

							  			//START - extra code needed for prelude
							  					m0=_mm256_slli_si256(r0,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
							  					m1=_mm256_slli_si256(r1,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
							  					m2=_mm256_slli_si256(r2,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
							  					m3=_mm256_slli_si256(r3,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
							  					m4=_mm256_slli_si256(r4,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning

							  					r0=_mm256_and_si256(r0,mask_prelude);
							  					r0=_mm256_permute2f128_si256(r0,r0,1);
							  					r0=_mm256_srli_si256(r0,14);//shift 14 elements
							  					r0=_mm256_add_epi16(m0,r0);

							  					r1=_mm256_and_si256(r1,mask_prelude);
							  					r1=_mm256_permute2f128_si256(r1,r1,1);
							  					r1=_mm256_srli_si256(r1,14);//shift 14 elements
							  					r1=_mm256_add_epi16(m1,r1);

							  					r2=_mm256_and_si256(r2,mask_prelude);
							  					r2=_mm256_permute2f128_si256(r2,r2,1);
							  					r2=_mm256_srli_si256(r2,14);//shift 14 elements
							  					r2=_mm256_add_epi16(m2,r2);

							  					r3=_mm256_and_si256(r3,mask_prelude);
							  					r3=_mm256_permute2f128_si256(r3,r3,1);
							  					r3=_mm256_srli_si256(r3,14);//shift 14 elements
							  					r3=_mm256_add_epi16(m3,r3);

							  					r4=_mm256_and_si256(r4,mask_prelude);
							  					r4=_mm256_permute2f128_si256(r4,r4,1);
							  					r4=_mm256_srli_si256(r4,14);//shift 14 elements
							  					r4=_mm256_add_epi16(m4,r4);

							  			//END - extra code needed for prelude
							  		}
							  else {
									//load the 5 rows
									r0=_mm256_loadu_si256( (__m256i *) &frame1[row-2][col-2]);
									r1=_mm256_loadu_si256( (__m256i *) &frame1[row-1][col-2]);
									r2=_mm256_loadu_si256( (__m256i *) &frame1[row][col-2]);
									r3=_mm256_loadu_si256( (__m256i *) &frame1[row+1][col-2]);
									r4=_mm256_loadu_si256( (__m256i *) &frame1[row+2][col-2]);
							  }

							//col iteration computes output pixels of 2,8,14,20,26
							// col+1 iteration computes output pixels of 3,9,15,21,27
							// col+2 iteration computes output pixels of 4,10,16,22,28
							// col+3 iteration computes output pixels of 5,11,17,23,29
							// col+4 iteration computes output pixels of 6,12,18,24,30
							// col+5 iteration computes output pixels of 7,13,19,25,31
							//afterwards, col2 becomes 32 and repeat the above process

							//1st col iteration
							 //--------------row=2

							//multiply with the mask
							m0=_mm256_maddubs_epi16(r0,c0);
							m1=_mm256_maddubs_epi16(r1,c1);
							m2=_mm256_maddubs_epi16(r2,c2);
							m3=_mm256_maddubs_epi16(r3,c1);
							m4=_mm256_maddubs_epi16(r4,c0);

							//vertical add
							m4=_mm256_add_epi16(m4,m3);
							m4=_mm256_add_epi16(m4,m2);
							m4=_mm256_add_epi16(m4,m1);
							m0=_mm256_add_epi16(m4,m0);

							m1=_mm256_srli_si256(m0,2);
							m2=_mm256_add_epi16(m1,m0);

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m2);

							//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
							m4=_mm256_and_si256(m0,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

							m2=_mm256_add_epi16(m2,m4);

							//now division of m2/divisor follows
							m2=division(division_case,m2,f);

							//and with mask to keep just 0,6,12,18,24
							output = _mm256_and_si256(m2,mask);

							//--------------row=0
							//multiply with the mask
							m1=_mm256_maddubs_epi16(r1,c0);
							m2=_mm256_maddubs_epi16(r2,c1);
							m3=_mm256_maddubs_epi16(r3,c2);
							m4=_mm256_maddubs_epi16(r4,c1);

							//vertical add
							m4=_mm256_add_epi16(m4,m3);
							m4=_mm256_add_epi16(m4,m2);
							m4=_mm256_add_epi16(m4,m1); m0_prelude_row0=m4;

							m1=_mm256_srli_si256(m0_prelude_row0,2);
							m2=_mm256_add_epi16(m1,m0_prelude_row0);

							m1=_mm256_srli_si256(m0_prelude_row0,4);
							m2=_mm256_add_epi16(m1,m2);

							//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
							m4=_mm256_and_si256(m0_prelude_row0,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

							m2=_mm256_add_epi16(m2,m4);

							//now division of m2/divisor follows
							m2=division(division_case,m2,f);

							//and with mask to keep just 0,6,12,18,24
							output_row0 = _mm256_and_si256(m2,mask);

							//--------------row=1
							//multiply with the mask
							m2=_mm256_maddubs_epi16(r2,c0);
							m3=_mm256_maddubs_epi16(r3,c1);
							m4=_mm256_maddubs_epi16(r4,c2);


							//vertical add
							m4=_mm256_add_epi16(m4,m3);
							m4=_mm256_add_epi16(m4,m2);m0_prelude_row1=m4;



							m1=_mm256_srli_si256(m0_prelude_row1,2);
							m2=_mm256_add_epi16(m1,m0_prelude_row1);

							m1=_mm256_srli_si256(m0_prelude_row1,4);
							m2=_mm256_add_epi16(m1,m2);

							//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
							m4=_mm256_and_si256(m0_prelude_row1,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

							m2=_mm256_add_epi16(m2,m4);

							//now division of m2/divisor follows
							m2=division(division_case,m2,f);

							//and with mask to keep just 0,6,12,18,24
							output_row1 = _mm256_and_si256(m2,mask);

							//2nd col iteration
							//----row=2

							//multiply with the mask
							m0=_mm256_maddubs_epi16(r0,c0_sh1);
							m1=_mm256_maddubs_epi16(r1,c1_sh1);
							m2=_mm256_maddubs_epi16(r2,c2_sh1);
							m3=_mm256_maddubs_epi16(r3,c1_sh1);
							m4=_mm256_maddubs_epi16(r4,c0_sh1);

							//vertical add
							m4=_mm256_add_epi16(m4,m3);
							m4=_mm256_add_epi16(m4,m2);
							m4=_mm256_add_epi16(m4,m1);
							m0=_mm256_add_epi16(m4,m0);


							m1=_mm256_srli_si256(m0,2);
							m2=_mm256_add_epi16(m1,m0);

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m2);

							//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
							m4=_mm256_and_si256(m0,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
							m2=_mm256_add_epi16(m2,m4);

							//now division of m2/divisor follows
							m2=division(division_case,m2,f);

							//and with mask to keep just 0,6,12,18,24
							m2 = _mm256_and_si256(m2,mask);
							m2 = _mm256_slli_si256(m2,1);
							output = _mm256_add_epi8(output,m2);

							//----row=0
							//multiply with the mask
							m1=_mm256_maddubs_epi16(r1,c0_sh1);
							m2=_mm256_maddubs_epi16(r2,c1_sh1);
							m3=_mm256_maddubs_epi16(r3,c2_sh1);
							m4=_mm256_maddubs_epi16(r4,c1_sh1);


							//vertical add
							m4=_mm256_add_epi16(m4,m3);
							m4=_mm256_add_epi16(m4,m2);
							m4=_mm256_add_epi16(m4,m1);m0_prelude_row0=m4;


							m1=_mm256_srli_si256(m0_prelude_row0,2);
							m2=_mm256_add_epi16(m1,m0_prelude_row0);

							m1=_mm256_srli_si256(m0_prelude_row0,4);
							m2=_mm256_add_epi16(m1,m2);

							//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
							m4=_mm256_and_si256(m0_prelude_row0,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
							m2=_mm256_add_epi16(m2,m4);

							//now division of m2/divisor follows
							m2=division(division_case,m2,f);

							//and with mask to keep just 0,6,12,18,24
							m2 = _mm256_and_si256(m2,mask);
							m2 = _mm256_slli_si256(m2,1);
							output_row0 = _mm256_add_epi8(output_row0,m2);

							//----row=1
							//multiply with the mask
							m2=_mm256_maddubs_epi16(r2,c0_sh1);
							m3=_mm256_maddubs_epi16(r3,c1_sh1);
							m4=_mm256_maddubs_epi16(r4,c2_sh1);


							//vertical add
							m4=_mm256_add_epi16(m4,m3);
							m4=_mm256_add_epi16(m4,m2);m0_prelude_row1=m4;


							m1=_mm256_srli_si256(m0_prelude_row1,2);
							m2=_mm256_add_epi16(m1,m0_prelude_row1);

							m1=_mm256_srli_si256(m0_prelude_row1,4);
							m2=_mm256_add_epi16(m1,m2);

							//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
							m4=_mm256_and_si256(m0_prelude_row1,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
							m2=_mm256_add_epi16(m2,m4);

							//now division of m2/divisor follows
							m2=division(division_case,m2,f);

							//and with mask to keep just 0,6,12,18,24
							m2 = _mm256_and_si256(m2,mask);
							m2 = _mm256_slli_si256(m2,1);
							output_row1 = _mm256_add_epi8(output_row1,m2);

					                 //3rd col iteration
							//---row=2
							//multiply with the mask
							m0=_mm256_maddubs_epi16(r0,c0_sh2);
							m1=_mm256_maddubs_epi16(r1,c1_sh2);
							m2=_mm256_maddubs_epi16(r2,c2_sh2);
							m3=_mm256_maddubs_epi16(r3,c1_sh2);
							m4=_mm256_maddubs_epi16(r4,c0_sh2);

							//vertical add
							m4=_mm256_add_epi16(m4,m3);
							m4=_mm256_add_epi16(m4,m2);
							m4=_mm256_add_epi16(m4,m1);
							m0=_mm256_add_epi16(m4,m0);


							m1=_mm256_srli_si256(m0,2);
							m2=_mm256_add_epi16(m1,m0);

							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
							m4=_mm256_and_si256(m2,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m2);

							//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

							m2=_mm256_add_epi16(m2,m4);

							//now division of m2/divisor follows
							m2=division(division_case,m2,f);

							//and with mask to keep just 2,8,14,20,26
							m2 = _mm256_and_si256(m2,mask2);
							output = _mm256_add_epi8(output,m2);

							//---row=0
							//multiply with the mask
							m1=_mm256_maddubs_epi16(r1,c0_sh2);
							m2=_mm256_maddubs_epi16(r2,c1_sh2);
							m3=_mm256_maddubs_epi16(r3,c2_sh2);
							m4=_mm256_maddubs_epi16(r4,c1_sh2);


							//vertical add
							m4=_mm256_add_epi16(m4,m3);
							m4=_mm256_add_epi16(m4,m2);
							m4=_mm256_add_epi16(m4,m1);m0_prelude_row0=m4;

							m1=_mm256_srli_si256(m0_prelude_row0,2);
							m2=_mm256_add_epi16(m1,m0_prelude_row0);

							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
							m4=_mm256_and_si256(m2,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

							m1=_mm256_srli_si256(m0_prelude_row0,4);
							m2=_mm256_add_epi16(m1,m2);

							//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

							m2=_mm256_add_epi16(m2,m4);

							//now division of m2/divisor follows
							m2=division(division_case,m2,f);

							//and with mask to keep just 2,8,14,20,26
							m2 = _mm256_and_si256(m2,mask2);
							output_row0 = _mm256_add_epi8(output_row0,m2);


							//---row=1
							//multiply with the mask
							m2=_mm256_maddubs_epi16(r2,c0_sh2);
							m3=_mm256_maddubs_epi16(r3,c1_sh2);
							m4=_mm256_maddubs_epi16(r4,c2_sh2);


							//vertical add
							m4=_mm256_add_epi16(m4,m3);
							m4=_mm256_add_epi16(m4,m2);m0_prelude_row1=m4;


							m1=_mm256_srli_si256(m0_prelude_row1,2);
							m2=_mm256_add_epi16(m1,m0_prelude_row1);

							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
							m4=_mm256_and_si256(m2,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

							m1=_mm256_srli_si256(m0_prelude_row1,4);
							m2=_mm256_add_epi16(m1,m2);

							//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

							m2=_mm256_add_epi16(m2,m4);

							//now division of m2/divisor follows
							m2=division(division_case,m2,f);

							//and with mask to keep just 2,8,14,20,26
							m2 = _mm256_and_si256(m2,mask2);
							output_row1 = _mm256_add_epi8(output_row1,m2);

							//4th col iteration
							//multiply with the mask
							m0=_mm256_maddubs_epi16(r0,c0_sh3);
							m1=_mm256_maddubs_epi16(r1,c1_sh3);
							m2=_mm256_maddubs_epi16(r2,c2_sh3);
							m3=_mm256_maddubs_epi16(r3,c1_sh3);
							m4=_mm256_maddubs_epi16(r4,c0_sh3);

							//vertical add
							m0=_mm256_add_epi16(m0,m1);
							m2=_mm256_add_epi16(m2,m3);
							m0=_mm256_add_epi16(m0,m2);
							m0=_mm256_add_epi16(m0,m4);

							//hozizontal additions
							//hadd(3:8)
							//hadd(9:14)
							//hadd(15:20)
							//hadd(21:26)
							//hadd(27:31)
							//result after division will be in 2,8,14,20,26

							m1=_mm256_srli_si256(m0,2);
							m4=_mm256_add_epi16(m1,m0);

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m4);

							//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
							m4=_mm256_and_si256(m4,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

							m2=_mm256_add_epi16(m2,m4);

							//now division of r2/159 follows
							m2=division(division_case,m2,f);


							//and with mask to keep just 0,6,12,18,24
							m2 = _mm256_and_si256(m2,mask2);
							m2 = _mm256_slli_si256(m2,1);
							output = _mm256_add_epi8(output,m2);

							//row0
							//multiply with the mask
								m1=_mm256_maddubs_epi16(r1,c0_sh3);
								m2=_mm256_maddubs_epi16(r2,c1_sh3);
								m3=_mm256_maddubs_epi16(r3,c2_sh3);
								m4=_mm256_maddubs_epi16(r4,c1_sh3);

								//vertical add
								m0=_mm256_add_epi16(m1,m2);
								m0=_mm256_add_epi16(m0,m3);
								m0=_mm256_add_epi16(m0,m4);


								m1=_mm256_srli_si256(m0,2);
								m4=_mm256_add_epi16(m1,m0);

								m1=_mm256_srli_si256(m0,4);
								m2=_mm256_add_epi16(m1,m4);

								//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
								//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
								m4=_mm256_and_si256(m4,mask3);
								m4=_mm256_permute2f128_si256(m4,m4,1);
								m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

								m2=_mm256_add_epi16(m2,m4);

								//now division of r2/159 follows
								m2=division(division_case,m2,f);

								//and with mask to keep just 0,6,12,18,24
								m2 = _mm256_and_si256(m2,mask2);
								m2 = _mm256_slli_si256(m2,1);
								output_row0 = _mm256_add_epi8(output_row0,m2);

								//row1
								//multiply with the mask
									m2=_mm256_maddubs_epi16(r2,c0_sh3);
									m3=_mm256_maddubs_epi16(r3,c1_sh3);
									m4=_mm256_maddubs_epi16(r4,c2_sh3);

									//vertical add
									m0=_mm256_add_epi16(m2,m3);
									m0=_mm256_add_epi16(m0,m4);


									m1=_mm256_srli_si256(m0,2);
									m4=_mm256_add_epi16(m1,m0);

									m1=_mm256_srli_si256(m0,4);
									m2=_mm256_add_epi16(m1,m4);

									//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
									//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
									m4=_mm256_and_si256(m4,mask3);
									m4=_mm256_permute2f128_si256(m4,m4,1);
									m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

									m2=_mm256_add_epi16(m2,m4);

									//now division of r2/159 follows
									m2=division(division_case,m2,f);


									//and with mask to keep just 0,6,12,18,24
									m2 = _mm256_and_si256(m2,mask2);
									m2 = _mm256_slli_si256(m2,1);
									output_row1 = _mm256_add_epi8(output_row1,m2);


							//5th col iteration
							//multiply with the mask
							m0=_mm256_maddubs_epi16(r0,c0_sh4);
							m1=_mm256_maddubs_epi16(r1,c1_sh4);
							m2=_mm256_maddubs_epi16(r2,c2_sh4);
							m3=_mm256_maddubs_epi16(r3,c1_sh4);
							m4=_mm256_maddubs_epi16(r4,c0_sh4);

							//vertical add
							m0=_mm256_add_epi16(m0,m1);
							m2=_mm256_add_epi16(m2,m3);
							m0=_mm256_add_epi16(m0,m2);
							m0=_mm256_add_epi16(m0,m4);

							//hozizontal additions
							//hadd(4:9)
							//hadd(10:15)
							//hadd(16:21)
							//hadd(22:27)
							//result after division will be in 4,10,16,22

							m1=_mm256_srli_si256(m0,2);
							m2=_mm256_add_epi16(m1,m0);

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m2);


							//now division of r2/159 follows
							m2=division(division_case,m2,f);

							//and with mask to keep just 0,6,12,18,24
							m2 = _mm256_and_si256(m2,mask6);
							//m1 = _mm256_slli_si256(m2,4);
							output = _mm256_add_epi8(output,m2);

							//row0
							//multiply with the mask
							m1=_mm256_maddubs_epi16(r1,c0_sh4);
							m2=_mm256_maddubs_epi16(r2,c1_sh4);
							m3=_mm256_maddubs_epi16(r3,c2_sh4);
							m4=_mm256_maddubs_epi16(r4,c1_sh4);

							//vertical add
							m0=_mm256_add_epi16(m1,m2);
							m0=_mm256_add_epi16(m0,m3);
							m0=_mm256_add_epi16(m0,m4);


							m1=_mm256_srli_si256(m0,2);
							m2=_mm256_add_epi16(m1,m0);

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m2);


							//now division of r2/159 follows
							m2=division(division_case,m2,f);

							//and with mask to keep just 0,6,12,18,24
							m2 = _mm256_and_si256(m2,mask6);
							//m1 = _mm256_slli_si256(m2,4);
							output_row0 = _mm256_add_epi8(output_row0,m2);

							//row1
							//multiply with the mask
							m2=_mm256_maddubs_epi16(r2,c0_sh4);
							m3=_mm256_maddubs_epi16(r3,c1_sh4);
							m4=_mm256_maddubs_epi16(r4,c2_sh4);

							//vertical add
							m0=_mm256_add_epi16(m2,m3);
							m0=_mm256_add_epi16(m0,m4);


							m1=_mm256_srli_si256(m0,2);
							m2=_mm256_add_epi16(m1,m0);

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m2);


							//now division of r2/159 follows
							m2=division(division_case,m2,f);

							//and with mask to keep just 0,6,12,18,24
							m2 = _mm256_and_si256(m2,mask6);
							//m1 = _mm256_slli_si256(m2,4);
							output_row1 = _mm256_add_epi8(output_row1,m2);

					                 //6th col iteration
							//multiply with the mask
							m0=_mm256_maddubs_epi16(r0,c0_sh5);
							m1=_mm256_maddubs_epi16(r1,c1_sh5);
							m2=_mm256_maddubs_epi16(r2,c2_sh5);
							m3=_mm256_maddubs_epi16(r3,c1_sh5);
							m4=_mm256_maddubs_epi16(r4,c0_sh5);

							//vertical add
							m0=_mm256_add_epi16(m0,m1);
							m2=_mm256_add_epi16(m2,m3);
							m0=_mm256_add_epi16(m0,m2);
							m0=_mm256_add_epi16(m0,m4);

							//hozizontal additions
							//hadd(5:10)
							//hadd(11:16)
							//hadd(17:22)
							//hadd(23:28)
							//result after division will be in 4,10,16,22

							m1=_mm256_srli_si256(m0,2);
							m2=_mm256_add_epi16(m1,m0);

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m2);

							//now division of r2/159 follows
							m2=division(division_case,m2,f);

							//and with mask to keep just 2,8,14,20,26
							m2 = _mm256_and_si256(m2,mask6);
							m1 = _mm256_slli_si256(m2,1);
							output = _mm256_add_epi8(output,m1);

							_mm256_storeu_si256( (__m256i *) &filt[row][col],output);

							//row0
							//multiply with the mask
							m1=_mm256_maddubs_epi16(r1,c0_sh5);
							m2=_mm256_maddubs_epi16(r2,c1_sh5);
							m3=_mm256_maddubs_epi16(r3,c2_sh5);
							m4=_mm256_maddubs_epi16(r4,c1_sh5);

							//vertical add
							m0=_mm256_add_epi16(m1,m2);
							m0=_mm256_add_epi16(m0,m3);
							m0=_mm256_add_epi16(m0,m4);


							m1=_mm256_srli_si256(m0,2);
							m2=_mm256_add_epi16(m1,m0);

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m2);

							//now division of r2/159 follows
							m2=division(division_case,m2,f);

							//and with mask to keep just 2,8,14,20,26
							m2 = _mm256_and_si256(m2,mask6);
							m1 = _mm256_slli_si256(m2,1);
							output_row0 = _mm256_add_epi8(output_row0,m1);
							_mm256_storeu_si256( (__m256i *) &filt[N-2][col],output_row0);

							//row1
							//multiply with the mask
							m2=_mm256_maddubs_epi16(r2,c0_sh5);
							m3=_mm256_maddubs_epi16(r3,c1_sh5);
							m4=_mm256_maddubs_epi16(r4,c2_sh5);

							//vertical add
							m0=_mm256_add_epi16(m2,m3);
							m0=_mm256_add_epi16(m0,m4);

								m1=_mm256_srli_si256(m0,2);
							m2=_mm256_add_epi16(m1,m0);

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m2);

							//now division of r2/159 follows
							m2=division(division_case,m2,f);

							//and with mask to keep just 2,8,14,20,26
							m2 = _mm256_and_si256(m2,mask6);
							m1 = _mm256_slli_si256(m2,1);
							output_row1 = _mm256_add_epi8(output_row1,m1);
							_mm256_storeu_si256( (__m256i *) &filt[N-1][col],output_row1);


							}

			if (REMINDER_ITERATIONS>=16)
				loop_reminder_last_rows_high_reminder_values(frame1,filt,M,N,col,REMINDER_ITERATIONS,division_case,c0,c1,c2,c0_sh1,c1_sh1,c2_sh1,c0_sh2,c1_sh2,c2_sh2,f,divisor);
			else
				loop_reminder_last_rows_low_reminder_values(frame1,filt,M,N,col,REMINDER_ITERATIONS,division_case,c0,c1,c2,c0_sh1,c1_sh1,c2_sh1,c0_sh2,c1_sh2,c2_sh2,f);

					}
	else {


	  for (col = 0; col <= M-32; col+=28){
	 //last col value that does not read outside of the array bounds is (col<M-29)

		  if (col==0){

				//load the 5 rows
				r0=_mm256_loadu_si256( (__m256i *) &frame1[row-2][0]);
				r1=_mm256_loadu_si256( (__m256i *) &frame1[row-1][0]);
				r2=_mm256_loadu_si256( (__m256i *) &frame1[row][0]);
				r3=_mm256_loadu_si256( (__m256i *) &frame1[row+1][0]);
				r4=_mm256_loadu_si256( (__m256i *) &frame1[row+2][0]);

		  			//START - extra code needed for prelude
		  					m0=_mm256_slli_si256(r0,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
		  					m1=_mm256_slli_si256(r1,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
		  					m2=_mm256_slli_si256(r2,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
		  					m3=_mm256_slli_si256(r3,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
		  					m4=_mm256_slli_si256(r4,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning

		  					r0=_mm256_and_si256(r0,mask_prelude);
		  					r0=_mm256_permute2f128_si256(r0,r0,1);
		  					r0=_mm256_srli_si256(r0,14);//shift 14 elements
		  					r0=_mm256_add_epi16(m0,r0);

		  					r1=_mm256_and_si256(r1,mask_prelude);
		  					r1=_mm256_permute2f128_si256(r1,r1,1);
		  					r1=_mm256_srli_si256(r1,14);//shift 14 elements
		  					r1=_mm256_add_epi16(m1,r1);

		  					r2=_mm256_and_si256(r2,mask_prelude);
		  					r2=_mm256_permute2f128_si256(r2,r2,1);
		  					r2=_mm256_srli_si256(r2,14);//shift 14 elements
		  					r2=_mm256_add_epi16(m2,r2);

		  					r3=_mm256_and_si256(r3,mask_prelude);
		  					r3=_mm256_permute2f128_si256(r3,r3,1);
		  					r3=_mm256_srli_si256(r3,14);//shift 14 elements
		  					r3=_mm256_add_epi16(m3,r3);

		  					r4=_mm256_and_si256(r4,mask_prelude);
		  					r4=_mm256_permute2f128_si256(r4,r4,1);
		  					r4=_mm256_srli_si256(r4,14);//shift 14 elements
		  					r4=_mm256_add_epi16(m4,r4);

		  			//END - extra code needed for prelude
		  		}
		  else {
				//load the 5 rows
				r0=_mm256_loadu_si256( (__m256i *) &frame1[row-2][col-2]);
				r1=_mm256_loadu_si256( (__m256i *) &frame1[row-1][col-2]);
				r2=_mm256_loadu_si256( (__m256i *) &frame1[row][col-2]);
				r3=_mm256_loadu_si256( (__m256i *) &frame1[row+1][col-2]);
				r4=_mm256_loadu_si256( (__m256i *) &frame1[row+2][col-2]);
		  }

		//col iteration computes output pixels of 2,8,14,20,26
		// col+1 iteration computes output pixels of 3,9,15,21,27
		// col+2 iteration computes output pixels of 4,10,16,22,28
		// col+3 iteration computes output pixels of 5,11,17,23,29
		// col+4 iteration computes output pixels of 6,12,18,24
		// col+5 iteration computes output pixels of 7,13,19,25
		//afterwards, col becomes 30 and repeat the above process

		//1st col iteration


		//multiply with the mask
		m0=_mm256_maddubs_epi16(r0,c0);
		m1=_mm256_maddubs_epi16(r1,c1);
		m2=_mm256_maddubs_epi16(r2,c2);
		m3=_mm256_maddubs_epi16(r3,c1);
		m4=_mm256_maddubs_epi16(r4,c0);

		//vertical add
		m0=_mm256_add_epi16(m0,m1);
		m2=_mm256_add_epi16(m2,m3);
		m0=_mm256_add_epi16(m0,m2);
		m0=_mm256_add_epi16(m0,m4);

		//hozizontal additions
		//hadd(0:5)
		//hadd(6:11)
		//hadd(12:17)
		//hadd(18:23)
		//hadd(24:28)

		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
		m4=_mm256_and_si256(m0,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

		m2=_mm256_add_epi16(m2,m4);

		//now division of m2/divisor follows
		m2=division(division_case,m2,f);


		//and with mask to keep just 0,6,12,18,24
		output = _mm256_and_si256(m2,mask);


		//2nd col iteration
		//multiply with the mask
		m0=_mm256_maddubs_epi16(r0,c0_sh1);
		m1=_mm256_maddubs_epi16(r1,c1_sh1);
		m2=_mm256_maddubs_epi16(r2,c2_sh1);
		m3=_mm256_maddubs_epi16(r3,c1_sh1);
		m4=_mm256_maddubs_epi16(r4,c0_sh1);

		//vertical add
		m0=_mm256_add_epi16(m0,m1);
		m2=_mm256_add_epi16(m2,m3);
		m0=_mm256_add_epi16(m0,m2);
		m0=_mm256_add_epi16(m0,m4);

		//hozizontal additions
		//hadd(1:6)
		//hadd(7:12)
		//hadd(13:18)
		//hadd(19:24)
		//hadd(25:29)

		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
		m4=_mm256_and_si256(m0,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m2=division(division_case,m2,f);


		//and with mask to keep just 0,6,12,18,24
		m2 = _mm256_and_si256(m2,mask);
		m2 = _mm256_slli_si256(m2,1);
		output = _mm256_add_epi8(output,m2);


         //3rd col iteration
		//multiply with the mask
		m0=_mm256_maddubs_epi16(r0,c0_sh2);
		m1=_mm256_maddubs_epi16(r1,c1_sh2);
		m2=_mm256_maddubs_epi16(r2,c2_sh2);
		m3=_mm256_maddubs_epi16(r3,c1_sh2);
		m4=_mm256_maddubs_epi16(r4,c0_sh2);

		//vertical add
		m0=_mm256_add_epi16(m0,m1);
		m2=_mm256_add_epi16(m2,m3);
		m0=_mm256_add_epi16(m0,m2);
		m0=_mm256_add_epi16(m0,m4);

		//hozizontal additions
		//hadd(2:7)
		//hadd(8:13)
		//hadd(14:19)
		//hadd(20:25)
		//hadd(26:30)


		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
		m4=_mm256_and_si256(m2,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m2=division(division_case,m2,f);


		//and with mask to keep just 2,8,14,20,26
		m2 = _mm256_and_si256(m2,mask2);
		output = _mm256_add_epi8(output,m2);


		//4th col iteration

		//multiply with the mask
		m0=_mm256_maddubs_epi16(r0,c0_sh3);
		m1=_mm256_maddubs_epi16(r1,c1_sh3);
		m2=_mm256_maddubs_epi16(r2,c2_sh3);
		m3=_mm256_maddubs_epi16(r3,c1_sh3);
		m4=_mm256_maddubs_epi16(r4,c0_sh3);

		//vertical add
		m0=_mm256_add_epi16(m0,m1);
		m2=_mm256_add_epi16(m2,m3);
		m0=_mm256_add_epi16(m0,m2);
		m0=_mm256_add_epi16(m0,m4);

		//hozizontal additions
		//hadd(3:8)
		//hadd(9:14)
		//hadd(15:20)
		//hadd(21:26)
		//hadd(27:31)
		//result after division will be in 2,8,14,20,26

		m1=_mm256_srli_si256(m0,2);
		m4=_mm256_add_epi16(m1,m0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m4);

		//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
		m4=_mm256_and_si256(m4,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m2=division(division_case,m2,f);


		//and with mask to keep just 0,6,12,18,24
		m2 = _mm256_and_si256(m2,mask2);
		m2 = _mm256_slli_si256(m2,1);
		output = _mm256_add_epi8(output,m2);


		//5th col iteration
		//multiply with the mask
		m0=_mm256_maddubs_epi16(r0,c0_sh4);
		m1=_mm256_maddubs_epi16(r1,c1_sh4);
		m2=_mm256_maddubs_epi16(r2,c2_sh4);
		m3=_mm256_maddubs_epi16(r3,c1_sh4);
		m4=_mm256_maddubs_epi16(r4,c0_sh4);

		//vertical add
		m0=_mm256_add_epi16(m0,m1);
		m2=_mm256_add_epi16(m2,m3);
		m0=_mm256_add_epi16(m0,m2);
		m0=_mm256_add_epi16(m0,m4);

		//hozizontal additions
		//hadd(4:9)
		//hadd(10:15)
		//hadd(16:21)
		//hadd(22:27)
		//result after division will be in 4,10,16,22

		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);


		//now division of r2/159 follows
		m2=division(division_case,m2,f);

		//and with mask to keep just 0,6,12,18,24
		m2 = _mm256_and_si256(m2,mask6);
		//m1 = _mm256_slli_si256(m2,4);
		output = _mm256_add_epi8(output,m2);


                 //6th col iteration
		//multiply with the mask
		m0=_mm256_maddubs_epi16(r0,c0_sh5);
		m1=_mm256_maddubs_epi16(r1,c1_sh5);
		m2=_mm256_maddubs_epi16(r2,c2_sh5);
		m3=_mm256_maddubs_epi16(r3,c1_sh5);
		m4=_mm256_maddubs_epi16(r4,c0_sh5);

		//vertical add
		m0=_mm256_add_epi16(m0,m1);
		m2=_mm256_add_epi16(m2,m3);
		m0=_mm256_add_epi16(m0,m2);
		m0=_mm256_add_epi16(m0,m4);

		//hozizontal additions
		//hadd(5:10)
		//hadd(11:16)
		//hadd(17:22)
		//hadd(23:28)
		//result after division will be in 4,10,16,22

		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//now division of r2/159 follows
		m2=division(division_case,m2,f);

		//and with mask to keep just 2,8,14,20,26
		m2 = _mm256_and_si256(m2,mask6);
		m1 = _mm256_slli_si256(m2,1);
		output = _mm256_add_epi8(output,m1);


		_mm256_storeu_si256( (__m256i *) &filt[row][col],output);


		}

        if (REMINDER_ITERATIONS>=16)
        	loop_reminder_high_reminder_values(frame1,filt,M,N,row,col,REMINDER_ITERATIONS,division_case,c0,c1,c2,c0_sh1,c1_sh1,c2_sh1,c0_sh2,c1_sh2,c2_sh2,f,divisor);
        else
        	loop_reminder_low_reminder_values(frame1,filt,M,N,row,col,REMINDER_ITERATIONS,division_case,c0,c1,c2,c0_sh1,c1_sh1,c2_sh1,c0_sh2,c1_sh2,c2_sh2,f);
		//padding code. The last three iterations  ABOVE get outside of the array bounds. The last three col iterations read outside but the garbage values are multiplied by zeros (last three mask zeros). From now on, I must include another mask with extra zeros.
//It is faster to read outside of the array's bounds and then fill the right values. there is an insert command that inserts a value to the vector
//TOMORROW: USE Gaussian_Blur_AVX_ver4_plus_less_load ROUTINE FOR LOOP REMINDER. LOAD OUTSIDE OF THE ARRAY AND THEN ZERO THE VALUES NEEDED.

		}
}

}//end of parallel


}




void Gaussian_Blur_optimized_5x5_seperable_filter(unsigned char **frame1,unsigned char **filt,const unsigned int M, const unsigned int N, const unsigned int divisor, const unsigned char filter_5x5[5][5]){

	//-----------load coefficients for the padding routines. The padding routines use 2d 5x5 filter. They need to be updated.
	/*const __m256i c0=_mm256_set_epi8(0,0,0,filter_5x5[0][4],filter_5x5[0][3],filter_5x5[0][2],filter_5x5[0][1],filter_5x5[0][0],0,filter_5x5[0][4],filter_5x5[0][3],filter_5x5[0][2],filter_5x5[0][1],filter_5x5[0][0],0,filter_5x5[0][4],filter_5x5[0][3],filter_5x5[0][2],filter_5x5[0][1],filter_5x5[0][0],0,filter_5x5[0][4],filter_5x5[0][3],filter_5x5[0][2],filter_5x5[0][1],filter_5x5[0][0],0,filter_5x5[0][4],filter_5x5[0][3],filter_5x5[0][2],filter_5x5[0][1],filter_5x5[0][0]);
	const __m256i c1=_mm256_set_epi8(0,0,0,filter_5x5[1][4],filter_5x5[1][3],filter_5x5[1][2],filter_5x5[1][1],filter_5x5[1][0],0,filter_5x5[1][4],filter_5x5[1][3],filter_5x5[1][2],filter_5x5[1][1],filter_5x5[1][0],0,filter_5x5[1][4],filter_5x5[1][3],filter_5x5[1][2],filter_5x5[1][1],filter_5x5[1][0],0,filter_5x5[1][4],filter_5x5[1][3],filter_5x5[1][2],filter_5x5[1][1],filter_5x5[1][0],0,filter_5x5[1][4],filter_5x5[1][3],filter_5x5[1][2],filter_5x5[1][1],filter_5x5[1][0]);
	const __m256i c2=_mm256_set_epi8(0,0,0,filter_5x5[2][4],filter_5x5[2][3],filter_5x5[2][2],filter_5x5[2][1],filter_5x5[2][0],0,filter_5x5[2][4],filter_5x5[2][3],filter_5x5[2][2],filter_5x5[2][1],filter_5x5[2][0],0,filter_5x5[2][4],filter_5x5[2][3],filter_5x5[2][2],filter_5x5[2][1],filter_5x5[2][0],0,filter_5x5[2][4],filter_5x5[2][3],filter_5x5[2][2],filter_5x5[2][1],filter_5x5[2][0],0,filter_5x5[2][4],filter_5x5[2][3],filter_5x5[2][2],filter_5x5[2][1],filter_5x5[2][0]);

	const __m256i c0_sh1=_mm256_slli_si256(c0,1);
	const __m256i c1_sh1=_mm256_slli_si256(c1,1);
	const __m256i c2_sh1=_mm256_slli_si256(c2,1);

	const __m256i c0_sh2=_mm256_slli_si256(c0,2);
	const __m256i c1_sh2=_mm256_slli_si256(c1,2);
	const __m256i c2_sh2=_mm256_slli_si256(c2,2);*/


	//load coefficients
	const __m256i     cx=_mm256_load_si256( (__m256i *) &gaussian_filter_5x5_seperable_x[0][0]);
	const __m256i cx_sh1=_mm256_load_si256( (__m256i *) &gaussian_filter_5x5_seperable_x[1][0]);
	const __m256i cx_sh2=_mm256_load_si256( (__m256i *) &gaussian_filter_5x5_seperable_x[2][0]);
	const __m256i cx_sh3=_mm256_load_si256( (__m256i *) &gaussian_filter_5x5_seperable_x[3][0]);
	const __m256i cx_sh4=_mm256_load_si256( (__m256i *) &gaussian_filter_5x5_seperable_x[4][0]);
	const __m256i cx_sh5=_mm256_load_si256( (__m256i *) &gaussian_filter_5x5_seperable_x[5][0]);

	const __m256i     cy0=_mm256_load_si256( (__m256i *) &gaussian_filter_5x5_seperable_y[0][0]);
	const __m256i     cy1=_mm256_load_si256( (__m256i *) &gaussian_filter_5x5_seperable_y[1][0]);
	const __m256i     cy2=_mm256_load_si256( (__m256i *) &gaussian_filter_5x5_seperable_y[2][0]);
	const __m256i cy0_sh1=_mm256_load_si256( (__m256i *) &gaussian_filter_5x5_seperable_y[3][0]);
	const __m256i cy1_sh1=_mm256_load_si256( (__m256i *) &gaussian_filter_5x5_seperable_y[4][0]);
	const __m256i cy2_sh1=_mm256_load_si256( (__m256i *) &gaussian_filter_5x5_seperable_y[5][0]);

	//const __m256i f  = _mm256_set_epi16(52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759);
	const __m256i mask  = _mm256_set_epi8(0,0,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255);
	const __m256i mask2  = _mm256_set_epi8(0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0);
	const __m256i mask6  = _mm256_set_epi8(0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0);

	const __m256i mask3  = _mm256_set_epi16(0,0,0,0,0,0,0,65535,0,0,0,0,0,0,0,0);

	const __m256i mask_prelude  = _mm256_set_epi8(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0);

	const unsigned int REMINDER_ITERATIONS =  (M-((((M-32)/28)*28)+28)); //M-(last_col_value+28)
	//printf("\n%d",REMINDER_ITERATIONS);


	const unsigned int division_case=prepare_for_division(divisor); //determine which is the division case (A, B or C)
	const __m256i f = _mm256_load_si256( (__m256i *) &f_vector[0]);// initialize the division vector



#pragma omp parallel
{

unsigned int row,col;
register __m256i r0,r1,r2,r3,r4,m0,m1,m2,m3,m4,output;
__m256i output_row0,output_row1;//these are for processing row #0 and #1 only.
__m256i even,odd,row_0,row_1,row_2;

//MORE EFFICIENT WAY TO DEAL WITH MANY CONSTANTS?

/*---------------------- Gaussian Blur ---------------------------------*/

    #pragma omp for schedule(static)
	for (row = 2; row < N-2; row++) {

		if (row==2){//in this case I calculate filt[0][:] and filt[1][:] too. No extra loads or multiplications are required for this
			  for (col = 0; col <= M-32; col+=28){

				  if (col==0){//this is a special case as the mask gets outside of the array (it is like adding two zeros in the beginning of frame[][]

						//load the 5 rows
						r0=_mm256_loadu_si256( (__m256i *) &frame1[row-2][0]);
						r1=_mm256_loadu_si256( (__m256i *) &frame1[row-1][0]);
						r2=_mm256_loadu_si256( (__m256i *) &frame1[row][0]);
						r3=_mm256_loadu_si256( (__m256i *) &frame1[row+1][0]);
						r4=_mm256_loadu_si256( (__m256i *) &frame1[row+2][0]);

				  			//START - extra code needed for prelude
				  					m0=_mm256_slli_si256(r0,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
				  					m1=_mm256_slli_si256(r1,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
				  					m2=_mm256_slli_si256(r2,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
				  					m3=_mm256_slli_si256(r3,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
				  					m4=_mm256_slli_si256(r4,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning

				  					r0=_mm256_and_si256(r0,mask_prelude);
				  					r0=_mm256_permute2f128_si256(r0,r0,1);
				  					r0=_mm256_srli_si256(r0,14);//shift 14 elements
				  					r0=_mm256_add_epi16(m0,r0);

				  					r1=_mm256_and_si256(r1,mask_prelude);
				  					r1=_mm256_permute2f128_si256(r1,r1,1);
				  					r1=_mm256_srli_si256(r1,14);//shift 14 elements
				  					r1=_mm256_add_epi16(m1,r1);

				  					r2=_mm256_and_si256(r2,mask_prelude);
				  					r2=_mm256_permute2f128_si256(r2,r2,1);
				  					r2=_mm256_srli_si256(r2,14);//shift 14 elements
				  					r2=_mm256_add_epi16(m2,r2);

				  					r3=_mm256_and_si256(r3,mask_prelude);
				  					r3=_mm256_permute2f128_si256(r3,r3,1);
				  					r3=_mm256_srli_si256(r3,14);//shift 14 elements
				  					r3=_mm256_add_epi16(m3,r3);

				  					r4=_mm256_and_si256(r4,mask_prelude);
				  					r4=_mm256_permute2f128_si256(r4,r4,1);
				  					r4=_mm256_srli_si256(r4,14);//shift 14 elements
				  					r4=_mm256_add_epi16(m4,r4);

				  			//END - extra code needed for prelude
				  		}
				  else {
						//load the 5 rows
						r0=_mm256_loadu_si256( (__m256i *) &frame1[row-2][col-2]);
						r1=_mm256_loadu_si256( (__m256i *) &frame1[row-1][col-2]);
						r2=_mm256_loadu_si256( (__m256i *) &frame1[row][col-2]);
						r3=_mm256_loadu_si256( (__m256i *) &frame1[row+1][col-2]);
						r4=_mm256_loadu_si256( (__m256i *) &frame1[row+2][col-2]);
				  }

				//col iteration computes output pixels of 2,8,14,20,26
				// col+1 iteration computes output pixels of 3,9,15,21,27
				// col+2 iteration computes output pixels of 4,10,16,22,28
				// col+3 iteration computes output pixels of 5,11,17,23,29
				// col+4 iteration computes output pixels of 6,12,18,24,30
				// col+5 iteration computes output pixels of 7,13,19,25,31
				//afterwards, col2 becomes 32 and repeat the above process

				  //y filter begins

					//multiply with the mask
					m0=_mm256_maddubs_epi16(r0,cy0);
					m1=_mm256_maddubs_epi16(r1,cy1);
					m2=_mm256_maddubs_epi16(r2,cy2);
					m3=_mm256_maddubs_epi16(r3,cy1);
					m4=_mm256_maddubs_epi16(r4,cy0);

					//vertical add
					m0=_mm256_add_epi16(m0,m1);
					m2=_mm256_add_epi16(m2,m3);
					m0=_mm256_add_epi16(m0,m2);
					m0=_mm256_add_epi16(m0,m4);

					even=division(division_case,m0,f);//even results

					//multiply with the mask
					m0=_mm256_maddubs_epi16(r0,cy0_sh1);
					m1=_mm256_maddubs_epi16(r1,cy1_sh1);
					m2=_mm256_maddubs_epi16(r2,cy2_sh1);
					m3=_mm256_maddubs_epi16(r3,cy1_sh1);
					m4=_mm256_maddubs_epi16(r4,cy0_sh1);

					//vertical add
					m0=_mm256_add_epi16(m0,m1);
					m2=_mm256_add_epi16(m2,m3);
					m0=_mm256_add_epi16(m0,m2);
					m0=_mm256_add_epi16(m0,m4);

					odd=division(division_case,m0,f);//odd results

					//pack to one register
					odd=_mm256_slli_si256(odd,1); //shift one position right
					row_2=_mm256_add_epi8(even,odd); //add the odd with the even

					//y filter ends - row_2 has the data to be processed by x filter

				//1st col iteration

				  //--------------row=2
				//multiply with the mask
				m0=_mm256_maddubs_epi16(row_2,cx);


				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
				m4=_mm256_and_si256(m0,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

				m2=_mm256_add_epi16(m2,m4);

				//now division of m2/divisor follows
				m2=division(division_case,m2,f);

				//and with mask to keep just 0,6,12,18,24
				output = _mm256_and_si256(m2,mask);

				//--------------row=0
				  //y filter begins

					//multiply with the mask
					m0=_mm256_maddubs_epi16(r0,cy2);
					m1=_mm256_maddubs_epi16(r1,cy1);
					m2=_mm256_maddubs_epi16(r2,cy0);

					//vertical add
					m0=_mm256_add_epi16(m0,m1);
					m0=_mm256_add_epi16(m0,m2);


					even=division(division_case,m0,f);//even results

					//multiply with the mask
					m0=_mm256_maddubs_epi16(r0,cy2_sh1);
					m1=_mm256_maddubs_epi16(r1,cy1_sh1);
					m2=_mm256_maddubs_epi16(r2,cy0_sh1);

					//vertical add
					m0=_mm256_add_epi16(m0,m1);
					m0=_mm256_add_epi16(m0,m2);

					odd=division(division_case,m0,f);//odd results

					//pack to one register
					odd=_mm256_slli_si256(odd,1); //shift one position right
					row_0=_mm256_add_epi8(even,odd); //add the odd with the even

					//y filter ends - row_0 has the data to be processed by x filter

				//multiply with the mask
				m0=_mm256_maddubs_epi16(row_0,cx);


				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
				m4=_mm256_and_si256(m0,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

				m2=_mm256_add_epi16(m2,m4);

				//now division of m2/divisor follows
				m2=division(division_case,m2,f);

				//and with mask to keep just 0,6,12,18,24
				output_row0 = _mm256_and_si256(m2,mask);

				//--------------row=1
				  //y filter begins

					//multiply with the mask
					m0=_mm256_maddubs_epi16(r0,cy1);
					m1=_mm256_maddubs_epi16(r1,cy2);
					m2=_mm256_maddubs_epi16(r2,cy1);
					m3=_mm256_maddubs_epi16(r3,cy0);


					//vertical add
					m0=_mm256_add_epi16(m0,m1);
					m2=_mm256_add_epi16(m2,m3);
					m0=_mm256_add_epi16(m0,m2);


					even=division(division_case,m0,f);//even results

					//multiply with the mask
					m0=_mm256_maddubs_epi16(r0,cy1_sh1);
					m1=_mm256_maddubs_epi16(r1,cy2_sh1);
					m2=_mm256_maddubs_epi16(r2,cy1_sh1);
					m3=_mm256_maddubs_epi16(r3,cy0_sh1);

					//vertical add
					m0=_mm256_add_epi16(m0,m1);
					m2=_mm256_add_epi16(m2,m3);
					m0=_mm256_add_epi16(m0,m2);

					odd=division(division_case,m0,f);//odd results

					//pack to one register
					odd=_mm256_slli_si256(odd,1); //shift one position right
					row_1=_mm256_add_epi8(even,odd); //add the odd with the even

					//y filter ends - row_1 has the data to be processed by x filter

				//multiply with the mask
				m0=_mm256_maddubs_epi16(row_1,cx);

				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
				m4=_mm256_and_si256(m0,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

				m2=_mm256_add_epi16(m2,m4);

				//now division of m2/divisor follows
				m2=division(division_case,m2,f);

				//and with mask to keep just 0,6,12,18,24
				output_row1 = _mm256_and_si256(m2,mask);

				//2nd col iteration

				//multiply with the mask

				//----row=2
				m0=_mm256_maddubs_epi16(row_2,cx_sh1);



				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
				m4=_mm256_and_si256(m0,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
				m2=_mm256_add_epi16(m2,m4);

				//now division of m2/divisor follows
				m2=division(division_case,m2,f);

				//and with mask to keep just 0,6,12,18,24
				m2 = _mm256_and_si256(m2,mask);
				m2 = _mm256_slli_si256(m2,1);
				output = _mm256_add_epi8(output,m2);

				//----row=0
				m0=_mm256_maddubs_epi16(row_0,cx_sh1);


				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
				m4=_mm256_and_si256(m0,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
				m2=_mm256_add_epi16(m2,m4);

				//now division of m2/divisor follows
				m2=division(division_case,m2,f);

				//and with mask to keep just 0,6,12,18,24
				m2 = _mm256_and_si256(m2,mask);
				m2 = _mm256_slli_si256(m2,1);
				output_row0 = _mm256_add_epi8(output_row0,m2);

				//----row=1
				m0=_mm256_maddubs_epi16(row_1,cx_sh1);


				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
				m4=_mm256_and_si256(m0,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
				m2=_mm256_add_epi16(m2,m4);

				//now division of m2/divisor follows
				m2=division(division_case,m2,f);

				//and with mask to keep just 0,6,12,18,24
				m2 = _mm256_and_si256(m2,mask);
				m2 = _mm256_slli_si256(m2,1);
				output_row1 = _mm256_add_epi8(output_row1,m2);

		                 //3rd col iteration
				//---row=2
				//multiply with the mask
				m0=_mm256_maddubs_epi16(row_2,cx_sh2);


				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
				m4=_mm256_and_si256(m2,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

				m2=_mm256_add_epi16(m2,m4);

				//now division of m2/divisor follows
				m2=division(division_case,m2,f);

				//and with mask to keep just 2,8,14,20,26
				m2 = _mm256_and_si256(m2,mask2);
				output = _mm256_add_epi8(output,m2);

				//---row=0
				//multiply with the mask
				m0=_mm256_maddubs_epi16(row_0,cx_sh2);


				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
				m4=_mm256_and_si256(m2,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

				m2=_mm256_add_epi16(m2,m4);

				//now division of m2/divisor follows
				m2=division(division_case,m2,f);

				//and with mask to keep just 2,8,14,20,26
				m2 = _mm256_and_si256(m2,mask2);
				output_row0 = _mm256_add_epi8(output_row0,m2);


				//---row=1
				//multiply with the mask
				m0=_mm256_maddubs_epi16(row_1,cx_sh2);

				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
				m4=_mm256_and_si256(m2,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

				m2=_mm256_add_epi16(m2,m4);

				//now division of m2/divisor follows
				m2=division(division_case,m2,f);

				//and with mask to keep just 2,8,14,20,26
				m2 = _mm256_and_si256(m2,mask2);
				output_row1 = _mm256_add_epi8(output_row1,m2);

				//4th col iteration

				//4th col iteration

				//multiply with the mask
				m0=_mm256_maddubs_epi16(row_2,cx_sh3);

				//hozizontal additions
				//hadd(3:8)
				//hadd(9:14)
				//hadd(15:20)
				//hadd(21:26)
				//hadd(27:31)
				//result after division will be in 2,8,14,20,26

				m1=_mm256_srli_si256(m0,2);
				m4=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m4);

				//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
				m4=_mm256_and_si256(m4,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

				m2=_mm256_add_epi16(m2,m4);

				//now division of r2/159 follows
				m2=division(division_case,m2,f);


				//and with mask to keep just 0,6,12,18,24
				m2 = _mm256_and_si256(m2,mask2);
				m2 = _mm256_slli_si256(m2,1);
				output = _mm256_add_epi8(output,m2);

				//row0
				//multiply with the mask
				m0=_mm256_maddubs_epi16(row_0,cx_sh3);


								m1=_mm256_srli_si256(m0,2);
								m4=_mm256_add_epi16(m1,m0);

								m1=_mm256_srli_si256(m0,4);
								m2=_mm256_add_epi16(m1,m4);

								//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
								//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
								m4=_mm256_and_si256(m4,mask3);
								m4=_mm256_permute2f128_si256(m4,m4,1);
								m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

								m2=_mm256_add_epi16(m2,m4);

								//now division of r2/159 follows
								m2=division(division_case,m2,f);


								//and with mask to keep just 0,6,12,18,24
								m2 = _mm256_and_si256(m2,mask2);
								m2 = _mm256_slli_si256(m2,1);
								output_row0 = _mm256_add_epi8(output_row0,m2);


								//-----------row1
								//multiply with the mask
								m0=_mm256_maddubs_epi16(row_1,cx_sh3);

												m1=_mm256_srli_si256(m0,2);
												m4=_mm256_add_epi16(m1,m0);

												m1=_mm256_srli_si256(m0,4);
												m2=_mm256_add_epi16(m1,m4);

												//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
												//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
												m4=_mm256_and_si256(m4,mask3);
												m4=_mm256_permute2f128_si256(m4,m4,1);
												m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

												m2=_mm256_add_epi16(m2,m4);

												//now division of r2/159 follows
												m2=division(division_case,m2,f);


												//and with mask to keep just 0,6,12,18,24
												m2 = _mm256_and_si256(m2,mask2);
												m2 = _mm256_slli_si256(m2,1);
												output_row1 = _mm256_add_epi8(output_row1,m2);



				//5th col iteration
				//multiply with the mask
				m0=_mm256_maddubs_epi16(row_2,cx_sh4);

				//hozizontal additions
				//hadd(4:9)
				//hadd(10:15)
				//hadd(16:21)
				//hadd(22:27)
				//result after division will be in 4,10,16,22

				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);


				//now division of r2/159 follows
				m2=division(division_case,m2,f);

				//and with mask to keep just 0,6,12,18,24
				m2 = _mm256_and_si256(m2,mask6);
				//m1 = _mm256_slli_si256(m2,4);
				output = _mm256_add_epi8(output,m2);

				//row0
				//multiply with the mask
				m0=_mm256_maddubs_epi16(row_0,cx_sh4);


				//hozizontal additions
				//hadd(4:9)
				//hadd(10:15)
				//hadd(16:21)
				//hadd(22:27)
				//result after division will be in 4,10,16,22

				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);


				//now division of r2/159 follows
				m2=division(division_case,m2,f);

				//and with mask to keep just 0,6,12,18,24
				m2 = _mm256_and_si256(m2,mask6);
				//m1 = _mm256_slli_si256(m2,4);
				output_row0 = _mm256_add_epi8(output_row0,m2);

				//row1
				//multiply with the mask
				m0=_mm256_maddubs_epi16(row_1,cx_sh4);


				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);


				//now division of r2/159 follows
				m2=division(division_case,m2,f);

				//and with mask to keep just 0,6,12,18,24
				m2 = _mm256_and_si256(m2,mask6);
				//m1 = _mm256_slli_si256(m2,4);
				output_row1 = _mm256_add_epi8(output_row1,m2);


		                 //6th col iteration
				//multiply with the mask
				m0=_mm256_maddubs_epi16(row_2,cx_sh5);

				//hozizontal additions
				//hadd(5:10)
				//hadd(11:16)
				//hadd(17:22)
				//hadd(23:28)
				//result after division will be in 4,10,16,22

				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//now division of r2/159 follows
				m2=division(division_case,m2,f);

				//and with mask to keep just 2,8,14,20,26
				m2 = _mm256_and_si256(m2,mask6);
				m1 = _mm256_slli_si256(m2,1);
				output = _mm256_add_epi8(output,m1);
				_mm256_storeu_si256( (__m256i *) &filt[row][col],output);

				//row0
				//multiply with the mask
				m0=_mm256_maddubs_epi16(row_0,cx_sh5);


				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//now division of r2/159 follows
				m2=division(division_case,m2,f);

				//and with mask to keep just 2,8,14,20,26
				m2 = _mm256_and_si256(m2,mask6);
				m1 = _mm256_slli_si256(m2,1);
				output_row0 = _mm256_add_epi8(output_row0,m1);
				_mm256_storeu_si256( (__m256i *) &filt[0][col],output_row0);

				//row1

				//multiply with the mask
				m0=_mm256_maddubs_epi16(row_1,cx_sh5);


				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//now division of r2/159 follows
				m2=division(division_case,m2,f);

				//and with mask to keep just 2,8,14,20,26
				m2 = _mm256_and_si256(m2,mask6);
				m1 = _mm256_slli_si256(m2,1);
				output_row1 = _mm256_add_epi8(output_row1,m1);

				_mm256_storeu_si256( (__m256i *) &filt[1][col],output_row1);


				}

			  if (REMINDER_ITERATIONS>=16)
				;//loop_reminder_first_rows_high_reminder_values(frame1,filt,M,N,col,REMINDER_ITERATIONS,division_case,c0,c1,c2,c0_sh1,c1_sh1,c2_sh1,c0_sh2,c1_sh2,c2_sh2,f,divisor);
			  else
			    ;//loop_reminder_first_rows_low_reminder_values(frame1,filt,M,N,col,REMINDER_ITERATIONS,division_case,c0,c1,c2,c0_sh1,c1_sh1,c2_sh1,c0_sh2,c1_sh2,c2_sh2,f);

		}

		else if (row==N-3){//in this case I calculate filt[N-2][:] and filt[N-1][:] too. Below row0 refers to row=N-2 and row1 refers to row=N-1
			for (col = 0; col <= M-32; col+=28){
						 //last col value that does not read outside of the array bounds is (col<M-29)

							  if (col==0){

									//load the 5 rows
									r0=_mm256_loadu_si256( (__m256i *) &frame1[row-2][0]);
									r1=_mm256_loadu_si256( (__m256i *) &frame1[row-1][0]);
									r2=_mm256_loadu_si256( (__m256i *) &frame1[row][0]);
									r3=_mm256_loadu_si256( (__m256i *) &frame1[row+1][0]);
									r4=_mm256_loadu_si256( (__m256i *) &frame1[row+2][0]);

							  			//START - extra code needed for prelude
							  					m0=_mm256_slli_si256(r0,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
							  					m1=_mm256_slli_si256(r1,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
							  					m2=_mm256_slli_si256(r2,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
							  					m3=_mm256_slli_si256(r3,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
							  					m4=_mm256_slli_si256(r4,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning

							  					r0=_mm256_and_si256(r0,mask_prelude);
							  					r0=_mm256_permute2f128_si256(r0,r0,1);
							  					r0=_mm256_srli_si256(r0,14);//shift 14 elements
							  					r0=_mm256_add_epi16(m0,r0);

							  					r1=_mm256_and_si256(r1,mask_prelude);
							  					r1=_mm256_permute2f128_si256(r1,r1,1);
							  					r1=_mm256_srli_si256(r1,14);//shift 14 elements
							  					r1=_mm256_add_epi16(m1,r1);

							  					r2=_mm256_and_si256(r2,mask_prelude);
							  					r2=_mm256_permute2f128_si256(r2,r2,1);
							  					r2=_mm256_srli_si256(r2,14);//shift 14 elements
							  					r2=_mm256_add_epi16(m2,r2);

							  					r3=_mm256_and_si256(r3,mask_prelude);
							  					r3=_mm256_permute2f128_si256(r3,r3,1);
							  					r3=_mm256_srli_si256(r3,14);//shift 14 elements
							  					r3=_mm256_add_epi16(m3,r3);

							  					r4=_mm256_and_si256(r4,mask_prelude);
							  					r4=_mm256_permute2f128_si256(r4,r4,1);
							  					r4=_mm256_srli_si256(r4,14);//shift 14 elements
							  					r4=_mm256_add_epi16(m4,r4);

							  			//END - extra code needed for prelude
							  		}
							  else {
									//load the 5 rows
									r0=_mm256_loadu_si256( (__m256i *) &frame1[row-2][col-2]);
									r1=_mm256_loadu_si256( (__m256i *) &frame1[row-1][col-2]);
									r2=_mm256_loadu_si256( (__m256i *) &frame1[row][col-2]);
									r3=_mm256_loadu_si256( (__m256i *) &frame1[row+1][col-2]);
									r4=_mm256_loadu_si256( (__m256i *) &frame1[row+2][col-2]);
							  }

							//col iteration computes output pixels of 2,8,14,20,26
							// col+1 iteration computes output pixels of 3,9,15,21,27
							// col+2 iteration computes output pixels of 4,10,16,22,28
							// col+3 iteration computes output pixels of 5,11,17,23,29
							// col+4 iteration computes output pixels of 6,12,18,24,30
							// col+5 iteration computes output pixels of 7,13,19,25,31
							//afterwards, col2 becomes 32 and repeat the above process

							//1st col iteration
							  //y filter begins

								//multiply with the mask
								m0=_mm256_maddubs_epi16(r0,cy0);
								m1=_mm256_maddubs_epi16(r1,cy1);
								m2=_mm256_maddubs_epi16(r2,cy2);
								m3=_mm256_maddubs_epi16(r3,cy1);
								m4=_mm256_maddubs_epi16(r4,cy0);

								//vertical add
								m0=_mm256_add_epi16(m0,m1);
								m2=_mm256_add_epi16(m2,m3);
								m0=_mm256_add_epi16(m0,m2);
								m0=_mm256_add_epi16(m0,m4);

								even=division(division_case,m0,f);//even results

								//multiply with the mask
								m0=_mm256_maddubs_epi16(r0,cy0_sh1);
								m1=_mm256_maddubs_epi16(r1,cy1_sh1);
								m2=_mm256_maddubs_epi16(r2,cy2_sh1);
								m3=_mm256_maddubs_epi16(r3,cy1_sh1);
								m4=_mm256_maddubs_epi16(r4,cy0_sh1);

								//vertical add
								m0=_mm256_add_epi16(m0,m1);
								m2=_mm256_add_epi16(m2,m3);
								m0=_mm256_add_epi16(m0,m2);
								m0=_mm256_add_epi16(m0,m4);

								odd=division(division_case,m0,f);//odd results

								//pack to one register
								odd=_mm256_slli_si256(odd,1); //shift one position right
								row_2=_mm256_add_epi8(even,odd); //add the odd with the even

								//y filter ends - row_2 has the data to be processed by x filter


							 //--------------row=2

							//multiply with the mask
							m0=_mm256_maddubs_epi16(row_2,cx);


							m1=_mm256_srli_si256(m0,2);
							m2=_mm256_add_epi16(m1,m0);

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m2);

							//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
							m4=_mm256_and_si256(m0,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

							m2=_mm256_add_epi16(m2,m4);

							//now division of m2/divisor follows
							m2=division(division_case,m2,f);

							//and with mask to keep just 0,6,12,18,24
							output = _mm256_and_si256(m2,mask);

							//--------------row=0
							  //y filter begins

								//multiply with the mask
								m1=_mm256_maddubs_epi16(r1,cy0);
								m2=_mm256_maddubs_epi16(r2,cy1);
								m3=_mm256_maddubs_epi16(r3,cy2);
								m4=_mm256_maddubs_epi16(r4,cy1);

								//vertical add
								m0=_mm256_add_epi16(m1,m2);
								m0=_mm256_add_epi16(m0,m3);
								m0=_mm256_add_epi16(m0,m4);

								even=division(division_case,m0,f);//even results

								//multiply with the mask
								m1=_mm256_maddubs_epi16(r1,cy0_sh1);
								m2=_mm256_maddubs_epi16(r2,cy1_sh1);
								m3=_mm256_maddubs_epi16(r3,cy2_sh1);
								m4=_mm256_maddubs_epi16(r4,cy1_sh1);

								//vertical add
								m0=_mm256_add_epi16(m1,m2);
								m0=_mm256_add_epi16(m0,m3);
								m0=_mm256_add_epi16(m0,m4);

								odd=division(division_case,m0,f);//odd results

								//pack to one register
								odd=_mm256_slli_si256(odd,1); //shift one position right
								row_0=_mm256_add_epi8(even,odd); //add the odd with the even

								//y filter ends - row_0 has the data to be processed by x filter

							//multiply with the mask
							m0=_mm256_maddubs_epi16(row_0,cx);


							m1=_mm256_srli_si256(m0,2);
							m2=_mm256_add_epi16(m1,m0);

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m2);

							//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
							m4=_mm256_and_si256(m0,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

							m2=_mm256_add_epi16(m2,m4);

							//now division of m2/divisor follows
							m2=division(division_case,m2,f);

							//and with mask to keep just 0,6,12,18,24
							output_row0 = _mm256_and_si256(m2,mask);

							//--------------row=1
							  //y filter begins

								//multiply with the mask
								m2=_mm256_maddubs_epi16(r2,cy0);
								m3=_mm256_maddubs_epi16(r3,cy1);
								m4=_mm256_maddubs_epi16(r4,cy2);

								//vertical add
								m0=_mm256_add_epi16(m2,m3);
								m0=_mm256_add_epi16(m0,m4);

								even=division(division_case,m0,f);//even results

								//multiply with the mask
								m2=_mm256_maddubs_epi16(r2,cy0_sh1);
								m3=_mm256_maddubs_epi16(r3,cy1_sh1);
								m4=_mm256_maddubs_epi16(r4,cy2_sh1);

								//vertical add
								m0=_mm256_add_epi16(m2,m3);
								m0=_mm256_add_epi16(m0,m4);

								odd=division(division_case,m0,f);//odd results

								//pack to one register
								odd=_mm256_slli_si256(odd,1); //shift one position right
								row_1=_mm256_add_epi8(even,odd); //add the odd with the even

								//y filter ends - row_1 has the data to be processed by x filter

							//multiply with the mask
							m0=_mm256_maddubs_epi16(row_1,cx);

							m1=_mm256_srli_si256(m0,2);
							m2=_mm256_add_epi16(m1,m0);

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m2);

							//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
							m4=_mm256_and_si256(m0,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

							m2=_mm256_add_epi16(m2,m4);

							//now division of m2/divisor follows
							m2=division(division_case,m2,f);

							//and with mask to keep just 0,6,12,18,24
							output_row1 = _mm256_and_si256(m2,mask);

							//2nd col iteration
							//----row=2

							//multiply with the mask
							m0=_mm256_maddubs_epi16(row_2,cx_sh1);


							m1=_mm256_srli_si256(m0,2);
							m2=_mm256_add_epi16(m1,m0);

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m2);

							//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
							m4=_mm256_and_si256(m0,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
							m2=_mm256_add_epi16(m2,m4);

							//now division of m2/divisor follows
							m2=division(division_case,m2,f);

							//and with mask to keep just 0,6,12,18,24
							m2 = _mm256_and_si256(m2,mask);
							m2 = _mm256_slli_si256(m2,1);
							output = _mm256_add_epi8(output,m2);

							//----row=0
							//multiply with the mask
							m0=_mm256_maddubs_epi16(row_0,cx_sh1);


							m1=_mm256_srli_si256(m0,2);
							m2=_mm256_add_epi16(m1,m0);

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m2);

							//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
							m4=_mm256_and_si256(m0,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
							m2=_mm256_add_epi16(m2,m4);

							//now division of m2/divisor follows
							m2=division(division_case,m2,f);

							//and with mask to keep just 0,6,12,18,24
							m2 = _mm256_and_si256(m2,mask);
							m2 = _mm256_slli_si256(m2,1);
							output_row0 = _mm256_add_epi8(output_row0,m2);

							//----row=1
							//multiply with the mask
							m0=_mm256_maddubs_epi16(row_1,cx_sh1);


							m1=_mm256_srli_si256(m0,2);
							m2=_mm256_add_epi16(m1,m0);

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m2);

							//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
							m4=_mm256_and_si256(m0,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
							m2=_mm256_add_epi16(m2,m4);

							//now division of m2/divisor follows
							m2=division(division_case,m2,f);

							//and with mask to keep just 0,6,12,18,24
							m2 = _mm256_and_si256(m2,mask);
							m2 = _mm256_slli_si256(m2,1);
							output_row1 = _mm256_add_epi8(output_row1,m2);

					                 //3rd col iteration
							//---row=2
							//multiply with the mask
							m0=_mm256_maddubs_epi16(row_2,cx_sh2);


							m1=_mm256_srli_si256(m0,2);
							m2=_mm256_add_epi16(m1,m0);

							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
							m4=_mm256_and_si256(m2,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m2);

							//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

							m2=_mm256_add_epi16(m2,m4);

							//now division of m2/divisor follows
							m2=division(division_case,m2,f);

							//and with mask to keep just 2,8,14,20,26
							m2 = _mm256_and_si256(m2,mask2);
							output = _mm256_add_epi8(output,m2);

							//---row=0
							//multiply with the mask
							m0=_mm256_maddubs_epi16(row_0,cx_sh2);

							m1=_mm256_srli_si256(m0,2);
							m2=_mm256_add_epi16(m1,m0);

							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
							m4=_mm256_and_si256(m2,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m2);

							//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

							m2=_mm256_add_epi16(m2,m4);

							//now division of m2/divisor follows
							m2=division(division_case,m2,f);

							//and with mask to keep just 2,8,14,20,26
							m2 = _mm256_and_si256(m2,mask2);
							output_row0 = _mm256_add_epi8(output_row0,m2);


							//---row=1
							//multiply with the mask
							m0=_mm256_maddubs_epi16(row_1,cx_sh2);


							m1=_mm256_srli_si256(m0,2);
							m2=_mm256_add_epi16(m1,m0);

							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
							m4=_mm256_and_si256(m2,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m2);

							//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

							m2=_mm256_add_epi16(m2,m4);

							//now division of m2/divisor follows
							m2=division(division_case,m2,f);

							//and with mask to keep just 2,8,14,20,26
							m2 = _mm256_and_si256(m2,mask2);
							output_row1 = _mm256_add_epi8(output_row1,m2);

							//4th col iteration
							//multiply with the mask
							m0=_mm256_maddubs_epi16(row_2,cx_sh3);

							//hozizontal additions
							//hadd(3:8)
							//hadd(9:14)
							//hadd(15:20)
							//hadd(21:26)
							//hadd(27:31)
							//result after division will be in 2,8,14,20,26

							m1=_mm256_srli_si256(m0,2);
							m4=_mm256_add_epi16(m1,m0);

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m4);

							//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
							m4=_mm256_and_si256(m4,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

							m2=_mm256_add_epi16(m2,m4);

							//now division of r2/159 follows
							m2=division(division_case,m2,f);


							//and with mask to keep just 0,6,12,18,24
							m2 = _mm256_and_si256(m2,mask2);
							m2 = _mm256_slli_si256(m2,1);
							output = _mm256_add_epi8(output,m2);

							//row0
							//multiply with the mask
							m0=_mm256_maddubs_epi16(row_0,cx_sh3);


								m1=_mm256_srli_si256(m0,2);
								m4=_mm256_add_epi16(m1,m0);

								m1=_mm256_srli_si256(m0,4);
								m2=_mm256_add_epi16(m1,m4);

								//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
								//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
								m4=_mm256_and_si256(m4,mask3);
								m4=_mm256_permute2f128_si256(m4,m4,1);
								m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

								m2=_mm256_add_epi16(m2,m4);

								//now division of r2/159 follows
								m2=division(division_case,m2,f);

								//and with mask to keep just 0,6,12,18,24
								m2 = _mm256_and_si256(m2,mask2);
								m2 = _mm256_slli_si256(m2,1);
								output_row0 = _mm256_add_epi8(output_row0,m2);

								//row1
								//multiply with the mask
								m0=_mm256_maddubs_epi16(row_1,cx_sh3);

									m1=_mm256_srli_si256(m0,2);
									m4=_mm256_add_epi16(m1,m0);

									m1=_mm256_srli_si256(m0,4);
									m2=_mm256_add_epi16(m1,m4);

									//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
									//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
									m4=_mm256_and_si256(m4,mask3);
									m4=_mm256_permute2f128_si256(m4,m4,1);
									m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

									m2=_mm256_add_epi16(m2,m4);

									//now division of r2/159 follows
									m2=division(division_case,m2,f);


									//and with mask to keep just 0,6,12,18,24
									m2 = _mm256_and_si256(m2,mask2);
									m2 = _mm256_slli_si256(m2,1);
									output_row1 = _mm256_add_epi8(output_row1,m2);


							//5th col iteration
							//multiply with the mask
							m0=_mm256_maddubs_epi16(row_2,cx_sh4);

							//hozizontal additions
							//hadd(4:9)
							//hadd(10:15)
							//hadd(16:21)
							//hadd(22:27)
							//result after division will be in 4,10,16,22

							m1=_mm256_srli_si256(m0,2);
							m2=_mm256_add_epi16(m1,m0);

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m2);


							//now division of r2/159 follows
							m2=division(division_case,m2,f);

							//and with mask to keep just 0,6,12,18,24
							m2 = _mm256_and_si256(m2,mask6);
							//m1 = _mm256_slli_si256(m2,4);
							output = _mm256_add_epi8(output,m2);

							//row0
							//multiply with the mask
							m0=_mm256_maddubs_epi16(row_0,cx_sh4);


							m1=_mm256_srli_si256(m0,2);
							m2=_mm256_add_epi16(m1,m0);

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m2);


							//now division of r2/159 follows
							m2=division(division_case,m2,f);

							//and with mask to keep just 0,6,12,18,24
							m2 = _mm256_and_si256(m2,mask6);
							//m1 = _mm256_slli_si256(m2,4);
							output_row0 = _mm256_add_epi8(output_row0,m2);

							//row1
							//multiply with the mask
							m0=_mm256_maddubs_epi16(row_1,cx_sh4);


							m1=_mm256_srli_si256(m0,2);
							m2=_mm256_add_epi16(m1,m0);

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m2);


							//now division of r2/159 follows
							m2=division(division_case,m2,f);

							//and with mask to keep just 0,6,12,18,24
							m2 = _mm256_and_si256(m2,mask6);
							//m1 = _mm256_slli_si256(m2,4);
							output_row1 = _mm256_add_epi8(output_row1,m2);

					                 //6th col iteration
							//multiply with the mask
							m0=_mm256_maddubs_epi16(row_2,cx_sh5);

							//hozizontal additions
							//hadd(5:10)
							//hadd(11:16)
							//hadd(17:22)
							//hadd(23:28)
							//result after division will be in 4,10,16,22

							m1=_mm256_srli_si256(m0,2);
							m2=_mm256_add_epi16(m1,m0);

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m2);

							//now division of r2/159 follows
							m2=division(division_case,m2,f);

							//and with mask to keep just 2,8,14,20,26
							m2 = _mm256_and_si256(m2,mask6);
							m1 = _mm256_slli_si256(m2,1);
							output = _mm256_add_epi8(output,m1);

							_mm256_storeu_si256( (__m256i *) &filt[row][col],output);

							//row0
							//multiply with the mask
							m0=_mm256_maddubs_epi16(row_0,cx_sh5);


							m1=_mm256_srli_si256(m0,2);
							m2=_mm256_add_epi16(m1,m0);

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m2);

							//now division of r2/159 follows
							m2=division(division_case,m2,f);

							//and with mask to keep just 2,8,14,20,26
							m2 = _mm256_and_si256(m2,mask6);
							m1 = _mm256_slli_si256(m2,1);
							output_row0 = _mm256_add_epi8(output_row0,m1);
							_mm256_storeu_si256( (__m256i *) &filt[N-2][col],output_row0);

							//row1
							//multiply with the mask
							m0=_mm256_maddubs_epi16(row_1,cx_sh5);

								m1=_mm256_srli_si256(m0,2);
							m2=_mm256_add_epi16(m1,m0);

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m2);

							//now division of r2/159 follows
							m2=division(division_case,m2,f);

							//and with mask to keep just 2,8,14,20,26
							m2 = _mm256_and_si256(m2,mask6);
							m1 = _mm256_slli_si256(m2,1);
							output_row1 = _mm256_add_epi8(output_row1,m1);
							_mm256_storeu_si256( (__m256i *) &filt[N-1][col],output_row1);


							}

			if (REMINDER_ITERATIONS>=16)
				;//loop_reminder_last_rows_high_reminder_values(frame1,filt,M,N,col,REMINDER_ITERATIONS,division_case,c0,c1,c2,c0_sh1,c1_sh1,c2_sh1,c0_sh2,c1_sh2,c2_sh2,f,divisor);
			else
				;//loop_reminder_last_rows_low_reminder_values(frame1,filt,M,N,col,REMINDER_ITERATIONS,division_case,c0,c1,c2,c0_sh1,c1_sh1,c2_sh1,c0_sh2,c1_sh2,c2_sh2,f);

					}
	else {


	  for (col = 0; col <= M-32; col+=28){
	 //last col value that does not read outside of the array bounds is (col<M-29)

		  if (col==0){

				//load the 5 rows
				r0=_mm256_loadu_si256( (__m256i *) &frame1[row-2][0]);
				r1=_mm256_loadu_si256( (__m256i *) &frame1[row-1][0]);
				r2=_mm256_loadu_si256( (__m256i *) &frame1[row][0]);
				r3=_mm256_loadu_si256( (__m256i *) &frame1[row+1][0]);
				r4=_mm256_loadu_si256( (__m256i *) &frame1[row+2][0]);

		  			//START - extra code needed for prelude
		  					m0=_mm256_slli_si256(r0,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
		  					m1=_mm256_slli_si256(r1,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
		  					m2=_mm256_slli_si256(r2,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
		  					m3=_mm256_slli_si256(r3,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
		  					m4=_mm256_slli_si256(r4,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning

		  					r0=_mm256_and_si256(r0,mask_prelude);
		  					r0=_mm256_permute2f128_si256(r0,r0,1);
		  					r0=_mm256_srli_si256(r0,14);//shift 14 elements
		  					r0=_mm256_add_epi16(m0,r0);

		  					r1=_mm256_and_si256(r1,mask_prelude);
		  					r1=_mm256_permute2f128_si256(r1,r1,1);
		  					r1=_mm256_srli_si256(r1,14);//shift 14 elements
		  					r1=_mm256_add_epi16(m1,r1);

		  					r2=_mm256_and_si256(r2,mask_prelude);
		  					r2=_mm256_permute2f128_si256(r2,r2,1);
		  					r2=_mm256_srli_si256(r2,14);//shift 14 elements
		  					r2=_mm256_add_epi16(m2,r2);

		  					r3=_mm256_and_si256(r3,mask_prelude);
		  					r3=_mm256_permute2f128_si256(r3,r3,1);
		  					r3=_mm256_srli_si256(r3,14);//shift 14 elements
		  					r3=_mm256_add_epi16(m3,r3);

		  					r4=_mm256_and_si256(r4,mask_prelude);
		  					r4=_mm256_permute2f128_si256(r4,r4,1);
		  					r4=_mm256_srli_si256(r4,14);//shift 14 elements
		  					r4=_mm256_add_epi16(m4,r4);

		  			//END - extra code needed for prelude
		  		}
		  else {
				//load the 5 rows
				r0=_mm256_loadu_si256( (__m256i *) &frame1[row-2][col-2]);
				r1=_mm256_loadu_si256( (__m256i *) &frame1[row-1][col-2]);
				r2=_mm256_loadu_si256( (__m256i *) &frame1[row][col-2]);
				r3=_mm256_loadu_si256( (__m256i *) &frame1[row+1][col-2]);
				r4=_mm256_loadu_si256( (__m256i *) &frame1[row+2][col-2]);
		  }

		  //y filter begins

			//multiply with the mask
			m0=_mm256_maddubs_epi16(r0,cy0);
			m1=_mm256_maddubs_epi16(r1,cy1);
			m2=_mm256_maddubs_epi16(r2,cy2);
			m3=_mm256_maddubs_epi16(r3,cy1);
			m4=_mm256_maddubs_epi16(r4,cy0);

			//vertical add
			m0=_mm256_add_epi16(m0,m1);
			m2=_mm256_add_epi16(m2,m3);
			m0=_mm256_add_epi16(m0,m2);
			m0=_mm256_add_epi16(m0,m4);

			even=division(division_case,m0,f);//even results

			//multiply with the mask
			m0=_mm256_maddubs_epi16(r0,cy0_sh1);
			m1=_mm256_maddubs_epi16(r1,cy1_sh1);
			m2=_mm256_maddubs_epi16(r2,cy2_sh1);
			m3=_mm256_maddubs_epi16(r3,cy1_sh1);
			m4=_mm256_maddubs_epi16(r4,cy0_sh1);

			//vertical add
			m0=_mm256_add_epi16(m0,m1);
			m2=_mm256_add_epi16(m2,m3);
			m0=_mm256_add_epi16(m0,m2);
			m0=_mm256_add_epi16(m0,m4);

			odd=division(division_case,m0,f);//odd results

			//pack to one register
			odd=_mm256_slli_si256(odd,1); //shift one position right
			r0=_mm256_add_epi8(even,odd); //add the odd with the even

			//y filter ends - r0 has the data to be processed by x filter

		//col iteration computes output pixels of 2,8,14,20,26
		// col+1 iteration computes output pixels of 3,9,15,21,27
		// col+2 iteration computes output pixels of 4,10,16,22,28
		// col+3 iteration computes output pixels of 5,11,17,23,29
		// col+4 iteration computes output pixels of 6,12,18,24
		// col+5 iteration computes output pixels of 7,13,19,25
		//afterwards, col becomes 30 and repeat the above process

		//1st col iteration


		//multiply with the mask
		m0=_mm256_maddubs_epi16(r0,cx);


		//hozizontal additions
		//hadd(0:5)
		//hadd(6:11)
		//hadd(12:17)
		//hadd(18:23)
		//hadd(24:28)

		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
		m4=_mm256_and_si256(m0,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

		m2=_mm256_add_epi16(m2,m4);

		//now division of m2/divisor follows
		m2=division(division_case,m2,f);


		//and with mask to keep just 0,6,12,18,24
		output = _mm256_and_si256(m2,mask);


		//2nd col iteration
		//multiply with the mask
		m0=_mm256_maddubs_epi16(r0,cx_sh1);

		//hozizontal additions
		//hadd(1:6)
		//hadd(7:12)
		//hadd(13:18)
		//hadd(19:24)
		//hadd(25:29)

		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
		m4=_mm256_and_si256(m0,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m2=division(division_case,m2,f);


		//and with mask to keep just 0,6,12,18,24
		m2 = _mm256_and_si256(m2,mask);
		m2 = _mm256_slli_si256(m2,1);
		output = _mm256_add_epi8(output,m2);


         //3rd col iteration
		//multiply with the mask
		m0=_mm256_maddubs_epi16(r0,cx_sh2);

		//hozizontal additions
		//hadd(2:7)
		//hadd(8:13)
		//hadd(14:19)
		//hadd(20:25)
		//hadd(26:30)


		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
		m4=_mm256_and_si256(m2,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m2=division(division_case,m2,f);


		//and with mask to keep just 2,8,14,20,26
		m2 = _mm256_and_si256(m2,mask2);
		output = _mm256_add_epi8(output,m2);


		//4th col iteration

		//multiply with the mask
		m0=_mm256_maddubs_epi16(r0,cx_sh3);

		//hozizontal additions
		//hadd(3:8)
		//hadd(9:14)
		//hadd(15:20)
		//hadd(21:26)
		//hadd(27:31)
		//result after division will be in 2,8,14,20,26

		m1=_mm256_srli_si256(m0,2);
		m4=_mm256_add_epi16(m1,m0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m4);

		//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
		m4=_mm256_and_si256(m4,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

		m2=_mm256_add_epi16(m2,m4);

		//now division of r2/159 follows
		m2=division(division_case,m2,f);


		//and with mask to keep just 0,6,12,18,24
		m2 = _mm256_and_si256(m2,mask2);
		m2 = _mm256_slli_si256(m2,1);
		output = _mm256_add_epi8(output,m2);


		//5th col iteration
		//multiply with the mask
		m0=_mm256_maddubs_epi16(r0,cx_sh4);

		//hozizontal additions
		//hadd(4:9)
		//hadd(10:15)
		//hadd(16:21)
		//hadd(22:27)
		//result after division will be in 4,10,16,22

		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);


		//now division of r2/159 follows
		m2=division(division_case,m2,f);

		//and with mask to keep just 0,6,12,18,24
		m2 = _mm256_and_si256(m2,mask6);
		//m1 = _mm256_slli_si256(m2,4);
		output = _mm256_add_epi8(output,m2);


                 //6th col iteration
		//multiply with the mask
		m0=_mm256_maddubs_epi16(r0,cx_sh5);

		//hozizontal additions
		//hadd(5:10)
		//hadd(11:16)
		//hadd(17:22)
		//hadd(23:28)
		//result after division will be in 4,10,16,22

		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//now division of r2/159 follows
		m2=division(division_case,m2,f);

		//and with mask to keep just 2,8,14,20,26
		m2 = _mm256_and_si256(m2,mask6);
		m1 = _mm256_slli_si256(m2,1);
		output = _mm256_add_epi8(output,m1);


		_mm256_storeu_si256( (__m256i *) &filt[row][col],output);


		}

        if (REMINDER_ITERATIONS>=16)
        	loop_reminder_high_reminder_values_seperable(frame1,filt,M,N,row,col,REMINDER_ITERATIONS,division_case, cx, cx_sh1, cx_sh2,cx_sh3,cx_sh4,cx_sh5,cy0, cy1,cy2, cy0_sh1, cy1_sh1, cy2_sh1,f,divisor);
        else
        	loop_reminder_low_reminder_values_seperable(frame1,filt,M,N,row,col,REMINDER_ITERATIONS,division_case, cx, cx_sh1, cx_sh2,cx_sh3,cx_sh4,cx_sh5,cy0, cy1,cy2, cy0_sh1, cy1_sh1, cy2_sh1,f);
		//padding code. The last three iterations  ABOVE get outside of the array bounds. The last three col iterations read outside but the garbage values are multiplied by zeros (last three mask zeros). From now on, I must include another mask with extra zeros.
//It is faster to read outside of the array's bounds and then fill the right values. there is an insert command that inserts a value to the vector
//TOMORROW: USE Gaussian_Blur_AVX_ver4_plus_less_load ROUTINE FOR LOOP REMINDER. LOAD OUTSIDE OF THE ARRAY AND THEN ZERO THE VALUES NEEDED.

		}
}

}//end of parallel


}



//for loop reminder<16 only
int loop_reminder_low_reminder_values_seperable(unsigned char **frame1,unsigned char **filt,const unsigned int M, const unsigned int N,const unsigned int row, const unsigned int col, const unsigned int REMINDER_ITERATIONS,const unsigned int division_case, const __m256i cx,const __m256i cx_sh1,const __m256i cx_sh2,const __m256i cx_sh3,const __m256i cx_sh4,const __m256i cx_sh5,const __m256i cy0, const __m256i cy1,const __m256i cy2,const __m256i cy0_sh1,const __m256i cy1_sh1, const __m256i cy2_sh1,const __m256i f ){

register	__m256i r0,r1,r2,r3,r4,m0,m1,m2,m3,m4,even,odd;

//const __m256i mask2  = _mm256_set_epi8(0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0);
const __m256i mask3  = _mm256_set_epi16(0,0,0,0,0,0,0,65535,0,0,0,0,0,0,0,0);

	//const __m256i f  = _mm256_set_epi16(52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759);


 __m256i reminder_mask1;//,reminder_mask2;

if (REMINDER_ITERATIONS == 0){
	return 0; //no loop reminder is needed
}

	reminder_mask1=_mm256_load_si256( (__m256i *) &reminder_msk1[REMINDER_ITERATIONS-1][0]);
	//reminder_mask2=_mm256_load_si256( (__m256i *) &reminder_msk2[REMINDER_ITERATIONS-1][0]);


	 //1st col iteration
	//load the 5 rows
	r0=_mm256_loadu_si256( (__m256i *) &frame1[row-2][col-2]);
	r1=_mm256_loadu_si256( (__m256i *) &frame1[row-1][col-2]);
	r2=_mm256_loadu_si256( (__m256i *) &frame1[row][col-2]);
	r3=_mm256_loadu_si256( (__m256i *) &frame1[row+1][col-2]);
	r4=_mm256_loadu_si256( (__m256i *) &frame1[row+2][col-2]);

	/*
	 * The above load operations load outside of the array bounds; these elements are filled with zeros just after
	 * Furthermore, I add two extra zeros in the end to compute col=N-2 and col=N-1. The last value of col is N-1, not N
	 */

	//AND r0-r4 with reminder_mask
	r0=_mm256_and_si256(r0,reminder_mask1);
	r1=_mm256_and_si256(r1,reminder_mask1);
	r2=_mm256_and_si256(r2,reminder_mask1);
	r3=_mm256_and_si256(r3,reminder_mask1);
	r4=_mm256_and_si256(r4,reminder_mask1);

	  //y filter begins

		//multiply with the mask
		m0=_mm256_maddubs_epi16(r0,cy0);
		m1=_mm256_maddubs_epi16(r1,cy1);
		m2=_mm256_maddubs_epi16(r2,cy2);
		m3=_mm256_maddubs_epi16(r3,cy1);
		m4=_mm256_maddubs_epi16(r4,cy0);

		//vertical add
		m0=_mm256_add_epi16(m0,m1);
		m2=_mm256_add_epi16(m2,m3);
		m0=_mm256_add_epi16(m0,m2);
		m0=_mm256_add_epi16(m0,m4);

		even=division(division_case,m0,f);//even results

		//multiply with the mask
		m0=_mm256_maddubs_epi16(r0,cy0_sh1);
		m1=_mm256_maddubs_epi16(r1,cy1_sh1);
		m2=_mm256_maddubs_epi16(r2,cy2_sh1);
		m3=_mm256_maddubs_epi16(r3,cy1_sh1);
		m4=_mm256_maddubs_epi16(r4,cy0_sh1);

		//vertical add
		m0=_mm256_add_epi16(m0,m1);
		m2=_mm256_add_epi16(m2,m3);
		m0=_mm256_add_epi16(m0,m2);
		m0=_mm256_add_epi16(m0,m4);

		odd=division(division_case,m0,f);//odd results

		//pack to one register
		odd=_mm256_slli_si256(odd,1); //shift one position right
		r0=_mm256_add_epi8(even,odd); //add the odd with the even

		//y filter ends - r0 has the data to be processed by x filter

	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,cx);

	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi
	m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m2=_mm256_add_epi16(m2,m4);

	//now division of m2/divisor follows
	m2=division(division_case,m2,f);


if (REMINDER_ITERATIONS > 12){
	filt[row][col] = (unsigned char) _mm256_extract_epi16(m2,0);
	filt[row][col+6] = (unsigned char) _mm256_extract_epi16(m2,3);
	filt[row][col+12] = (unsigned char) _mm256_extract_epi16(m2,6);
}
else if (REMINDER_ITERATIONS > 6){
	filt[row][col] = (unsigned char) _mm256_extract_epi16(m2,0);
	filt[row][col+6] = (unsigned char) _mm256_extract_epi16(m2,3);
}
else if (REMINDER_ITERATIONS > 0)
	filt[row][col] = (unsigned char) _mm256_extract_epi16(m2,0);

/*
if (REMINDER_ITERATIONS > 18)
	filt[row][col+18] = (unsigned char) _mm256_extract_epi16(m2,9);

if (REMINDER_ITERATIONS > 24)
	filt[row][col+24] = (unsigned char) _mm256_extract_epi16(m2,12);
*/


if (REMINDER_ITERATIONS ==1)
	return 0;


    //2nd col iteration

	//multiply with the mask
m0=_mm256_maddubs_epi16(r0,cx_sh1);

	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi
	m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m2=_mm256_add_epi16(m2,m4);

	//now division of m2/divisor follows
	m2=division(division_case,m2,f);




if (REMINDER_ITERATIONS > 13){
	filt[row][col+1] = (unsigned char) _mm256_extract_epi16(m2,0);
	filt[row][col+6+1] = (unsigned char) _mm256_extract_epi16(m2,3);
	filt[row][col+12+1] = (unsigned char) _mm256_extract_epi16(m2,6);
}
else if (REMINDER_ITERATIONS > 7){
	filt[row][col+1] = (unsigned char) _mm256_extract_epi16(m2,0);
	filt[row][col+6+1] = (unsigned char) _mm256_extract_epi16(m2,3);
}
else if (REMINDER_ITERATIONS > 1)
	filt[row][col+1] = (unsigned char) _mm256_extract_epi16(m2,0);

/*
if (REMINDER_ITERATIONS > 19)
	filt[row][col+18+1] = (unsigned char) _mm256_extract_epi16(m2,9);

if (REMINDER_ITERATIONS > 25)
	filt[row][col+24+1] = (unsigned char) _mm256_extract_epi16(m2,12);
*/


if (REMINDER_ITERATIONS ==2)
	return 0;


     //3rd col iteration

	//multiply with the mask
m0=_mm256_maddubs_epi16(r0,cx_sh2);

	//hozizontal additions
	//hadd(0:5)   and store filt[row[col]
	//hadd(6:11)   and store filt[row[col+8]
	//hadd(12:17) and store filt[row[col+14]
	//hadd(18:23) and store filt[row[col+20]
	//hadd(24:30) and store filt[row[col+26]

	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);
	m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

	m2=_mm256_add_epi16(m2,m4);

	//now division of m2/divisor follows
	m2=division(division_case,m2,f);



if (REMINDER_ITERATIONS > 14){
	filt[row][col+2] = (unsigned char) _mm256_extract_epi16(m2,1);
	filt[row][col+6+2] = (unsigned char) _mm256_extract_epi16(m2,4);
	filt[row][col+12+2] = (unsigned char) _mm256_extract_epi16(m2,7);
}
else if (REMINDER_ITERATIONS > 8){
	filt[row][col+2] = (unsigned char) _mm256_extract_epi16(m2,1);
	filt[row][col+6+2] = (unsigned char) _mm256_extract_epi16(m2,4);
}
else if (REMINDER_ITERATIONS > 2)
	filt[row][col+2] = (unsigned char) _mm256_extract_epi16(m2,1);


/*
if (REMINDER_ITERATIONS > 20)
	filt[row][col+18+2] = (unsigned char) _mm256_extract_epi16(m2,10);

if (REMINDER_ITERATIONS > 26)
	filt[row][col+24+2] = (unsigned char) _mm256_extract_epi16(m2,13);
*/

if (REMINDER_ITERATIONS ==3){
	return 0;
}


	 //4th col iteration
m0=_mm256_maddubs_epi16(r0,cx_sh3);


	m1=_mm256_srli_si256(m0,2);
	m4=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m4);

	//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m4=_mm256_and_si256(m4,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

	m2=_mm256_add_epi16(m2,m4);

	//now division of r2/159 follows
	m2=division(division_case,m2,f);



if (REMINDER_ITERATIONS > 9){
	filt[row][col+3] = (unsigned char) _mm256_extract_epi16(m2,1);
	filt[row][col+6+3] = (unsigned char) _mm256_extract_epi16(m2,4);
}
else if (REMINDER_ITERATIONS > 3)
	filt[row][col+3] = (unsigned char) _mm256_extract_epi16(m2,1);
/*
if (REMINDER_ITERATIONS > 15)
	filt[row][col+12+3] = (unsigned char) _mm256_extract_epi16(m2,6);

if (REMINDER_ITERATIONS > 21)
	filt[row][col+18+3] = (unsigned char) _mm256_extract_epi16(m2,9);

if (REMINDER_ITERATIONS > 27)
	filt[row][col+24+3] = (unsigned char) _mm256_extract_epi16(m2,12);
*/


if (REMINDER_ITERATIONS ==4)
	return 0;


   //5th col iteration

	//multiply with the mask
m0=_mm256_maddubs_epi16(r0,cx_sh4);

	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);


	//now division of m2/divisor follows
	m2=division(division_case,m2,f);




if (REMINDER_ITERATIONS > 10){
	filt[row][col+1+3] = (unsigned char) _mm256_extract_epi16(m2,2);
	filt[row][col+6+1+3] = (unsigned char) _mm256_extract_epi16(m2,5);
}
else if (REMINDER_ITERATIONS > 4)
	filt[row][col+1+3] = (unsigned char) _mm256_extract_epi16(m2,2);

/*
if (REMINDER_ITERATIONS > 16)
	filt[row][col+12+1+3] = (unsigned char) _mm256_extract_epi16(m2,6);

if (REMINDER_ITERATIONS > 22)
	filt[row][col+18+1+3] = (unsigned char) _mm256_extract_epi16(m2,9);

if (REMINDER_ITERATIONS > 28)
	filt[row][col+24+1+3] = (unsigned char) _mm256_extract_epi16(m2,12);
*/


if (REMINDER_ITERATIONS ==5)
	return 0;


    //6th col iteration

	//multiply with the mask
m0=_mm256_maddubs_epi16(r0,cx_sh5);

m1=_mm256_srli_si256(m0,2);
m2=_mm256_add_epi16(m1,m0);

m1=_mm256_srli_si256(m0,4);
m2=_mm256_add_epi16(m1,m2);


	//now division of m2/divisor follows
	m2=division(division_case,m2,f);



if (REMINDER_ITERATIONS > 11){
	filt[row][col+2+3] = (unsigned char) _mm256_extract_epi16(m2,2);
	filt[row][col+6+2+3] = (unsigned char) _mm256_extract_epi16(m2,5);
}
else if (REMINDER_ITERATIONS > 5)
	filt[row][col+2+3] = (unsigned char) _mm256_extract_epi16(m2,2);
/*
if (REMINDER_ITERATIONS > 17)
	filt[row][col+12+2+3] = (unsigned char) _mm256_extract_epi16(m2,7);

if (REMINDER_ITERATIONS > 23)
	filt[row][col+18+2+3] = (unsigned char) _mm256_extract_epi16(m2,10);

if (REMINDER_ITERATIONS > 29)
	filt[row][col+24+2+3] = (unsigned char) _mm256_extract_epi16(m2,13);
*/
/*
if (REMINDER_ITERATIONS == 31){

	int newPixel = 0;
	int col2=M-1;
	for (int rowOffset=-2; rowOffset<=2; rowOffset++) {
		for (int colOffset=-2; colOffset<=2; colOffset++) {

		   if ( ((row+rowOffset)<N) && ((col2+colOffset)<M) && ((row+rowOffset)>=0) && ((col2+colOffset)>=0) )
              newPixel += frame1[row+rowOffset][col2+colOffset] * gaussianMask[2 + rowOffset][2 + colOffset];

		      }
	        }
filt[row][M-1] = (unsigned char) (newPixel / 159);
}
*/
return 0;

}




//for REMINDER_ITERATIONS >=16 only
int loop_reminder_high_reminder_values_seperable(unsigned char **frame1,unsigned char **filt,const unsigned int M, const unsigned int N,const unsigned int row, const unsigned int col,const unsigned int REMINDER_ITERATIONS,const unsigned int division_case,const __m256i cx,const __m256i cx_sh1,const __m256i cx_sh2,const __m256i cx_sh3,const __m256i cx_sh4,const __m256i cx_sh5,const __m256i cy0, const __m256i cy1,const __m256i cy2,const __m256i cy0_sh1,const __m256i cy1_sh1, const __m256i cy2_sh1,const __m256i f,const unsigned int divisor){

register	__m256i r0,r1,r2,r3,r4,m0,m1,m2,m3,m4,output,even,odd;


		//const __m256i f  = _mm256_set_epi16(52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759);
		const __m256i mask  = _mm256_set_epi8(0,0,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255);
		const __m256i mask2  = _mm256_set_epi8(0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0);
		const __m256i mask3  = _mm256_set_epi16(0,0,0,0,0,0,0,65535,0,0,0,0,0,0,0,0);
//		const __m256i mask4  = _mm256_set_epi8(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,255,0,0,0,0,0,0,0,0,0,0,0,0);
//		const __m256i mask5  = _mm256_set_epi8(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
		const __m256i mask6  = _mm256_set_epi8(0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0);

 __m256i reminder_mask1;
		unsigned char temp[5],pix;
		unsigned int col2;
		int newPixel;

	reminder_mask1=_mm256_load_si256( (__m256i *) &reminder_msk1[REMINDER_ITERATIONS-1][0]);
//	reminder_mask2=_mm256_load_si256( (__m256i *) &reminder_msk2[REMINDER_ITERATIONS-1][0]);




	 //1st col iteration
	//load the 5 rows
	r0=_mm256_loadu_si256( (__m256i *) &frame1[row-2][col-2]);
	r1=_mm256_loadu_si256( (__m256i *) &frame1[row-1][col-2]);
	r2=_mm256_loadu_si256( (__m256i *) &frame1[row][col-2]);
	r3=_mm256_loadu_si256( (__m256i *) &frame1[row+1][col-2]);
	r4=_mm256_loadu_si256( (__m256i *) &frame1[row+2][col-2]);

	/*
	 * The above load operations load outside of the array bounds; these elements are filled with zeros just after
	 * Furthermore, I add two extra zeros in the end to compute col=N-2 and col=N-1. The last value of col is N-1, not N
	 */

	//AND r0-r4 with reminder_mask
	r0=_mm256_and_si256(r0,reminder_mask1);
	r1=_mm256_and_si256(r1,reminder_mask1);
	r2=_mm256_and_si256(r2,reminder_mask1);
	r3=_mm256_and_si256(r3,reminder_mask1);
	r4=_mm256_and_si256(r4,reminder_mask1);

	  //y filter begins

			//multiply with the mask
			m0=_mm256_maddubs_epi16(r0,cy0);
			m1=_mm256_maddubs_epi16(r1,cy1);
			m2=_mm256_maddubs_epi16(r2,cy2);
			m3=_mm256_maddubs_epi16(r3,cy1);
			m4=_mm256_maddubs_epi16(r4,cy0);

			//vertical add
			m0=_mm256_add_epi16(m0,m1);
			m2=_mm256_add_epi16(m2,m3);
			m0=_mm256_add_epi16(m0,m2);
			m0=_mm256_add_epi16(m0,m4);

			even=division(division_case,m0,f);//even results

			//multiply with the mask
			m0=_mm256_maddubs_epi16(r0,cy0_sh1);
			m1=_mm256_maddubs_epi16(r1,cy1_sh1);
			m2=_mm256_maddubs_epi16(r2,cy2_sh1);
			m3=_mm256_maddubs_epi16(r3,cy1_sh1);
			m4=_mm256_maddubs_epi16(r4,cy0_sh1);

			//vertical add
			m0=_mm256_add_epi16(m0,m1);
			m2=_mm256_add_epi16(m2,m3);
			m0=_mm256_add_epi16(m0,m2);
			m0=_mm256_add_epi16(m0,m4);

			odd=division(division_case,m0,f);//odd results

			//pack to one register
			odd=_mm256_slli_si256(odd,1); //shift one position right
			r0=_mm256_add_epi8(even,odd); //add the odd with the even

			//y filter ends - r0 has the data to be processed by x filter


	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,cx);

	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m4=_mm256_and_si256(m0,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

	m2=_mm256_add_epi16(m2,m4);

	//now division of r2/159 follows
	m2=division(division_case,m2,f);

	//and with mask to keep just 0,6,12,18,24
	output = _mm256_and_si256(m2,mask);


	//2nd col iteration
	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,cx_sh1);

	//hozizontal additions
	//hadd(0:5)   and store filt[row[col]
	//hadd(6:11)   and store filt[row[col+8]
	//hadd(12:17) and store filt[row[col+14]
	//hadd(18:23) and store filt[row[col+20]
	//hadd(24:30) and store filt[row[col+26]

	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m4=_mm256_and_si256(m0,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
	m2=_mm256_add_epi16(m2,m4);

	//now division of r2/159 follows
	m2=division(division_case,m2,f);

	//and with mask to keep just 0,6,12,18,24
	m2 = _mm256_and_si256(m2,mask);
	m2 = _mm256_slli_si256(m2,1);
	output = _mm256_add_epi8(output,m2);


             //3rd col iteration
	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,cx_sh2);

	//hozizontal additions
	//hadd(0:5)   and store filt[row[col]
	//hadd(6:11)   and store filt[row[col+8]
	//hadd(12:17) and store filt[row[col+14]
	//hadd(18:23) and store filt[row[col+20]
	//hadd(24:30) and store filt[row[col+26]

	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
	m4=_mm256_and_si256(m2,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

	m2=_mm256_add_epi16(m2,m4);

	//now division of r2/159 follows
	m2=division(division_case,m2,f);

	//and with mask to keep just 2,8,14,20,26
	m2 = _mm256_and_si256(m2,mask2);
	output = _mm256_add_epi8(output,m2);

	//4th col iteration
	m0=_mm256_maddubs_epi16(r0,cx_sh3);

	m1=_mm256_srli_si256(m0,2);
	m4=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m4);

	//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m4=_mm256_and_si256(m4,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

	m2=_mm256_add_epi16(m2,m4);

	//now division of r2/159 follows
	m2=division(division_case,m2,f);


	//and with mask to keep just 0,6,12,18,24
	m2 = _mm256_and_si256(m2,mask2);
	m2 = _mm256_slli_si256(m2,1);
	output = _mm256_add_epi8(output,m2);




	//5th col iteration
	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,cx_sh4);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);


	//now division of r2/159 follows
	m2=division(division_case,m2,f);

	//and with mask to keep just 0,6,12,18,24
	m2 = _mm256_and_si256(m2,mask6);
	//m1 = _mm256_slli_si256(m2,4);
	output = _mm256_add_epi8(output,m2);

             //6th col iteration
	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,cx_sh5);


	m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//now division of r2/159 follows
		m2=division(division_case,m2,f);

		//and with mask to keep just 2,8,14,20,26
		m2 = _mm256_and_si256(m2,mask6);
		m1 = _mm256_slli_si256(m2,1);
		output = _mm256_add_epi8(output,m1);

	//_mm256_storeu_si256( (__m256i *) &filt[row][col],output);
	_mm_storeu_si128( (__m128i *) &filt[row][col],_mm256_extractf128_si256(output, 0)); //store low 128bit - 16pixels

	switch (REMINDER_ITERATIONS){
	case 16:
	  break;
	case 17:
		filt[row][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		  break;
	case 18:
		filt[row][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[row][col+17] = (unsigned char) _mm256_extract_epi8(output,17);
		  break;
	case 19:
		filt[row][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[row][col+17] = (unsigned char) _mm256_extract_epi8(output,17);
		filt[row][col+18] = (unsigned char) _mm256_extract_epi8(output,18);
		  break;
	case 20:
		filt[row][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[row][col+17] = (unsigned char) _mm256_extract_epi8(output,17);
		filt[row][col+18] = (unsigned char) _mm256_extract_epi8(output,18);
		filt[row][col+19] = (unsigned char) _mm256_extract_epi8(output,19);
		  break;
	case 21:
		filt[row][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[row][col+17] = (unsigned char) _mm256_extract_epi8(output,17);
		filt[row][col+18] = (unsigned char) _mm256_extract_epi8(output,18);
		filt[row][col+19] = (unsigned char) _mm256_extract_epi8(output,19);
		filt[row][col+20] = (unsigned char) _mm256_extract_epi8(output,20);
		  break;
	case 22:
		filt[row][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[row][col+17] = (unsigned char) _mm256_extract_epi8(output,17);
		filt[row][col+18] = (unsigned char) _mm256_extract_epi8(output,18);
		filt[row][col+19] = (unsigned char) _mm256_extract_epi8(output,19);
		filt[row][col+20] = (unsigned char) _mm256_extract_epi8(output,20);
		filt[row][col+21] = (unsigned char) _mm256_extract_epi8(output,21);
		  break;
	case 23:
		filt[row][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[row][col+17] = (unsigned char) _mm256_extract_epi8(output,17);
		filt[row][col+18] = (unsigned char) _mm256_extract_epi8(output,18);
		filt[row][col+19] = (unsigned char) _mm256_extract_epi8(output,19);
		filt[row][col+20] = (unsigned char) _mm256_extract_epi8(output,20);
		filt[row][col+21] = (unsigned char) _mm256_extract_epi8(output,21);
		filt[row][col+22] = (unsigned char) _mm256_extract_epi8(output,22);
		  break;
	case 24:
		//_mm_storeu_si64( (__m128i *) &filt[row][col+16],_mm256_extractf128_si256(output, 0)); //store low 128bit - 16pixels
		filt[row][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[row][col+17] = (unsigned char) _mm256_extract_epi8(output,17);
		filt[row][col+18] = (unsigned char) _mm256_extract_epi8(output,18);
		filt[row][col+19] = (unsigned char) _mm256_extract_epi8(output,19);
		filt[row][col+20] = (unsigned char) _mm256_extract_epi8(output,20);
		filt[row][col+21] = (unsigned char) _mm256_extract_epi8(output,21);
		filt[row][col+22] = (unsigned char) _mm256_extract_epi8(output,22);
		filt[row][col+23] = (unsigned char) _mm256_extract_epi8(output,23);
		  break;
	case 25:
		filt[row][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[row][col+17] = (unsigned char) _mm256_extract_epi8(output,17);
		filt[row][col+18] = (unsigned char) _mm256_extract_epi8(output,18);
		filt[row][col+19] = (unsigned char) _mm256_extract_epi8(output,19);
		filt[row][col+20] = (unsigned char) _mm256_extract_epi8(output,20);
		filt[row][col+21] = (unsigned char) _mm256_extract_epi8(output,21);
		filt[row][col+22] = (unsigned char) _mm256_extract_epi8(output,22);
		filt[row][col+23] = (unsigned char) _mm256_extract_epi8(output,23);
		filt[row][col+24] = (unsigned char) _mm256_extract_epi8(output,24);
		  break;
	case 26:
		filt[row][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[row][col+17] = (unsigned char) _mm256_extract_epi8(output,17);
		filt[row][col+18] = (unsigned char) _mm256_extract_epi8(output,18);
		filt[row][col+19] = (unsigned char) _mm256_extract_epi8(output,19);
		filt[row][col+20] = (unsigned char) _mm256_extract_epi8(output,20);
		filt[row][col+21] = (unsigned char) _mm256_extract_epi8(output,21);
		filt[row][col+22] = (unsigned char) _mm256_extract_epi8(output,22);
		filt[row][col+23] = (unsigned char) _mm256_extract_epi8(output,23);
		filt[row][col+24] = (unsigned char) _mm256_extract_epi8(output,24);
		filt[row][col+25] = (unsigned char) _mm256_extract_epi8(output,25);
		  break;
	case 27:
		filt[row][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[row][col+17] = (unsigned char) _mm256_extract_epi8(output,17);
		filt[row][col+18] = (unsigned char) _mm256_extract_epi8(output,18);
		filt[row][col+19] = (unsigned char) _mm256_extract_epi8(output,19);
		filt[row][col+20] = (unsigned char) _mm256_extract_epi8(output,20);
		filt[row][col+21] = (unsigned char) _mm256_extract_epi8(output,21);
		filt[row][col+22] = (unsigned char) _mm256_extract_epi8(output,22);
		filt[row][col+23] = (unsigned char) _mm256_extract_epi8(output,23);
		filt[row][col+24] = (unsigned char) _mm256_extract_epi8(output,24);
		filt[row][col+25] = (unsigned char) _mm256_extract_epi8(output,25);
		filt[row][col+26] = (unsigned char) _mm256_extract_epi8(output,26);
		  break;
	case 28:
		filt[row][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[row][col+17] = (unsigned char) _mm256_extract_epi8(output,17);
		filt[row][col+18] = (unsigned char) _mm256_extract_epi8(output,18);
		filt[row][col+19] = (unsigned char) _mm256_extract_epi8(output,19);
		filt[row][col+20] = (unsigned char) _mm256_extract_epi8(output,20);
		filt[row][col+21] = (unsigned char) _mm256_extract_epi8(output,21);
		filt[row][col+22] = (unsigned char) _mm256_extract_epi8(output,22);
		filt[row][col+23] = (unsigned char) _mm256_extract_epi8(output,23);
		filt[row][col+24] = (unsigned char) _mm256_extract_epi8(output,24);
		filt[row][col+25] = (unsigned char) _mm256_extract_epi8(output,25);
		filt[row][col+26] = (unsigned char) _mm256_extract_epi8(output,26);
		filt[row][col+27] = (unsigned char) _mm256_extract_epi8(output,27);
		  break;
	case 29:
		filt[row][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[row][col+17] = (unsigned char) _mm256_extract_epi8(output,17);
		filt[row][col+18] = (unsigned char) _mm256_extract_epi8(output,18);
		filt[row][col+19] = (unsigned char) _mm256_extract_epi8(output,19);
		filt[row][col+20] = (unsigned char) _mm256_extract_epi8(output,20);
		filt[row][col+21] = (unsigned char) _mm256_extract_epi8(output,21);
		filt[row][col+22] = (unsigned char) _mm256_extract_epi8(output,22);
		filt[row][col+23] = (unsigned char) _mm256_extract_epi8(output,23);
		filt[row][col+24] = (unsigned char) _mm256_extract_epi8(output,24);
		filt[row][col+25] = (unsigned char) _mm256_extract_epi8(output,25);
		filt[row][col+26] = (unsigned char) _mm256_extract_epi8(output,26);
		filt[row][col+27] = (unsigned char) _mm256_extract_epi8(output,27);

		//I need to calculate the y filter for elements  prior to the M-3, otherwise the x filter cannot work
	for (col2 = col+26; col2 <=col+28; col2++) {
		newPixel = 0;
		for (int offs=-2; offs<=2; offs++) {

               newPixel += frame1[row+offs][col2] * gaussianMask_1d[2 + offs];

			}

	temp[col2-(col+26)] = (unsigned char) (newPixel / divisor);

	}
	temp[3]=0;temp[4]=0;

	for (col2 = col+28; col2 <= col+28; col2++) {
					newPixel = 0;
					for (int off=-2; off<=2; off++) {
						//printf("\n %d",col2-(col+26)+off);
							if ( (col2-(col+26)+off>=3) )
								pix=0;
							else
								pix=temp[col2-(col+26)+off];

		                   newPixel += pix * gaussianMask_1d[2 + off];
						}

				filt[row][col2] = (unsigned char) (newPixel / divisor);

				}

		  break;
	case 30:
		filt[row][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[row][col+17] = (unsigned char) _mm256_extract_epi8(output,17);
		filt[row][col+18] = (unsigned char) _mm256_extract_epi8(output,18);
		filt[row][col+19] = (unsigned char) _mm256_extract_epi8(output,19);
		filt[row][col+20] = (unsigned char) _mm256_extract_epi8(output,20);
		filt[row][col+21] = (unsigned char) _mm256_extract_epi8(output,21);
		filt[row][col+22] = (unsigned char) _mm256_extract_epi8(output,22);
		filt[row][col+23] = (unsigned char) _mm256_extract_epi8(output,23);
		filt[row][col+24] = (unsigned char) _mm256_extract_epi8(output,24);
		filt[row][col+25] = (unsigned char) _mm256_extract_epi8(output,25);
		filt[row][col+26] = (unsigned char) _mm256_extract_epi8(output,26);
		filt[row][col+27] = (unsigned char) _mm256_extract_epi8(output,27);

		//I need to calculate the y filter for elements  prior to the M-3, otherwise the x filter cannot work
	for (col2 = col+26; col2 <=col+29; col2++) {
		newPixel = 0;
		for (int offs=-2; offs<=2; offs++) {

               newPixel += frame1[row+offs][col2] * gaussianMask_1d[2 + offs];

			}

	temp[col2-(col+26)] = (unsigned char) (newPixel / divisor);
	}
	temp[5]=0;

	for (col2 = col+28; col2 <= col+29; col2++) {
					newPixel = 0;
					for (int off=-2; off<=2; off++) {
						//printf("\n %d",col2-(col+26)+off);
							if ( (col2-(col+26)+off>=4) )
								pix=0;
							else
								pix=temp[col2-(col+26)+off];

		                   newPixel += pix * gaussianMask_1d[2 + off];
						}

				filt[row][col2] = (unsigned char) (newPixel / divisor);

				}

		  break;
	case 31:
		filt[row][col+16] = (unsigned char) _mm256_extract_epi8(output,16);
		filt[row][col+17] = (unsigned char) _mm256_extract_epi8(output,17);
		filt[row][col+18] = (unsigned char) _mm256_extract_epi8(output,18);
		filt[row][col+19] = (unsigned char) _mm256_extract_epi8(output,19);
		filt[row][col+20] = (unsigned char) _mm256_extract_epi8(output,20);
		filt[row][col+21] = (unsigned char) _mm256_extract_epi8(output,21);
		filt[row][col+22] = (unsigned char) _mm256_extract_epi8(output,22);
		filt[row][col+23] = (unsigned char) _mm256_extract_epi8(output,23);
		filt[row][col+24] = (unsigned char) _mm256_extract_epi8(output,24);
		filt[row][col+25] = (unsigned char) _mm256_extract_epi8(output,25);
		filt[row][col+26] = (unsigned char) _mm256_extract_epi8(output,26);
		filt[row][col+27] = (unsigned char) _mm256_extract_epi8(output,27);

			//I need to calculate the y filter for elements  prior to the M-3, otherwise the x filter cannot work
		for (col2 = col+26; col2 <=col+30; col2++) {
			newPixel = 0;
			for (int offs=-2; offs<=2; offs++) {

                   newPixel += frame1[row+offs][col2] * gaussianMask_1d[2 + offs];

				}

		temp[col2-(col+26)] = (unsigned char) (newPixel / divisor);

		}

		for (col2 = col+28; col2 <= col+30; col2++) {
						newPixel = 0;
						for (int off=-2; off<=2; off++) {
							//printf("\n %d",col2-(col+26)+off);
								if ( (col2-(col+26)+off>=5) )
									pix=0;
								else
									pix=temp[col2-(col+26)+off];

			                   newPixel += pix * gaussianMask_1d[2 + off];
							}

					filt[row][col2] = (unsigned char) (newPixel / divisor);

					}



		  break;
	default:
		printf("\n something went wrong");
	}

return 0;

}




void Gaussian_Blur_optimized_5x5_step28_less_div(unsigned char **frame1,unsigned char **filt,const unsigned int M, const unsigned int N, const unsigned short int divisor, unsigned char **filter5x5){

const unsigned char f00=filter5x5[0][0];
const unsigned char f01=filter5x5[0][1];
const unsigned char f02=filter5x5[0][2];
const unsigned char f03=filter5x5[0][3];
const unsigned char f04=filter5x5[0][4];

const unsigned char f10=filter5x5[1][0];
const unsigned char f11=filter5x5[1][1];
const unsigned char f12=filter5x5[1][2];
const unsigned char f13=filter5x5[1][3];
const unsigned char f14=filter5x5[1][4];

const unsigned char f20=filter5x5[2][0];
const unsigned char f21=filter5x5[2][1];
const unsigned char f22=filter5x5[2][2];
const unsigned char f23=filter5x5[2][3];
const unsigned char f24=filter5x5[2][4];


	const __m256i c0=_mm256_set_epi8(0,0,0,f04,f03,f02,f01,f00,0,f04,f03,f02,f01,f00,0,f04,f03,f02,f01,f00,0,f04,f03,f02,f01,f00,0,f04,f03,f02,f01,f00);
	const __m256i c1=_mm256_set_epi8(0,0,0,f14,f13,f12,f11,f10,0,f14,f13,f12,f11,f10,0,f14,f13,f12,f11,f10,0,f14,f13,f12,f11,f10,0,f14,f13,f12,f11,f10);
	const __m256i c2=_mm256_set_epi8(0,0,0,f24,f23,f22,f21,f20,0,f24,f23,f22,f21,f20,0,f24,f23,f22,f21,f20,0,f24,f23,f22,f21,f20,0,f24,f23,f22,f21,f20);

	const __m256i c0_sh1=_mm256_set_epi8(0,0,f04,f03,f02,f01,f00,0,f04,f03,f02,f01,f00,0,f04,f03,f02,f01,f00,0,f04,f03,f02,f01,f00,0,f04,f03,f02,f01,f00,0);
	const __m256i c1_sh1=_mm256_set_epi8(0,0,f14,f13,f12,f11,f10,0,f14,f13,f12,f11,f10,0,f14,f13,f12,f11,f10,0,f14,f13,f12,f11,f10,0,f14,f13,f12,f11,f10,0);
	const __m256i c2_sh1=_mm256_set_epi8(0,0,f24,f23,f22,f21,f20,0,f24,f23,f22,f21,f20,0,f24,f23,f22,f21,f20,0,f24,f23,f22,f21,f20,0,f24,f23,f22,f21,f20,0);

	const __m256i c0_sh2=_mm256_set_epi8(0,f04,f03,f02,f01,f00,0,f04,f03,f02,f01,f00,0,f04,f03,f02,f01,f00,0,f04,f03,f02,f01,f00,0,f04,f03,f02,f01,f00,0,0);
	const __m256i c1_sh2=_mm256_set_epi8(0,f14,f13,f12,f11,f10,0,f14,f13,f12,f11,f10,0,f14,f13,f12,f11,f10,0,f14,f13,f12,f11,f10,0,f14,f13,f12,f11,f10,0,0);
	const __m256i c2_sh2=_mm256_set_epi8(0,f24,f23,f22,f21,f20,0,f24,f23,f22,f21,f20,0,f24,f23,f22,f21,f20,0,f24,f23,f22,f21,f20,0,f24,f23,f22,f21,f20,0,0);

	const __m256i c0_sh3=_mm256_set_epi8(f04,f03,f02,f01,f00,0,f04,f03,f02,f01,f00,0,f04,f03,f02,f01,f00,0,f04,f03,f02,f01,f00,0,f04,f03,f02,f01,f00,0,0,0);
	const __m256i c1_sh3=_mm256_set_epi8(f14,f13,f12,f11,f10,0,f14,f13,f12,f11,f10,0,f14,f13,f12,f11,f10,0,f14,f13,f12,f11,f10,0,f14,f13,f12,f11,f10,0,0,0);
	const __m256i c2_sh3=_mm256_set_epi8(f24,f23,f22,f21,f20,0,f24,f23,f22,f21,f20,0,f24,f23,f22,f21,f20,0,f24,f23,f22,f21,f20,0,f24,f23,f22,f21,f20,0,0,0);

	const __m256i c0_sh4=_mm256_set_epi8(0,0,0,0,0,f04,f03,f02,f01,f00,0,f04,f03,f02,f01,f00,0,f04,f03,f02,f01,f00,0,f04,f03,f02,f01,f00,0,0,0,0);
	const __m256i c1_sh4=_mm256_set_epi8(0,0,0,0,0,f14,f13,f12,f11,f10,0,f14,f13,f12,f11,f10,0,f14,f13,f12,f11,f10,0,f14,f13,f12,f11,f10,0,0,0,0);
	const __m256i c2_sh4=_mm256_set_epi8(0,0,0,0,0,f24,f23,f22,f21,f20,0,f24,f23,f22,f21,f20,0,f24,f23,f22,f21,f20,0,f24,f23,f22,f21,f20,0,0,0,0);

	const __m256i c0_sh5=_mm256_set_epi8(0,0,0,0,f04,f03,f02,f01,f00,0,f04,f03,f02,f01,f00,0,f04,f03,f02,f01,f00,0,f04,f03,f02,f01,f00,0,0,0,0,0);
	const __m256i c1_sh5=_mm256_set_epi8(0,0,0,0,f14,f13,f12,f11,f10,0,f14,f13,f12,f11,f10,0,f14,f13,f12,f11,f10,0,f14,f13,f12,f11,f10,0,0,0,0,0);
	const __m256i c2_sh5=_mm256_set_epi8(0,0,0,0,f24,f23,f22,f21,f20,0,f24,f23,f22,f21,f20,0,f24,f23,f22,f21,f20,0,f24,f23,f22,f21,f20,0,0,0,0,0);



	//const __m256i f  = _mm256_set_epi16(52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759);
	//const __m256i mask  = _mm256_set_epi8(0,0,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255);
	//const __m256i mask2  = _mm256_set_epi8(0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0);
	//const __m256i mask6  = _mm256_set_epi8(0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0);

	const __m256i mask3  = _mm256_set_epi16(0,0,0,0,0,0,0,65535,0,0,0,0,0,0,0,0);
	const __m256i mask_prelude  = _mm256_set_epi8(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0);

	const __m256i output_mask      = _mm256_set_epi16(0,0,0,65535,0,0,65535,0,0,65535,0,0,65535,0,0,65535);
	const __m256i output_mask_sh1  = _mm256_set_epi16(0,0,65535,0,0,65535,0,0,65535,0,0,65535,0,0,65535,0);
	const __m256i output_mask_sh2  = _mm256_set_epi16(0,0,0,    0,65535,0,0,65535,0,0,65535,0,0,65535,0,0);



	const unsigned int REMINDER_ITERATIONS =  (M-((((M-32)/28)*28)+28)); //M-(last_col_value+28)
	//printf("\n%d",REMINDER_ITERATIONS);


	const unsigned int division_case=prepare_for_division(divisor); //determine which is the division case (A, B or C)
	const __m256i f = _mm256_load_si256( (__m256i *) &f_vector[0]);// initialize the division vector

//printf("\n%d %d",division_case,b);


#pragma omp parallel
{

unsigned int row,col;
register __m256i r0,r1,r2,r3,r4,m0,m1,m2,m3,m4;
__m256i output_row0_even,output_row1_even,output_row0_odd,output_row1_odd; //these are for processing row #0 and #1 only.
__m256i output_even,output_odd;
__m256i m0_prelude_row0,m0_prelude_row1;


/*---------------------- Gaussian Blur ---------------------------------*/

    #pragma omp for schedule(static)
	for (row = 2; row < N-2; row++) {

		if (row==2){//in this case I calculate filt[0][:] and filt[1][:] too. No extra loads or multiplications are required for this
			  for (col = 0; col <= M-32; col+=28){

				  if (col==0){//this is a special case as the mask gets outside of the array (it is like adding two zeros in the beginning of frame[][]

						//load the 5 rows
						r0=_mm256_loadu_si256( (__m256i *) &frame1[row-2][0]);
						r1=_mm256_loadu_si256( (__m256i *) &frame1[row-1][0]);
						r2=_mm256_loadu_si256( (__m256i *) &frame1[row][0]);
						r3=_mm256_loadu_si256( (__m256i *) &frame1[row+1][0]);
						r4=_mm256_loadu_si256( (__m256i *) &frame1[row+2][0]);

				  			//START - extra code needed for prelude
				  					m0=_mm256_slli_si256(r0,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
				  					m1=_mm256_slli_si256(r1,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
				  					m2=_mm256_slli_si256(r2,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
				  					m3=_mm256_slli_si256(r3,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
				  					m4=_mm256_slli_si256(r4,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning

				  					r0=_mm256_and_si256(r0,mask_prelude);
				  					r0=_mm256_permute2f128_si256(r0,r0,1);
				  					r0=_mm256_srli_si256(r0,14);//shift 14 elements
				  					r0=_mm256_add_epi16(m0,r0);

				  					r1=_mm256_and_si256(r1,mask_prelude);
				  					r1=_mm256_permute2f128_si256(r1,r1,1);
				  					r1=_mm256_srli_si256(r1,14);//shift 14 elements
				  					r1=_mm256_add_epi16(m1,r1);

				  					r2=_mm256_and_si256(r2,mask_prelude);
				  					r2=_mm256_permute2f128_si256(r2,r2,1);
				  					r2=_mm256_srli_si256(r2,14);//shift 14 elements
				  					r2=_mm256_add_epi16(m2,r2);

				  					r3=_mm256_and_si256(r3,mask_prelude);
				  					r3=_mm256_permute2f128_si256(r3,r3,1);
				  					r3=_mm256_srli_si256(r3,14);//shift 14 elements
				  					r3=_mm256_add_epi16(m3,r3);

				  					r4=_mm256_and_si256(r4,mask_prelude);
				  					r4=_mm256_permute2f128_si256(r4,r4,1);
				  					r4=_mm256_srli_si256(r4,14);//shift 14 elements
				  					r4=_mm256_add_epi16(m4,r4);

				  			//END - extra code needed for prelude
				  		}
				  else {
						//load the 5 rows
						r0=_mm256_loadu_si256( (__m256i *) &frame1[row-2][col-2]);
						r1=_mm256_loadu_si256( (__m256i *) &frame1[row-1][col-2]);
						r2=_mm256_loadu_si256( (__m256i *) &frame1[row][col-2]);
						r3=_mm256_loadu_si256( (__m256i *) &frame1[row+1][col-2]);
						r4=_mm256_loadu_si256( (__m256i *) &frame1[row+2][col-2]);
				  }

				//col iteration computes output pixels of 2,8,14,20,26
				// col+1 iteration computes output pixels of 3,9,15,21,27
				// col+2 iteration computes output pixels of 4,10,16,22,28
				// col+3 iteration computes output pixels of 5,11,17,23,29
				// col+4 iteration computes output pixels of 6,12,18,24,30
				// col+5 iteration computes output pixels of 7,13,19,25,31
				//afterwards, col2 becomes 32 and repeat the above process

				//1st col iteration

				  //--------------row=2
				//multiply with the mask
				m0=_mm256_maddubs_epi16(r0,c0);
				m1=_mm256_maddubs_epi16(r1,c1);
				m2=_mm256_maddubs_epi16(r2,c2);
				m3=_mm256_maddubs_epi16(r3,c1);
				m4=_mm256_maddubs_epi16(r4,c0);

				//vertical add
				m0=_mm256_add_epi16(m0,m1);
				m0=_mm256_add_epi16(m0,m2);
				m0=_mm256_add_epi16(m0,m3);
				m0=_mm256_add_epi16(m0,m4);


				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
				m4=_mm256_and_si256(m0,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
				m2=_mm256_add_epi16(m2,m4);

				//m2 has 16 16bit values now. the results I need are in positions 0,3,6,9,12. keep only those, discard others
				output_even=_mm256_and_si256(m2,output_mask);

				//--------------row=0
				//multiply with the mask
				m0=_mm256_maddubs_epi16(r0,c2);
				m1=_mm256_maddubs_epi16(r1,c1);
				m2=_mm256_maddubs_epi16(r2,c0);

				//vertical add
				m0=_mm256_add_epi16(m0,m1);
				m0=_mm256_add_epi16(m0,m2);


				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
				m4=_mm256_and_si256(m0,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
				m2=_mm256_add_epi16(m2,m4);

				//m2 has 16 16bit values now. the results I need are in positions 0,3,6,9,12. keep only those, discard others
				output_row0_even=_mm256_and_si256(m2,output_mask);

				//--------------row=1
				//multiply with the mask
				m0=_mm256_maddubs_epi16(r0,c1);
				m1=_mm256_maddubs_epi16(r1,c2);
				m2=_mm256_maddubs_epi16(r2,c1);
				m3=_mm256_maddubs_epi16(r3,c0);

				//vertical add
				m0=_mm256_add_epi16(m0,m1);
				m0=_mm256_add_epi16(m0,m2);
				m0=_mm256_add_epi16(m0,m3);

				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
				m4=_mm256_and_si256(m0,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
				m2=_mm256_add_epi16(m2,m4);

				//m2 has 16 16bit values now. the results I need are in positions 0,3,6,9,12. keep only those, discard others
				output_row1_even=_mm256_and_si256(m2,output_mask);

				//2nd col iteration
				//multiply with the mask

				//----row=2
				m0=_mm256_maddubs_epi16(r0,c0_sh1);
				m1=_mm256_maddubs_epi16(r1,c1_sh1);
				m2=_mm256_maddubs_epi16(r2,c2_sh1);
				m3=_mm256_maddubs_epi16(r3,c1_sh1);
				m4=_mm256_maddubs_epi16(r4,c0_sh1);

				//vertical add
				m0=_mm256_add_epi16(m0,m1);
				m0=_mm256_add_epi16(m0,m2);
				m0=_mm256_add_epi16(m0,m3);
				m0=_mm256_add_epi16(m0,m4);


				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
				m4=_mm256_and_si256(m0,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
				m2=_mm256_add_epi16(m2,m4);

				//m2 has 16 16bit values now. the results I need are in positions 0,3,6,9,12. keep only those, discard others
				output_odd = _mm256_and_si256(m2,output_mask);

				//----row=0
				m0=_mm256_maddubs_epi16(r0,c2_sh1);
				m1=_mm256_maddubs_epi16(r1,c1_sh1);
				m2=_mm256_maddubs_epi16(r2,c0_sh1);

				//vertical add
				m0=_mm256_add_epi16(m0,m1);
				m0=_mm256_add_epi16(m0,m2);


				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
				m4=_mm256_and_si256(m0,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
				m2=_mm256_add_epi16(m2,m4);

				//m2 has 16 16bit values now. the results I need are in positions 0,3,6,9,12. keep only those, discard others
				output_row0_odd = _mm256_and_si256(m2,output_mask);

				//----row=1
				m0=_mm256_maddubs_epi16(r0,c1_sh1);
				m1=_mm256_maddubs_epi16(r1,c2_sh1);
				m2=_mm256_maddubs_epi16(r2,c1_sh1);
				m3=_mm256_maddubs_epi16(r3,c0_sh1);

				//vertical add
				m0=_mm256_add_epi16(m0,m1);
				m0=_mm256_add_epi16(m0,m2);
				m0=_mm256_add_epi16(m0,m3);


				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
				m4=_mm256_and_si256(m0,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
				m2=_mm256_add_epi16(m2,m4);

				//m2 has 16 16bit values now. the results I need are in positions 0,3,6,9,12. keep only those, discard others
				output_row1_odd = _mm256_and_si256(m2,output_mask);

		                 //3rd col iteration
				//---row=2
				//multiply with the mask
				m0=_mm256_maddubs_epi16(r0,c0_sh2);
				m1=_mm256_maddubs_epi16(r1,c1_sh2);
				m2=_mm256_maddubs_epi16(r2,c2_sh2);
				m3=_mm256_maddubs_epi16(r3,c1_sh2);
				m4=_mm256_maddubs_epi16(r4,c0_sh2);

				//vertical add
				m0=_mm256_add_epi16(m0,m1);
				m0=_mm256_add_epi16(m0,m2);
				m0=_mm256_add_epi16(m0,m3);
				m0=_mm256_add_epi16(m0,m4);


				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
				m4=_mm256_and_si256(m2,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);
				m2=_mm256_add_epi16(m2,m4);

				//m2 has 16 16bit values now. the results I need are in positions 1,4,7,10,13. keep only those, discard others
				m2 = _mm256_and_si256(m2,output_mask_sh1);
				output_even = _mm256_add_epi16(output_even,m2);

				//---row=0
				//multiply with the mask

				m0=_mm256_maddubs_epi16(r0,c2_sh2);
				m1=_mm256_maddubs_epi16(r1,c1_sh2);
				m2=_mm256_maddubs_epi16(r2,c0_sh2);

				//vertical add
				m0=_mm256_add_epi16(m0,m1);
				m0=_mm256_add_epi16(m0,m2);


				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
				m4=_mm256_and_si256(m2,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

				m2=_mm256_add_epi16(m2,m4);

				//m2 has 16 16bit values now. the results I need are in positions 1,4,7,10,13. keep only those, discard others
				m2 = _mm256_and_si256(m2,output_mask_sh1);
				output_row0_even = _mm256_add_epi16(output_row0_even,m2);


				//---row=1
				//multiply with the mask

				m0=_mm256_maddubs_epi16(r0,c1_sh2);
				m1=_mm256_maddubs_epi16(r1,c2_sh2);
				m2=_mm256_maddubs_epi16(r2,c1_sh2);
				m3=_mm256_maddubs_epi16(r3,c0_sh2);

				//vertical add
				m0=_mm256_add_epi16(m0,m1);
				m0=_mm256_add_epi16(m0,m2);
				m0=_mm256_add_epi16(m0,m3);

				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
				m4=_mm256_and_si256(m2,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

				m2=_mm256_add_epi16(m2,m4);

				//m2 has 16 16bit values now. the results I need are in positions 1,4,7,10,13. keep only those, discard others
				m2 = _mm256_and_si256(m2,output_mask_sh1);
				output_row1_even = _mm256_add_epi16(output_row1_even,m2);

				//4th col iteration

				//4th col iteration

				//multiply with the mask
				m0=_mm256_maddubs_epi16(r0,c0_sh3);
				m1=_mm256_maddubs_epi16(r1,c1_sh3);
				m2=_mm256_maddubs_epi16(r2,c2_sh3);
				m3=_mm256_maddubs_epi16(r3,c1_sh3);
				m4=_mm256_maddubs_epi16(r4,c0_sh3);

				//vertical add
				m0=_mm256_add_epi16(m0,m1);
				m2=_mm256_add_epi16(m2,m3);
				m0=_mm256_add_epi16(m0,m2);
				m0=_mm256_add_epi16(m0,m4);

				//hozizontal additions
				//hadd(3:8)
				//hadd(9:14)
				//hadd(15:20)
				//hadd(21:26)
				//hadd(27:31)
				//result after division will be in 2,8,14,20,26

				m1=_mm256_srli_si256(m0,2);
				m4=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m4);

				//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
				m4=_mm256_and_si256(m4,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

				m2=_mm256_add_epi16(m2,m4);

				//m2 has 16 16bit values now. the results I need are in positions 1,4,7,10,13. keep only those, discard others
				m2 = _mm256_and_si256(m2,output_mask_sh1);
				output_odd = _mm256_add_epi16(output_odd,m2);

				//row0
				//multiply with the mask
								m0=_mm256_maddubs_epi16(r0,c2_sh3);
								m1=_mm256_maddubs_epi16(r1,c1_sh3);
								m2=_mm256_maddubs_epi16(r2,c0_sh3);


								//vertical add
								m0=_mm256_add_epi16(m0,m1);
								m0=_mm256_add_epi16(m0,m2);


								m1=_mm256_srli_si256(m0,2);
								m4=_mm256_add_epi16(m1,m0);

								m1=_mm256_srli_si256(m0,4);
								m2=_mm256_add_epi16(m1,m4);

								//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
								//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
								m4=_mm256_and_si256(m4,mask3);
								m4=_mm256_permute2f128_si256(m4,m4,1);
								m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

								m2=_mm256_add_epi16(m2,m4);

								//m2 has 16 16bit values now. the results I need are in positions 1,4,7,10,13. keep only those, discard others
								m2 = _mm256_and_si256(m2,output_mask_sh1);
								output_row0_odd = _mm256_add_epi16(output_row0_odd,m2);


								//-----------row1
								//multiply with the mask
												m0=_mm256_maddubs_epi16(r0,c1_sh3);
												m1=_mm256_maddubs_epi16(r1,c2_sh3);
												m2=_mm256_maddubs_epi16(r2,c1_sh3);
												m3=_mm256_maddubs_epi16(r3,c0_sh3);

												//vertical add
												m0=_mm256_add_epi16(m0,m1);
												m0=_mm256_add_epi16(m0,m2);
												m0=_mm256_add_epi16(m0,m3);

												m1=_mm256_srli_si256(m0,2);
												m4=_mm256_add_epi16(m1,m0);

												m1=_mm256_srli_si256(m0,4);
												m2=_mm256_add_epi16(m1,m4);

												//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
												//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
												m4=_mm256_and_si256(m4,mask3);
												m4=_mm256_permute2f128_si256(m4,m4,1);
												m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

												m2=_mm256_add_epi16(m2,m4);

												//m2 has 16 16bit values now. the results I need are in positions 1,4,7,10,13. keep only those, discard others
												m2 = _mm256_and_si256(m2,output_mask_sh1);
												output_row1_odd = _mm256_add_epi16(output_row1_odd,m2);



				//5th col iteration
				//multiply with the mask
				m0=_mm256_maddubs_epi16(r0,c0_sh4);
				m1=_mm256_maddubs_epi16(r1,c1_sh4);
				m2=_mm256_maddubs_epi16(r2,c2_sh4);
				m3=_mm256_maddubs_epi16(r3,c1_sh4);
				m4=_mm256_maddubs_epi16(r4,c0_sh4);

				//vertical add
				m0=_mm256_add_epi16(m0,m1);
				m2=_mm256_add_epi16(m2,m3);
				m0=_mm256_add_epi16(m0,m2);
				m0=_mm256_add_epi16(m0,m4);

				//hozizontal additions
				//hadd(4:9)
				//hadd(10:15)
				//hadd(16:21)
				//hadd(22:27)
				//result after division will be in 4,10,16,22

				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);


				//m2 has 16 16bit values now. the results I need are in positions 2,5,8,11. keep only those, discard others
				m2 = _mm256_and_si256(m2,output_mask_sh2);
				output_even = _mm256_add_epi16(output_even,m2);

				//row0
				//multiply with the mask
				m0=_mm256_maddubs_epi16(r0,c2_sh4);
				m1=_mm256_maddubs_epi16(r1,c1_sh4);
				m2=_mm256_maddubs_epi16(r2,c0_sh4);


				//vertical add
				m0=_mm256_add_epi16(m0,m1);
				m0=_mm256_add_epi16(m0,m2);


				//hozizontal additions
				//hadd(4:9)
				//hadd(10:15)
				//hadd(16:21)
				//hadd(22:27)
				//result after division will be in 4,10,16,22

				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);


				//m2 has 16 16bit values now. the results I need are in positions 2,5,8,11. keep only those, discard others
				m2 = _mm256_and_si256(m2,output_mask_sh2);
				output_row0_even = _mm256_add_epi16(output_row0_even,m2);

				//row1
				//multiply with the mask
				m0=_mm256_maddubs_epi16(r0,c1_sh4);
				m1=_mm256_maddubs_epi16(r1,c2_sh4);
				m2=_mm256_maddubs_epi16(r2,c1_sh4);
				m3=_mm256_maddubs_epi16(r3,c0_sh4);


				//vertical add
				m0=_mm256_add_epi16(m0,m1);
				m0=_mm256_add_epi16(m0,m2);
				m0=_mm256_add_epi16(m0,m3);


				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);


				//m2 has 16 16bit values now. the results I need are in positions 2,5,8,11. keep only those, discard others
				m2 = _mm256_and_si256(m2,output_mask_sh2);
				output_row1_even = _mm256_add_epi16(output_row1_even,m2);


		                 //6th col iteration
				//multiply with the mask
				m0=_mm256_maddubs_epi16(r0,c0_sh5);
				m1=_mm256_maddubs_epi16(r1,c1_sh5);
				m2=_mm256_maddubs_epi16(r2,c2_sh5);
				m3=_mm256_maddubs_epi16(r3,c1_sh5);
				m4=_mm256_maddubs_epi16(r4,c0_sh5);

				//vertical add
				m0=_mm256_add_epi16(m0,m1);
				m2=_mm256_add_epi16(m2,m3);
				m0=_mm256_add_epi16(m0,m2);
				m0=_mm256_add_epi16(m0,m4);

				//hozizontal additions
				//hadd(5:10)
				//hadd(11:16)
				//hadd(17:22)
				//hadd(23:28)
				//result after division will be in 4,10,16,22

				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//m2 has 16 16bit values now. the results I need are in positions 2,5,8,11. keep only those, discard others
				m2 = _mm256_and_si256(m2,output_mask_sh2);
				output_odd = _mm256_add_epi16(output_odd,m2);

				//now division follows
				output_even=division(division_case,output_even,f);
				output_odd=division(division_case,output_odd,f);

				//shift odd 1 position and add to even
				output_odd = _mm256_slli_si256(output_odd,1);
				output_even = _mm256_add_epi8(output_even,output_odd);

				_mm256_storeu_si256( (__m256i *) &filt[row][col],output_even );

				//row0
				//multiply with the mask
				m0=_mm256_maddubs_epi16(r0,c2_sh5);
				m1=_mm256_maddubs_epi16(r1,c1_sh5);
				m2=_mm256_maddubs_epi16(r2,c0_sh5);

				//vertical add
				m0=_mm256_add_epi16(m0,m1);
				m0=_mm256_add_epi16(m0,m2);


				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//m2 has 16 16bit values now. the results I need are in positions 2,5,8,11. keep only those, discard others
				m2 = _mm256_and_si256(m2,output_mask_sh2);
				output_row0_odd = _mm256_add_epi16(output_row0_odd,m2);

				//now division follows
				output_row0_even=division(division_case,output_row0_even,f);
				output_row0_odd=division(division_case,output_row0_odd,f);

				//shift odd 1 position and add to even
				output_row0_odd = _mm256_slli_si256(output_row0_odd,1);
				output_row0_even = _mm256_add_epi8(output_row0_even,output_row0_odd);


				_mm256_storeu_si256( (__m256i *) &filt[0][col],output_row0_even );

				//row1

				//multiply with the mask
				m0=_mm256_maddubs_epi16(r0,c1_sh5);
				m1=_mm256_maddubs_epi16(r1,c2_sh5);
				m2=_mm256_maddubs_epi16(r2,c1_sh5);
				m3=_mm256_maddubs_epi16(r3,c0_sh5);

				//vertical add
				m0=_mm256_add_epi16(m0,m1);
				m0=_mm256_add_epi16(m0,m2);
				m0=_mm256_add_epi16(m0,m3);


				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//m2 has 16 16bit values now. the results I need are in positions 2,5,8,11. keep only those, discard others
				m2 = _mm256_and_si256(m2,output_mask_sh2);
				output_row1_odd = _mm256_add_epi16(output_row1_odd,m2);

				//now division follows
				output_row1_even=division(division_case,output_row1_even,f);
				output_row1_odd=division(division_case,output_row1_odd,f);

				//shift odd 1 position and add to even
				output_row1_odd = _mm256_slli_si256(output_row1_odd,1);
				output_row1_even = _mm256_add_epi8(output_row1_even,output_row1_odd);


				_mm256_storeu_si256( (__m256i *) &filt[1][col],output_row1_even );


				}


		    loop_reminder_first_less_div(frame1,filt,M,N,col,REMINDER_ITERATIONS,division_case,c0,c1,c2,c0_sh1,c1_sh1,c2_sh1,c0_sh2,c1_sh2,c2_sh2,f,divisor,filter5x5);
		}

		else if (row==N-3){//in this case I calculate filt[N-2][:] and filt[N-1][:] too. Below row0 refers to row=N-2 and row1 refers to row=N-1
			for (col = 0; col <= M-32; col+=28){
						 //last col value that does not read outside of the array bounds is (col<M-29)

							  if (col==0){

									//load the 5 rows
									r0=_mm256_loadu_si256( (__m256i *) &frame1[row-2][0]);
									r1=_mm256_loadu_si256( (__m256i *) &frame1[row-1][0]);
									r2=_mm256_loadu_si256( (__m256i *) &frame1[row][0]);
									r3=_mm256_loadu_si256( (__m256i *) &frame1[row+1][0]);
									r4=_mm256_loadu_si256( (__m256i *) &frame1[row+2][0]);

							  			//START - extra code needed for prelude
							  					m0=_mm256_slli_si256(r0,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
							  					m1=_mm256_slli_si256(r1,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
							  					m2=_mm256_slli_si256(r2,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
							  					m3=_mm256_slli_si256(r3,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
							  					m4=_mm256_slli_si256(r4,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning

							  					r0=_mm256_and_si256(r0,mask_prelude);
							  					r0=_mm256_permute2f128_si256(r0,r0,1);
							  					r0=_mm256_srli_si256(r0,14);//shift 14 elements
							  					r0=_mm256_add_epi16(m0,r0);

							  					r1=_mm256_and_si256(r1,mask_prelude);
							  					r1=_mm256_permute2f128_si256(r1,r1,1);
							  					r1=_mm256_srli_si256(r1,14);//shift 14 elements
							  					r1=_mm256_add_epi16(m1,r1);

							  					r2=_mm256_and_si256(r2,mask_prelude);
							  					r2=_mm256_permute2f128_si256(r2,r2,1);
							  					r2=_mm256_srli_si256(r2,14);//shift 14 elements
							  					r2=_mm256_add_epi16(m2,r2);

							  					r3=_mm256_and_si256(r3,mask_prelude);
							  					r3=_mm256_permute2f128_si256(r3,r3,1);
							  					r3=_mm256_srli_si256(r3,14);//shift 14 elements
							  					r3=_mm256_add_epi16(m3,r3);

							  					r4=_mm256_and_si256(r4,mask_prelude);
							  					r4=_mm256_permute2f128_si256(r4,r4,1);
							  					r4=_mm256_srli_si256(r4,14);//shift 14 elements
							  					r4=_mm256_add_epi16(m4,r4);

							  			//END - extra code needed for prelude
							  		}
							  else {
									//load the 5 rows
									r0=_mm256_loadu_si256( (__m256i *) &frame1[row-2][col-2]);
									r1=_mm256_loadu_si256( (__m256i *) &frame1[row-1][col-2]);
									r2=_mm256_loadu_si256( (__m256i *) &frame1[row][col-2]);
									r3=_mm256_loadu_si256( (__m256i *) &frame1[row+1][col-2]);
									r4=_mm256_loadu_si256( (__m256i *) &frame1[row+2][col-2]);
							  }

							//col iteration computes output pixels of 2,8,14,20,26
							// col+1 iteration computes output pixels of 3,9,15,21,27
							// col+2 iteration computes output pixels of 4,10,16,22,28
							// col+3 iteration computes output pixels of 5,11,17,23,29
							// col+4 iteration computes output pixels of 6,12,18,24,30
							// col+5 iteration computes output pixels of 7,13,19,25,31
							//afterwards, col2 becomes 32 and repeat the above process

							//1st col iteration
							 //--------------row=2

							//multiply with the mask
							m0=_mm256_maddubs_epi16(r0,c0);
							m1=_mm256_maddubs_epi16(r1,c1);
							m2=_mm256_maddubs_epi16(r2,c2);
							m3=_mm256_maddubs_epi16(r3,c1);
							m4=_mm256_maddubs_epi16(r4,c0);

							//vertical add
							m4=_mm256_add_epi16(m4,m3);
							m4=_mm256_add_epi16(m4,m2);
							m4=_mm256_add_epi16(m4,m1);
							m0=_mm256_add_epi16(m4,m0);

							m1=_mm256_srli_si256(m0,2);
							m2=_mm256_add_epi16(m1,m0);

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m2);

							//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
							m4=_mm256_and_si256(m0,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

							m2=_mm256_add_epi16(m2,m4);

							//m2 has 16 16bit values now. the results I need are in positions 0,3,6,9,12. keep only those, discard others
							output_even=_mm256_and_si256(m2,output_mask);

							//--------------row=0
							//multiply with the mask
							m1=_mm256_maddubs_epi16(r1,c0);
							m2=_mm256_maddubs_epi16(r2,c1);
							m3=_mm256_maddubs_epi16(r3,c2);
							m4=_mm256_maddubs_epi16(r4,c1);

							//vertical add
							m4=_mm256_add_epi16(m4,m3);
							m4=_mm256_add_epi16(m4,m2);
							m4=_mm256_add_epi16(m4,m1); m0_prelude_row0=m4;

							m1=_mm256_srli_si256(m0_prelude_row0,2);
							m2=_mm256_add_epi16(m1,m0_prelude_row0);

							m1=_mm256_srli_si256(m0_prelude_row0,4);
							m2=_mm256_add_epi16(m1,m2);

							//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
							m4=_mm256_and_si256(m0_prelude_row0,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

							m2=_mm256_add_epi16(m2,m4);

							//m2 has 16 16bit values now. the results I need are in positions 0,3,6,9,12. keep only those, discard others
							output_row0_even=_mm256_and_si256(m2,output_mask);

							//--------------row=1
							//multiply with the mask
							m2=_mm256_maddubs_epi16(r2,c0);
							m3=_mm256_maddubs_epi16(r3,c1);
							m4=_mm256_maddubs_epi16(r4,c2);


							//vertical add
							m4=_mm256_add_epi16(m4,m3);
							m4=_mm256_add_epi16(m4,m2);m0_prelude_row1=m4;



							m1=_mm256_srli_si256(m0_prelude_row1,2);
							m2=_mm256_add_epi16(m1,m0_prelude_row1);

							m1=_mm256_srli_si256(m0_prelude_row1,4);
							m2=_mm256_add_epi16(m1,m2);

							//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
							m4=_mm256_and_si256(m0_prelude_row1,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

							m2=_mm256_add_epi16(m2,m4);

							//m2 has 16 16bit values now. the results I need are in positions 0,3,6,9,12. keep only those, discard others
							output_row1_even=_mm256_and_si256(m2,output_mask);

							//2nd col iteration
							//----row=2

							//multiply with the mask
							m0=_mm256_maddubs_epi16(r0,c0_sh1);
							m1=_mm256_maddubs_epi16(r1,c1_sh1);
							m2=_mm256_maddubs_epi16(r2,c2_sh1);
							m3=_mm256_maddubs_epi16(r3,c1_sh1);
							m4=_mm256_maddubs_epi16(r4,c0_sh1);

							//vertical add
							m4=_mm256_add_epi16(m4,m3);
							m4=_mm256_add_epi16(m4,m2);
							m4=_mm256_add_epi16(m4,m1);
							m0=_mm256_add_epi16(m4,m0);


							m1=_mm256_srli_si256(m0,2);
							m2=_mm256_add_epi16(m1,m0);

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m2);

							//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
							m4=_mm256_and_si256(m0,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
							m2=_mm256_add_epi16(m2,m4);

							//m2 has 16 16bit values now. the results I need are in positions 0,3,6,9,12. keep only those, discard others
							output_odd = _mm256_and_si256(m2,output_mask);

							//----row=0
							//multiply with the mask
							m1=_mm256_maddubs_epi16(r1,c0_sh1);
							m2=_mm256_maddubs_epi16(r2,c1_sh1);
							m3=_mm256_maddubs_epi16(r3,c2_sh1);
							m4=_mm256_maddubs_epi16(r4,c1_sh1);


							//vertical add
							m4=_mm256_add_epi16(m4,m3);
							m4=_mm256_add_epi16(m4,m2);
							m4=_mm256_add_epi16(m4,m1);m0_prelude_row0=m4;


							m1=_mm256_srli_si256(m0_prelude_row0,2);
							m2=_mm256_add_epi16(m1,m0_prelude_row0);

							m1=_mm256_srli_si256(m0_prelude_row0,4);
							m2=_mm256_add_epi16(m1,m2);

							//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
							m4=_mm256_and_si256(m0_prelude_row0,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
							m2=_mm256_add_epi16(m2,m4);

							//m2 has 16 16bit values now. the results I need are in positions 0,3,6,9,12. keep only those, discard others
							output_row0_odd = _mm256_and_si256(m2,output_mask);

							//----row=1
							//multiply with the mask
							m2=_mm256_maddubs_epi16(r2,c0_sh1);
							m3=_mm256_maddubs_epi16(r3,c1_sh1);
							m4=_mm256_maddubs_epi16(r4,c2_sh1);


							//vertical add
							m4=_mm256_add_epi16(m4,m3);
							m4=_mm256_add_epi16(m4,m2);m0_prelude_row1=m4;


							m1=_mm256_srli_si256(m0_prelude_row1,2);
							m2=_mm256_add_epi16(m1,m0_prelude_row1);

							m1=_mm256_srli_si256(m0_prelude_row1,4);
							m2=_mm256_add_epi16(m1,m2);

							//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
							m4=_mm256_and_si256(m0_prelude_row1,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
							m2=_mm256_add_epi16(m2,m4);

							//m2 has 16 16bit values now. the results I need are in positions 0,3,6,9,12. keep only those, discard others
							output_row1_odd = _mm256_and_si256(m2,output_mask);

					                 //3rd col iteration
							//---row=2
							//multiply with the mask
							m0=_mm256_maddubs_epi16(r0,c0_sh2);
							m1=_mm256_maddubs_epi16(r1,c1_sh2);
							m2=_mm256_maddubs_epi16(r2,c2_sh2);
							m3=_mm256_maddubs_epi16(r3,c1_sh2);
							m4=_mm256_maddubs_epi16(r4,c0_sh2);

							//vertical add
							m4=_mm256_add_epi16(m4,m3);
							m4=_mm256_add_epi16(m4,m2);
							m4=_mm256_add_epi16(m4,m1);
							m0=_mm256_add_epi16(m4,m0);


							m1=_mm256_srli_si256(m0,2);
							m2=_mm256_add_epi16(m1,m0);

							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
							m4=_mm256_and_si256(m2,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m2);

							//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

							m2=_mm256_add_epi16(m2,m4);

							//m2 has 16 16bit values now. the results I need are in positions 1,4,7,10,13. keep only those, discard others
							m2 = _mm256_and_si256(m2,output_mask_sh1);
							output_even = _mm256_add_epi16(output_even,m2);

							//---row=0
							//multiply with the mask
							m1=_mm256_maddubs_epi16(r1,c0_sh2);
							m2=_mm256_maddubs_epi16(r2,c1_sh2);
							m3=_mm256_maddubs_epi16(r3,c2_sh2);
							m4=_mm256_maddubs_epi16(r4,c1_sh2);


							//vertical add
							m4=_mm256_add_epi16(m4,m3);
							m4=_mm256_add_epi16(m4,m2);
							m4=_mm256_add_epi16(m4,m1);m0_prelude_row0=m4;

							m1=_mm256_srli_si256(m0_prelude_row0,2);
							m2=_mm256_add_epi16(m1,m0_prelude_row0);

							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
							m4=_mm256_and_si256(m2,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

							m1=_mm256_srli_si256(m0_prelude_row0,4);
							m2=_mm256_add_epi16(m1,m2);

							//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

							m2=_mm256_add_epi16(m2,m4);

							//m2 has 16 16bit values now. the results I need are in positions 1,4,7,10,13. keep only those, discard others
							m2 = _mm256_and_si256(m2,output_mask_sh1);
							output_row0_even = _mm256_add_epi16(output_row0_even,m2);


							//---row=1
							//multiply with the mask
							m2=_mm256_maddubs_epi16(r2,c0_sh2);
							m3=_mm256_maddubs_epi16(r3,c1_sh2);
							m4=_mm256_maddubs_epi16(r4,c2_sh2);


							//vertical add
							m4=_mm256_add_epi16(m4,m3);
							m4=_mm256_add_epi16(m4,m2);m0_prelude_row1=m4;


							m1=_mm256_srli_si256(m0_prelude_row1,2);
							m2=_mm256_add_epi16(m1,m0_prelude_row1);

							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
							m4=_mm256_and_si256(m2,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

							m1=_mm256_srli_si256(m0_prelude_row1,4);
							m2=_mm256_add_epi16(m1,m2);

							//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

							m2=_mm256_add_epi16(m2,m4);

							//m2 has 16 16bit values now. the results I need are in positions 1,4,7,10,13. keep only those, discard others
							m2 = _mm256_and_si256(m2,output_mask_sh1);
							output_row1_even = _mm256_add_epi16(output_row1_even,m2);

							//4th col iteration
							//multiply with the mask
							m0=_mm256_maddubs_epi16(r0,c0_sh3);
							m1=_mm256_maddubs_epi16(r1,c1_sh3);
							m2=_mm256_maddubs_epi16(r2,c2_sh3);
							m3=_mm256_maddubs_epi16(r3,c1_sh3);
							m4=_mm256_maddubs_epi16(r4,c0_sh3);

							//vertical add
							m0=_mm256_add_epi16(m0,m1);
							m2=_mm256_add_epi16(m2,m3);
							m0=_mm256_add_epi16(m0,m2);
							m0=_mm256_add_epi16(m0,m4);

							//hozizontal additions
							//hadd(3:8)
							//hadd(9:14)
							//hadd(15:20)
							//hadd(21:26)
							//hadd(27:31)
							//result after division will be in 2,8,14,20,26

							m1=_mm256_srli_si256(m0,2);
							m4=_mm256_add_epi16(m1,m0);

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m4);

							//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
							m4=_mm256_and_si256(m4,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

							m2=_mm256_add_epi16(m2,m4);

							//m2 has 16 16bit values now. the results I need are in positions 1,4,7,10,13. keep only those, discard others
							m2 = _mm256_and_si256(m2,output_mask_sh1);
							output_odd = _mm256_add_epi16(output_odd,m2);

							//row0
							//multiply with the mask
								m1=_mm256_maddubs_epi16(r1,c0_sh3);
								m2=_mm256_maddubs_epi16(r2,c1_sh3);
								m3=_mm256_maddubs_epi16(r3,c2_sh3);
								m4=_mm256_maddubs_epi16(r4,c1_sh3);

								//vertical add
								m0=_mm256_add_epi16(m1,m2);
								m0=_mm256_add_epi16(m0,m3);
								m0=_mm256_add_epi16(m0,m4);


								m1=_mm256_srli_si256(m0,2);
								m4=_mm256_add_epi16(m1,m0);

								m1=_mm256_srli_si256(m0,4);
								m2=_mm256_add_epi16(m1,m4);

								//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
								//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
								m4=_mm256_and_si256(m4,mask3);
								m4=_mm256_permute2f128_si256(m4,m4,1);
								m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

								m2=_mm256_add_epi16(m2,m4);

								//m2 has 16 16bit values now. the results I need are in positions 1,4,7,10,13. keep only those, discard others
								m2 = _mm256_and_si256(m2,output_mask_sh1);
								output_row0_odd = _mm256_add_epi16(output_row0_odd,m2);

								//row1
								//multiply with the mask
									m2=_mm256_maddubs_epi16(r2,c0_sh3);
									m3=_mm256_maddubs_epi16(r3,c1_sh3);
									m4=_mm256_maddubs_epi16(r4,c2_sh3);

									//vertical add
									m0=_mm256_add_epi16(m2,m3);
									m0=_mm256_add_epi16(m0,m4);


									m1=_mm256_srli_si256(m0,2);
									m4=_mm256_add_epi16(m1,m0);

									m1=_mm256_srli_si256(m0,4);
									m2=_mm256_add_epi16(m1,m4);

									//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
									//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
									m4=_mm256_and_si256(m4,mask3);
									m4=_mm256_permute2f128_si256(m4,m4,1);
									m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

									m2=_mm256_add_epi16(m2,m4);

									//m2 has 16 16bit values now. the results I need are in positions 1,4,7,10,13. keep only those, discard others
									m2 = _mm256_and_si256(m2,output_mask_sh1);
									output_row1_odd = _mm256_add_epi16(output_row1_odd,m2);


							//5th col iteration
							//multiply with the mask
							m0=_mm256_maddubs_epi16(r0,c0_sh4);
							m1=_mm256_maddubs_epi16(r1,c1_sh4);
							m2=_mm256_maddubs_epi16(r2,c2_sh4);
							m3=_mm256_maddubs_epi16(r3,c1_sh4);
							m4=_mm256_maddubs_epi16(r4,c0_sh4);

							//vertical add
							m0=_mm256_add_epi16(m0,m1);
							m2=_mm256_add_epi16(m2,m3);
							m0=_mm256_add_epi16(m0,m2);
							m0=_mm256_add_epi16(m0,m4);

							//hozizontal additions
							//hadd(4:9)
							//hadd(10:15)
							//hadd(16:21)
							//hadd(22:27)
							//result after division will be in 4,10,16,22

							m1=_mm256_srli_si256(m0,2);
							m2=_mm256_add_epi16(m1,m0);

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m2);


							//m2 has 16 16bit values now. the results I need are in positions 2,5,8,11. keep only those, discard others
							m2 = _mm256_and_si256(m2,output_mask_sh2);
							output_even = _mm256_add_epi16(output_even,m2);

							//row0
							//multiply with the mask
							m1=_mm256_maddubs_epi16(r1,c0_sh4);
							m2=_mm256_maddubs_epi16(r2,c1_sh4);
							m3=_mm256_maddubs_epi16(r3,c2_sh4);
							m4=_mm256_maddubs_epi16(r4,c1_sh4);

							//vertical add
							m0=_mm256_add_epi16(m1,m2);
							m0=_mm256_add_epi16(m0,m3);
							m0=_mm256_add_epi16(m0,m4);


							m1=_mm256_srli_si256(m0,2);
							m2=_mm256_add_epi16(m1,m0);

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m2);


							//m2 has 16 16bit values now. the results I need are in positions 2,5,8,11. keep only those, discard others
							m2 = _mm256_and_si256(m2,output_mask_sh2);
							output_row0_even = _mm256_add_epi16(output_row0_even,m2);

							//row1
							//multiply with the mask
							m2=_mm256_maddubs_epi16(r2,c0_sh4);
							m3=_mm256_maddubs_epi16(r3,c1_sh4);
							m4=_mm256_maddubs_epi16(r4,c2_sh4);

							//vertical add
							m0=_mm256_add_epi16(m2,m3);
							m0=_mm256_add_epi16(m0,m4);


							m1=_mm256_srli_si256(m0,2);
							m2=_mm256_add_epi16(m1,m0);

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m2);


							//m2 has 16 16bit values now. the results I need are in positions 2,5,8,11. keep only those, discard others
							m2 = _mm256_and_si256(m2,output_mask_sh2);
							output_row1_even = _mm256_add_epi16(output_row1_even,m2);

					                 //6th col iteration
							//multiply with the mask
							m0=_mm256_maddubs_epi16(r0,c0_sh5);
							m1=_mm256_maddubs_epi16(r1,c1_sh5);
							m2=_mm256_maddubs_epi16(r2,c2_sh5);
							m3=_mm256_maddubs_epi16(r3,c1_sh5);
							m4=_mm256_maddubs_epi16(r4,c0_sh5);

							//vertical add
							m0=_mm256_add_epi16(m0,m1);
							m2=_mm256_add_epi16(m2,m3);
							m0=_mm256_add_epi16(m0,m2);
							m0=_mm256_add_epi16(m0,m4);

							//hozizontal additions
							//hadd(5:10)
							//hadd(11:16)
							//hadd(17:22)
							//hadd(23:28)
							//result after division will be in 4,10,16,22

							m1=_mm256_srli_si256(m0,2);
							m2=_mm256_add_epi16(m1,m0);

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m2);

							//m2 has 16 16bit values now. the results I need are in positions 2,5,8,11. keep only those, discard others
							m2 = _mm256_and_si256(m2,output_mask_sh2);
							output_odd = _mm256_add_epi16(output_odd,m2);

							//now division follows
							output_even=division(division_case,output_even,f);
							output_odd=division(division_case,output_odd,f);

							//shift odd 1 position and add to even
							output_odd = _mm256_slli_si256(output_odd,1);
							output_even = _mm256_add_epi8(output_even,output_odd);


							_mm256_storeu_si256( (__m256i *) &filt[row][col],output_even );

							//row0
							//multiply with the mask
							m1=_mm256_maddubs_epi16(r1,c0_sh5);
							m2=_mm256_maddubs_epi16(r2,c1_sh5);
							m3=_mm256_maddubs_epi16(r3,c2_sh5);
							m4=_mm256_maddubs_epi16(r4,c1_sh5);

							//vertical add
							m0=_mm256_add_epi16(m1,m2);
							m0=_mm256_add_epi16(m0,m3);
							m0=_mm256_add_epi16(m0,m4);


							m1=_mm256_srli_si256(m0,2);
							m2=_mm256_add_epi16(m1,m0);

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m2);

							//m2 has 16 16bit values now. the results I need are in positions 2,5,8,11. keep only those, discard others
							m2 = _mm256_and_si256(m2,output_mask_sh2);
							output_row0_odd = _mm256_add_epi16(output_row0_odd,m2);

							//now division follows
							output_row0_even=division(division_case,output_row0_even,f);
							output_row0_odd=division(division_case,output_row0_odd,f);

							//shift odd 1 position and add to even
							output_row0_odd = _mm256_slli_si256(output_row0_odd,1);
							output_row0_even = _mm256_add_epi8(output_row0_even,output_row0_odd);


							_mm256_storeu_si256( (__m256i *) &filt[N-2][col],output_row0_even );

							//row1
							//multiply with the mask
							m2=_mm256_maddubs_epi16(r2,c0_sh5);
							m3=_mm256_maddubs_epi16(r3,c1_sh5);
							m4=_mm256_maddubs_epi16(r4,c2_sh5);

							//vertical add
							m0=_mm256_add_epi16(m2,m3);
							m0=_mm256_add_epi16(m0,m4);

								m1=_mm256_srli_si256(m0,2);
							m2=_mm256_add_epi16(m1,m0);

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m2);

							//m2 has 16 16bit values now. the results I need are in positions 2,5,8,11. keep only those, discard others
							m2 = _mm256_and_si256(m2,output_mask_sh2);
							output_row1_odd = _mm256_add_epi16(output_row1_odd,m2);

							//now division follows
							output_row1_even=division(division_case,output_row1_even,f);
							output_row1_odd=division(division_case,output_row1_odd,f);

							//shift odd 1 position and add to even
							output_row1_odd = _mm256_slli_si256(output_row1_odd,1);
							output_row1_even = _mm256_add_epi8(output_row1_even,output_row1_odd);


							_mm256_storeu_si256( (__m256i *) &filt[N-1][col],output_row1_even );


							}

		    loop_reminder_last_less_div(frame1,filt,M,N,col,REMINDER_ITERATIONS,division_case,c0,c1,c2,c0_sh1,c1_sh1,c2_sh1,c0_sh2,c1_sh2,c2_sh2,f,divisor,filter5x5);

					}
	else {


	  for (col = 0; col <= M-32; col+=28){
	 //last col value that does not read outside of the array bounds is (col<M-29)

		  if (col==0){

				//load the 5 rows
				r0=_mm256_loadu_si256( (__m256i *) &frame1[row-2][0]);
				r1=_mm256_loadu_si256( (__m256i *) &frame1[row-1][0]);
				r2=_mm256_loadu_si256( (__m256i *) &frame1[row][0]);
				r3=_mm256_loadu_si256( (__m256i *) &frame1[row+1][0]);
				r4=_mm256_loadu_si256( (__m256i *) &frame1[row+2][0]);

		  			//START - extra code needed for prelude
		  					m0=_mm256_slli_si256(r0,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
		  					m1=_mm256_slli_si256(r1,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
		  					m2=_mm256_slli_si256(r2,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
		  					m3=_mm256_slli_si256(r3,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
		  					m4=_mm256_slli_si256(r4,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning

		  					r0=_mm256_and_si256(r0,mask_prelude);
		  					r0=_mm256_permute2f128_si256(r0,r0,1);
		  					r0=_mm256_srli_si256(r0,14);//shift 14 elements
		  					r0=_mm256_add_epi16(m0,r0);

		  					r1=_mm256_and_si256(r1,mask_prelude);
		  					r1=_mm256_permute2f128_si256(r1,r1,1);
		  					r1=_mm256_srli_si256(r1,14);//shift 14 elements
		  					r1=_mm256_add_epi16(m1,r1);

		  					r2=_mm256_and_si256(r2,mask_prelude);
		  					r2=_mm256_permute2f128_si256(r2,r2,1);
		  					r2=_mm256_srli_si256(r2,14);//shift 14 elements
		  					r2=_mm256_add_epi16(m2,r2);

		  					r3=_mm256_and_si256(r3,mask_prelude);
		  					r3=_mm256_permute2f128_si256(r3,r3,1);
		  					r3=_mm256_srli_si256(r3,14);//shift 14 elements
		  					r3=_mm256_add_epi16(m3,r3);

		  					r4=_mm256_and_si256(r4,mask_prelude);
		  					r4=_mm256_permute2f128_si256(r4,r4,1);
		  					r4=_mm256_srli_si256(r4,14);//shift 14 elements
		  					r4=_mm256_add_epi16(m4,r4);

		  			//END - extra code needed for prelude
		  		}
		  else {
				//load the 5 rows
				r0=_mm256_loadu_si256( (__m256i *) &frame1[row-2][col-2]);
				r1=_mm256_loadu_si256( (__m256i *) &frame1[row-1][col-2]);
				r2=_mm256_loadu_si256( (__m256i *) &frame1[row][col-2]);
				r3=_mm256_loadu_si256( (__m256i *) &frame1[row+1][col-2]);
				r4=_mm256_loadu_si256( (__m256i *) &frame1[row+2][col-2]);
		  }

		//col iteration computes output pixels of 2,8,14,20,26
		// col+1 iteration computes output pixels of 3,9,15,21,27
		// col+2 iteration computes output pixels of 4,10,16,22,28
		// col+3 iteration computes output pixels of 5,11,17,23,29
		// col+4 iteration computes output pixels of 6,12,18,24
		// col+5 iteration computes output pixels of 7,13,19,25
		//afterwards, col becomes 30 and repeat the above process

		//1st col iteration


		//multiply with the mask
		m0=_mm256_maddubs_epi16(r0,c0);
		m1=_mm256_maddubs_epi16(r1,c1);
		m2=_mm256_maddubs_epi16(r2,c2);
		m3=_mm256_maddubs_epi16(r3,c1);
		m4=_mm256_maddubs_epi16(r4,c0);

		//vertical add
		m0=_mm256_add_epi16(m0,m1);
		m2=_mm256_add_epi16(m2,m3);
		m0=_mm256_add_epi16(m0,m2);
		m0=_mm256_add_epi16(m0,m4);

		//hozizontal additions
		//hadd(0:5)
		//hadd(6:11)
		//hadd(12:17)
		//hadd(18:23)
		//hadd(24:28)

		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//after shifts the 15th element is lost as it cannot be propagated to the 16th position (AVX registers are managed as two seperate SSE registers)
		m4=_mm256_and_si256(m0,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
		m2=_mm256_add_epi16(m2,m4);

		//m2 has 16 16bit values now. the results I need are in positions 0,3,6,9,12. keep only those, discard others
		output_even=_mm256_and_si256(m2,output_mask);


		//2nd col iteration
		//multiply with the mask
		m0=_mm256_maddubs_epi16(r0,c0_sh1);
		m1=_mm256_maddubs_epi16(r1,c1_sh1);
		m2=_mm256_maddubs_epi16(r2,c2_sh1);
		m3=_mm256_maddubs_epi16(r3,c1_sh1);
		m4=_mm256_maddubs_epi16(r4,c0_sh1);

		//vertical add
		m0=_mm256_add_epi16(m0,m1);
		m2=_mm256_add_epi16(m2,m3);
		m0=_mm256_add_epi16(m0,m2);
		m0=_mm256_add_epi16(m0,m4);

		//hozizontal additions
		//hadd(1:6)
		//hadd(7:12)
		//hadd(13:18)
		//hadd(19:24)
		//hadd(25:29)

		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//after shifts the 15th element is lost as it cannot be propagated to the 16th position (AVX registers are managed as two seperate SSE registers)
		m4=_mm256_and_si256(m0,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
		m2=_mm256_add_epi16(m2,m4);

		//m2 has 16 16bit values now. the results I need are in positions 0,3,6,9,12. keep only those, discard others
		output_odd = _mm256_and_si256(m2,output_mask);



         //3rd col iteration
		//multiply with the mask
		m0=_mm256_maddubs_epi16(r0,c0_sh2);
		m1=_mm256_maddubs_epi16(r1,c1_sh2);
		m2=_mm256_maddubs_epi16(r2,c2_sh2);
		m3=_mm256_maddubs_epi16(r3,c1_sh2);
		m4=_mm256_maddubs_epi16(r4,c0_sh2);

		//vertical add
		m0=_mm256_add_epi16(m0,m1);
		m2=_mm256_add_epi16(m2,m3);
		m0=_mm256_add_epi16(m0,m2);
		m0=_mm256_add_epi16(m0,m4);

		//hozizontal additions
		//hadd(2:7)
		//hadd(8:13)
		//hadd(14:19)
		//hadd(20:25)
		//hadd(26:30)

		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		m4=_mm256_and_si256(m2,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);
		m2=_mm256_add_epi16(m2,m4);

		//m2 has 16 16bit values now. the results I need are in positions 1,4,7,10,13. keep only those, discard others
		m2 = _mm256_and_si256(m2,output_mask_sh1);
		output_even = _mm256_add_epi16(output_even,m2);


		//4th col iteration

		//multiply with the mask
		m0=_mm256_maddubs_epi16(r0,c0_sh3);
		m1=_mm256_maddubs_epi16(r1,c1_sh3);
		m2=_mm256_maddubs_epi16(r2,c2_sh3);
		m3=_mm256_maddubs_epi16(r3,c1_sh3);
		m4=_mm256_maddubs_epi16(r4,c0_sh3);

		//vertical add
		m0=_mm256_add_epi16(m0,m1);
		m2=_mm256_add_epi16(m2,m3);
		m0=_mm256_add_epi16(m0,m2);
		m0=_mm256_add_epi16(m0,m4);

		//hozizontal additions
		//hadd(3:8)
		//hadd(9:14)
		//hadd(15:20)
		//hadd(21:26)
		//hadd(27:31)
		//result after division will be in 2,8,14,20,26

		m1=_mm256_srli_si256(m0,2);
		m4=_mm256_add_epi16(m1,m0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m4);


		m4=_mm256_and_si256(m4,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

		m2=_mm256_add_epi16(m2,m4);

		//m2 has 16 16bit values now. the results I need are in positions 1,4,7,10,13. keep only those, discard others
		m2 = _mm256_and_si256(m2,output_mask_sh1);
		output_odd = _mm256_add_epi16(output_odd,m2);




		//5th col iteration
		//multiply with the mask
		m0=_mm256_maddubs_epi16(r0,c0_sh4);
		m1=_mm256_maddubs_epi16(r1,c1_sh4);
		m2=_mm256_maddubs_epi16(r2,c2_sh4);
		m3=_mm256_maddubs_epi16(r3,c1_sh4);
		m4=_mm256_maddubs_epi16(r4,c0_sh4);

		//vertical add
		m0=_mm256_add_epi16(m0,m1);
		m2=_mm256_add_epi16(m2,m3);
		m0=_mm256_add_epi16(m0,m2);
		m0=_mm256_add_epi16(m0,m4);

		//hozizontal additions
		//hadd(4:9)
		//hadd(10:15)
		//hadd(16:21)
		//hadd(22:27)
		//result after division will be in 4,10,16,22

		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);


		//m2 has 16 16bit values now. the results I need are in positions 2,5,8,11. keep only those, discard others
		m2 = _mm256_and_si256(m2,output_mask_sh2);
		output_even = _mm256_add_epi16(output_even,m2);



                 //6th col iteration
		//multiply with the mask
		m0=_mm256_maddubs_epi16(r0,c0_sh5);
		m1=_mm256_maddubs_epi16(r1,c1_sh5);
		m2=_mm256_maddubs_epi16(r2,c2_sh5);
		m3=_mm256_maddubs_epi16(r3,c1_sh5);
		m4=_mm256_maddubs_epi16(r4,c0_sh5);

		//vertical add
		m0=_mm256_add_epi16(m0,m1);
		m2=_mm256_add_epi16(m2,m3);
		m0=_mm256_add_epi16(m0,m2);
		m0=_mm256_add_epi16(m0,m4);

		//hozizontal additions
		//hadd(5:10)
		//hadd(11:16)
		//hadd(17:22)
		//hadd(23:28)
		//result after division will be in 4,10,16,22

		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//m2 has 16 16bit values now. the results I need are in positions 2,5,8,11. keep only those, discard others
		m2 = _mm256_and_si256(m2,output_mask_sh2);
		output_odd = _mm256_add_epi16(output_odd,m2);

		//now division follows
		output_even=division(division_case,output_even,f);
		output_odd=division(division_case,output_odd,f);

		//shift odd 1 position and add to even
		output_odd = _mm256_slli_si256(output_odd,1);
		output_even = _mm256_add_epi8(output_even,output_odd);


		_mm256_storeu_si256( (__m256i *) &filt[row][col],output_even );


		}

        if (REMINDER_ITERATIONS>=29)
        	loop_reminder_high_reminder_values_less_div(frame1,filt,M,N,row,col,REMINDER_ITERATIONS,division_case,c0,c1,c2,c0_sh1,c1_sh1,c2_sh1,c0_sh2,c1_sh2,c2_sh2,f,divisor,filter5x5);
        else
        	loop_reminder_low_reminder_values_less_div(frame1,filt,M,N,row,col,REMINDER_ITERATIONS,division_case,c0,c1,c2,c0_sh1,c1_sh1,c2_sh1,c0_sh2,c1_sh2,c2_sh2,c0_sh3,c1_sh3,c2_sh3,c0_sh4,c1_sh4,c2_sh4,c0_sh5,c1_sh5,c2_sh5,f);
		//padding code. The last three iterations  ABOVE get outside of the array bounds. The last three col iterations read outside but the garbage values are multiplied by zeros (last three mask zeros). From now on, I must include another mask with extra zeros.
//It is faster to read outside of the array's bounds and then fill the right values. there is an insert command that inserts a value to the vector
//TOMORROW: USE Gaussian_Blur_AVX_ver4_plus_less_load ROUTINE FOR LOOP REMINDER. LOAD OUTSIDE OF THE ARRAY AND THEN ZERO THE VALUES NEEDED.

		}
}

}//end of parallel


}









void Gaussian_Blur_optimized_5x5_seperable_filter_less_div(unsigned char **frame1,unsigned char **filt,const unsigned int M, const unsigned int N, const unsigned int divisor, const unsigned char filter_5x5[5][5]){

	//-----------load coefficients for the padding routines. The padding routines use 2d 5x5 filter. They need to be updated.
	/*const __m256i c0=_mm256_set_epi8(0,0,0,filter_5x5[0][4],filter_5x5[0][3],filter_5x5[0][2],filter_5x5[0][1],filter_5x5[0][0],0,filter_5x5[0][4],filter_5x5[0][3],filter_5x5[0][2],filter_5x5[0][1],filter_5x5[0][0],0,filter_5x5[0][4],filter_5x5[0][3],filter_5x5[0][2],filter_5x5[0][1],filter_5x5[0][0],0,filter_5x5[0][4],filter_5x5[0][3],filter_5x5[0][2],filter_5x5[0][1],filter_5x5[0][0],0,filter_5x5[0][4],filter_5x5[0][3],filter_5x5[0][2],filter_5x5[0][1],filter_5x5[0][0]);
	const __m256i c1=_mm256_set_epi8(0,0,0,filter_5x5[1][4],filter_5x5[1][3],filter_5x5[1][2],filter_5x5[1][1],filter_5x5[1][0],0,filter_5x5[1][4],filter_5x5[1][3],filter_5x5[1][2],filter_5x5[1][1],filter_5x5[1][0],0,filter_5x5[1][4],filter_5x5[1][3],filter_5x5[1][2],filter_5x5[1][1],filter_5x5[1][0],0,filter_5x5[1][4],filter_5x5[1][3],filter_5x5[1][2],filter_5x5[1][1],filter_5x5[1][0],0,filter_5x5[1][4],filter_5x5[1][3],filter_5x5[1][2],filter_5x5[1][1],filter_5x5[1][0]);
	const __m256i c2=_mm256_set_epi8(0,0,0,filter_5x5[2][4],filter_5x5[2][3],filter_5x5[2][2],filter_5x5[2][1],filter_5x5[2][0],0,filter_5x5[2][4],filter_5x5[2][3],filter_5x5[2][2],filter_5x5[2][1],filter_5x5[2][0],0,filter_5x5[2][4],filter_5x5[2][3],filter_5x5[2][2],filter_5x5[2][1],filter_5x5[2][0],0,filter_5x5[2][4],filter_5x5[2][3],filter_5x5[2][2],filter_5x5[2][1],filter_5x5[2][0],0,filter_5x5[2][4],filter_5x5[2][3],filter_5x5[2][2],filter_5x5[2][1],filter_5x5[2][0]);

	const __m256i c0_sh1=_mm256_slli_si256(c0,1);
	const __m256i c1_sh1=_mm256_slli_si256(c1,1);
	const __m256i c2_sh1=_mm256_slli_si256(c2,1);

	const __m256i c0_sh2=_mm256_slli_si256(c0,2);
	const __m256i c1_sh2=_mm256_slli_si256(c1,2);
	const __m256i c2_sh2=_mm256_slli_si256(c2,2);*/


	//load coefficients
	const __m256i     cx=_mm256_load_si256( (__m256i *) &gaussian_filter_5x5_seperable_x[0][0]);
	const __m256i cx_sh1=_mm256_load_si256( (__m256i *) &gaussian_filter_5x5_seperable_x[1][0]);
	const __m256i cx_sh2=_mm256_load_si256( (__m256i *) &gaussian_filter_5x5_seperable_x[2][0]);
	const __m256i cx_sh3=_mm256_load_si256( (__m256i *) &gaussian_filter_5x5_seperable_x[3][0]);
	const __m256i cx_sh4=_mm256_load_si256( (__m256i *) &gaussian_filter_5x5_seperable_x[4][0]);
	const __m256i cx_sh5=_mm256_load_si256( (__m256i *) &gaussian_filter_5x5_seperable_x[5][0]);

	const __m256i     cy0=_mm256_load_si256( (__m256i *) &gaussian_filter_5x5_seperable_y[0][0]);
	const __m256i     cy1=_mm256_load_si256( (__m256i *) &gaussian_filter_5x5_seperable_y[1][0]);
	const __m256i     cy2=_mm256_load_si256( (__m256i *) &gaussian_filter_5x5_seperable_y[2][0]);
	const __m256i cy0_sh1=_mm256_load_si256( (__m256i *) &gaussian_filter_5x5_seperable_y[3][0]);
	const __m256i cy1_sh1=_mm256_load_si256( (__m256i *) &gaussian_filter_5x5_seperable_y[4][0]);
	const __m256i cy2_sh1=_mm256_load_si256( (__m256i *) &gaussian_filter_5x5_seperable_y[5][0]);

	//const __m256i f  = _mm256_set_epi16(52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759);
	//const __m256i mask  = _mm256_set_epi8(0,0,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255);
	//const __m256i mask2  = _mm256_set_epi8(0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0);
	//const __m256i mask6  = _mm256_set_epi8(0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0);

	const __m256i mask3  = _mm256_set_epi16(0,0,0,0,0,0,0,65535,0,0,0,0,0,0,0,0);

	const __m256i mask_prelude  = _mm256_set_epi8(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0);

	const unsigned int REMINDER_ITERATIONS =  (M-((((M-32)/28)*28)+28)); //M-(last_col_value+28)
	//printf("\n%d",REMINDER_ITERATIONS);

	const __m256i output_mask      = _mm256_set_epi16(0,0,0,65535,0,0,65535,0,0,65535,0,0,65535,0,0,65535);
	const __m256i output_mask_sh1  = _mm256_set_epi16(0,0,65535,0,0,65535,0,0,65535,0,0,65535,0,0,65535,0);
	const __m256i output_mask_sh2  = _mm256_set_epi16(0,0,0,    0,65535,0,0,65535,0,0,65535,0,0,65535,0,0);

	const unsigned int division_case=prepare_for_division(divisor); //determine which is the division case (A, B or C)
	const __m256i f = _mm256_load_si256( (__m256i *) &f_vector[0]);// initialize the division vector



#pragma omp parallel
{

unsigned int row,col;
register __m256i r0,r1,r2,r3,r4,m0,m1,m2,m3,m4,output_even,output_odd,output_row0_even,output_row0_odd,output_row1_even,output_row1_odd;
//__m256i output_row0,output_row1;//these are for processing row #0 and #1 only.
__m256i even,odd,row_0,row_1,row_2;

//MORE EFFICIENT WAY TO DEAL WITH MANY CONSTANTS?

/*---------------------- Gaussian Blur ---------------------------------*/

    #pragma omp for schedule(static)
	for (row = 2; row < N-2; row++) {

		if (row==2){//in this case I calculate filt[0][:] and filt[1][:] too. No extra loads or multiplications are required for this
			  for (col = 0; col <= M-32; col+=28){

				  if (col==0){//this is a special case as the mask gets outside of the array (it is like adding two zeros in the beginning of frame[][]

						//load the 5 rows
						r0=_mm256_loadu_si256( (__m256i *) &frame1[row-2][0]);
						r1=_mm256_loadu_si256( (__m256i *) &frame1[row-1][0]);
						r2=_mm256_loadu_si256( (__m256i *) &frame1[row][0]);
						r3=_mm256_loadu_si256( (__m256i *) &frame1[row+1][0]);
						r4=_mm256_loadu_si256( (__m256i *) &frame1[row+2][0]);

				  			//START - extra code needed for prelude
				  					m0=_mm256_slli_si256(r0,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
				  					m1=_mm256_slli_si256(r1,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
				  					m2=_mm256_slli_si256(r2,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
				  					m3=_mm256_slli_si256(r3,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
				  					m4=_mm256_slli_si256(r4,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning

				  					r0=_mm256_and_si256(r0,mask_prelude);
				  					r0=_mm256_permute2f128_si256(r0,r0,1);
				  					r0=_mm256_srli_si256(r0,14);//shift 14 elements
				  					r0=_mm256_add_epi16(m0,r0);

				  					r1=_mm256_and_si256(r1,mask_prelude);
				  					r1=_mm256_permute2f128_si256(r1,r1,1);
				  					r1=_mm256_srli_si256(r1,14);//shift 14 elements
				  					r1=_mm256_add_epi16(m1,r1);

				  					r2=_mm256_and_si256(r2,mask_prelude);
				  					r2=_mm256_permute2f128_si256(r2,r2,1);
				  					r2=_mm256_srli_si256(r2,14);//shift 14 elements
				  					r2=_mm256_add_epi16(m2,r2);

				  					r3=_mm256_and_si256(r3,mask_prelude);
				  					r3=_mm256_permute2f128_si256(r3,r3,1);
				  					r3=_mm256_srli_si256(r3,14);//shift 14 elements
				  					r3=_mm256_add_epi16(m3,r3);

				  					r4=_mm256_and_si256(r4,mask_prelude);
				  					r4=_mm256_permute2f128_si256(r4,r4,1);
				  					r4=_mm256_srli_si256(r4,14);//shift 14 elements
				  					r4=_mm256_add_epi16(m4,r4);

				  			//END - extra code needed for prelude
				  		}
				  else {
						//load the 5 rows
						r0=_mm256_loadu_si256( (__m256i *) &frame1[row-2][col-2]);
						r1=_mm256_loadu_si256( (__m256i *) &frame1[row-1][col-2]);
						r2=_mm256_loadu_si256( (__m256i *) &frame1[row][col-2]);
						r3=_mm256_loadu_si256( (__m256i *) &frame1[row+1][col-2]);
						r4=_mm256_loadu_si256( (__m256i *) &frame1[row+2][col-2]);
				  }

				//col iteration computes output pixels of 2,8,14,20,26
				// col+1 iteration computes output pixels of 3,9,15,21,27
				// col+2 iteration computes output pixels of 4,10,16,22,28
				// col+3 iteration computes output pixels of 5,11,17,23,29
				// col+4 iteration computes output pixels of 6,12,18,24,30
				// col+5 iteration computes output pixels of 7,13,19,25,31
				//afterwards, col2 becomes 32 and repeat the above process

				  //y filter begins

					//multiply with the mask
					m0=_mm256_maddubs_epi16(r0,cy0);
					m1=_mm256_maddubs_epi16(r1,cy1);
					m2=_mm256_maddubs_epi16(r2,cy2);
					m3=_mm256_maddubs_epi16(r3,cy1);
					m4=_mm256_maddubs_epi16(r4,cy0);

					//vertical add
					m0=_mm256_add_epi16(m0,m1);
					m2=_mm256_add_epi16(m2,m3);
					m0=_mm256_add_epi16(m0,m2);
					m0=_mm256_add_epi16(m0,m4);

					even=division(division_case,m0,f);//even results

					//multiply with the mask
					m0=_mm256_maddubs_epi16(r0,cy0_sh1);
					m1=_mm256_maddubs_epi16(r1,cy1_sh1);
					m2=_mm256_maddubs_epi16(r2,cy2_sh1);
					m3=_mm256_maddubs_epi16(r3,cy1_sh1);
					m4=_mm256_maddubs_epi16(r4,cy0_sh1);

					//vertical add
					m0=_mm256_add_epi16(m0,m1);
					m2=_mm256_add_epi16(m2,m3);
					m0=_mm256_add_epi16(m0,m2);
					m0=_mm256_add_epi16(m0,m4);

					odd=division(division_case,m0,f);//odd results

					//pack to one register
					odd=_mm256_slli_si256(odd,1); //shift one position right
					row_2=_mm256_add_epi8(even,odd); //add the odd with the even

					//y filter ends - row_2 has the data to be processed by x filter

				//1st col iteration

				  //--------------row=2
				//multiply with the mask
				m0=_mm256_maddubs_epi16(row_2,cx);


				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
				m4=_mm256_and_si256(m0,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

				m2=_mm256_add_epi16(m2,m4);

				//m2 has 16 16bit values now. the results I need are in positions 0,3,6,9,12. keep only those, discard others
				output_even=_mm256_and_si256(m2,output_mask);

				//--------------row=0
				  //y filter begins

					//multiply with the mask
					m0=_mm256_maddubs_epi16(r0,cy2);
					m1=_mm256_maddubs_epi16(r1,cy1);
					m2=_mm256_maddubs_epi16(r2,cy0);

					//vertical add
					m0=_mm256_add_epi16(m0,m1);
					m0=_mm256_add_epi16(m0,m2);


					even=division(division_case,m0,f);//even results

					//multiply with the mask
					m0=_mm256_maddubs_epi16(r0,cy2_sh1);
					m1=_mm256_maddubs_epi16(r1,cy1_sh1);
					m2=_mm256_maddubs_epi16(r2,cy0_sh1);

					//vertical add
					m0=_mm256_add_epi16(m0,m1);
					m0=_mm256_add_epi16(m0,m2);

					odd=division(division_case,m0,f);//odd results

					//pack to one register
					odd=_mm256_slli_si256(odd,1); //shift one position right
					row_0=_mm256_add_epi8(even,odd); //add the odd with the even

					//y filter ends - row_0 has the data to be processed by x filter

				//multiply with the mask
				m0=_mm256_maddubs_epi16(row_0,cx);


				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
				m4=_mm256_and_si256(m0,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

				m2=_mm256_add_epi16(m2,m4);

				//m2 has 16 16bit values now. the results I need are in positions 0,3,6,9,12. keep only those, discard others
				output_row0_even=_mm256_and_si256(m2,output_mask);

				//--------------row=1
				  //y filter begins

					//multiply with the mask
					m0=_mm256_maddubs_epi16(r0,cy1);
					m1=_mm256_maddubs_epi16(r1,cy2);
					m2=_mm256_maddubs_epi16(r2,cy1);
					m3=_mm256_maddubs_epi16(r3,cy0);


					//vertical add
					m0=_mm256_add_epi16(m0,m1);
					m2=_mm256_add_epi16(m2,m3);
					m0=_mm256_add_epi16(m0,m2);


					even=division(division_case,m0,f);//even results

					//multiply with the mask
					m0=_mm256_maddubs_epi16(r0,cy1_sh1);
					m1=_mm256_maddubs_epi16(r1,cy2_sh1);
					m2=_mm256_maddubs_epi16(r2,cy1_sh1);
					m3=_mm256_maddubs_epi16(r3,cy0_sh1);

					//vertical add
					m0=_mm256_add_epi16(m0,m1);
					m2=_mm256_add_epi16(m2,m3);
					m0=_mm256_add_epi16(m0,m2);

					odd=division(division_case,m0,f);//odd results

					//pack to one register
					odd=_mm256_slli_si256(odd,1); //shift one position right
					row_1=_mm256_add_epi8(even,odd); //add the odd with the even

					//y filter ends - row_1 has the data to be processed by x filter

				//multiply with the mask
				m0=_mm256_maddubs_epi16(row_1,cx);

				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
				m4=_mm256_and_si256(m0,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

				m2=_mm256_add_epi16(m2,m4);

				//m2 has 16 16bit values now. the results I need are in positions 0,3,6,9,12. keep only those, discard others
				output_row1_even=_mm256_and_si256(m2,output_mask);

				//2nd col iteration

				//multiply with the mask

				//----row=2
				m0=_mm256_maddubs_epi16(row_2,cx_sh1);



				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
				m4=_mm256_and_si256(m0,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
				m2=_mm256_add_epi16(m2,m4);

				//m2 has 16 16bit values now. the results I need are in positions 0,3,6,9,12. keep only those, discard others
				output_odd = _mm256_and_si256(m2,output_mask);

				//----row=0
				m0=_mm256_maddubs_epi16(row_0,cx_sh1);


				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
				m4=_mm256_and_si256(m0,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
				m2=_mm256_add_epi16(m2,m4);

				//m2 has 16 16bit values now. the results I need are in positions 0,3,6,9,12. keep only those, discard others
				output_row0_odd = _mm256_and_si256(m2,output_mask);

				//----row=1
				m0=_mm256_maddubs_epi16(row_1,cx_sh1);


				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
				m4=_mm256_and_si256(m0,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
				m2=_mm256_add_epi16(m2,m4);

				//m2 has 16 16bit values now. the results I need are in positions 0,3,6,9,12. keep only those, discard others
				output_row1_odd = _mm256_and_si256(m2,output_mask);

		                 //3rd col iteration
				//---row=2
				//multiply with the mask
				m0=_mm256_maddubs_epi16(row_2,cx_sh2);


				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
				m4=_mm256_and_si256(m2,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

				m2=_mm256_add_epi16(m2,m4);

				//m2 has 16 16bit values now. the results I need are in positions 1,4,7,10,13. keep only those, discard others
				m2 = _mm256_and_si256(m2,output_mask_sh1);
				output_even = _mm256_add_epi16(output_even,m2);

				//---row=0
				//multiply with the mask
				m0=_mm256_maddubs_epi16(row_0,cx_sh2);


				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
				m4=_mm256_and_si256(m2,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

				m2=_mm256_add_epi16(m2,m4);

				//m2 has 16 16bit values now. the results I need are in positions 1,4,7,10,13. keep only those, discard others
				m2 = _mm256_and_si256(m2,output_mask_sh1);
				output_row0_even = _mm256_add_epi16(output_row0_even,m2);


				//---row=1
				//multiply with the mask
				m0=_mm256_maddubs_epi16(row_1,cx_sh2);

				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
				m4=_mm256_and_si256(m2,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

				m2=_mm256_add_epi16(m2,m4);

				//m2 has 16 16bit values now. the results I need are in positions 1,4,7,10,13. keep only those, discard others
				m2 = _mm256_and_si256(m2,output_mask_sh1);
				output_row1_even = _mm256_add_epi16(output_row1_even,m2);

				//4th col iteration

				//4th col iteration

				//multiply with the mask
				m0=_mm256_maddubs_epi16(row_2,cx_sh3);

				//hozizontal additions
				//hadd(3:8)
				//hadd(9:14)
				//hadd(15:20)
				//hadd(21:26)
				//hadd(27:31)
				//result after division will be in 2,8,14,20,26

				m1=_mm256_srli_si256(m0,2);
				m4=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m4);

				//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
				//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
				m4=_mm256_and_si256(m4,mask3);
				m4=_mm256_permute2f128_si256(m4,m4,1);
				m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

				m2=_mm256_add_epi16(m2,m4);

				//m2 has 16 16bit values now. the results I need are in positions 1,4,7,10,13. keep only those, discard others
				m2 = _mm256_and_si256(m2,output_mask_sh1);
				output_odd = _mm256_add_epi16(output_odd,m2);

				//row0
				//multiply with the mask
				m0=_mm256_maddubs_epi16(row_0,cx_sh3);


								m1=_mm256_srli_si256(m0,2);
								m4=_mm256_add_epi16(m1,m0);

								m1=_mm256_srli_si256(m0,4);
								m2=_mm256_add_epi16(m1,m4);

								//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
								//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
								m4=_mm256_and_si256(m4,mask3);
								m4=_mm256_permute2f128_si256(m4,m4,1);
								m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

								m2=_mm256_add_epi16(m2,m4);

								//m2 has 16 16bit values now. the results I need are in positions 1,4,7,10,13. keep only those, discard others
								m2 = _mm256_and_si256(m2,output_mask_sh1);
								output_row0_odd = _mm256_add_epi16(output_row0_odd,m2);


								//-----------row1
								//multiply with the mask
								m0=_mm256_maddubs_epi16(row_1,cx_sh3);

												m1=_mm256_srli_si256(m0,2);
												m4=_mm256_add_epi16(m1,m0);

												m1=_mm256_srli_si256(m0,4);
												m2=_mm256_add_epi16(m1,m4);

												//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
												//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
												m4=_mm256_and_si256(m4,mask3);
												m4=_mm256_permute2f128_si256(m4,m4,1);
												m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

												m2=_mm256_add_epi16(m2,m4);

												//m2 has 16 16bit values now. the results I need are in positions 1,4,7,10,13. keep only those, discard others
												m2 = _mm256_and_si256(m2,output_mask_sh1);
												output_row1_odd = _mm256_add_epi16(output_row1_odd,m2);



				//5th col iteration
				//multiply with the mask
				m0=_mm256_maddubs_epi16(row_2,cx_sh4);

				//hozizontal additions
				//hadd(4:9)
				//hadd(10:15)
				//hadd(16:21)
				//hadd(22:27)
				//result after division will be in 4,10,16,22

				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);


				//m2 has 16 16bit values now. the results I need are in positions 2,5,8,11. keep only those, discard others
				m2 = _mm256_and_si256(m2,output_mask_sh2);
				output_even = _mm256_add_epi16(output_even,m2);

				//row0
				//multiply with the mask
				m0=_mm256_maddubs_epi16(row_0,cx_sh4);


				//hozizontal additions
				//hadd(4:9)
				//hadd(10:15)
				//hadd(16:21)
				//hadd(22:27)
				//result after division will be in 4,10,16,22

				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);


				//m2 has 16 16bit values now. the results I need are in positions 2,5,8,11. keep only those, discard others
				m2 = _mm256_and_si256(m2,output_mask_sh2);
				output_row0_even = _mm256_add_epi16(output_row0_even,m2);

				//row1
				//multiply with the mask
				m0=_mm256_maddubs_epi16(row_1,cx_sh4);


				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);


				//m2 has 16 16bit values now. the results I need are in positions 2,5,8,11. keep only those, discard others
				m2 = _mm256_and_si256(m2,output_mask_sh2);
				output_row1_even = _mm256_add_epi16(output_row1_even,m2);


		                 //6th col iteration
				//multiply with the mask
				m0=_mm256_maddubs_epi16(row_2,cx_sh5);

				//hozizontal additions
				//hadd(5:10)
				//hadd(11:16)
				//hadd(17:22)
				//hadd(23:28)
				//result after division will be in 4,10,16,22

				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//m2 has 16 16bit values now. the results I need are in positions 2,5,8,11. keep only those, discard others
				m2 = _mm256_and_si256(m2,output_mask_sh2);
				output_odd = _mm256_add_epi16(output_odd,m2);

				//now division follows
				output_even=division(division_case,output_even,f);
				output_odd=division(division_case,output_odd,f);

				//shift odd 1 position and add to even
				output_odd = _mm256_slli_si256(output_odd,1);
				output_even = _mm256_add_epi8(output_even,output_odd);

				_mm256_storeu_si256( (__m256i *) &filt[row][col],output_even );

				//row0
				//multiply with the mask
				m0=_mm256_maddubs_epi16(row_0,cx_sh5);


				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//m2 has 16 16bit values now. the results I need are in positions 2,5,8,11. keep only those, discard others
				m2 = _mm256_and_si256(m2,output_mask_sh2);
				output_row0_odd = _mm256_add_epi16(output_row0_odd,m2);

				//now division follows
				output_row0_even=division(division_case,output_row0_even,f);
				output_row0_odd=division(division_case,output_row0_odd,f);

				//shift odd 1 position and add to even
				output_row0_odd = _mm256_slli_si256(output_row0_odd,1);
				output_row0_even = _mm256_add_epi8(output_row0_even,output_row0_odd);


				_mm256_storeu_si256( (__m256i *) &filt[0][col],output_row0_even );

				//row1

				//multiply with the mask
				m0=_mm256_maddubs_epi16(row_1,cx_sh5);


				m1=_mm256_srli_si256(m0,2);
				m2=_mm256_add_epi16(m1,m0);

				m1=_mm256_srli_si256(m0,4);
				m2=_mm256_add_epi16(m1,m2);

				//m2 has 16 16bit values now. the results I need are in positions 2,5,8,11. keep only those, discard others
				m2 = _mm256_and_si256(m2,output_mask_sh2);
				output_row1_odd = _mm256_add_epi16(output_row1_odd,m2);

				//now division follows
				output_row1_even=division(division_case,output_row1_even,f);
				output_row1_odd=division(division_case,output_row1_odd,f);

				//shift odd 1 position and add to even
				output_row1_odd = _mm256_slli_si256(output_row1_odd,1);
				output_row1_even = _mm256_add_epi8(output_row1_even,output_row1_odd);


				_mm256_storeu_si256( (__m256i *) &filt[1][col],output_row1_even );


				}

			  if (REMINDER_ITERATIONS>=16)
				;//loop_reminder_first_rows_high_reminder_values(frame1,filt,M,N,col,REMINDER_ITERATIONS,division_case,c0,c1,c2,c0_sh1,c1_sh1,c2_sh1,c0_sh2,c1_sh2,c2_sh2,f,divisor);
			  else
			    ;//loop_reminder_first_rows_low_reminder_values(frame1,filt,M,N,col,REMINDER_ITERATIONS,division_case,c0,c1,c2,c0_sh1,c1_sh1,c2_sh1,c0_sh2,c1_sh2,c2_sh2,f);

		}

		else if (row==N-3){//in this case I calculate filt[N-2][:] and filt[N-1][:] too. Below row0 refers to row=N-2 and row1 refers to row=N-1
			for (col = 0; col <= M-32; col+=28){
						 //last col value that does not read outside of the array bounds is (col<M-29)

							  if (col==0){

									//load the 5 rows
									r0=_mm256_loadu_si256( (__m256i *) &frame1[row-2][0]);
									r1=_mm256_loadu_si256( (__m256i *) &frame1[row-1][0]);
									r2=_mm256_loadu_si256( (__m256i *) &frame1[row][0]);
									r3=_mm256_loadu_si256( (__m256i *) &frame1[row+1][0]);
									r4=_mm256_loadu_si256( (__m256i *) &frame1[row+2][0]);

							  			//START - extra code needed for prelude
							  					m0=_mm256_slli_si256(r0,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
							  					m1=_mm256_slli_si256(r1,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
							  					m2=_mm256_slli_si256(r2,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
							  					m3=_mm256_slli_si256(r3,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
							  					m4=_mm256_slli_si256(r4,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning

							  					r0=_mm256_and_si256(r0,mask_prelude);
							  					r0=_mm256_permute2f128_si256(r0,r0,1);
							  					r0=_mm256_srli_si256(r0,14);//shift 14 elements
							  					r0=_mm256_add_epi16(m0,r0);

							  					r1=_mm256_and_si256(r1,mask_prelude);
							  					r1=_mm256_permute2f128_si256(r1,r1,1);
							  					r1=_mm256_srli_si256(r1,14);//shift 14 elements
							  					r1=_mm256_add_epi16(m1,r1);

							  					r2=_mm256_and_si256(r2,mask_prelude);
							  					r2=_mm256_permute2f128_si256(r2,r2,1);
							  					r2=_mm256_srli_si256(r2,14);//shift 14 elements
							  					r2=_mm256_add_epi16(m2,r2);

							  					r3=_mm256_and_si256(r3,mask_prelude);
							  					r3=_mm256_permute2f128_si256(r3,r3,1);
							  					r3=_mm256_srli_si256(r3,14);//shift 14 elements
							  					r3=_mm256_add_epi16(m3,r3);

							  					r4=_mm256_and_si256(r4,mask_prelude);
							  					r4=_mm256_permute2f128_si256(r4,r4,1);
							  					r4=_mm256_srli_si256(r4,14);//shift 14 elements
							  					r4=_mm256_add_epi16(m4,r4);

							  			//END - extra code needed for prelude
							  		}
							  else {
									//load the 5 rows
									r0=_mm256_loadu_si256( (__m256i *) &frame1[row-2][col-2]);
									r1=_mm256_loadu_si256( (__m256i *) &frame1[row-1][col-2]);
									r2=_mm256_loadu_si256( (__m256i *) &frame1[row][col-2]);
									r3=_mm256_loadu_si256( (__m256i *) &frame1[row+1][col-2]);
									r4=_mm256_loadu_si256( (__m256i *) &frame1[row+2][col-2]);
							  }

							//col iteration computes output pixels of 2,8,14,20,26
							// col+1 iteration computes output pixels of 3,9,15,21,27
							// col+2 iteration computes output pixels of 4,10,16,22,28
							// col+3 iteration computes output pixels of 5,11,17,23,29
							// col+4 iteration computes output pixels of 6,12,18,24,30
							// col+5 iteration computes output pixels of 7,13,19,25,31
							//afterwards, col2 becomes 32 and repeat the above process

							//1st col iteration
							  //y filter begins

								//multiply with the mask
								m0=_mm256_maddubs_epi16(r0,cy0);
								m1=_mm256_maddubs_epi16(r1,cy1);
								m2=_mm256_maddubs_epi16(r2,cy2);
								m3=_mm256_maddubs_epi16(r3,cy1);
								m4=_mm256_maddubs_epi16(r4,cy0);

								//vertical add
								m0=_mm256_add_epi16(m0,m1);
								m2=_mm256_add_epi16(m2,m3);
								m0=_mm256_add_epi16(m0,m2);
								m0=_mm256_add_epi16(m0,m4);

								even=division(division_case,m0,f);//even results

								//multiply with the mask
								m0=_mm256_maddubs_epi16(r0,cy0_sh1);
								m1=_mm256_maddubs_epi16(r1,cy1_sh1);
								m2=_mm256_maddubs_epi16(r2,cy2_sh1);
								m3=_mm256_maddubs_epi16(r3,cy1_sh1);
								m4=_mm256_maddubs_epi16(r4,cy0_sh1);

								//vertical add
								m0=_mm256_add_epi16(m0,m1);
								m2=_mm256_add_epi16(m2,m3);
								m0=_mm256_add_epi16(m0,m2);
								m0=_mm256_add_epi16(m0,m4);

								odd=division(division_case,m0,f);//odd results

								//pack to one register
								odd=_mm256_slli_si256(odd,1); //shift one position right
								row_2=_mm256_add_epi8(even,odd); //add the odd with the even

								//y filter ends - row_2 has the data to be processed by x filter


							 //--------------row=2

							//multiply with the mask
							m0=_mm256_maddubs_epi16(row_2,cx);


							m1=_mm256_srli_si256(m0,2);
							m2=_mm256_add_epi16(m1,m0);

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m2);

							//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
							m4=_mm256_and_si256(m0,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

							m2=_mm256_add_epi16(m2,m4);

							//m2 has 16 16bit values now. the results I need are in positions 0,3,6,9,12. keep only those, discard others
							output_even=_mm256_and_si256(m2,output_mask);

							//--------------row=0
							  //y filter begins

								//multiply with the mask
								m1=_mm256_maddubs_epi16(r1,cy0);
								m2=_mm256_maddubs_epi16(r2,cy1);
								m3=_mm256_maddubs_epi16(r3,cy2);
								m4=_mm256_maddubs_epi16(r4,cy1);

								//vertical add
								m0=_mm256_add_epi16(m1,m2);
								m0=_mm256_add_epi16(m0,m3);
								m0=_mm256_add_epi16(m0,m4);

								even=division(division_case,m0,f);//even results

								//multiply with the mask
								m1=_mm256_maddubs_epi16(r1,cy0_sh1);
								m2=_mm256_maddubs_epi16(r2,cy1_sh1);
								m3=_mm256_maddubs_epi16(r3,cy2_sh1);
								m4=_mm256_maddubs_epi16(r4,cy1_sh1);

								//vertical add
								m0=_mm256_add_epi16(m1,m2);
								m0=_mm256_add_epi16(m0,m3);
								m0=_mm256_add_epi16(m0,m4);

								odd=division(division_case,m0,f);//odd results

								//pack to one register
								odd=_mm256_slli_si256(odd,1); //shift one position right
								row_0=_mm256_add_epi8(even,odd); //add the odd with the even

								//y filter ends - row_0 has the data to be processed by x filter

							//multiply with the mask
							m0=_mm256_maddubs_epi16(row_0,cx);


							m1=_mm256_srli_si256(m0,2);
							m2=_mm256_add_epi16(m1,m0);

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m2);

							//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
							m4=_mm256_and_si256(m0,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

							m2=_mm256_add_epi16(m2,m4);

							//m2 has 16 16bit values now. the results I need are in positions 0,3,6,9,12. keep only those, discard others
							output_row0_even=_mm256_and_si256(m2,output_mask);

							//--------------row=1
							  //y filter begins

								//multiply with the mask
								m2=_mm256_maddubs_epi16(r2,cy0);
								m3=_mm256_maddubs_epi16(r3,cy1);
								m4=_mm256_maddubs_epi16(r4,cy2);

								//vertical add
								m0=_mm256_add_epi16(m2,m3);
								m0=_mm256_add_epi16(m0,m4);

								even=division(division_case,m0,f);//even results

								//multiply with the mask
								m2=_mm256_maddubs_epi16(r2,cy0_sh1);
								m3=_mm256_maddubs_epi16(r3,cy1_sh1);
								m4=_mm256_maddubs_epi16(r4,cy2_sh1);

								//vertical add
								m0=_mm256_add_epi16(m2,m3);
								m0=_mm256_add_epi16(m0,m4);

								odd=division(division_case,m0,f);//odd results

								//pack to one register
								odd=_mm256_slli_si256(odd,1); //shift one position right
								row_1=_mm256_add_epi8(even,odd); //add the odd with the even

								//y filter ends - row_1 has the data to be processed by x filter

							//multiply with the mask
							m0=_mm256_maddubs_epi16(row_1,cx);

							m1=_mm256_srli_si256(m0,2);
							m2=_mm256_add_epi16(m1,m0);

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m2);

							//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
							m4=_mm256_and_si256(m0,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

							m2=_mm256_add_epi16(m2,m4);

							//m2 has 16 16bit values now. the results I need are in positions 0,3,6,9,12. keep only those, discard others
							output_row1_even=_mm256_and_si256(m2,output_mask);

							//2nd col iteration
							//----row=2

							//multiply with the mask
							m0=_mm256_maddubs_epi16(row_2,cx_sh1);


							m1=_mm256_srli_si256(m0,2);
							m2=_mm256_add_epi16(m1,m0);

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m2);

							//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
							m4=_mm256_and_si256(m0,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
							m2=_mm256_add_epi16(m2,m4);

							//m2 has 16 16bit values now. the results I need are in positions 0,3,6,9,12. keep only those, discard others
							output_odd = _mm256_and_si256(m2,output_mask);

							//----row=0
							//multiply with the mask
							m0=_mm256_maddubs_epi16(row_0,cx_sh1);


							m1=_mm256_srli_si256(m0,2);
							m2=_mm256_add_epi16(m1,m0);

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m2);

							//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
							m4=_mm256_and_si256(m0,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
							m2=_mm256_add_epi16(m2,m4);

							//m2 has 16 16bit values now. the results I need are in positions 0,3,6,9,12. keep only those, discard others
							output_row0_odd = _mm256_and_si256(m2,output_mask);

							//----row=1
							//multiply with the mask
							m0=_mm256_maddubs_epi16(row_1,cx_sh1);


							m1=_mm256_srli_si256(m0,2);
							m2=_mm256_add_epi16(m1,m0);

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m2);

							//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
							m4=_mm256_and_si256(m0,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
							m2=_mm256_add_epi16(m2,m4);

							//m2 has 16 16bit values now. the results I need are in positions 0,3,6,9,12. keep only those, discard others
							output_row1_odd = _mm256_and_si256(m2,output_mask);

					                 //3rd col iteration
							//---row=2
							//multiply with the mask
							m0=_mm256_maddubs_epi16(row_2,cx_sh2);


							m1=_mm256_srli_si256(m0,2);
							m2=_mm256_add_epi16(m1,m0);

							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
							m4=_mm256_and_si256(m2,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m2);

							//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

							m2=_mm256_add_epi16(m2,m4);

							//m2 has 16 16bit values now. the results I need are in positions 1,4,7,10,13. keep only those, discard others
							m2 = _mm256_and_si256(m2,output_mask_sh1);
							output_even = _mm256_add_epi16(output_even,m2);

							//---row=0
							//multiply with the mask
							m0=_mm256_maddubs_epi16(row_0,cx_sh2);

							m1=_mm256_srli_si256(m0,2);
							m2=_mm256_add_epi16(m1,m0);

							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
							m4=_mm256_and_si256(m2,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m2);

							//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

							m2=_mm256_add_epi16(m2,m4);

							//m2 has 16 16bit values now. the results I need are in positions 1,4,7,10,13. keep only those, discard others
							m2 = _mm256_and_si256(m2,output_mask_sh1);
							output_row0_even = _mm256_add_epi16(output_row0_even,m2);


							//---row=1
							//multiply with the mask
							m0=_mm256_maddubs_epi16(row_1,cx_sh2);


							m1=_mm256_srli_si256(m0,2);
							m2=_mm256_add_epi16(m1,m0);

							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
							m4=_mm256_and_si256(m2,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m2);

							//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

							m2=_mm256_add_epi16(m2,m4);

							//m2 has 16 16bit values now. the results I need are in positions 1,4,7,10,13. keep only those, discard others
							m2 = _mm256_and_si256(m2,output_mask_sh1);
							output_row1_even = _mm256_add_epi16(output_row1_even,m2);

							//4th col iteration
							//multiply with the mask
							m0=_mm256_maddubs_epi16(row_2,cx_sh3);

							//hozizontal additions
							//hadd(3:8)
							//hadd(9:14)
							//hadd(15:20)
							//hadd(21:26)
							//hadd(27:31)
							//result after division will be in 2,8,14,20,26

							m1=_mm256_srli_si256(m0,2);
							m4=_mm256_add_epi16(m1,m0);

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m4);

							//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
							//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
							m4=_mm256_and_si256(m4,mask3);
							m4=_mm256_permute2f128_si256(m4,m4,1);
							m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

							m2=_mm256_add_epi16(m2,m4);

							//m2 has 16 16bit values now. the results I need are in positions 1,4,7,10,13. keep only those, discard others
							m2 = _mm256_and_si256(m2,output_mask_sh1);
							output_odd = _mm256_add_epi16(output_odd,m2);

							//row0
							//multiply with the mask
							m0=_mm256_maddubs_epi16(row_0,cx_sh3);


								m1=_mm256_srli_si256(m0,2);
								m4=_mm256_add_epi16(m1,m0);

								m1=_mm256_srli_si256(m0,4);
								m2=_mm256_add_epi16(m1,m4);

								//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
								//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
								m4=_mm256_and_si256(m4,mask3);
								m4=_mm256_permute2f128_si256(m4,m4,1);
								m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

								m2=_mm256_add_epi16(m2,m4);

								//m2 has 16 16bit values now. the results I need are in positions 1,4,7,10,13. keep only those, discard others
								m2 = _mm256_and_si256(m2,output_mask_sh1);
								output_row0_odd = _mm256_add_epi16(output_row0_odd,m2);

								//row1
								//multiply with the mask
								m0=_mm256_maddubs_epi16(row_1,cx_sh3);

									m1=_mm256_srli_si256(m0,2);
									m4=_mm256_add_epi16(m1,m0);

									m1=_mm256_srli_si256(m0,4);
									m2=_mm256_add_epi16(m1,m4);

									//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
									//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
									m4=_mm256_and_si256(m4,mask3);
									m4=_mm256_permute2f128_si256(m4,m4,1);
									m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

									m2=_mm256_add_epi16(m2,m4);

									//m2 has 16 16bit values now. the results I need are in positions 1,4,7,10,13. keep only those, discard others
									m2 = _mm256_and_si256(m2,output_mask_sh1);
									output_row1_odd = _mm256_add_epi16(output_row1_odd,m2);


							//5th col iteration
							//multiply with the mask
							m0=_mm256_maddubs_epi16(row_2,cx_sh4);

							//hozizontal additions
							//hadd(4:9)
							//hadd(10:15)
							//hadd(16:21)
							//hadd(22:27)
							//result after division will be in 4,10,16,22

							m1=_mm256_srli_si256(m0,2);
							m2=_mm256_add_epi16(m1,m0);

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m2);


							//m2 has 16 16bit values now. the results I need are in positions 2,5,8,11. keep only those, discard others
							m2 = _mm256_and_si256(m2,output_mask_sh2);
							output_even = _mm256_add_epi16(output_even,m2);

							//row0
							//multiply with the mask
							m0=_mm256_maddubs_epi16(row_0,cx_sh4);


							m1=_mm256_srli_si256(m0,2);
							m2=_mm256_add_epi16(m1,m0);

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m2);


							//m2 has 16 16bit values now. the results I need are in positions 2,5,8,11. keep only those, discard others
							m2 = _mm256_and_si256(m2,output_mask_sh2);
							output_row0_even = _mm256_add_epi16(output_row0_even,m2);

							//row1
							//multiply with the mask
							m0=_mm256_maddubs_epi16(row_1,cx_sh4);


							m1=_mm256_srli_si256(m0,2);
							m2=_mm256_add_epi16(m1,m0);

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m2);


							//m2 has 16 16bit values now. the results I need are in positions 2,5,8,11. keep only those, discard others
							m2 = _mm256_and_si256(m2,output_mask_sh2);
							output_row1_even = _mm256_add_epi16(output_row1_even,m2);

					                 //6th col iteration
							//multiply with the mask
							m0=_mm256_maddubs_epi16(row_2,cx_sh5);

							//hozizontal additions
							//hadd(5:10)
							//hadd(11:16)
							//hadd(17:22)
							//hadd(23:28)
							//result after division will be in 4,10,16,22

							m1=_mm256_srli_si256(m0,2);
							m2=_mm256_add_epi16(m1,m0);

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m2);

							//m2 has 16 16bit values now. the results I need are in positions 2,5,8,11. keep only those, discard others
							m2 = _mm256_and_si256(m2,output_mask_sh2);
							output_odd = _mm256_add_epi16(output_odd,m2);

							//now division follows
							output_even=division(division_case,output_even,f);
							output_odd=division(division_case,output_odd,f);

							//shift odd 1 position and add to even
							output_odd = _mm256_slli_si256(output_odd,1);
							output_even = _mm256_add_epi8(output_even,output_odd);


							_mm256_storeu_si256( (__m256i *) &filt[row][col],output_even );


							//row0
							//multiply with the mask
							m0=_mm256_maddubs_epi16(row_0,cx_sh5);


							m1=_mm256_srli_si256(m0,2);
							m2=_mm256_add_epi16(m1,m0);

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m2);

							//m2 has 16 16bit values now. the results I need are in positions 2,5,8,11. keep only those, discard others
							m2 = _mm256_and_si256(m2,output_mask_sh2);
							output_row0_odd = _mm256_add_epi16(output_row0_odd,m2);

							//now division follows
							output_row0_even=division(division_case,output_row0_even,f);
							output_row0_odd=division(division_case,output_row0_odd,f);

							//shift odd 1 position and add to even
							output_row0_odd = _mm256_slli_si256(output_row0_odd,1);
							output_row0_even = _mm256_add_epi8(output_row0_even,output_row0_odd);


							_mm256_storeu_si256( (__m256i *) &filt[N-2][col],output_row0_even );

							//row1
							//multiply with the mask
							m0=_mm256_maddubs_epi16(row_1,cx_sh5);

								m1=_mm256_srli_si256(m0,2);
							m2=_mm256_add_epi16(m1,m0);

							m1=_mm256_srli_si256(m0,4);
							m2=_mm256_add_epi16(m1,m2);

							//m2 has 16 16bit values now. the results I need are in positions 2,5,8,11. keep only those, discard others
							m2 = _mm256_and_si256(m2,output_mask_sh2);
							output_row1_odd = _mm256_add_epi16(output_row1_odd,m2);

							//now division follows
							output_row1_even=division(division_case,output_row1_even,f);
							output_row1_odd=division(division_case,output_row1_odd,f);

							//shift odd 1 position and add to even
							output_row1_odd = _mm256_slli_si256(output_row1_odd,1);
							output_row1_even = _mm256_add_epi8(output_row1_even,output_row1_odd);


							_mm256_storeu_si256( (__m256i *) &filt[N-1][col],output_row1_even );


							}

			if (REMINDER_ITERATIONS>=16)
				;//loop_reminder_last_rows_high_reminder_values(frame1,filt,M,N,col,REMINDER_ITERATIONS,division_case,c0,c1,c2,c0_sh1,c1_sh1,c2_sh1,c0_sh2,c1_sh2,c2_sh2,f,divisor);
			else
				;//loop_reminder_last_rows_low_reminder_values(frame1,filt,M,N,col,REMINDER_ITERATIONS,division_case,c0,c1,c2,c0_sh1,c1_sh1,c2_sh1,c0_sh2,c1_sh2,c2_sh2,f);

					}
	else {


	  for (col = 0; col <= M-32; col+=28){
	 //last col value that does not read outside of the array bounds is (col<M-29)

		  if (col==0){

				//load the 5 rows
				r0=_mm256_loadu_si256( (__m256i *) &frame1[row-2][0]);
				r1=_mm256_loadu_si256( (__m256i *) &frame1[row-1][0]);
				r2=_mm256_loadu_si256( (__m256i *) &frame1[row][0]);
				r3=_mm256_loadu_si256( (__m256i *) &frame1[row+1][0]);
				r4=_mm256_loadu_si256( (__m256i *) &frame1[row+2][0]);

		  			//START - extra code needed for prelude
		  					m0=_mm256_slli_si256(r0,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
		  					m1=_mm256_slli_si256(r1,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
		  					m2=_mm256_slli_si256(r2,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
		  					m3=_mm256_slli_si256(r3,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning
		  					m4=_mm256_slli_si256(r4,2);//shift 2 elements left - equivalent to filling with two zeros inthe beginning

		  					r0=_mm256_and_si256(r0,mask_prelude);
		  					r0=_mm256_permute2f128_si256(r0,r0,1);
		  					r0=_mm256_srli_si256(r0,14);//shift 14 elements
		  					r0=_mm256_add_epi16(m0,r0);

		  					r1=_mm256_and_si256(r1,mask_prelude);
		  					r1=_mm256_permute2f128_si256(r1,r1,1);
		  					r1=_mm256_srli_si256(r1,14);//shift 14 elements
		  					r1=_mm256_add_epi16(m1,r1);

		  					r2=_mm256_and_si256(r2,mask_prelude);
		  					r2=_mm256_permute2f128_si256(r2,r2,1);
		  					r2=_mm256_srli_si256(r2,14);//shift 14 elements
		  					r2=_mm256_add_epi16(m2,r2);

		  					r3=_mm256_and_si256(r3,mask_prelude);
		  					r3=_mm256_permute2f128_si256(r3,r3,1);
		  					r3=_mm256_srli_si256(r3,14);//shift 14 elements
		  					r3=_mm256_add_epi16(m3,r3);

		  					r4=_mm256_and_si256(r4,mask_prelude);
		  					r4=_mm256_permute2f128_si256(r4,r4,1);
		  					r4=_mm256_srli_si256(r4,14);//shift 14 elements
		  					r4=_mm256_add_epi16(m4,r4);

		  			//END - extra code needed for prelude
		  		}
		  else {
				//load the 5 rows
				r0=_mm256_loadu_si256( (__m256i *) &frame1[row-2][col-2]);
				r1=_mm256_loadu_si256( (__m256i *) &frame1[row-1][col-2]);
				r2=_mm256_loadu_si256( (__m256i *) &frame1[row][col-2]);
				r3=_mm256_loadu_si256( (__m256i *) &frame1[row+1][col-2]);
				r4=_mm256_loadu_si256( (__m256i *) &frame1[row+2][col-2]);
		  }

		  //y filter begins

			//multiply with the mask
			m0=_mm256_maddubs_epi16(r0,cy0);
			m1=_mm256_maddubs_epi16(r1,cy1);
			m2=_mm256_maddubs_epi16(r2,cy2);
			m3=_mm256_maddubs_epi16(r3,cy1);
			m4=_mm256_maddubs_epi16(r4,cy0);

			//vertical add
			m0=_mm256_add_epi16(m0,m1);
			m2=_mm256_add_epi16(m2,m3);
			m0=_mm256_add_epi16(m0,m2);
			m0=_mm256_add_epi16(m0,m4);

			even=division(division_case,m0,f);//even results

			//multiply with the mask
			m0=_mm256_maddubs_epi16(r0,cy0_sh1);
			m1=_mm256_maddubs_epi16(r1,cy1_sh1);
			m2=_mm256_maddubs_epi16(r2,cy2_sh1);
			m3=_mm256_maddubs_epi16(r3,cy1_sh1);
			m4=_mm256_maddubs_epi16(r4,cy0_sh1);

			//vertical add
			m0=_mm256_add_epi16(m0,m1);
			m2=_mm256_add_epi16(m2,m3);
			m0=_mm256_add_epi16(m0,m2);
			m0=_mm256_add_epi16(m0,m4);

			odd=division(division_case,m0,f);//odd results

			//pack to one register
			odd=_mm256_slli_si256(odd,1); //shift one position right
			r0=_mm256_add_epi8(even,odd); //add the odd with the even

			//y filter ends - r0 has the data to be processed by x filter

		//col iteration computes output pixels of 2,8,14,20,26
		// col+1 iteration computes output pixels of 3,9,15,21,27
		// col+2 iteration computes output pixels of 4,10,16,22,28
		// col+3 iteration computes output pixels of 5,11,17,23,29
		// col+4 iteration computes output pixels of 6,12,18,24
		// col+5 iteration computes output pixels of 7,13,19,25
		//afterwards, col becomes 30 and repeat the above process

		//1st col iteration


		//multiply with the mask
		m0=_mm256_maddubs_epi16(r0,cx);


		//hozizontal additions
		//hadd(0:5)
		//hadd(6:11)
		//hadd(12:17)
		//hadd(18:23)
		//hadd(24:28)

		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
		m4=_mm256_and_si256(m0,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

		m2=_mm256_add_epi16(m2,m4);

		//m2 has 16 16bit values now. the results I need are in positions 0,3,6,9,12. keep only those, discard others
		output_even=_mm256_and_si256(m2,output_mask);


		//2nd col iteration
		//multiply with the mask
		m0=_mm256_maddubs_epi16(r0,cx_sh1);

		//hozizontal additions
		//hadd(1:6)
		//hadd(7:12)
		//hadd(13:18)
		//hadd(19:24)
		//hadd(25:29)

		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
		m4=_mm256_and_si256(m0,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
		m2=_mm256_add_epi16(m2,m4);

		//m2 has 16 16bit values now. the results I need are in positions 0,3,6,9,12. keep only those, discard others
		output_odd = _mm256_and_si256(m2,output_mask);


         //3rd col iteration
		//multiply with the mask
		m0=_mm256_maddubs_epi16(r0,cx_sh2);

		//hozizontal additions
		//hadd(2:7)
		//hadd(8:13)
		//hadd(14:19)
		//hadd(20:25)
		//hadd(26:30)


		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
		m4=_mm256_and_si256(m2,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

		m2=_mm256_add_epi16(m2,m4);

		//m2 has 16 16bit values now. the results I need are in positions 1,4,7,10,13. keep only those, discard others
		m2 = _mm256_and_si256(m2,output_mask_sh1);
		output_even = _mm256_add_epi16(output_even,m2);


		//4th col iteration

		//multiply with the mask
		m0=_mm256_maddubs_epi16(r0,cx_sh3);

		//hozizontal additions
		//hadd(3:8)
		//hadd(9:14)
		//hadd(15:20)
		//hadd(21:26)
		//hadd(27:31)
		//result after division will be in 2,8,14,20,26

		m1=_mm256_srli_si256(m0,2);
		m4=_mm256_add_epi16(m1,m0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m4);

		//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
		//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
		m4=_mm256_and_si256(m4,mask3);
		m4=_mm256_permute2f128_si256(m4,m4,1);
		m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

		m2=_mm256_add_epi16(m2,m4);

		//m2 has 16 16bit values now. the results I need are in positions 1,4,7,10,13. keep only those, discard others
		m2 = _mm256_and_si256(m2,output_mask_sh1);
		output_odd = _mm256_add_epi16(output_odd,m2);


		//5th col iteration
		//multiply with the mask
		m0=_mm256_maddubs_epi16(r0,cx_sh4);

		//hozizontal additions
		//hadd(4:9)
		//hadd(10:15)
		//hadd(16:21)
		//hadd(22:27)
		//result after division will be in 4,10,16,22

		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);


		//m2 has 16 16bit values now. the results I need are in positions 2,5,8,11. keep only those, discard others
		m2 = _mm256_and_si256(m2,output_mask_sh2);
		output_even = _mm256_add_epi16(output_even,m2);


                 //6th col iteration
		//multiply with the mask
		m0=_mm256_maddubs_epi16(r0,cx_sh5);

		//hozizontal additions
		//hadd(5:10)
		//hadd(11:16)
		//hadd(17:22)
		//hadd(23:28)
		//result after division will be in 4,10,16,22

		m1=_mm256_srli_si256(m0,2);
		m2=_mm256_add_epi16(m1,m0);

		m1=_mm256_srli_si256(m0,4);
		m2=_mm256_add_epi16(m1,m2);

		//m2 has 16 16bit values now. the results I need are in positions 2,5,8,11. keep only those, discard others
		m2 = _mm256_and_si256(m2,output_mask_sh2);
		output_odd = _mm256_add_epi16(output_odd,m2);

		//now division follows
		output_even=division(division_case,output_even,f);
		output_odd=division(division_case,output_odd,f);

		//shift odd 1 position and add to even
		output_odd = _mm256_slli_si256(output_odd,1);
		output_even = _mm256_add_epi8(output_even,output_odd);


		_mm256_storeu_si256( (__m256i *) &filt[row][col],output_even );


		}

        if (REMINDER_ITERATIONS>=16)
        	loop_reminder_high_reminder_values_seperable(frame1,filt,M,N,row,col,REMINDER_ITERATIONS,division_case, cx, cx_sh1, cx_sh2,cx_sh3,cx_sh4,cx_sh5,cy0, cy1,cy2, cy0_sh1, cy1_sh1, cy2_sh1,f,divisor);
        else
        	loop_reminder_low_reminder_values_seperable(frame1,filt,M,N,row,col,REMINDER_ITERATIONS,division_case, cx, cx_sh1, cx_sh2,cx_sh3,cx_sh4,cx_sh5,cy0, cy1,cy2, cy0_sh1, cy1_sh1, cy2_sh1,f);
		//padding code. The last three iterations  ABOVE get outside of the array bounds. The last three col iterations read outside but the garbage values are multiplied by zeros (last three mask zeros). From now on, I must include another mask with extra zeros.
//It is faster to read outside of the array's bounds and then fill the right values. there is an insert command that inserts a value to the vector
//TOMORROW: USE Gaussian_Blur_AVX_ver4_plus_less_load ROUTINE FOR LOOP REMINDER. LOAD OUTSIDE OF THE ARRAY AND THEN ZERO THE VALUES NEEDED.

		}
}

}//end of parallel


}




//for REMINDER_ITERATIONS >=29 only
int loop_reminder_high_reminder_values_less_div(unsigned char **frame1,unsigned char **filt,const unsigned int M, const unsigned int N,const unsigned int row, const unsigned int col, const unsigned int REMINDER_ITERATIONS,const unsigned int division_case,const __m256i c0,const __m256i c1,const __m256i c2,const __m256i c0_sh1,const __m256i c1_sh1,const __m256i c2_sh1,const __m256i c0_sh2,const __m256i c1_sh2,const __m256i c2_sh2, const __m256i f, const unsigned short int divisor, unsigned char **filter ){

__m256i r0,r1,r2,r3,r4,m0,m1,m2,m3,m4;
__m256i output_even,output_odd;


		//const __m256i f  = _mm256_set_epi16(52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759);
		//const __m256i mask  = _mm256_set_epi8(0,0,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255);
		//const __m256i mask2  = _mm256_set_epi8(0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0);
		const __m256i mask3  = _mm256_set_epi16(0,0,0,0,0,0,0,65535,0,0,0,0,0,0,0,0);
		//const __m256i mask4  = _mm256_set_epi8(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,255,0,0,0,0,0,0,0,0,0,0,0,0);
		//const __m256i mask5  = _mm256_set_epi8(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0);

		const __m256i output_mask      = _mm256_set_epi16(0,0,0,65535,0,0,65535,0,0,65535,0,0,65535,0,0,65535);
		const __m256i output_mask_sh1  = _mm256_set_epi16(0,0,65535,0,0,65535,0,0,65535,0,0,65535,0,0,65535,0);
		//const __m256i output_mask_sh2  = _mm256_set_epi16(0,0,0,    0,65535,0,0,65535,0,0,65535,0,0,65535,0,0);
		const __m256i mask_new      = _mm256_set_epi16(0,0,0,0,0,0,0,0,0,65535,0,0,0,0,0,0);
		const __m256i mask_new2      = _mm256_set_epi16(0,0,0,0,0,0,0,0,65535,0,0,0,0,0,0,0);



 __m256i reminder_mask1,reminder_mask2;

	reminder_mask1=_mm256_load_si256( (__m256i *) &reminder_msk1[REMINDER_ITERATIONS-1][0]);
	reminder_mask2=_mm256_load_si256( (__m256i *) &reminder_msk2[REMINDER_ITERATIONS-1][0]);




	 //1st col iteration
	//load the 5 rows
	r0=_mm256_loadu_si256( (__m256i *) &frame1[row-2][col-2]);
	r1=_mm256_loadu_si256( (__m256i *) &frame1[row-1][col-2]);
	r2=_mm256_loadu_si256( (__m256i *) &frame1[row][col-2]);
	r3=_mm256_loadu_si256( (__m256i *) &frame1[row+1][col-2]);
	r4=_mm256_loadu_si256( (__m256i *) &frame1[row+2][col-2]);

	/*
	 * The above load operations load outside of the array bounds; these elements are filled with zeros just after
	 * Furthermore, I add two extra zeros in the end to compute col=N-2 and col=N-1. The last value of col is N-1, not N
	 */

	//AND r0-r4 with reminder_mask
	r0=_mm256_and_si256(r0,reminder_mask1);
	r1=_mm256_and_si256(r1,reminder_mask1);
	r2=_mm256_and_si256(r2,reminder_mask1);
	r3=_mm256_and_si256(r3,reminder_mask1);
	r4=_mm256_and_si256(r4,reminder_mask1);

	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c0);
	m1=_mm256_maddubs_epi16(r1,c1);
	m2=_mm256_maddubs_epi16(r2,c2);
	m3=_mm256_maddubs_epi16(r3,c1);
	m4=_mm256_maddubs_epi16(r4,c0);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m2=_mm256_add_epi16(m2,m3);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m4);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m4=_mm256_and_si256(m0,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

	m2=_mm256_add_epi16(m2,m4);

	//m2 has 16 16bit values now. the results I need are in positions 0,3,6,9,12. keep only those, discard others
	output_even=_mm256_and_si256(m2,output_mask);

	//2nd col iteration
	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c0_sh1);
	m1=_mm256_maddubs_epi16(r1,c1_sh1);
	m2=_mm256_maddubs_epi16(r2,c2_sh1);
	m3=_mm256_maddubs_epi16(r3,c1_sh1);
	m4=_mm256_maddubs_epi16(r4,c0_sh1);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m2=_mm256_add_epi16(m2,m3);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m4);

	//hozizontal additions
	//hadd(0:5)   and store filt[row[col]
	//hadd(6:11)   and store filt[row[col+8]
	//hadd(12:17) and store filt[row[col+14]
	//hadd(18:23) and store filt[row[col+20]
	//hadd(24:30) and store filt[row[col+26]

	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m4=_mm256_and_si256(m0,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
	m2=_mm256_add_epi16(m2,m4);

	//m2 has 16 16bit values now. the results I need are in positions 0,3,6,9,12. keep only those, discard others
	output_odd = _mm256_and_si256(m2,output_mask);

             //3rd col iteration
	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c0_sh2);
	m1=_mm256_maddubs_epi16(r1,c1_sh2);
	m2=_mm256_maddubs_epi16(r2,c2_sh2);
	m3=_mm256_maddubs_epi16(r3,c1_sh2);
	m4=_mm256_maddubs_epi16(r4,c0_sh2);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m2=_mm256_add_epi16(m2,m3);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m4);

	//hozizontal additions
	//hadd(0:5)   and store filt[row[col]
	//hadd(6:11)   and store filt[row[col+8]
	//hadd(12:17) and store filt[row[col+14]
	//hadd(18:23) and store filt[row[col+20]
	//hadd(24:30) and store filt[row[col+26]

	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
	m4=_mm256_and_si256(m2,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

	m2=_mm256_add_epi16(m2,m4);

	//m2 has 16 16bit values now. the results I need are in positions 1,4,7,10,13. keep only those, discard others
	m2 = _mm256_and_si256(m2,output_mask_sh1);
	output_even = _mm256_add_epi16(output_even,m2);


	//4th col iteration
	//load the 5 rows
	r0=_mm256_loadu_si256( (__m256i *) &frame1[row-2][col+3-2]);
	r1=_mm256_loadu_si256( (__m256i *) &frame1[row-1][col+3-2]);
	r2=_mm256_loadu_si256( (__m256i *) &frame1[row][col+3-2]);
	r3=_mm256_loadu_si256( (__m256i *) &frame1[row+1][col+3-2]);
	r4=_mm256_loadu_si256( (__m256i *) &frame1[row+2][col+3-2]);

	//AND r0-r4 with reminder_mask
	r0=_mm256_and_si256(r0,reminder_mask2);
	r1=_mm256_and_si256(r1,reminder_mask2);
	r2=_mm256_and_si256(r2,reminder_mask2);
	r3=_mm256_and_si256(r3,reminder_mask2);
	r4=_mm256_and_si256(r4,reminder_mask2);

	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c0);
	m1=_mm256_maddubs_epi16(r1,c1);
	m2=_mm256_maddubs_epi16(r2,c2);
	m3=_mm256_maddubs_epi16(r3,c1);
	m4=_mm256_maddubs_epi16(r4,c0);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m2=_mm256_add_epi16(m2,m3);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m4);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m4=_mm256_and_si256(m0,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

	m2=_mm256_add_epi16(m2,m4);

	//m2 has 16 16bit values now. the results I need are in positions 1,4,7,10,13. keep only those, discard others
	m2 = _mm256_and_si256(m2,output_mask);
	m2 = _mm256_slli_si256(m2,2);
	output_odd = _mm256_add_epi16(output_odd,m2);



	//5th col iteration
	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c0_sh1);
	m1=_mm256_maddubs_epi16(r1,c1_sh1);
	m2=_mm256_maddubs_epi16(r2,c2_sh1);
	m3=_mm256_maddubs_epi16(r3,c1_sh1);
	m4=_mm256_maddubs_epi16(r4,c0_sh1);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m2=_mm256_add_epi16(m2,m3);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m4);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m4=_mm256_and_si256(m0,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

	m2=_mm256_add_epi16(m2,m4);

	//m2 has 16 16bit values now.
	m2 = _mm256_and_si256(m2,output_mask); //holds results in positions 0,3,6,9,12
	m1 = _mm256_slli_si256(m2,4); //put results in positions 2,5,8,11,14 , but 8 is not written
	m2=_mm256_and_si256(m2,mask_new);//extract only the 6th
	m2=_mm256_permute2f128_si256(m2,m2,1);
	m2=_mm256_srli_si256(m2,12);
	m2 = _mm256_add_epi16(m1,m2);
	output_even = _mm256_add_epi16(output_even,m2);



             //6th col iteration
	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c0_sh2);
	m1=_mm256_maddubs_epi16(r1,c1_sh2);
	m2=_mm256_maddubs_epi16(r2,c2_sh2);
	m3=_mm256_maddubs_epi16(r3,c1_sh2);
	m4=_mm256_maddubs_epi16(r4,c0_sh2);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m2=_mm256_add_epi16(m2,m3);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m4);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
	m4=_mm256_and_si256(m2,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);
	m2=_mm256_add_epi16(m2,m4);

	//m2 has 16 16bit values now.
	m2 = _mm256_and_si256(m2,output_mask_sh1);//holds results in positions 1,4,7,10,13
	m1 = _mm256_slli_si256(m2,2); //put results in positions 2,5,8,11,14 , but 8 is not written
	m2=_mm256_and_si256(m2,mask_new2);//extract only the 7th
	m2=_mm256_permute2f128_si256(m2,m2,1);
	m2=_mm256_srli_si256(m2,14);
	m2 = _mm256_add_epi16(m1,m2);
	output_odd = _mm256_add_epi16(output_odd,m2);


	//now division follows
	output_even=division(division_case,output_even,f);
	output_odd=division(division_case,output_odd,f);

	//shift odd 1 position and add to even
	output_odd = _mm256_slli_si256(output_odd,1);
	output_even = _mm256_add_epi8(output_even,output_odd);


	_mm_storeu_si128( (__m128i *) &filt[row][col],_mm256_extractf128_si256(output_even, 0)); //store low 128bit - 16pixels

	switch (REMINDER_ITERATIONS){
	case 29:
		filt[row][col+16] = (unsigned char) _mm256_extract_epi8(output_even,16);
		filt[row][col+17] = (unsigned char) _mm256_extract_epi8(output_even,17);
		filt[row][col+18] = (unsigned char) _mm256_extract_epi8(output_even,18);
		filt[row][col+19] = (unsigned char) _mm256_extract_epi8(output_even,19);
		filt[row][col+20] = (unsigned char) _mm256_extract_epi8(output_even,20);
		filt[row][col+21] = (unsigned char) _mm256_extract_epi8(output_even,21);
		filt[row][col+22] = (unsigned char) _mm256_extract_epi8(output_even,22);
		filt[row][col+23] = (unsigned char) _mm256_extract_epi8(output_even,23);
		filt[row][col+24] = (unsigned char) _mm256_extract_epi8(output_even,24);
		filt[row][col+25] = (unsigned char) _mm256_extract_epi8(output_even,25);
		filt[row][col+26] = (unsigned char) _mm256_extract_epi8(output_even,26);
		filt[row][col+27] = (unsigned char) _mm256_extract_epi8(output_even,27);
		filt[row][col+28] = (unsigned char) _mm256_extract_epi8(output_even,28);
		  break;
	case 30:
		filt[row][col+16] = (unsigned char) _mm256_extract_epi8(output_even,16);
		filt[row][col+17] = (unsigned char) _mm256_extract_epi8(output_even,17);
		filt[row][col+18] = (unsigned char) _mm256_extract_epi8(output_even,18);
		filt[row][col+19] = (unsigned char) _mm256_extract_epi8(output_even,19);
		filt[row][col+20] = (unsigned char) _mm256_extract_epi8(output_even,20);
		filt[row][col+21] = (unsigned char) _mm256_extract_epi8(output_even,21);
		filt[row][col+22] = (unsigned char) _mm256_extract_epi8(output_even,22);
		filt[row][col+23] = (unsigned char) _mm256_extract_epi8(output_even,23);
		filt[row][col+24] = (unsigned char) _mm256_extract_epi8(output_even,24);
		filt[row][col+25] = (unsigned char) _mm256_extract_epi8(output_even,25);
		filt[row][col+26] = (unsigned char) _mm256_extract_epi8(output_even,26);
		filt[row][col+27] = (unsigned char) _mm256_extract_epi8(output_even,27);
		filt[row][col+28] = (unsigned char) _mm256_extract_epi8(output_even,28);
		filt[row][col+29] = (unsigned char) _mm256_extract_epi8(output_even,29);
		  break;
	case 31:
		filt[row][col+16] = (unsigned char) _mm256_extract_epi8(output_even,16);
		filt[row][col+17] = (unsigned char) _mm256_extract_epi8(output_even,17);
		filt[row][col+18] = (unsigned char) _mm256_extract_epi8(output_even,18);
		filt[row][col+19] = (unsigned char) _mm256_extract_epi8(output_even,19);
		filt[row][col+20] = (unsigned char) _mm256_extract_epi8(output_even,20);
		filt[row][col+21] = (unsigned char) _mm256_extract_epi8(output_even,21);
		filt[row][col+22] = (unsigned char) _mm256_extract_epi8(output_even,22);
		filt[row][col+23] = (unsigned char) _mm256_extract_epi8(output_even,23);
		filt[row][col+24] = (unsigned char) _mm256_extract_epi8(output_even,24);
		filt[row][col+25] = (unsigned char) _mm256_extract_epi8(output_even,25);
		filt[row][col+26] = (unsigned char) _mm256_extract_epi8(output_even,26);
		filt[row][col+27] = (unsigned char) _mm256_extract_epi8(output_even,27);
		filt[row][col+28] = (unsigned char) _mm256_extract_epi8(output_even,28);
		filt[row][col+29] = (unsigned char) _mm256_extract_epi8(output_even,29);

		//the filt[row][M-1] pixel will be computed without vectorization
		int newPixel = 0;
		newPixel += frame1[row-2][M-1-2] * filter[0][0];
		newPixel += frame1[row-2][M-1-1] * filter[0][1];
		newPixel += frame1[row-2][M-1-0] * filter[0][2];

		newPixel += frame1[row-1][M-1-2] * filter[1][0];
		newPixel += frame1[row-1][M-1-1] * filter[1][1];
		newPixel += frame1[row-1][M-1-0] * filter[1][2];

		newPixel += frame1[row-0][M-1-2] * filter[2][0];
		newPixel += frame1[row-0][M-1-1] * filter[2][1];
		newPixel += frame1[row-0][M-1-0] * filter[2][2];

		newPixel += frame1[row+1][M-1-2] * filter[3][0];
		newPixel += frame1[row+1][M-1-1] * filter[3][1];
		newPixel += frame1[row+1][M-1-0] * filter[3][2];

		newPixel += frame1[row+2][M-1-2] * filter[4][0];
		newPixel += frame1[row+2][M-1-1] * filter[4][1];
		newPixel += frame1[row+2][M-1-0] * filter[4][2];

    	filt[row][M-1] = (unsigned char) (newPixel / divisor);

		  break;
	default:
		printf("\n something went wrong");
	}

return 0;

}




//for loop reminder<29 only
int loop_reminder_low_reminder_values_less_div(unsigned char **frame1,unsigned char **filt,const unsigned int M, const unsigned int N,const unsigned int row, const unsigned int col,const unsigned int REMINDER_ITERATIONS,const unsigned int division_case,const __m256i c0,const __m256i c1,const __m256i c2,const __m256i c0_sh1,const __m256i c1_sh1,const __m256i c2_sh1,const __m256i c0_sh2,const __m256i c1_sh2,const __m256i c2_sh2, const __m256i c0_sh3,const __m256i c1_sh3,const __m256i c2_sh3,const __m256i c0_sh4,const __m256i c1_sh4,const __m256i c2_sh4,const __m256i c0_sh5,const __m256i c1_sh5,const __m256i c2_sh5,const __m256i f){

register	__m256i r0,r1,r2,r3,r4,m0,m1,m2,m3,m4,output_even,output_odd;


	//const __m256i f  = _mm256_set_epi16(52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759);
const __m256i output_mask      = _mm256_set_epi16(0,0,0,65535,0,0,65535,0,0,65535,0,0,65535,0,0,65535);
const __m256i output_mask_sh1  = _mm256_set_epi16(0,0,65535,0,0,65535,0,0,65535,0,0,65535,0,0,65535,0);
const __m256i output_mask_sh2  = _mm256_set_epi16(0,0,0,    0,65535,0,0,65535,0,0,65535,0,0,65535,0,0);
const __m256i mask3  = _mm256_set_epi16(0,0,0,0,0,0,0,65535,0,0,0,0,0,0,0,0);

 __m256i reminder_mask1;

if (REMINDER_ITERATIONS == 0){
	return 0; //no loop reminder is needed
}

	reminder_mask1=_mm256_load_si256( (__m256i *) &reminder_msk1[REMINDER_ITERATIONS-1][0]);
	//reminder_mask2=_mm256_load_si256( (__m256i *) &reminder_msk2[REMINDER_ITERATIONS-1][0]);



	 //1st col iteration
	//load the 5 rows
	r0=_mm256_loadu_si256( (__m256i *) &frame1[row-2][col-2]);
	r1=_mm256_loadu_si256( (__m256i *) &frame1[row-1][col-2]);
	r2=_mm256_loadu_si256( (__m256i *) &frame1[row][col-2]);
	r3=_mm256_loadu_si256( (__m256i *) &frame1[row+1][col-2]);
	r4=_mm256_loadu_si256( (__m256i *) &frame1[row+2][col-2]);

	/*
	 * The above load operations load outside of the array bounds; these elements are filled with zeros just after
	 * Furthermore, I add two extra zeros in the end to compute col=N-2 and col=N-1. The last value of col is N-1, not N
	 */

	//AND r0-r4 with reminder_mask
	r0=_mm256_and_si256(r0,reminder_mask1);
	r1=_mm256_and_si256(r1,reminder_mask1);
	r2=_mm256_and_si256(r2,reminder_mask1);
	r3=_mm256_and_si256(r3,reminder_mask1);
	r4=_mm256_and_si256(r4,reminder_mask1);

	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c0);
	m1=_mm256_maddubs_epi16(r1,c1);
	m2=_mm256_maddubs_epi16(r2,c2);
	m3=_mm256_maddubs_epi16(r3,c1);
	m4=_mm256_maddubs_epi16(r4,c0);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m2=_mm256_add_epi16(m2,m3);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m4);

	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//after shifts the 15th element is lost as it cannot be propagated to the 16th position (AVX registers are managed as two seperate SSE registers)
	m4=_mm256_and_si256(m0,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
	m2=_mm256_add_epi16(m2,m4);

	//m2 has 16 16bit values now. the results I need are in positions 0,3,6,9,12. keep only those, discard others
	output_even=_mm256_and_si256(m2,output_mask);



    //2nd col iteration

	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c0_sh1);
	m1=_mm256_maddubs_epi16(r1,c1_sh1);
	m2=_mm256_maddubs_epi16(r2,c2_sh1);
	m3=_mm256_maddubs_epi16(r3,c1_sh1);
	m4=_mm256_maddubs_epi16(r4,c0_sh1);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m2=_mm256_add_epi16(m2,m3);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m4);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//after shifts the 15th element is lost as it cannot be propagated to the 16th position (AVX registers are managed as two seperate SSE registers)
	m4=_mm256_and_si256(m0,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
	m2=_mm256_add_epi16(m2,m4);

	//m2 has 16 16bit values now. the results I need are in positions 0,3,6,9,12. keep only those, discard others
	output_odd = _mm256_and_si256(m2,output_mask);




     //3rd col iteration

	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c0_sh2);
	m1=_mm256_maddubs_epi16(r1,c1_sh2);
	m2=_mm256_maddubs_epi16(r2,c2_sh2);
	m3=_mm256_maddubs_epi16(r3,c1_sh2);
	m4=_mm256_maddubs_epi16(r4,c0_sh2);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m2=_mm256_add_epi16(m2,m3);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m4);

	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m4=_mm256_and_si256(m2,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);
	m2=_mm256_add_epi16(m2,m4);

	//m2 has 16 16bit values now. the results I need are in positions 1,4,7,10,13. keep only those, discard others
	m2 = _mm256_and_si256(m2,output_mask_sh1);
	output_even = _mm256_add_epi16(output_even,m2);



	 //4th col iteration

	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c0_sh3);
	m1=_mm256_maddubs_epi16(r1,c1_sh3);
	m2=_mm256_maddubs_epi16(r2,c2_sh3);
	m3=_mm256_maddubs_epi16(r3,c1_sh3);
	m4=_mm256_maddubs_epi16(r4,c0_sh3);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m2=_mm256_add_epi16(m2,m3);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m4);


	m1=_mm256_srli_si256(m0,2);
	m4=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m4);


	m4=_mm256_and_si256(m4,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

	m2=_mm256_add_epi16(m2,m4);

	//m2 has 16 16bit values now. the results I need are in positions 1,4,7,10,13. keep only those, discard others
	m2 = _mm256_and_si256(m2,output_mask_sh1);
	output_odd = _mm256_add_epi16(output_odd,m2);


   //5th col iteration

	m0=_mm256_maddubs_epi16(r0,c0_sh4);
			m1=_mm256_maddubs_epi16(r1,c1_sh4);
			m2=_mm256_maddubs_epi16(r2,c2_sh4);
			m3=_mm256_maddubs_epi16(r3,c1_sh4);
			m4=_mm256_maddubs_epi16(r4,c0_sh4);

			//vertical add
			m0=_mm256_add_epi16(m0,m1);
			m2=_mm256_add_epi16(m2,m3);
			m0=_mm256_add_epi16(m0,m2);
			m0=_mm256_add_epi16(m0,m4);

			//hozizontal additions
			//hadd(4:9)
			//hadd(10:15)
			//hadd(16:21)
			//hadd(22:27)
			//result after division will be in 4,10,16,22

			m1=_mm256_srli_si256(m0,2);
			m2=_mm256_add_epi16(m1,m0);

			m1=_mm256_srli_si256(m0,4);
			m2=_mm256_add_epi16(m1,m2);


			//m2 has 16 16bit values now. the results I need are in positions 2,5,8,11. keep only those, discard others
			m2 = _mm256_and_si256(m2,output_mask_sh2);
			output_even = _mm256_add_epi16(output_even,m2);

    //6th col iteration

			//multiply with the mask
			m0=_mm256_maddubs_epi16(r0,c0_sh5);
			m1=_mm256_maddubs_epi16(r1,c1_sh5);
			m2=_mm256_maddubs_epi16(r2,c2_sh5);
			m3=_mm256_maddubs_epi16(r3,c1_sh5);
			m4=_mm256_maddubs_epi16(r4,c0_sh5);


	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m2=_mm256_add_epi16(m2,m3);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m4);

	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//m2 has 16 16bit values now. the results I need are in positions 2,5,8,11. keep only those, discard others
	m2 = _mm256_and_si256(m2,output_mask_sh2);
	output_odd = _mm256_add_epi16(output_odd,m2);

	//now division follows
	output_even=division(division_case,output_even,f);
	output_odd=division(division_case,output_odd,f);

	//shift odd 1 position and add to even
	output_odd = _mm256_slli_si256(output_odd,1);
	output_even = _mm256_add_epi8(output_even,output_odd);

 	switch (REMINDER_ITERATIONS){
	case 1:
		filt[row][col] = (unsigned char) _mm256_extract_epi8(output_even,0);
	  break;
	case 2:
		filt[row][col] = (unsigned char) _mm256_extract_epi8(output_even,0);
		filt[row][col+1] = (unsigned char) _mm256_extract_epi8(output_even,1);
		  break;
	case 3:
		filt[row][col] = (unsigned char) _mm256_extract_epi8(output_even,0);
		filt[row][col+1] = (unsigned char) _mm256_extract_epi8(output_even,1);
		filt[row][col+2] = (unsigned char) _mm256_extract_epi8(output_even,2);
		  break;
	case 4:
		filt[row][col] = (unsigned char) _mm256_extract_epi8(output_even,0);
		filt[row][col+1] = (unsigned char) _mm256_extract_epi8(output_even,1);
		filt[row][col+2] = (unsigned char) _mm256_extract_epi8(output_even,2);
		filt[row][col+3] = (unsigned char) _mm256_extract_epi8(output_even,3);
		  break;
	case 5:
		filt[row][col] = (unsigned char) _mm256_extract_epi8(output_even,0);
		filt[row][col+1] = (unsigned char) _mm256_extract_epi8(output_even,1);
		filt[row][col+2] = (unsigned char) _mm256_extract_epi8(output_even,2);
		filt[row][col+3] = (unsigned char) _mm256_extract_epi8(output_even,3);
		filt[row][col+4] = (unsigned char) _mm256_extract_epi8(output_even,4);
		  break;
	case 6:
		filt[row][col] = (unsigned char) _mm256_extract_epi8(output_even,0);
		filt[row][col+1] = (unsigned char) _mm256_extract_epi8(output_even,1);
		filt[row][col+2] = (unsigned char) _mm256_extract_epi8(output_even,2);
		filt[row][col+3] = (unsigned char) _mm256_extract_epi8(output_even,3);
		filt[row][col+4] = (unsigned char) _mm256_extract_epi8(output_even,4);
		filt[row][col+5] = (unsigned char) _mm256_extract_epi8(output_even,5);
		  break;
	case 7:
		filt[row][col] = (unsigned char) _mm256_extract_epi8(output_even,0);
		filt[row][col+1] = (unsigned char) _mm256_extract_epi8(output_even,1);
		filt[row][col+2] = (unsigned char) _mm256_extract_epi8(output_even,2);
		filt[row][col+3] = (unsigned char) _mm256_extract_epi8(output_even,3);
		filt[row][col+4] = (unsigned char) _mm256_extract_epi8(output_even,4);
		filt[row][col+5] = (unsigned char) _mm256_extract_epi8(output_even,5);
		filt[row][col+6] = (unsigned char) _mm256_extract_epi8(output_even,6);
		  break;
	case 8:
		filt[row][col] = (unsigned char) _mm256_extract_epi8(output_even,0);
		filt[row][col+1] = (unsigned char) _mm256_extract_epi8(output_even,1);
		filt[row][col+2] = (unsigned char) _mm256_extract_epi8(output_even,2);
		filt[row][col+3] = (unsigned char) _mm256_extract_epi8(output_even,3);
		filt[row][col+4] = (unsigned char) _mm256_extract_epi8(output_even,4);
		filt[row][col+5] = (unsigned char) _mm256_extract_epi8(output_even,5);
		filt[row][col+6] = (unsigned char) _mm256_extract_epi8(output_even,6);
		filt[row][col+7] = (unsigned char) _mm256_extract_epi8(output_even,7);
		  break;
	case 9:
		filt[row][col] = (unsigned char) _mm256_extract_epi8(output_even,0);
		filt[row][col+1] = (unsigned char) _mm256_extract_epi8(output_even,1);
		filt[row][col+2] = (unsigned char) _mm256_extract_epi8(output_even,2);
		filt[row][col+3] = (unsigned char) _mm256_extract_epi8(output_even,3);
		filt[row][col+4] = (unsigned char) _mm256_extract_epi8(output_even,4);
		filt[row][col+5] = (unsigned char) _mm256_extract_epi8(output_even,5);
		filt[row][col+6] = (unsigned char) _mm256_extract_epi8(output_even,6);
		filt[row][col+7] = (unsigned char) _mm256_extract_epi8(output_even,7);
		filt[row][col+8] = (unsigned char) _mm256_extract_epi8(output_even,8);
		  break;
	case 10:
		filt[row][col] = (unsigned char) _mm256_extract_epi8(output_even,0);
		filt[row][col+1] = (unsigned char) _mm256_extract_epi8(output_even,1);
		filt[row][col+2] = (unsigned char) _mm256_extract_epi8(output_even,2);
		filt[row][col+3] = (unsigned char) _mm256_extract_epi8(output_even,3);
		filt[row][col+4] = (unsigned char) _mm256_extract_epi8(output_even,4);
		filt[row][col+5] = (unsigned char) _mm256_extract_epi8(output_even,5);
		filt[row][col+6] = (unsigned char) _mm256_extract_epi8(output_even,6);
		filt[row][col+7] = (unsigned char) _mm256_extract_epi8(output_even,7);
		filt[row][col+8] = (unsigned char) _mm256_extract_epi8(output_even,8);
		filt[row][col+9] = (unsigned char) _mm256_extract_epi8(output_even,9);
		  break;
	case 11:
		filt[row][col] = (unsigned char) _mm256_extract_epi8(output_even,0);
		filt[row][col+1] = (unsigned char) _mm256_extract_epi8(output_even,1);
		filt[row][col+2] = (unsigned char) _mm256_extract_epi8(output_even,2);
		filt[row][col+3] = (unsigned char) _mm256_extract_epi8(output_even,3);
		filt[row][col+4] = (unsigned char) _mm256_extract_epi8(output_even,4);
		filt[row][col+5] = (unsigned char) _mm256_extract_epi8(output_even,5);
		filt[row][col+6] = (unsigned char) _mm256_extract_epi8(output_even,6);
		filt[row][col+7] = (unsigned char) _mm256_extract_epi8(output_even,7);
		filt[row][col+8] = (unsigned char) _mm256_extract_epi8(output_even,8);
		filt[row][col+9] = (unsigned char) _mm256_extract_epi8(output_even,9);
		filt[row][col+10] = (unsigned char) _mm256_extract_epi8(output_even,10);
		  break;
	case 12:
		filt[row][col] = (unsigned char) _mm256_extract_epi8(output_even,0);
		filt[row][col+1] = (unsigned char) _mm256_extract_epi8(output_even,1);
		filt[row][col+2] = (unsigned char) _mm256_extract_epi8(output_even,2);
		filt[row][col+3] = (unsigned char) _mm256_extract_epi8(output_even,3);
		filt[row][col+4] = (unsigned char) _mm256_extract_epi8(output_even,4);
		filt[row][col+5] = (unsigned char) _mm256_extract_epi8(output_even,5);
		filt[row][col+6] = (unsigned char) _mm256_extract_epi8(output_even,6);
		filt[row][col+7] = (unsigned char) _mm256_extract_epi8(output_even,7);
		filt[row][col+8] = (unsigned char) _mm256_extract_epi8(output_even,8);
		filt[row][col+9] = (unsigned char) _mm256_extract_epi8(output_even,9);
		filt[row][col+10] = (unsigned char) _mm256_extract_epi8(output_even,10);
		filt[row][col+11] = (unsigned char) _mm256_extract_epi8(output_even,11);
		  break;
	case 13:
		filt[row][col] = (unsigned char) _mm256_extract_epi8(output_even,0);
		filt[row][col+1] = (unsigned char) _mm256_extract_epi8(output_even,1);
		filt[row][col+2] = (unsigned char) _mm256_extract_epi8(output_even,2);
		filt[row][col+3] = (unsigned char) _mm256_extract_epi8(output_even,3);
		filt[row][col+4] = (unsigned char) _mm256_extract_epi8(output_even,4);
		filt[row][col+5] = (unsigned char) _mm256_extract_epi8(output_even,5);
		filt[row][col+6] = (unsigned char) _mm256_extract_epi8(output_even,6);
		filt[row][col+7] = (unsigned char) _mm256_extract_epi8(output_even,7);
		filt[row][col+8] = (unsigned char) _mm256_extract_epi8(output_even,8);
		filt[row][col+9] = (unsigned char) _mm256_extract_epi8(output_even,9);
		filt[row][col+10] = (unsigned char) _mm256_extract_epi8(output_even,10);
		filt[row][col+11] = (unsigned char) _mm256_extract_epi8(output_even,11);
		filt[row][col+12] = (unsigned char) _mm256_extract_epi8(output_even,12);
		  break;
	case 14:
		filt[row][col] = (unsigned char) _mm256_extract_epi8(output_even,0);
		filt[row][col+1] = (unsigned char) _mm256_extract_epi8(output_even,1);
		filt[row][col+2] = (unsigned char) _mm256_extract_epi8(output_even,2);
		filt[row][col+3] = (unsigned char) _mm256_extract_epi8(output_even,3);
		filt[row][col+4] = (unsigned char) _mm256_extract_epi8(output_even,4);
		filt[row][col+5] = (unsigned char) _mm256_extract_epi8(output_even,5);
		filt[row][col+6] = (unsigned char) _mm256_extract_epi8(output_even,6);
		filt[row][col+7] = (unsigned char) _mm256_extract_epi8(output_even,7);
		filt[row][col+8] = (unsigned char) _mm256_extract_epi8(output_even,8);
		filt[row][col+9] = (unsigned char) _mm256_extract_epi8(output_even,9);
		filt[row][col+10] = (unsigned char) _mm256_extract_epi8(output_even,10);
		filt[row][col+11] = (unsigned char) _mm256_extract_epi8(output_even,11);
		filt[row][col+12] = (unsigned char) _mm256_extract_epi8(output_even,12);
		filt[row][col+13] = (unsigned char) _mm256_extract_epi8(output_even,13);
		  break;
	case 15:
		filt[row][col] = (unsigned char) _mm256_extract_epi8(output_even,0);
		filt[row][col+1] = (unsigned char) _mm256_extract_epi8(output_even,1);
		filt[row][col+2] = (unsigned char) _mm256_extract_epi8(output_even,2);
		filt[row][col+3] = (unsigned char) _mm256_extract_epi8(output_even,3);
		filt[row][col+4] = (unsigned char) _mm256_extract_epi8(output_even,4);
		filt[row][col+5] = (unsigned char) _mm256_extract_epi8(output_even,5);
		filt[row][col+6] = (unsigned char) _mm256_extract_epi8(output_even,6);
		filt[row][col+7] = (unsigned char) _mm256_extract_epi8(output_even,7);
		filt[row][col+8] = (unsigned char) _mm256_extract_epi8(output_even,8);
		filt[row][col+9] = (unsigned char) _mm256_extract_epi8(output_even,9);
		filt[row][col+10] = (unsigned char) _mm256_extract_epi8(output_even,10);
		filt[row][col+11] = (unsigned char) _mm256_extract_epi8(output_even,11);
		filt[row][col+12] = (unsigned char) _mm256_extract_epi8(output_even,12);
		filt[row][col+13] = (unsigned char) _mm256_extract_epi8(output_even,13);
		filt[row][col+14] = (unsigned char) _mm256_extract_epi8(output_even,14);
		  break;
	case 16:
  	_mm_storeu_si128( (__m128i *) &filt[row][col],_mm256_extractf128_si256(output_even, 0)); //store low 128bit - 16pixels
		  break;
	case 17:
  	_mm_storeu_si128( (__m128i *) &filt[row][col],_mm256_extractf128_si256(output_even, 0)); //store low 128bit - 16pixels
	filt[row][col+16] = (unsigned char) _mm256_extract_epi8(output_even,16);
		  break;
	case 18:
  	_mm_storeu_si128( (__m128i *) &filt[row][col],_mm256_extractf128_si256(output_even, 0)); //store low 128bit - 16pixels
	filt[row][col+16] = (unsigned char) _mm256_extract_epi8(output_even,16);
	filt[row][col+17] = (unsigned char) _mm256_extract_epi8(output_even,17);
		  break;
	case 19:
  	_mm_storeu_si128( (__m128i *) &filt[row][col],_mm256_extractf128_si256(output_even, 0)); //store low 128bit - 16pixels
	filt[row][col+16] = (unsigned char) _mm256_extract_epi8(output_even,16);
	filt[row][col+17] = (unsigned char) _mm256_extract_epi8(output_even,17);
	filt[row][col+18] = (unsigned char) _mm256_extract_epi8(output_even,18);
		  break;
	case 20:
  	_mm_storeu_si128( (__m128i *) &filt[row][col],_mm256_extractf128_si256(output_even, 0)); //store low 128bit - 16pixels
	filt[row][col+16] = (unsigned char) _mm256_extract_epi8(output_even,16);
	filt[row][col+17] = (unsigned char) _mm256_extract_epi8(output_even,17);
	filt[row][col+18] = (unsigned char) _mm256_extract_epi8(output_even,18);
	filt[row][col+19] = (unsigned char) _mm256_extract_epi8(output_even,19);
		  break;
	case 21:
  	_mm_storeu_si128( (__m128i *) &filt[row][col],_mm256_extractf128_si256(output_even, 0)); //store low 128bit - 16pixels
	filt[row][col+16] = (unsigned char) _mm256_extract_epi8(output_even,16);
	filt[row][col+17] = (unsigned char) _mm256_extract_epi8(output_even,17);
	filt[row][col+18] = (unsigned char) _mm256_extract_epi8(output_even,18);
	filt[row][col+19] = (unsigned char) _mm256_extract_epi8(output_even,19);
	filt[row][col+20] = (unsigned char) _mm256_extract_epi8(output_even,20);
		  break;
	case 22:
  	_mm_storeu_si128( (__m128i *) &filt[row][col],_mm256_extractf128_si256(output_even, 0)); //store low 128bit - 16pixels
	filt[row][col+16] = (unsigned char) _mm256_extract_epi8(output_even,16);
	filt[row][col+17] = (unsigned char) _mm256_extract_epi8(output_even,17);
	filt[row][col+18] = (unsigned char) _mm256_extract_epi8(output_even,18);
	filt[row][col+19] = (unsigned char) _mm256_extract_epi8(output_even,19);
	filt[row][col+20] = (unsigned char) _mm256_extract_epi8(output_even,20);
	filt[row][col+21] = (unsigned char) _mm256_extract_epi8(output_even,21);
		break;
	case 23:
  	_mm_storeu_si128( (__m128i *) &filt[row][col],_mm256_extractf128_si256(output_even, 0)); //store low 128bit - 16pixels
	filt[row][col+16] = (unsigned char) _mm256_extract_epi8(output_even,16);
	filt[row][col+17] = (unsigned char) _mm256_extract_epi8(output_even,17);
	filt[row][col+18] = (unsigned char) _mm256_extract_epi8(output_even,18);
	filt[row][col+19] = (unsigned char) _mm256_extract_epi8(output_even,19);
	filt[row][col+20] = (unsigned char) _mm256_extract_epi8(output_even,20);
	filt[row][col+21] = (unsigned char) _mm256_extract_epi8(output_even,21);
	filt[row][col+22] = (unsigned char) _mm256_extract_epi8(output_even,22);
		  break;
	case 24:
  	_mm_storeu_si128( (__m128i *) &filt[row][col],_mm256_extractf128_si256(output_even, 0)); //store low 128bit - 16pixels
	filt[row][col+16] = (unsigned char) _mm256_extract_epi8(output_even,16);
	filt[row][col+17] = (unsigned char) _mm256_extract_epi8(output_even,17);
	filt[row][col+18] = (unsigned char) _mm256_extract_epi8(output_even,18);
	filt[row][col+19] = (unsigned char) _mm256_extract_epi8(output_even,19);
	filt[row][col+20] = (unsigned char) _mm256_extract_epi8(output_even,20);
	filt[row][col+21] = (unsigned char) _mm256_extract_epi8(output_even,21);
	filt[row][col+22] = (unsigned char) _mm256_extract_epi8(output_even,22);
	filt[row][col+23] = (unsigned char) _mm256_extract_epi8(output_even,23);
		  break;
	case 25:
  	_mm_storeu_si128( (__m128i *) &filt[row][col],_mm256_extractf128_si256(output_even, 0)); //store low 128bit - 16pixels
	filt[row][col+16] = (unsigned char) _mm256_extract_epi8(output_even,16);
	filt[row][col+17] = (unsigned char) _mm256_extract_epi8(output_even,17);
	filt[row][col+18] = (unsigned char) _mm256_extract_epi8(output_even,18);
	filt[row][col+19] = (unsigned char) _mm256_extract_epi8(output_even,19);
	filt[row][col+20] = (unsigned char) _mm256_extract_epi8(output_even,20);
	filt[row][col+21] = (unsigned char) _mm256_extract_epi8(output_even,21);
	filt[row][col+22] = (unsigned char) _mm256_extract_epi8(output_even,22);
	filt[row][col+23] = (unsigned char) _mm256_extract_epi8(output_even,23);
	filt[row][col+24] = (unsigned char) _mm256_extract_epi8(output_even,24);
		  break;
	case 26:
  	_mm_storeu_si128( (__m128i *) &filt[row][col],_mm256_extractf128_si256(output_even, 0)); //store low 128bit - 16pixels
	filt[row][col+16] = (unsigned char) _mm256_extract_epi8(output_even,16);
	filt[row][col+17] = (unsigned char) _mm256_extract_epi8(output_even,17);
	filt[row][col+18] = (unsigned char) _mm256_extract_epi8(output_even,18);
	filt[row][col+19] = (unsigned char) _mm256_extract_epi8(output_even,19);
	filt[row][col+20] = (unsigned char) _mm256_extract_epi8(output_even,20);
	filt[row][col+21] = (unsigned char) _mm256_extract_epi8(output_even,21);
	filt[row][col+22] = (unsigned char) _mm256_extract_epi8(output_even,22);
	filt[row][col+23] = (unsigned char) _mm256_extract_epi8(output_even,23);
	filt[row][col+24] = (unsigned char) _mm256_extract_epi8(output_even,24);
	filt[row][col+25] = (unsigned char) _mm256_extract_epi8(output_even,25);
		  break;
	case 27:
  	_mm_storeu_si128( (__m128i *) &filt[row][col],_mm256_extractf128_si256(output_even, 0)); //store low 128bit - 16pixels
	filt[row][col+16] = (unsigned char) _mm256_extract_epi8(output_even,16);
	filt[row][col+17] = (unsigned char) _mm256_extract_epi8(output_even,17);
	filt[row][col+18] = (unsigned char) _mm256_extract_epi8(output_even,18);
	filt[row][col+19] = (unsigned char) _mm256_extract_epi8(output_even,19);
	filt[row][col+20] = (unsigned char) _mm256_extract_epi8(output_even,20);
	filt[row][col+21] = (unsigned char) _mm256_extract_epi8(output_even,21);
	filt[row][col+22] = (unsigned char) _mm256_extract_epi8(output_even,22);
	filt[row][col+23] = (unsigned char) _mm256_extract_epi8(output_even,23);
	filt[row][col+24] = (unsigned char) _mm256_extract_epi8(output_even,24);
	filt[row][col+25] = (unsigned char) _mm256_extract_epi8(output_even,25);
	filt[row][col+26] = (unsigned char) _mm256_extract_epi8(output_even,26);
		  break;
	case 28:
  	_mm_storeu_si128( (__m128i *) &filt[row][col],_mm256_extractf128_si256(output_even, 0)); //store low 128bit - 16pixels
	filt[row][col+16] = (unsigned char) _mm256_extract_epi8(output_even,16);
	filt[row][col+17] = (unsigned char) _mm256_extract_epi8(output_even,17);
	filt[row][col+18] = (unsigned char) _mm256_extract_epi8(output_even,18);
	filt[row][col+19] = (unsigned char) _mm256_extract_epi8(output_even,19);
	filt[row][col+20] = (unsigned char) _mm256_extract_epi8(output_even,20);
	filt[row][col+21] = (unsigned char) _mm256_extract_epi8(output_even,21);
	filt[row][col+22] = (unsigned char) _mm256_extract_epi8(output_even,22);
	filt[row][col+23] = (unsigned char) _mm256_extract_epi8(output_even,23);
	filt[row][col+24] = (unsigned char) _mm256_extract_epi8(output_even,24);
	filt[row][col+25] = (unsigned char) _mm256_extract_epi8(output_even,25);
	filt[row][col+26] = (unsigned char) _mm256_extract_epi8(output_even,26);
	filt[row][col+27] = (unsigned char) _mm256_extract_epi8(output_even,27);
		  break;
	default:
		printf("\nsomething went wrong");
		return -1;
 	}

return 0;

}



//for row=0,1,2 only
int loop_reminder_first_less_div(unsigned char **frame1,unsigned char **filt,const unsigned int M, const unsigned int N, const unsigned int col, const unsigned int REMINDER_ITERATIONS,const unsigned int division_case,const __m256i c0,const __m256i c1,const __m256i c2,const __m256i c0_sh1,const __m256i c1_sh1,const __m256i c2_sh1,const __m256i c0_sh2,const __m256i c1_sh2,const __m256i c2_sh2, const __m256i f, const unsigned short int divisor, unsigned char **filter ){

__m256i r0,r1,r2,r3,r4,m0,m1,m2,m3,m4;
__m256i output_even,output_odd;
__m256i output_row0_even,output_row1_even,output_row0_odd,output_row1_odd;

		//const __m256i f  = _mm256_set_epi16(52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759);
		//const __m256i mask  = _mm256_set_epi8(0,0,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255);
		//const __m256i mask2  = _mm256_set_epi8(0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0);
		const __m256i mask3  = _mm256_set_epi16(0,0,0,0,0,0,0,65535,0,0,0,0,0,0,0,0);
		//const __m256i mask4  = _mm256_set_epi8(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,255,0,0,0,0,0,0,0,0,0,0,0,0);
		//const __m256i mask5  = _mm256_set_epi8(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0);

		const __m256i output_mask      = _mm256_set_epi16(0,0,0,65535,0,0,65535,0,0,65535,0,0,65535,0,0,65535);
		const __m256i output_mask_sh1  = _mm256_set_epi16(0,0,65535,0,0,65535,0,0,65535,0,0,65535,0,0,65535,0);
		//const __m256i output_mask_sh2  = _mm256_set_epi16(0,0,0,    0,65535,0,0,65535,0,0,65535,0,0,65535,0,0);
		const __m256i mask_new      = _mm256_set_epi16(0,0,0,0,0,0,0,0,0,65535,0,0,0,0,0,0);
		const __m256i mask_new2      = _mm256_set_epi16(0,0,0,0,0,0,0,0,65535,0,0,0,0,0,0,0);



 __m256i reminder_mask1,reminder_mask2;

	reminder_mask1=_mm256_load_si256( (__m256i *) &reminder_msk1[REMINDER_ITERATIONS-1][0]);
	reminder_mask2=_mm256_load_si256( (__m256i *) &reminder_msk2[REMINDER_ITERATIONS-1][0]);


	 //1st col iteration
	//load the 5 rows
	r0=_mm256_loadu_si256( (__m256i *) &frame1[0][col-2]);
	r1=_mm256_loadu_si256( (__m256i *) &frame1[1][col-2]);
	r2=_mm256_loadu_si256( (__m256i *) &frame1[2][col-2]);
	r3=_mm256_loadu_si256( (__m256i *) &frame1[3][col-2]);
	r4=_mm256_loadu_si256( (__m256i *) &frame1[4][col-2]);

	/*
	 * The above load operations load outside of the array bounds; these elements are filled with zeros just after
	 * Furthermore, I add two extra zeros in the end to compute col=N-2 and col=N-1. The last value of col is N-1, not N
	 */

	//AND r0-r4 with reminder_mask
	r0=_mm256_and_si256(r0,reminder_mask1);
	r1=_mm256_and_si256(r1,reminder_mask1);
	r2=_mm256_and_si256(r2,reminder_mask1);
	r3=_mm256_and_si256(r3,reminder_mask1);
	r4=_mm256_and_si256(r4,reminder_mask1);

	//row=2
	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c0);
	m1=_mm256_maddubs_epi16(r1,c1);
	m2=_mm256_maddubs_epi16(r2,c2);
	m3=_mm256_maddubs_epi16(r3,c1);
	m4=_mm256_maddubs_epi16(r4,c0);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m2=_mm256_add_epi16(m2,m3);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m4);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m4=_mm256_and_si256(m0,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

	m2=_mm256_add_epi16(m2,m4);

	//m2 has 16 16bit values now. the results I need are in positions 0,3,6,9,12. keep only those, discard others
	output_even=_mm256_and_si256(m2,output_mask);

	//row=0
	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c2);
	m1=_mm256_maddubs_epi16(r1,c1);
	m2=_mm256_maddubs_epi16(r2,c0);


	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m0=_mm256_add_epi16(m0,m2);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m4=_mm256_and_si256(m0,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

	m2=_mm256_add_epi16(m2,m4);

	//m2 has 16 16bit values now. the results I need are in positions 0,3,6,9,12. keep only those, discard others
	output_row0_even=_mm256_and_si256(m2,output_mask);


	//row=1
	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c1);
	m1=_mm256_maddubs_epi16(r1,c2);
	m2=_mm256_maddubs_epi16(r2,c1);
	m3=_mm256_maddubs_epi16(r3,c0);


	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m3);

	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m4=_mm256_and_si256(m0,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

	m2=_mm256_add_epi16(m2,m4);

	//m2 has 16 16bit values now. the results I need are in positions 0,3,6,9,12. keep only those, discard others
	output_row1_even=_mm256_and_si256(m2,output_mask);

	//2nd col iteration

	//row=2
	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c0_sh1);
	m1=_mm256_maddubs_epi16(r1,c1_sh1);
	m2=_mm256_maddubs_epi16(r2,c2_sh1);
	m3=_mm256_maddubs_epi16(r3,c1_sh1);
	m4=_mm256_maddubs_epi16(r4,c0_sh1);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m2=_mm256_add_epi16(m2,m3);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m4);

	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m4=_mm256_and_si256(m0,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
	m2=_mm256_add_epi16(m2,m4);

	//m2 has 16 16bit values now. the results I need are in positions 0,3,6,9,12. keep only those, discard others
	output_odd = _mm256_and_si256(m2,output_mask);

	//row=0
	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c2_sh1);
	m1=_mm256_maddubs_epi16(r1,c1_sh1);
	m2=_mm256_maddubs_epi16(r2,c0_sh1);


	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m0=_mm256_add_epi16(m0,m2);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m4=_mm256_and_si256(m0,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
	m2=_mm256_add_epi16(m2,m4);

	//m2 has 16 16bit values now. the results I need are in positions 0,3,6,9,12. keep only those, discard others
	output_row0_odd = _mm256_and_si256(m2,output_mask);

	//row=1
	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c1_sh1);
	m1=_mm256_maddubs_epi16(r1,c2_sh1);
	m2=_mm256_maddubs_epi16(r2,c1_sh1);
	m3=_mm256_maddubs_epi16(r3,c0_sh1);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m3);

	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m4=_mm256_and_si256(m0,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
	m2=_mm256_add_epi16(m2,m4);

	//m2 has 16 16bit values now. the results I need are in positions 0,3,6,9,12. keep only those, discard others
	output_row1_odd = _mm256_and_si256(m2,output_mask);

             //3rd col iteration

	//row=2
	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c0_sh2);
	m1=_mm256_maddubs_epi16(r1,c1_sh2);
	m2=_mm256_maddubs_epi16(r2,c2_sh2);
	m3=_mm256_maddubs_epi16(r3,c1_sh2);
	m4=_mm256_maddubs_epi16(r4,c0_sh2);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m2=_mm256_add_epi16(m2,m3);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m4);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
	m4=_mm256_and_si256(m2,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

	m2=_mm256_add_epi16(m2,m4);

	//m2 has 16 16bit values now. the results I need are in positions 1,4,7,10,13. keep only those, discard others
	m2 = _mm256_and_si256(m2,output_mask_sh1);
	output_even = _mm256_add_epi16(output_even,m2);

	//row=0
	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c2_sh2);
	m1=_mm256_maddubs_epi16(r1,c1_sh2);
	m2=_mm256_maddubs_epi16(r2,c0_sh2);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m0=_mm256_add_epi16(m0,m2);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
	m4=_mm256_and_si256(m2,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

	m2=_mm256_add_epi16(m2,m4);

	//m2 has 16 16bit values now. the results I need are in positions 1,4,7,10,13. keep only those, discard others
	m2 = _mm256_and_si256(m2,output_mask_sh1);
	output_row0_even = _mm256_add_epi16(output_row0_even,m2);

	//row=1
	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c1_sh2);
	m1=_mm256_maddubs_epi16(r1,c2_sh2);
	m2=_mm256_maddubs_epi16(r2,c1_sh2);
	m3=_mm256_maddubs_epi16(r3,c0_sh2);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m3);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
	m4=_mm256_and_si256(m2,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

	m2=_mm256_add_epi16(m2,m4);

	//m2 has 16 16bit values now. the results I need are in positions 1,4,7,10,13. keep only those, discard others
	m2 = _mm256_and_si256(m2,output_mask_sh1);
	output_row1_even = _mm256_add_epi16(output_row1_even,m2);

	//4th col iteration
	//load the 5 rows
	r0=_mm256_loadu_si256( (__m256i *) &frame1[0][col+3-2]);
	r1=_mm256_loadu_si256( (__m256i *) &frame1[1][col+3-2]);
	r2=_mm256_loadu_si256( (__m256i *) &frame1[2][col+3-2]);
	r3=_mm256_loadu_si256( (__m256i *) &frame1[3][col+3-2]);
	r4=_mm256_loadu_si256( (__m256i *) &frame1[4][col+3-2]);

	//AND r0-r4 with reminder_mask
	r0=_mm256_and_si256(r0,reminder_mask2);
	r1=_mm256_and_si256(r1,reminder_mask2);
	r2=_mm256_and_si256(r2,reminder_mask2);
	r3=_mm256_and_si256(r3,reminder_mask2);
	r4=_mm256_and_si256(r4,reminder_mask2);

	//row=2
	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c0);
	m1=_mm256_maddubs_epi16(r1,c1);
	m2=_mm256_maddubs_epi16(r2,c2);
	m3=_mm256_maddubs_epi16(r3,c1);
	m4=_mm256_maddubs_epi16(r4,c0);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m2=_mm256_add_epi16(m2,m3);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m4);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m4=_mm256_and_si256(m0,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

	m2=_mm256_add_epi16(m2,m4);

	//m2 has 16 16bit values now. the results I need are in positions 1,4,7,10,13. keep only those, discard others
	m2 = _mm256_and_si256(m2,output_mask);
	m2 = _mm256_slli_si256(m2,2);
	output_odd = _mm256_add_epi16(output_odd,m2);

	//row=0
	//multiply with the mask
	m0=_mm256_maddubs_epi16(r2,c0);
	m1=_mm256_maddubs_epi16(r1,c1);
	m2=_mm256_maddubs_epi16(r0,c2);


	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m0=_mm256_add_epi16(m2,m0);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m4=_mm256_and_si256(m0,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

	m2=_mm256_add_epi16(m2,m4);

	//m2 has 16 16bit values now. the results I need are in positions 1,4,7,10,13. keep only those, discard others
	m2 = _mm256_and_si256(m2,output_mask);
	m2 = _mm256_slli_si256(m2,2);
	output_row0_odd = _mm256_add_epi16(output_row0_odd,m2);

	//row=1
	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c1);
	m1=_mm256_maddubs_epi16(r1,c2);
	m2=_mm256_maddubs_epi16(r2,c1);
	m3=_mm256_maddubs_epi16(r3,c0);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m0=_mm256_add_epi16(m2,m0);
	m0=_mm256_add_epi16(m0,m3);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m4=_mm256_and_si256(m0,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

	m2=_mm256_add_epi16(m2,m4);

	//m2 has 16 16bit values now. the results I need are in positions 1,4,7,10,13. keep only those, discard others
	m2 = _mm256_and_si256(m2,output_mask);
	m2 = _mm256_slli_si256(m2,2);
	output_row1_odd = _mm256_add_epi16(output_row1_odd,m2);

	//5th col iteration

	//row=2
	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c0_sh1);
	m1=_mm256_maddubs_epi16(r1,c1_sh1);
	m2=_mm256_maddubs_epi16(r2,c2_sh1);
	m3=_mm256_maddubs_epi16(r3,c1_sh1);
	m4=_mm256_maddubs_epi16(r4,c0_sh1);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m2=_mm256_add_epi16(m2,m3);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m4);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m4=_mm256_and_si256(m0,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

	m2=_mm256_add_epi16(m2,m4);

	//m2 has 16 16bit values now.
	m2 = _mm256_and_si256(m2,output_mask); //holds results in positions 0,3,6,9,12
	m1 = _mm256_slli_si256(m2,4); //put results in positions 2,5,8,11,14 , but 8 is not written
	m2=_mm256_and_si256(m2,mask_new);//extract only the 6th
	m2=_mm256_permute2f128_si256(m2,m2,1);
	m2=_mm256_srli_si256(m2,12);
	m2 = _mm256_add_epi16(m1,m2);
	output_even = _mm256_add_epi16(output_even,m2);

	//row=0
	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c2_sh1);
	m1=_mm256_maddubs_epi16(r1,c1_sh1);
	m2=_mm256_maddubs_epi16(r2,c0_sh1);


	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m0=_mm256_add_epi16(m2,m0);



	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m4=_mm256_and_si256(m0,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

	m2=_mm256_add_epi16(m2,m4);

	//m2 has 16 16bit values now.
	m2 = _mm256_and_si256(m2,output_mask); //holds results in positions 0,3,6,9,12
	m1 = _mm256_slli_si256(m2,4); //put results in positions 2,5,8,11,14 , but 8 is not written
	m2=_mm256_and_si256(m2,mask_new);//extract only the 6th
	m2=_mm256_permute2f128_si256(m2,m2,1);
	m2=_mm256_srli_si256(m2,12);
	m2 = _mm256_add_epi16(m1,m2);
	output_row0_even = _mm256_add_epi16(output_row0_even,m2);

	//row=1
	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c1_sh1);
	m1=_mm256_maddubs_epi16(r1,c2_sh1);
	m2=_mm256_maddubs_epi16(r2,c1_sh1);
	m3=_mm256_maddubs_epi16(r3,c0_sh1);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m0=_mm256_add_epi16(m2,m0);
	m0=_mm256_add_epi16(m0,m3);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m4=_mm256_and_si256(m0,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

	m2=_mm256_add_epi16(m2,m4);

	//m2 has 16 16bit values now.
	m2 = _mm256_and_si256(m2,output_mask); //holds results in positions 0,3,6,9,12
	m1 = _mm256_slli_si256(m2,4); //put results in positions 2,5,8,11,14 , but 8 is not written
	m2=_mm256_and_si256(m2,mask_new);//extract only the 6th
	m2=_mm256_permute2f128_si256(m2,m2,1);
	m2=_mm256_srli_si256(m2,12);
	m2 = _mm256_add_epi16(m1,m2);
	output_row1_even = _mm256_add_epi16(output_row1_even,m2);

             //6th col iteration
	//row=2
	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c0_sh2);
	m1=_mm256_maddubs_epi16(r1,c1_sh2);
	m2=_mm256_maddubs_epi16(r2,c2_sh2);
	m3=_mm256_maddubs_epi16(r3,c1_sh2);
	m4=_mm256_maddubs_epi16(r4,c0_sh2);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m2=_mm256_add_epi16(m2,m3);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m4);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
	m4=_mm256_and_si256(m2,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);
	m2=_mm256_add_epi16(m2,m4);

	//m2 has 16 16bit values now.
	m2 = _mm256_and_si256(m2,output_mask_sh1);//holds results in positions 1,4,7,10,13
	m1 = _mm256_slli_si256(m2,2); //put results in positions 2,5,8,11,14 , but 8 is not written
	m2=_mm256_and_si256(m2,mask_new2);//extract only the 7th
	m2=_mm256_permute2f128_si256(m2,m2,1);
	m2=_mm256_srli_si256(m2,14);
	m2 = _mm256_add_epi16(m1,m2);
	output_odd = _mm256_add_epi16(output_odd,m2);


	//now division follows
	output_even=division(division_case,output_even,f);
	output_odd=division(division_case,output_odd,f);

	//shift odd 1 position and add to even
	output_odd = _mm256_slli_si256(output_odd,1);
	output_even = _mm256_add_epi8(output_even,output_odd);

	//row=0
	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c2_sh2);
	m1=_mm256_maddubs_epi16(r1,c1_sh2);
	m2=_mm256_maddubs_epi16(r2,c0_sh2);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m0=_mm256_add_epi16(m2,m0);



	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
	m4=_mm256_and_si256(m2,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);
	m2=_mm256_add_epi16(m2,m4);

	//m2 has 16 16bit values now.
	m2 = _mm256_and_si256(m2,output_mask_sh1);//holds results in positions 1,4,7,10,13
	m1 = _mm256_slli_si256(m2,2); //put results in positions 2,5,8,11,14 , but 8 is not written
	m2=_mm256_and_si256(m2,mask_new2);//extract only the 7th
	m2=_mm256_permute2f128_si256(m2,m2,1);
	m2=_mm256_srli_si256(m2,14);
	m2 = _mm256_add_epi16(m1,m2);
	output_row0_odd = _mm256_add_epi16(output_row0_odd,m2);


	//now division follows
	output_row0_even=division(division_case,output_row0_even,f);
	output_row0_odd=division(division_case,output_row0_odd,f);

	//shift odd 1 position and add to even
	output_row0_odd = _mm256_slli_si256(output_row0_odd,1);
	output_row0_even = _mm256_add_epi8(output_row0_even,output_row0_odd);

	//row=1
	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c1_sh2);
	m1=_mm256_maddubs_epi16(r1,c2_sh2);
	m2=_mm256_maddubs_epi16(r2,c1_sh2);
	m3=_mm256_maddubs_epi16(r3,c0_sh2);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m0=_mm256_add_epi16(m2,m0);
	m0=_mm256_add_epi16(m0,m3);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
	m4=_mm256_and_si256(m2,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);
	m2=_mm256_add_epi16(m2,m4);

	//m2 has 16 16bit values now.
	m2 = _mm256_and_si256(m2,output_mask_sh1);//holds results in positions 1,4,7,10,13
	m1 = _mm256_slli_si256(m2,2); //put results in positions 2,5,8,11,14 , but 8 is not written
	m2=_mm256_and_si256(m2,mask_new2);//extract only the 7th
	m2=_mm256_permute2f128_si256(m2,m2,1);
	m2=_mm256_srli_si256(m2,14);
	m2 = _mm256_add_epi16(m1,m2);
	output_row1_odd = _mm256_add_epi16(output_row1_odd,m2);


	//now division follows
	output_row1_even=division(division_case,output_row1_even,f);
	output_row1_odd=division(division_case,output_row1_odd,f);

	//shift odd 1 position and add to even
	output_row1_odd = _mm256_slli_si256(output_row1_odd,1);
	output_row1_even = _mm256_add_epi8(output_row1_even,output_row1_odd);




	switch (REMINDER_ITERATIONS){
	case 1:
		filt[2][col] = (unsigned char) _mm256_extract_epi8(output_even,0);
		filt[0][col] = (unsigned char) _mm256_extract_epi8(output_row0_even,0);
		filt[1][col] = (unsigned char) _mm256_extract_epi8(output_row1_even,0);
		 break;
	case 2:
		filt[2][col] = (unsigned char) _mm256_extract_epi8(output_even,0);
		filt[2][col+1] = (unsigned char) _mm256_extract_epi8(output_even,1);

		filt[0][col] = (unsigned char) _mm256_extract_epi8(output_row0_even,0);
		filt[0][col+1] = (unsigned char) _mm256_extract_epi8(output_row0_even,1);

		filt[1][col] = (unsigned char) _mm256_extract_epi8(output_row1_even,0);
		filt[1][col+1] = (unsigned char) _mm256_extract_epi8(output_row1_even,1);
		 break;
	case 3:
		filt[2][col] = (unsigned char) _mm256_extract_epi8(output_even,0);
		filt[2][col+1] = (unsigned char) _mm256_extract_epi8(output_even,1);
		filt[2][col+2] = (unsigned char) _mm256_extract_epi8(output_even,2);

		filt[0][col] = (unsigned char) _mm256_extract_epi8(output_row0_even,0);
		filt[0][col+1] = (unsigned char) _mm256_extract_epi8(output_row0_even,1);
		filt[0][col+2] = (unsigned char) _mm256_extract_epi8(output_row0_even,2);

		filt[1][col] = (unsigned char) _mm256_extract_epi8(output_row1_even,0);
		filt[1][col+1] = (unsigned char) _mm256_extract_epi8(output_row1_even,1);
		filt[1][col+2] = (unsigned char) _mm256_extract_epi8(output_row1_even,2);
		  break;
	case 4:
		filt[2][col] = (unsigned char) _mm256_extract_epi8(output_even,0);
		filt[2][col+1] = (unsigned char) _mm256_extract_epi8(output_even,1);
		filt[2][col+2] = (unsigned char) _mm256_extract_epi8(output_even,2);
		filt[2][col+3] = (unsigned char) _mm256_extract_epi8(output_even,3);

		filt[0][col] = (unsigned char) _mm256_extract_epi8(output_row0_even,0);
		filt[0][col+1] = (unsigned char) _mm256_extract_epi8(output_row0_even,1);
		filt[0][col+2] = (unsigned char) _mm256_extract_epi8(output_row0_even,2);
		filt[0][col+3] = (unsigned char) _mm256_extract_epi8(output_row0_even,3);

		filt[1][col] = (unsigned char) _mm256_extract_epi8(output_row1_even,0);
		filt[1][col+1] = (unsigned char) _mm256_extract_epi8(output_row1_even,1);
		filt[1][col+2] = (unsigned char) _mm256_extract_epi8(output_row1_even,2);
		filt[1][col+3] = (unsigned char) _mm256_extract_epi8(output_row1_even,3);
		  break;
	case 5:
		filt[2][col] = (unsigned char) _mm256_extract_epi8(output_even,0);
		filt[2][col+1] = (unsigned char) _mm256_extract_epi8(output_even,1);
		filt[2][col+2] = (unsigned char) _mm256_extract_epi8(output_even,2);
		filt[2][col+3] = (unsigned char) _mm256_extract_epi8(output_even,3);
		filt[2][col+4] = (unsigned char) _mm256_extract_epi8(output_even,4);

		filt[0][col] = (unsigned char) _mm256_extract_epi8(output_row0_even,0);
		filt[0][col+1] = (unsigned char) _mm256_extract_epi8(output_row0_even,1);
		filt[0][col+2] = (unsigned char) _mm256_extract_epi8(output_row0_even,2);
		filt[0][col+3] = (unsigned char) _mm256_extract_epi8(output_row0_even,3);
		filt[0][col+4] = (unsigned char) _mm256_extract_epi8(output_row0_even,4);

		filt[1][col] = (unsigned char) _mm256_extract_epi8(output_row1_even,0);
		filt[1][col+1] = (unsigned char) _mm256_extract_epi8(output_row1_even,1);
		filt[1][col+2] = (unsigned char) _mm256_extract_epi8(output_row1_even,2);
		filt[1][col+3] = (unsigned char) _mm256_extract_epi8(output_row1_even,3);
		filt[1][col+4] = (unsigned char) _mm256_extract_epi8(output_row1_even,4);
		  break;
	case 6:
		filt[2][col] = (unsigned char) _mm256_extract_epi8(output_even,0);
		filt[2][col+1] = (unsigned char) _mm256_extract_epi8(output_even,1);
		filt[2][col+2] = (unsigned char) _mm256_extract_epi8(output_even,2);
		filt[2][col+3] = (unsigned char) _mm256_extract_epi8(output_even,3);
		filt[2][col+4] = (unsigned char) _mm256_extract_epi8(output_even,4);
		filt[2][col+5] = (unsigned char) _mm256_extract_epi8(output_even,5);

		filt[0][col] = (unsigned char) _mm256_extract_epi8(output_row0_even,0);
		filt[0][col+1] = (unsigned char) _mm256_extract_epi8(output_row0_even,1);
		filt[0][col+2] = (unsigned char) _mm256_extract_epi8(output_row0_even,2);
		filt[0][col+3] = (unsigned char) _mm256_extract_epi8(output_row0_even,3);
		filt[0][col+4] = (unsigned char) _mm256_extract_epi8(output_row0_even,4);
		filt[0][col+5] = (unsigned char) _mm256_extract_epi8(output_row0_even,5);

		filt[1][col] = (unsigned char) _mm256_extract_epi8(output_row1_even,0);
		filt[1][col+1] = (unsigned char) _mm256_extract_epi8(output_row1_even,1);
		filt[1][col+2] = (unsigned char) _mm256_extract_epi8(output_row1_even,2);
		filt[1][col+3] = (unsigned char) _mm256_extract_epi8(output_row1_even,3);
		filt[1][col+4] = (unsigned char) _mm256_extract_epi8(output_row1_even,4);
		filt[1][col+5] = (unsigned char) _mm256_extract_epi8(output_row1_even,5);
		  break;
	case 7:
		filt[2][col] = (unsigned char) _mm256_extract_epi8(output_even,0);
		filt[2][col+1] = (unsigned char) _mm256_extract_epi8(output_even,1);
		filt[2][col+2] = (unsigned char) _mm256_extract_epi8(output_even,2);
		filt[2][col+3] = (unsigned char) _mm256_extract_epi8(output_even,3);
		filt[2][col+4] = (unsigned char) _mm256_extract_epi8(output_even,4);
		filt[2][col+5] = (unsigned char) _mm256_extract_epi8(output_even,5);
		filt[2][col+6] = (unsigned char) _mm256_extract_epi8(output_even,6);

		filt[0][col] = (unsigned char) _mm256_extract_epi8(output_row0_even,0);
		filt[0][col+1] = (unsigned char) _mm256_extract_epi8(output_row0_even,1);
		filt[0][col+2] = (unsigned char) _mm256_extract_epi8(output_row0_even,2);
		filt[0][col+3] = (unsigned char) _mm256_extract_epi8(output_row0_even,3);
		filt[0][col+4] = (unsigned char) _mm256_extract_epi8(output_row0_even,4);
		filt[0][col+5] = (unsigned char) _mm256_extract_epi8(output_row0_even,5);
		filt[0][col+6] = (unsigned char) _mm256_extract_epi8(output_row0_even,6);

		filt[1][col] = (unsigned char) _mm256_extract_epi8(output_row1_even,0);
		filt[1][col+1] = (unsigned char) _mm256_extract_epi8(output_row1_even,1);
		filt[1][col+2] = (unsigned char) _mm256_extract_epi8(output_row1_even,2);
		filt[1][col+3] = (unsigned char) _mm256_extract_epi8(output_row1_even,3);
		filt[1][col+4] = (unsigned char) _mm256_extract_epi8(output_row1_even,4);
		filt[1][col+5] = (unsigned char) _mm256_extract_epi8(output_row1_even,5);
		filt[1][col+6] = (unsigned char) _mm256_extract_epi8(output_row1_even,6);
		  break;
	case 8:
		filt[2][col] = (unsigned char) _mm256_extract_epi8(output_even,0);
		filt[2][col+1] = (unsigned char) _mm256_extract_epi8(output_even,1);
		filt[2][col+2] = (unsigned char) _mm256_extract_epi8(output_even,2);
		filt[2][col+3] = (unsigned char) _mm256_extract_epi8(output_even,3);
		filt[2][col+4] = (unsigned char) _mm256_extract_epi8(output_even,4);
		filt[2][col+5] = (unsigned char) _mm256_extract_epi8(output_even,5);
		filt[2][col+6] = (unsigned char) _mm256_extract_epi8(output_even,6);
		filt[2][col+7] = (unsigned char) _mm256_extract_epi8(output_even,7);

		filt[0][col] = (unsigned char) _mm256_extract_epi8(output_row0_even,0);
		filt[0][col+1] = (unsigned char) _mm256_extract_epi8(output_row0_even,1);
		filt[0][col+2] = (unsigned char) _mm256_extract_epi8(output_row0_even,2);
		filt[0][col+3] = (unsigned char) _mm256_extract_epi8(output_row0_even,3);
		filt[0][col+4] = (unsigned char) _mm256_extract_epi8(output_row0_even,4);
		filt[0][col+5] = (unsigned char) _mm256_extract_epi8(output_row0_even,5);
		filt[0][col+6] = (unsigned char) _mm256_extract_epi8(output_row0_even,6);
		filt[0][col+7] = (unsigned char) _mm256_extract_epi8(output_row0_even,7);

		filt[1][col] = (unsigned char) _mm256_extract_epi8(output_row1_even,0);
		filt[1][col+1] = (unsigned char) _mm256_extract_epi8(output_row1_even,1);
		filt[1][col+2] = (unsigned char) _mm256_extract_epi8(output_row1_even,2);
		filt[1][col+3] = (unsigned char) _mm256_extract_epi8(output_row1_even,3);
		filt[1][col+4] = (unsigned char) _mm256_extract_epi8(output_row1_even,4);
		filt[1][col+5] = (unsigned char) _mm256_extract_epi8(output_row1_even,5);
		filt[1][col+6] = (unsigned char) _mm256_extract_epi8(output_row1_even,6);
		filt[1][col+7] = (unsigned char) _mm256_extract_epi8(output_row1_even,7);
		  break;
	case 9:
		filt[2][col] = (unsigned char) _mm256_extract_epi8(output_even,0);
		filt[2][col+1] = (unsigned char) _mm256_extract_epi8(output_even,1);
		filt[2][col+2] = (unsigned char) _mm256_extract_epi8(output_even,2);
		filt[2][col+3] = (unsigned char) _mm256_extract_epi8(output_even,3);
		filt[2][col+4] = (unsigned char) _mm256_extract_epi8(output_even,4);
		filt[2][col+5] = (unsigned char) _mm256_extract_epi8(output_even,5);
		filt[2][col+6] = (unsigned char) _mm256_extract_epi8(output_even,6);
		filt[2][col+7] = (unsigned char) _mm256_extract_epi8(output_even,7);
		filt[2][col+8] = (unsigned char) _mm256_extract_epi8(output_even,8);

		filt[0][col] = (unsigned char) _mm256_extract_epi8(output_row0_even,0);
		filt[0][col+1] = (unsigned char) _mm256_extract_epi8(output_row0_even,1);
		filt[0][col+2] = (unsigned char) _mm256_extract_epi8(output_row0_even,2);
		filt[0][col+3] = (unsigned char) _mm256_extract_epi8(output_row0_even,3);
		filt[0][col+4] = (unsigned char) _mm256_extract_epi8(output_row0_even,4);
		filt[0][col+5] = (unsigned char) _mm256_extract_epi8(output_row0_even,5);
		filt[0][col+6] = (unsigned char) _mm256_extract_epi8(output_row0_even,6);
		filt[0][col+7] = (unsigned char) _mm256_extract_epi8(output_row0_even,7);
		filt[0][col+8] = (unsigned char) _mm256_extract_epi8(output_row0_even,8);

		filt[1][col] = (unsigned char) _mm256_extract_epi8(output_row1_even,0);
		filt[1][col+1] = (unsigned char) _mm256_extract_epi8(output_row1_even,1);
		filt[1][col+2] = (unsigned char) _mm256_extract_epi8(output_row1_even,2);
		filt[1][col+3] = (unsigned char) _mm256_extract_epi8(output_row1_even,3);
		filt[1][col+4] = (unsigned char) _mm256_extract_epi8(output_row1_even,4);
		filt[1][col+5] = (unsigned char) _mm256_extract_epi8(output_row1_even,5);
		filt[1][col+6] = (unsigned char) _mm256_extract_epi8(output_row1_even,6);
		filt[1][col+7] = (unsigned char) _mm256_extract_epi8(output_row1_even,7);
		filt[1][col+8] = (unsigned char) _mm256_extract_epi8(output_row1_even,8);
		  break;
	case 10:
		filt[2][col] = (unsigned char) _mm256_extract_epi8(output_even,0);
		filt[2][col+1] = (unsigned char) _mm256_extract_epi8(output_even,1);
		filt[2][col+2] = (unsigned char) _mm256_extract_epi8(output_even,2);
		filt[2][col+3] = (unsigned char) _mm256_extract_epi8(output_even,3);
		filt[2][col+4] = (unsigned char) _mm256_extract_epi8(output_even,4);
		filt[2][col+5] = (unsigned char) _mm256_extract_epi8(output_even,5);
		filt[2][col+6] = (unsigned char) _mm256_extract_epi8(output_even,6);
		filt[2][col+7] = (unsigned char) _mm256_extract_epi8(output_even,7);
		filt[2][col+8] = (unsigned char) _mm256_extract_epi8(output_even,8);
		filt[2][col+9] = (unsigned char) _mm256_extract_epi8(output_even,9);

		filt[0][col] = (unsigned char) _mm256_extract_epi8(output_row0_even,0);
		filt[0][col+1] = (unsigned char) _mm256_extract_epi8(output_row0_even,1);
		filt[0][col+2] = (unsigned char) _mm256_extract_epi8(output_row0_even,2);
		filt[0][col+3] = (unsigned char) _mm256_extract_epi8(output_row0_even,3);
		filt[0][col+4] = (unsigned char) _mm256_extract_epi8(output_row0_even,4);
		filt[0][col+5] = (unsigned char) _mm256_extract_epi8(output_row0_even,5);
		filt[0][col+6] = (unsigned char) _mm256_extract_epi8(output_row0_even,6);
		filt[0][col+7] = (unsigned char) _mm256_extract_epi8(output_row0_even,7);
		filt[0][col+8] = (unsigned char) _mm256_extract_epi8(output_row0_even,8);
		filt[0][col+9] = (unsigned char) _mm256_extract_epi8(output_row0_even,9);

		filt[1][col] = (unsigned char) _mm256_extract_epi8(output_row1_even,0);
		filt[1][col+1] = (unsigned char) _mm256_extract_epi8(output_row1_even,1);
		filt[1][col+2] = (unsigned char) _mm256_extract_epi8(output_row1_even,2);
		filt[1][col+3] = (unsigned char) _mm256_extract_epi8(output_row1_even,3);
		filt[1][col+4] = (unsigned char) _mm256_extract_epi8(output_row1_even,4);
		filt[1][col+5] = (unsigned char) _mm256_extract_epi8(output_row1_even,5);
		filt[1][col+6] = (unsigned char) _mm256_extract_epi8(output_row1_even,6);
		filt[1][col+7] = (unsigned char) _mm256_extract_epi8(output_row1_even,7);
		filt[1][col+8] = (unsigned char) _mm256_extract_epi8(output_row1_even,8);
		filt[1][col+9] = (unsigned char) _mm256_extract_epi8(output_row1_even,9);
		  break;
	case 11:
		filt[2][col] = (unsigned char) _mm256_extract_epi8(output_even,0);
		filt[2][col+1] = (unsigned char) _mm256_extract_epi8(output_even,1);
		filt[2][col+2] = (unsigned char) _mm256_extract_epi8(output_even,2);
		filt[2][col+3] = (unsigned char) _mm256_extract_epi8(output_even,3);
		filt[2][col+4] = (unsigned char) _mm256_extract_epi8(output_even,4);
		filt[2][col+5] = (unsigned char) _mm256_extract_epi8(output_even,5);
		filt[2][col+6] = (unsigned char) _mm256_extract_epi8(output_even,6);
		filt[2][col+7] = (unsigned char) _mm256_extract_epi8(output_even,7);
		filt[2][col+8] = (unsigned char) _mm256_extract_epi8(output_even,8);
		filt[2][col+9] = (unsigned char) _mm256_extract_epi8(output_even,9);
		filt[2][col+10] = (unsigned char) _mm256_extract_epi8(output_even,10);

		filt[0][col] = (unsigned char) _mm256_extract_epi8(output_row0_even,0);
		filt[0][col+1] = (unsigned char) _mm256_extract_epi8(output_row0_even,1);
		filt[0][col+2] = (unsigned char) _mm256_extract_epi8(output_row0_even,2);
		filt[0][col+3] = (unsigned char) _mm256_extract_epi8(output_row0_even,3);
		filt[0][col+4] = (unsigned char) _mm256_extract_epi8(output_row0_even,4);
		filt[0][col+5] = (unsigned char) _mm256_extract_epi8(output_row0_even,5);
		filt[0][col+6] = (unsigned char) _mm256_extract_epi8(output_row0_even,6);
		filt[0][col+7] = (unsigned char) _mm256_extract_epi8(output_row0_even,7);
		filt[0][col+8] = (unsigned char) _mm256_extract_epi8(output_row0_even,8);
		filt[0][col+9] = (unsigned char) _mm256_extract_epi8(output_row0_even,9);
		filt[0][col+10] = (unsigned char) _mm256_extract_epi8(output_row0_even,10);

		filt[1][col] = (unsigned char) _mm256_extract_epi8(output_row1_even,0);
		filt[1][col+1] = (unsigned char) _mm256_extract_epi8(output_row1_even,1);
		filt[1][col+2] = (unsigned char) _mm256_extract_epi8(output_row1_even,2);
		filt[1][col+3] = (unsigned char) _mm256_extract_epi8(output_row1_even,3);
		filt[1][col+4] = (unsigned char) _mm256_extract_epi8(output_row1_even,4);
		filt[1][col+5] = (unsigned char) _mm256_extract_epi8(output_row1_even,5);
		filt[1][col+6] = (unsigned char) _mm256_extract_epi8(output_row1_even,6);
		filt[1][col+7] = (unsigned char) _mm256_extract_epi8(output_row1_even,7);
		filt[1][col+8] = (unsigned char) _mm256_extract_epi8(output_row1_even,8);
		filt[1][col+9] = (unsigned char) _mm256_extract_epi8(output_row1_even,9);
		filt[1][col+10] = (unsigned char) _mm256_extract_epi8(output_row1_even,10);
		  break;
	case 12:
		filt[2][col] = (unsigned char) _mm256_extract_epi8(output_even,0);
		filt[2][col+1] = (unsigned char) _mm256_extract_epi8(output_even,1);
		filt[2][col+2] = (unsigned char) _mm256_extract_epi8(output_even,2);
		filt[2][col+3] = (unsigned char) _mm256_extract_epi8(output_even,3);
		filt[2][col+4] = (unsigned char) _mm256_extract_epi8(output_even,4);
		filt[2][col+5] = (unsigned char) _mm256_extract_epi8(output_even,5);
		filt[2][col+6] = (unsigned char) _mm256_extract_epi8(output_even,6);
		filt[2][col+7] = (unsigned char) _mm256_extract_epi8(output_even,7);
		filt[2][col+8] = (unsigned char) _mm256_extract_epi8(output_even,8);
		filt[2][col+9] = (unsigned char) _mm256_extract_epi8(output_even,9);
		filt[2][col+10] = (unsigned char) _mm256_extract_epi8(output_even,10);
		filt[2][col+11] = (unsigned char) _mm256_extract_epi8(output_even,11);

		filt[0][col] = (unsigned char) _mm256_extract_epi8(output_row0_even,0);
		filt[0][col+1] = (unsigned char) _mm256_extract_epi8(output_row0_even,1);
		filt[0][col+2] = (unsigned char) _mm256_extract_epi8(output_row0_even,2);
		filt[0][col+3] = (unsigned char) _mm256_extract_epi8(output_row0_even,3);
		filt[0][col+4] = (unsigned char) _mm256_extract_epi8(output_row0_even,4);
		filt[0][col+5] = (unsigned char) _mm256_extract_epi8(output_row0_even,5);
		filt[0][col+6] = (unsigned char) _mm256_extract_epi8(output_row0_even,6);
		filt[0][col+7] = (unsigned char) _mm256_extract_epi8(output_row0_even,7);
		filt[0][col+8] = (unsigned char) _mm256_extract_epi8(output_row0_even,8);
		filt[0][col+9] = (unsigned char) _mm256_extract_epi8(output_row0_even,9);
		filt[0][col+10] = (unsigned char) _mm256_extract_epi8(output_row0_even,10);
		filt[0][col+11] = (unsigned char) _mm256_extract_epi8(output_row0_even,11);

		filt[1][col] = (unsigned char) _mm256_extract_epi8(output_row1_even,0);
		filt[1][col+1] = (unsigned char) _mm256_extract_epi8(output_row1_even,1);
		filt[1][col+2] = (unsigned char) _mm256_extract_epi8(output_row1_even,2);
		filt[1][col+3] = (unsigned char) _mm256_extract_epi8(output_row1_even,3);
		filt[1][col+4] = (unsigned char) _mm256_extract_epi8(output_row1_even,4);
		filt[1][col+5] = (unsigned char) _mm256_extract_epi8(output_row1_even,5);
		filt[1][col+6] = (unsigned char) _mm256_extract_epi8(output_row1_even,6);
		filt[1][col+7] = (unsigned char) _mm256_extract_epi8(output_row1_even,7);
		filt[1][col+8] = (unsigned char) _mm256_extract_epi8(output_row1_even,8);
		filt[1][col+9] = (unsigned char) _mm256_extract_epi8(output_row1_even,9);
		filt[1][col+10] = (unsigned char) _mm256_extract_epi8(output_row1_even,10);
		filt[1][col+11] = (unsigned char) _mm256_extract_epi8(output_row1_even,11);
		  break;
	case 13:
		filt[2][col] = (unsigned char) _mm256_extract_epi8(output_even,0);
		filt[2][col+1] = (unsigned char) _mm256_extract_epi8(output_even,1);
		filt[2][col+2] = (unsigned char) _mm256_extract_epi8(output_even,2);
		filt[2][col+3] = (unsigned char) _mm256_extract_epi8(output_even,3);
		filt[2][col+4] = (unsigned char) _mm256_extract_epi8(output_even,4);
		filt[2][col+5] = (unsigned char) _mm256_extract_epi8(output_even,5);
		filt[2][col+6] = (unsigned char) _mm256_extract_epi8(output_even,6);
		filt[2][col+7] = (unsigned char) _mm256_extract_epi8(output_even,7);
		filt[2][col+8] = (unsigned char) _mm256_extract_epi8(output_even,8);
		filt[2][col+9] = (unsigned char) _mm256_extract_epi8(output_even,9);
		filt[2][col+10] = (unsigned char) _mm256_extract_epi8(output_even,10);
		filt[2][col+11] = (unsigned char) _mm256_extract_epi8(output_even,11);
		filt[2][col+12] = (unsigned char) _mm256_extract_epi8(output_even,12);

		filt[0][col] = (unsigned char) _mm256_extract_epi8(output_row0_even,0);
		filt[0][col+1] = (unsigned char) _mm256_extract_epi8(output_row0_even,1);
		filt[0][col+2] = (unsigned char) _mm256_extract_epi8(output_row0_even,2);
		filt[0][col+3] = (unsigned char) _mm256_extract_epi8(output_row0_even,3);
		filt[0][col+4] = (unsigned char) _mm256_extract_epi8(output_row0_even,4);
		filt[0][col+5] = (unsigned char) _mm256_extract_epi8(output_row0_even,5);
		filt[0][col+6] = (unsigned char) _mm256_extract_epi8(output_row0_even,6);
		filt[0][col+7] = (unsigned char) _mm256_extract_epi8(output_row0_even,7);
		filt[0][col+8] = (unsigned char) _mm256_extract_epi8(output_row0_even,8);
		filt[0][col+9] = (unsigned char) _mm256_extract_epi8(output_row0_even,9);
		filt[0][col+10] = (unsigned char) _mm256_extract_epi8(output_row0_even,10);
		filt[0][col+11] = (unsigned char) _mm256_extract_epi8(output_row0_even,11);
		filt[0][col+12] = (unsigned char) _mm256_extract_epi8(output_row0_even,12);

		filt[1][col] = (unsigned char) _mm256_extract_epi8(output_row1_even,0);
		filt[1][col+1] = (unsigned char) _mm256_extract_epi8(output_row1_even,1);
		filt[1][col+2] = (unsigned char) _mm256_extract_epi8(output_row1_even,2);
		filt[1][col+3] = (unsigned char) _mm256_extract_epi8(output_row1_even,3);
		filt[1][col+4] = (unsigned char) _mm256_extract_epi8(output_row1_even,4);
		filt[1][col+5] = (unsigned char) _mm256_extract_epi8(output_row1_even,5);
		filt[1][col+6] = (unsigned char) _mm256_extract_epi8(output_row1_even,6);
		filt[1][col+7] = (unsigned char) _mm256_extract_epi8(output_row1_even,7);
		filt[1][col+8] = (unsigned char) _mm256_extract_epi8(output_row1_even,8);
		filt[1][col+9] = (unsigned char) _mm256_extract_epi8(output_row1_even,9);
		filt[1][col+10] = (unsigned char) _mm256_extract_epi8(output_row1_even,10);
		filt[1][col+11] = (unsigned char) _mm256_extract_epi8(output_row1_even,11);
		filt[1][col+12] = (unsigned char) _mm256_extract_epi8(output_row1_even,12);
		  break;
	case 14:
		filt[2][col] = (unsigned char) _mm256_extract_epi8(output_even,0);
		filt[2][col+1] = (unsigned char) _mm256_extract_epi8(output_even,1);
		filt[2][col+2] = (unsigned char) _mm256_extract_epi8(output_even,2);
		filt[2][col+3] = (unsigned char) _mm256_extract_epi8(output_even,3);
		filt[2][col+4] = (unsigned char) _mm256_extract_epi8(output_even,4);
		filt[2][col+5] = (unsigned char) _mm256_extract_epi8(output_even,5);
		filt[2][col+6] = (unsigned char) _mm256_extract_epi8(output_even,6);
		filt[2][col+7] = (unsigned char) _mm256_extract_epi8(output_even,7);
		filt[2][col+8] = (unsigned char) _mm256_extract_epi8(output_even,8);
		filt[2][col+9] = (unsigned char) _mm256_extract_epi8(output_even,9);
		filt[2][col+10] = (unsigned char) _mm256_extract_epi8(output_even,10);
		filt[2][col+11] = (unsigned char) _mm256_extract_epi8(output_even,11);
		filt[2][col+12] = (unsigned char) _mm256_extract_epi8(output_even,12);
		filt[2][col+13] = (unsigned char) _mm256_extract_epi8(output_even,13);

		filt[0][col] = (unsigned char) _mm256_extract_epi8(output_row0_even,0);
		filt[0][col+1] = (unsigned char) _mm256_extract_epi8(output_row0_even,1);
		filt[0][col+2] = (unsigned char) _mm256_extract_epi8(output_row0_even,2);
		filt[0][col+3] = (unsigned char) _mm256_extract_epi8(output_row0_even,3);
		filt[0][col+4] = (unsigned char) _mm256_extract_epi8(output_row0_even,4);
		filt[0][col+5] = (unsigned char) _mm256_extract_epi8(output_row0_even,5);
		filt[0][col+6] = (unsigned char) _mm256_extract_epi8(output_row0_even,6);
		filt[0][col+7] = (unsigned char) _mm256_extract_epi8(output_row0_even,7);
		filt[0][col+8] = (unsigned char) _mm256_extract_epi8(output_row0_even,8);
		filt[0][col+9] = (unsigned char) _mm256_extract_epi8(output_row0_even,9);
		filt[0][col+10] = (unsigned char) _mm256_extract_epi8(output_row0_even,10);
		filt[0][col+11] = (unsigned char) _mm256_extract_epi8(output_row0_even,11);
		filt[0][col+12] = (unsigned char) _mm256_extract_epi8(output_row0_even,12);
		filt[0][col+13] = (unsigned char) _mm256_extract_epi8(output_row0_even,13);

		filt[1][col] = (unsigned char) _mm256_extract_epi8(output_row1_even,0);
		filt[1][col+1] = (unsigned char) _mm256_extract_epi8(output_row1_even,1);
		filt[1][col+2] = (unsigned char) _mm256_extract_epi8(output_row1_even,2);
		filt[1][col+3] = (unsigned char) _mm256_extract_epi8(output_row1_even,3);
		filt[1][col+4] = (unsigned char) _mm256_extract_epi8(output_row1_even,4);
		filt[1][col+5] = (unsigned char) _mm256_extract_epi8(output_row1_even,5);
		filt[1][col+6] = (unsigned char) _mm256_extract_epi8(output_row1_even,6);
		filt[1][col+7] = (unsigned char) _mm256_extract_epi8(output_row1_even,7);
		filt[1][col+8] = (unsigned char) _mm256_extract_epi8(output_row1_even,8);
		filt[1][col+9] = (unsigned char) _mm256_extract_epi8(output_row1_even,9);
		filt[1][col+10] = (unsigned char) _mm256_extract_epi8(output_row1_even,10);
		filt[1][col+11] = (unsigned char) _mm256_extract_epi8(output_row1_even,11);
		filt[1][col+12] = (unsigned char) _mm256_extract_epi8(output_row1_even,12);
		filt[1][col+13] = (unsigned char) _mm256_extract_epi8(output_row1_even,13);
		  break;
	case 15:
		filt[2][col] = (unsigned char) _mm256_extract_epi8(output_even,0);
		filt[2][col+1] = (unsigned char) _mm256_extract_epi8(output_even,1);
		filt[2][col+2] = (unsigned char) _mm256_extract_epi8(output_even,2);
		filt[2][col+3] = (unsigned char) _mm256_extract_epi8(output_even,3);
		filt[2][col+4] = (unsigned char) _mm256_extract_epi8(output_even,4);
		filt[2][col+5] = (unsigned char) _mm256_extract_epi8(output_even,5);
		filt[2][col+6] = (unsigned char) _mm256_extract_epi8(output_even,6);
		filt[2][col+7] = (unsigned char) _mm256_extract_epi8(output_even,7);
		filt[2][col+8] = (unsigned char) _mm256_extract_epi8(output_even,8);
		filt[2][col+9] = (unsigned char) _mm256_extract_epi8(output_even,9);
		filt[2][col+10] = (unsigned char) _mm256_extract_epi8(output_even,10);
		filt[2][col+11] = (unsigned char) _mm256_extract_epi8(output_even,11);
		filt[2][col+12] = (unsigned char) _mm256_extract_epi8(output_even,12);
		filt[2][col+13] = (unsigned char) _mm256_extract_epi8(output_even,13);
		filt[2][col+14] = (unsigned char) _mm256_extract_epi8(output_even,14);

		filt[0][col] = (unsigned char) _mm256_extract_epi8(output_row0_even,0);
		filt[0][col+1] = (unsigned char) _mm256_extract_epi8(output_row0_even,1);
		filt[0][col+2] = (unsigned char) _mm256_extract_epi8(output_row0_even,2);
		filt[0][col+3] = (unsigned char) _mm256_extract_epi8(output_row0_even,3);
		filt[0][col+4] = (unsigned char) _mm256_extract_epi8(output_row0_even,4);
		filt[0][col+5] = (unsigned char) _mm256_extract_epi8(output_row0_even,5);
		filt[0][col+6] = (unsigned char) _mm256_extract_epi8(output_row0_even,6);
		filt[0][col+7] = (unsigned char) _mm256_extract_epi8(output_row0_even,7);
		filt[0][col+8] = (unsigned char) _mm256_extract_epi8(output_row0_even,8);
		filt[0][col+9] = (unsigned char) _mm256_extract_epi8(output_row0_even,9);
		filt[0][col+10] = (unsigned char) _mm256_extract_epi8(output_row0_even,10);
		filt[0][col+11] = (unsigned char) _mm256_extract_epi8(output_row0_even,11);
		filt[0][col+12] = (unsigned char) _mm256_extract_epi8(output_row0_even,12);
		filt[0][col+13] = (unsigned char) _mm256_extract_epi8(output_row0_even,13);
		filt[0][col+14] = (unsigned char) _mm256_extract_epi8(output_row0_even,14);

		filt[1][col] = (unsigned char) _mm256_extract_epi8(output_row1_even,0);
		filt[1][col+1] = (unsigned char) _mm256_extract_epi8(output_row1_even,1);
		filt[1][col+2] = (unsigned char) _mm256_extract_epi8(output_row1_even,2);
		filt[1][col+3] = (unsigned char) _mm256_extract_epi8(output_row1_even,3);
		filt[1][col+4] = (unsigned char) _mm256_extract_epi8(output_row1_even,4);
		filt[1][col+5] = (unsigned char) _mm256_extract_epi8(output_row1_even,5);
		filt[1][col+6] = (unsigned char) _mm256_extract_epi8(output_row1_even,6);
		filt[1][col+7] = (unsigned char) _mm256_extract_epi8(output_row1_even,7);
		filt[1][col+8] = (unsigned char) _mm256_extract_epi8(output_row1_even,8);
		filt[1][col+9] = (unsigned char) _mm256_extract_epi8(output_row1_even,9);
		filt[1][col+10] = (unsigned char) _mm256_extract_epi8(output_row1_even,10);
		filt[1][col+11] = (unsigned char) _mm256_extract_epi8(output_row1_even,11);
		filt[1][col+12] = (unsigned char) _mm256_extract_epi8(output_row1_even,12);
		filt[1][col+13] = (unsigned char) _mm256_extract_epi8(output_row1_even,13);
		filt[1][col+14] = (unsigned char) _mm256_extract_epi8(output_row1_even,14);
		  break;
	case 16:
		_mm_storeu_si128( (__m128i *) &filt[2][col],_mm256_extractf128_si256(output_even, 0)); //store low 128bit - 16pixels
		_mm_storeu_si128( (__m128i *) &filt[0][col],_mm256_extractf128_si256(output_row0_even, 0)); //store low 128bit - 16pixels
		_mm_storeu_si128( (__m128i *) &filt[1][col],_mm256_extractf128_si256(output_row1_even, 0)); //store low 128bit - 16pixels
		  break;
	case 17:
		_mm_storeu_si128( (__m128i *) &filt[2][col],_mm256_extractf128_si256(output_even, 0)); //store low 128bit - 16pixels
		filt[2][col+16] = (unsigned char) _mm256_extract_epi8(output_even,16);

		_mm_storeu_si128( (__m128i *) &filt[0][col],_mm256_extractf128_si256(output_row0_even, 0)); //store low 128bit - 16pixels
		filt[0][col+16] = (unsigned char) _mm256_extract_epi8(output_row0_even,16);

		_mm_storeu_si128( (__m128i *) &filt[1][col],_mm256_extractf128_si256(output_row1_even, 0)); //store low 128bit - 16pixels
		filt[1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1_even,16);
		  break;
	case 18:
		_mm_storeu_si128( (__m128i *) &filt[2][col],_mm256_extractf128_si256(output_even, 0)); //store low 128bit - 16pixels
		filt[2][col+16] = (unsigned char) _mm256_extract_epi8(output_even,16);
		filt[2][col+17] = (unsigned char) _mm256_extract_epi8(output_even,17);

		_mm_storeu_si128( (__m128i *) &filt[0][col],_mm256_extractf128_si256(output_row0_even, 0)); //store low 128bit - 16pixels
		filt[0][col+16] = (unsigned char) _mm256_extract_epi8(output_row0_even,16);
		filt[0][col+17] = (unsigned char) _mm256_extract_epi8(output_row0_even,17);

		_mm_storeu_si128( (__m128i *) &filt[1][col],_mm256_extractf128_si256(output_row1_even, 0)); //store low 128bit - 16pixels
		filt[1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1_even,16);
		filt[1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1_even,17);
		  break;
	case 19:
		_mm_storeu_si128( (__m128i *) &filt[2][col],_mm256_extractf128_si256(output_even, 0)); //store low 128bit - 16pixels
		filt[2][col+16] = (unsigned char) _mm256_extract_epi8(output_even,16);
		filt[2][col+17] = (unsigned char) _mm256_extract_epi8(output_even,17);
		filt[2][col+18] = (unsigned char) _mm256_extract_epi8(output_even,18);

		_mm_storeu_si128( (__m128i *) &filt[0][col],_mm256_extractf128_si256(output_row0_even, 0)); //store low 128bit - 16pixels
		filt[0][col+16] = (unsigned char) _mm256_extract_epi8(output_row0_even,16);
		filt[0][col+17] = (unsigned char) _mm256_extract_epi8(output_row0_even,17);
		filt[0][col+18] = (unsigned char) _mm256_extract_epi8(output_row0_even,18);

		_mm_storeu_si128( (__m128i *) &filt[1][col],_mm256_extractf128_si256(output_row1_even, 0)); //store low 128bit - 16pixels
		filt[1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1_even,16);
		filt[1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1_even,17);
		filt[1][col+18] = (unsigned char) _mm256_extract_epi8(output_row1_even,18);
		  break;
	case 20:
		_mm_storeu_si128( (__m128i *) &filt[2][col],_mm256_extractf128_si256(output_even, 0)); //store low 128bit - 16pixels
		filt[2][col+16] = (unsigned char) _mm256_extract_epi8(output_even,16);
		filt[2][col+17] = (unsigned char) _mm256_extract_epi8(output_even,17);
		filt[2][col+18] = (unsigned char) _mm256_extract_epi8(output_even,18);
		filt[2][col+19] = (unsigned char) _mm256_extract_epi8(output_even,19);

		_mm_storeu_si128( (__m128i *) &filt[0][col],_mm256_extractf128_si256(output_row0_even, 0)); //store low 128bit - 16pixels
		filt[0][col+16] = (unsigned char) _mm256_extract_epi8(output_row0_even,16);
		filt[0][col+17] = (unsigned char) _mm256_extract_epi8(output_row0_even,17);
		filt[0][col+18] = (unsigned char) _mm256_extract_epi8(output_row0_even,18);
		filt[0][col+19] = (unsigned char) _mm256_extract_epi8(output_row0_even,19);

		_mm_storeu_si128( (__m128i *) &filt[1][col],_mm256_extractf128_si256(output_row1_even, 0)); //store low 128bit - 16pixels
		filt[1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1_even,16);
		filt[1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1_even,17);
		filt[1][col+18] = (unsigned char) _mm256_extract_epi8(output_row1_even,18);
		filt[1][col+19] = (unsigned char) _mm256_extract_epi8(output_row1_even,19);
		  break;
	case 21:
		_mm_storeu_si128( (__m128i *) &filt[2][col],_mm256_extractf128_si256(output_even, 0)); //store low 128bit - 16pixels
		filt[2][col+16] = (unsigned char) _mm256_extract_epi8(output_even,16);
		filt[2][col+17] = (unsigned char) _mm256_extract_epi8(output_even,17);
		filt[2][col+18] = (unsigned char) _mm256_extract_epi8(output_even,18);
		filt[2][col+19] = (unsigned char) _mm256_extract_epi8(output_even,19);
		filt[2][col+20] = (unsigned char) _mm256_extract_epi8(output_even,20);

		_mm_storeu_si128( (__m128i *) &filt[0][col],_mm256_extractf128_si256(output_row0_even, 0)); //store low 128bit - 16pixels
		filt[0][col+16] = (unsigned char) _mm256_extract_epi8(output_row0_even,16);
		filt[0][col+17] = (unsigned char) _mm256_extract_epi8(output_row0_even,17);
		filt[0][col+18] = (unsigned char) _mm256_extract_epi8(output_row0_even,18);
		filt[0][col+19] = (unsigned char) _mm256_extract_epi8(output_row0_even,19);
		filt[0][col+20] = (unsigned char) _mm256_extract_epi8(output_row0_even,20);

		_mm_storeu_si128( (__m128i *) &filt[1][col],_mm256_extractf128_si256(output_row1_even, 0)); //store low 128bit - 16pixels
		filt[1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1_even,16);
		filt[1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1_even,17);
		filt[1][col+18] = (unsigned char) _mm256_extract_epi8(output_row1_even,18);
		filt[1][col+19] = (unsigned char) _mm256_extract_epi8(output_row1_even,19);
		filt[1][col+20] = (unsigned char) _mm256_extract_epi8(output_row1_even,20);
		  break;
	case 22:
		_mm_storeu_si128( (__m128i *) &filt[2][col],_mm256_extractf128_si256(output_even, 0)); //store low 128bit - 16pixels
		filt[2][col+16] = (unsigned char) _mm256_extract_epi8(output_even,16);
		filt[2][col+17] = (unsigned char) _mm256_extract_epi8(output_even,17);
		filt[2][col+18] = (unsigned char) _mm256_extract_epi8(output_even,18);
		filt[2][col+19] = (unsigned char) _mm256_extract_epi8(output_even,19);
		filt[2][col+20] = (unsigned char) _mm256_extract_epi8(output_even,20);
		filt[2][col+21] = (unsigned char) _mm256_extract_epi8(output_even,21);

		_mm_storeu_si128( (__m128i *) &filt[0][col],_mm256_extractf128_si256(output_row0_even, 0)); //store low 128bit - 16pixels
		filt[0][col+16] = (unsigned char) _mm256_extract_epi8(output_row0_even,16);
		filt[0][col+17] = (unsigned char) _mm256_extract_epi8(output_row0_even,17);
		filt[0][col+18] = (unsigned char) _mm256_extract_epi8(output_row0_even,18);
		filt[0][col+19] = (unsigned char) _mm256_extract_epi8(output_row0_even,19);
		filt[0][col+20] = (unsigned char) _mm256_extract_epi8(output_row0_even,20);
		filt[0][col+21] = (unsigned char) _mm256_extract_epi8(output_row0_even,21);

		_mm_storeu_si128( (__m128i *) &filt[1][col],_mm256_extractf128_si256(output_row1_even, 0)); //store low 128bit - 16pixels
		filt[1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1_even,16);
		filt[1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1_even,17);
		filt[1][col+18] = (unsigned char) _mm256_extract_epi8(output_row1_even,18);
		filt[1][col+19] = (unsigned char) _mm256_extract_epi8(output_row1_even,19);
		filt[1][col+20] = (unsigned char) _mm256_extract_epi8(output_row1_even,20);
		filt[1][col+21] = (unsigned char) _mm256_extract_epi8(output_row1_even,21);
		  break;
	case 23:
		_mm_storeu_si128( (__m128i *) &filt[2][col],_mm256_extractf128_si256(output_even, 0)); //store low 128bit - 16pixels
		filt[2][col+16] = (unsigned char) _mm256_extract_epi8(output_even,16);
		filt[2][col+17] = (unsigned char) _mm256_extract_epi8(output_even,17);
		filt[2][col+18] = (unsigned char) _mm256_extract_epi8(output_even,18);
		filt[2][col+19] = (unsigned char) _mm256_extract_epi8(output_even,19);
		filt[2][col+20] = (unsigned char) _mm256_extract_epi8(output_even,20);
		filt[2][col+21] = (unsigned char) _mm256_extract_epi8(output_even,21);
		filt[2][col+22] = (unsigned char) _mm256_extract_epi8(output_even,22);


		_mm_storeu_si128( (__m128i *) &filt[0][col],_mm256_extractf128_si256(output_row0_even, 0)); //store low 128bit - 16pixels
		filt[0][col+16] = (unsigned char) _mm256_extract_epi8(output_row0_even,16);
		filt[0][col+17] = (unsigned char) _mm256_extract_epi8(output_row0_even,17);
		filt[0][col+18] = (unsigned char) _mm256_extract_epi8(output_row0_even,18);
		filt[0][col+19] = (unsigned char) _mm256_extract_epi8(output_row0_even,19);
		filt[0][col+20] = (unsigned char) _mm256_extract_epi8(output_row0_even,20);
		filt[0][col+21] = (unsigned char) _mm256_extract_epi8(output_row0_even,21);
		filt[0][col+22] = (unsigned char) _mm256_extract_epi8(output_row0_even,22);

		_mm_storeu_si128( (__m128i *) &filt[1][col],_mm256_extractf128_si256(output_row1_even, 0)); //store low 128bit - 16pixels
		filt[1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1_even,16);
		filt[1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1_even,17);
		filt[1][col+18] = (unsigned char) _mm256_extract_epi8(output_row1_even,18);
		filt[1][col+19] = (unsigned char) _mm256_extract_epi8(output_row1_even,19);
		filt[1][col+20] = (unsigned char) _mm256_extract_epi8(output_row1_even,20);
		filt[1][col+21] = (unsigned char) _mm256_extract_epi8(output_row1_even,21);
		filt[1][col+22] = (unsigned char) _mm256_extract_epi8(output_row1_even,22);
		  break;
	case 24:
		_mm_storeu_si128( (__m128i *) &filt[2][col],_mm256_extractf128_si256(output_even, 0)); //store low 128bit - 16pixels
		filt[2][col+16] = (unsigned char) _mm256_extract_epi8(output_even,16);
		filt[2][col+17] = (unsigned char) _mm256_extract_epi8(output_even,17);
		filt[2][col+18] = (unsigned char) _mm256_extract_epi8(output_even,18);
		filt[2][col+19] = (unsigned char) _mm256_extract_epi8(output_even,19);
		filt[2][col+20] = (unsigned char) _mm256_extract_epi8(output_even,20);
		filt[2][col+21] = (unsigned char) _mm256_extract_epi8(output_even,21);
		filt[2][col+22] = (unsigned char) _mm256_extract_epi8(output_even,22);
		filt[2][col+23] = (unsigned char) _mm256_extract_epi8(output_even,23);

		_mm_storeu_si128( (__m128i *) &filt[0][col],_mm256_extractf128_si256(output_row0_even, 0)); //store low 128bit - 16pixels
		filt[0][col+16] = (unsigned char) _mm256_extract_epi8(output_row0_even,16);
		filt[0][col+17] = (unsigned char) _mm256_extract_epi8(output_row0_even,17);
		filt[0][col+18] = (unsigned char) _mm256_extract_epi8(output_row0_even,18);
		filt[0][col+19] = (unsigned char) _mm256_extract_epi8(output_row0_even,19);
		filt[0][col+20] = (unsigned char) _mm256_extract_epi8(output_row0_even,20);
		filt[0][col+21] = (unsigned char) _mm256_extract_epi8(output_row0_even,21);
		filt[0][col+22] = (unsigned char) _mm256_extract_epi8(output_row0_even,22);
		filt[0][col+23] = (unsigned char) _mm256_extract_epi8(output_row0_even,23);

		_mm_storeu_si128( (__m128i *) &filt[1][col],_mm256_extractf128_si256(output_row1_even, 0)); //store low 128bit - 16pixels
		filt[1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1_even,16);
		filt[1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1_even,17);
		filt[1][col+18] = (unsigned char) _mm256_extract_epi8(output_row1_even,18);
		filt[1][col+19] = (unsigned char) _mm256_extract_epi8(output_row1_even,19);
		filt[1][col+20] = (unsigned char) _mm256_extract_epi8(output_row1_even,20);
		filt[1][col+21] = (unsigned char) _mm256_extract_epi8(output_row1_even,21);
		filt[1][col+22] = (unsigned char) _mm256_extract_epi8(output_row1_even,22);
		filt[1][col+23] = (unsigned char) _mm256_extract_epi8(output_row1_even,23);
		  break;
	case 25:
		_mm_storeu_si128( (__m128i *) &filt[2][col],_mm256_extractf128_si256(output_even, 0)); //store low 128bit - 16pixels
		filt[2][col+16] = (unsigned char) _mm256_extract_epi8(output_even,16);
		filt[2][col+17] = (unsigned char) _mm256_extract_epi8(output_even,17);
		filt[2][col+18] = (unsigned char) _mm256_extract_epi8(output_even,18);
		filt[2][col+19] = (unsigned char) _mm256_extract_epi8(output_even,19);
		filt[2][col+20] = (unsigned char) _mm256_extract_epi8(output_even,20);
		filt[2][col+21] = (unsigned char) _mm256_extract_epi8(output_even,21);
		filt[2][col+22] = (unsigned char) _mm256_extract_epi8(output_even,22);
		filt[2][col+23] = (unsigned char) _mm256_extract_epi8(output_even,23);
		filt[2][col+24] = (unsigned char) _mm256_extract_epi8(output_even,24);

		_mm_storeu_si128( (__m128i *) &filt[0][col],_mm256_extractf128_si256(output_row0_even, 0)); //store low 128bit - 16pixels
		filt[0][col+16] = (unsigned char) _mm256_extract_epi8(output_row0_even,16);
		filt[0][col+17] = (unsigned char) _mm256_extract_epi8(output_row0_even,17);
		filt[0][col+18] = (unsigned char) _mm256_extract_epi8(output_row0_even,18);
		filt[0][col+19] = (unsigned char) _mm256_extract_epi8(output_row0_even,19);
		filt[0][col+20] = (unsigned char) _mm256_extract_epi8(output_row0_even,20);
		filt[0][col+21] = (unsigned char) _mm256_extract_epi8(output_row0_even,21);
		filt[0][col+22] = (unsigned char) _mm256_extract_epi8(output_row0_even,22);
		filt[0][col+23] = (unsigned char) _mm256_extract_epi8(output_row0_even,23);
		filt[0][col+24] = (unsigned char) _mm256_extract_epi8(output_row0_even,24);

		_mm_storeu_si128( (__m128i *) &filt[1][col],_mm256_extractf128_si256(output_row1_even, 0)); //store low 128bit - 16pixels
		filt[1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1_even,16);
		filt[1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1_even,17);
		filt[1][col+18] = (unsigned char) _mm256_extract_epi8(output_row1_even,18);
		filt[1][col+19] = (unsigned char) _mm256_extract_epi8(output_row1_even,19);
		filt[1][col+20] = (unsigned char) _mm256_extract_epi8(output_row1_even,20);
		filt[1][col+21] = (unsigned char) _mm256_extract_epi8(output_row1_even,21);
		filt[1][col+22] = (unsigned char) _mm256_extract_epi8(output_row1_even,22);
		filt[1][col+23] = (unsigned char) _mm256_extract_epi8(output_row1_even,23);
		filt[1][col+24] = (unsigned char) _mm256_extract_epi8(output_row1_even,24);
		  break;
	case 26:
		_mm_storeu_si128( (__m128i *) &filt[2][col],_mm256_extractf128_si256(output_even, 0)); //store low 128bit - 16pixels
		filt[2][col+16] = (unsigned char) _mm256_extract_epi8(output_even,16);
		filt[2][col+17] = (unsigned char) _mm256_extract_epi8(output_even,17);
		filt[2][col+18] = (unsigned char) _mm256_extract_epi8(output_even,18);
		filt[2][col+19] = (unsigned char) _mm256_extract_epi8(output_even,19);
		filt[2][col+20] = (unsigned char) _mm256_extract_epi8(output_even,20);
		filt[2][col+21] = (unsigned char) _mm256_extract_epi8(output_even,21);
		filt[2][col+22] = (unsigned char) _mm256_extract_epi8(output_even,22);
		filt[2][col+23] = (unsigned char) _mm256_extract_epi8(output_even,23);
		filt[2][col+24] = (unsigned char) _mm256_extract_epi8(output_even,24);
		filt[2][col+25] = (unsigned char) _mm256_extract_epi8(output_even,25);

		_mm_storeu_si128( (__m128i *) &filt[0][col],_mm256_extractf128_si256(output_row0_even, 0)); //store low 128bit - 16pixels
		filt[0][col+16] = (unsigned char) _mm256_extract_epi8(output_row0_even,16);
		filt[0][col+17] = (unsigned char) _mm256_extract_epi8(output_row0_even,17);
		filt[0][col+18] = (unsigned char) _mm256_extract_epi8(output_row0_even,18);
		filt[0][col+19] = (unsigned char) _mm256_extract_epi8(output_row0_even,19);
		filt[0][col+20] = (unsigned char) _mm256_extract_epi8(output_row0_even,20);
		filt[0][col+21] = (unsigned char) _mm256_extract_epi8(output_row0_even,21);
		filt[0][col+22] = (unsigned char) _mm256_extract_epi8(output_row0_even,22);
		filt[0][col+23] = (unsigned char) _mm256_extract_epi8(output_row0_even,23);
		filt[0][col+24] = (unsigned char) _mm256_extract_epi8(output_row0_even,24);
		filt[0][col+25] = (unsigned char) _mm256_extract_epi8(output_row0_even,25);

		_mm_storeu_si128( (__m128i *) &filt[1][col],_mm256_extractf128_si256(output_row1_even, 0)); //store low 128bit - 16pixels
		filt[1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1_even,16);
		filt[1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1_even,17);
		filt[1][col+18] = (unsigned char) _mm256_extract_epi8(output_row1_even,18);
		filt[1][col+19] = (unsigned char) _mm256_extract_epi8(output_row1_even,19);
		filt[1][col+20] = (unsigned char) _mm256_extract_epi8(output_row1_even,20);
		filt[1][col+21] = (unsigned char) _mm256_extract_epi8(output_row1_even,21);
		filt[1][col+22] = (unsigned char) _mm256_extract_epi8(output_row1_even,22);
		filt[1][col+23] = (unsigned char) _mm256_extract_epi8(output_row1_even,23);
		filt[1][col+24] = (unsigned char) _mm256_extract_epi8(output_row1_even,24);
		filt[1][col+25] = (unsigned char) _mm256_extract_epi8(output_row1_even,25);
		  break;
	case 27:
		_mm_storeu_si128( (__m128i *) &filt[2][col],_mm256_extractf128_si256(output_even, 0)); //store low 128bit - 16pixels
		filt[2][col+16] = (unsigned char) _mm256_extract_epi8(output_even,16);
		filt[2][col+17] = (unsigned char) _mm256_extract_epi8(output_even,17);
		filt[2][col+18] = (unsigned char) _mm256_extract_epi8(output_even,18);
		filt[2][col+19] = (unsigned char) _mm256_extract_epi8(output_even,19);
		filt[2][col+20] = (unsigned char) _mm256_extract_epi8(output_even,20);
		filt[2][col+21] = (unsigned char) _mm256_extract_epi8(output_even,21);
		filt[2][col+22] = (unsigned char) _mm256_extract_epi8(output_even,22);
		filt[2][col+23] = (unsigned char) _mm256_extract_epi8(output_even,23);
		filt[2][col+24] = (unsigned char) _mm256_extract_epi8(output_even,24);
		filt[2][col+25] = (unsigned char) _mm256_extract_epi8(output_even,25);
		filt[2][col+26] = (unsigned char) _mm256_extract_epi8(output_even,26);

		_mm_storeu_si128( (__m128i *) &filt[0][col],_mm256_extractf128_si256(output_row0_even, 0)); //store low 128bit - 16pixels
		filt[0][col+16] = (unsigned char) _mm256_extract_epi8(output_row0_even,16);
		filt[0][col+17] = (unsigned char) _mm256_extract_epi8(output_row0_even,17);
		filt[0][col+18] = (unsigned char) _mm256_extract_epi8(output_row0_even,18);
		filt[0][col+19] = (unsigned char) _mm256_extract_epi8(output_row0_even,19);
		filt[0][col+20] = (unsigned char) _mm256_extract_epi8(output_row0_even,20);
		filt[0][col+21] = (unsigned char) _mm256_extract_epi8(output_row0_even,21);
		filt[0][col+22] = (unsigned char) _mm256_extract_epi8(output_row0_even,22);
		filt[0][col+23] = (unsigned char) _mm256_extract_epi8(output_row0_even,23);
		filt[0][col+24] = (unsigned char) _mm256_extract_epi8(output_row0_even,24);
		filt[0][col+25] = (unsigned char) _mm256_extract_epi8(output_row0_even,25);
		filt[0][col+26] = (unsigned char) _mm256_extract_epi8(output_row0_even,26);

		_mm_storeu_si128( (__m128i *) &filt[1][col],_mm256_extractf128_si256(output_row1_even, 0)); //store low 128bit - 16pixels
		filt[1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1_even,16);
		filt[1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1_even,17);
		filt[1][col+18] = (unsigned char) _mm256_extract_epi8(output_row1_even,18);
		filt[1][col+19] = (unsigned char) _mm256_extract_epi8(output_row1_even,19);
		filt[1][col+20] = (unsigned char) _mm256_extract_epi8(output_row1_even,20);
		filt[1][col+21] = (unsigned char) _mm256_extract_epi8(output_row1_even,21);
		filt[1][col+22] = (unsigned char) _mm256_extract_epi8(output_row1_even,22);
		filt[1][col+23] = (unsigned char) _mm256_extract_epi8(output_row1_even,23);
		filt[1][col+24] = (unsigned char) _mm256_extract_epi8(output_row1_even,24);
		filt[1][col+25] = (unsigned char) _mm256_extract_epi8(output_row1_even,25);
		filt[1][col+26] = (unsigned char) _mm256_extract_epi8(output_row1_even,26);
		  break;
	case 28:
		_mm_storeu_si128( (__m128i *) &filt[2][col],_mm256_extractf128_si256(output_even, 0)); //store low 128bit - 16pixels
		filt[2][col+16] = (unsigned char) _mm256_extract_epi8(output_even,16);
		filt[2][col+17] = (unsigned char) _mm256_extract_epi8(output_even,17);
		filt[2][col+18] = (unsigned char) _mm256_extract_epi8(output_even,18);
		filt[2][col+19] = (unsigned char) _mm256_extract_epi8(output_even,19);
		filt[2][col+20] = (unsigned char) _mm256_extract_epi8(output_even,20);
		filt[2][col+21] = (unsigned char) _mm256_extract_epi8(output_even,21);
		filt[2][col+22] = (unsigned char) _mm256_extract_epi8(output_even,22);
		filt[2][col+23] = (unsigned char) _mm256_extract_epi8(output_even,23);
		filt[2][col+24] = (unsigned char) _mm256_extract_epi8(output_even,24);
		filt[2][col+25] = (unsigned char) _mm256_extract_epi8(output_even,25);
		filt[2][col+26] = (unsigned char) _mm256_extract_epi8(output_even,26);
		filt[2][col+27] = (unsigned char) _mm256_extract_epi8(output_even,27);

		_mm_storeu_si128( (__m128i *) &filt[0][col],_mm256_extractf128_si256(output_row0_even, 0)); //store low 128bit - 16pixels
		filt[0][col+16] = (unsigned char) _mm256_extract_epi8(output_row0_even,16);
		filt[0][col+17] = (unsigned char) _mm256_extract_epi8(output_row0_even,17);
		filt[0][col+18] = (unsigned char) _mm256_extract_epi8(output_row0_even,18);
		filt[0][col+19] = (unsigned char) _mm256_extract_epi8(output_row0_even,19);
		filt[0][col+20] = (unsigned char) _mm256_extract_epi8(output_row0_even,20);
		filt[0][col+21] = (unsigned char) _mm256_extract_epi8(output_row0_even,21);
		filt[0][col+22] = (unsigned char) _mm256_extract_epi8(output_row0_even,22);
		filt[0][col+23] = (unsigned char) _mm256_extract_epi8(output_row0_even,23);
		filt[0][col+24] = (unsigned char) _mm256_extract_epi8(output_row0_even,24);
		filt[0][col+25] = (unsigned char) _mm256_extract_epi8(output_row0_even,25);
		filt[0][col+26] = (unsigned char) _mm256_extract_epi8(output_row0_even,26);
		filt[0][col+27] = (unsigned char) _mm256_extract_epi8(output_row0_even,27);

		_mm_storeu_si128( (__m128i *) &filt[1][col],_mm256_extractf128_si256(output_row1_even, 0)); //store low 128bit - 16pixels
		filt[1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1_even,16);
		filt[1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1_even,17);
		filt[1][col+18] = (unsigned char) _mm256_extract_epi8(output_row1_even,18);
		filt[1][col+19] = (unsigned char) _mm256_extract_epi8(output_row1_even,19);
		filt[1][col+20] = (unsigned char) _mm256_extract_epi8(output_row1_even,20);
		filt[1][col+21] = (unsigned char) _mm256_extract_epi8(output_row1_even,21);
		filt[1][col+22] = (unsigned char) _mm256_extract_epi8(output_row1_even,22);
		filt[1][col+23] = (unsigned char) _mm256_extract_epi8(output_row1_even,23);
		filt[1][col+24] = (unsigned char) _mm256_extract_epi8(output_row1_even,24);
		filt[1][col+25] = (unsigned char) _mm256_extract_epi8(output_row1_even,25);
		filt[1][col+26] = (unsigned char) _mm256_extract_epi8(output_row1_even,26);
		filt[1][col+27] = (unsigned char) _mm256_extract_epi8(output_row1_even,27);
		  break;
	case 29:
		_mm_storeu_si128( (__m128i *) &filt[2][col],_mm256_extractf128_si256(output_even, 0)); //store low 128bit - 16pixels
		filt[2][col+16] = (unsigned char) _mm256_extract_epi8(output_even,16);
		filt[2][col+17] = (unsigned char) _mm256_extract_epi8(output_even,17);
		filt[2][col+18] = (unsigned char) _mm256_extract_epi8(output_even,18);
		filt[2][col+19] = (unsigned char) _mm256_extract_epi8(output_even,19);
		filt[2][col+20] = (unsigned char) _mm256_extract_epi8(output_even,20);
		filt[2][col+21] = (unsigned char) _mm256_extract_epi8(output_even,21);
		filt[2][col+22] = (unsigned char) _mm256_extract_epi8(output_even,22);
		filt[2][col+23] = (unsigned char) _mm256_extract_epi8(output_even,23);
		filt[2][col+24] = (unsigned char) _mm256_extract_epi8(output_even,24);
		filt[2][col+25] = (unsigned char) _mm256_extract_epi8(output_even,25);
		filt[2][col+26] = (unsigned char) _mm256_extract_epi8(output_even,26);
		filt[2][col+27] = (unsigned char) _mm256_extract_epi8(output_even,27);
		filt[2][col+28] = (unsigned char) _mm256_extract_epi8(output_even,28);

		_mm_storeu_si128( (__m128i *) &filt[0][col],_mm256_extractf128_si256(output_row0_even, 0)); //store low 128bit - 16pixels
		filt[0][col+16] = (unsigned char) _mm256_extract_epi8(output_row0_even,16);
		filt[0][col+17] = (unsigned char) _mm256_extract_epi8(output_row0_even,17);
		filt[0][col+18] = (unsigned char) _mm256_extract_epi8(output_row0_even,18);
		filt[0][col+19] = (unsigned char) _mm256_extract_epi8(output_row0_even,19);
		filt[0][col+20] = (unsigned char) _mm256_extract_epi8(output_row0_even,20);
		filt[0][col+21] = (unsigned char) _mm256_extract_epi8(output_row0_even,21);
		filt[0][col+22] = (unsigned char) _mm256_extract_epi8(output_row0_even,22);
		filt[0][col+23] = (unsigned char) _mm256_extract_epi8(output_row0_even,23);
		filt[0][col+24] = (unsigned char) _mm256_extract_epi8(output_row0_even,24);
		filt[0][col+25] = (unsigned char) _mm256_extract_epi8(output_row0_even,25);
		filt[0][col+26] = (unsigned char) _mm256_extract_epi8(output_row0_even,26);
		filt[0][col+27] = (unsigned char) _mm256_extract_epi8(output_row0_even,27);
		filt[0][col+28] = (unsigned char) _mm256_extract_epi8(output_row0_even,28);

		_mm_storeu_si128( (__m128i *) &filt[1][col],_mm256_extractf128_si256(output_row1_even, 0)); //store low 128bit - 16pixels
		filt[1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1_even,16);
		filt[1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1_even,17);
		filt[1][col+18] = (unsigned char) _mm256_extract_epi8(output_row1_even,18);
		filt[1][col+19] = (unsigned char) _mm256_extract_epi8(output_row1_even,19);
		filt[1][col+20] = (unsigned char) _mm256_extract_epi8(output_row1_even,20);
		filt[1][col+21] = (unsigned char) _mm256_extract_epi8(output_row1_even,21);
		filt[1][col+22] = (unsigned char) _mm256_extract_epi8(output_row1_even,22);
		filt[1][col+23] = (unsigned char) _mm256_extract_epi8(output_row1_even,23);
		filt[1][col+24] = (unsigned char) _mm256_extract_epi8(output_row1_even,24);
		filt[1][col+25] = (unsigned char) _mm256_extract_epi8(output_row1_even,25);
		filt[1][col+26] = (unsigned char) _mm256_extract_epi8(output_row1_even,26);
		filt[1][col+27] = (unsigned char) _mm256_extract_epi8(output_row1_even,27);
		filt[1][col+28] = (unsigned char) _mm256_extract_epi8(output_row1_even,28);
		  break;
	case 30:
		_mm_storeu_si128( (__m128i *) &filt[2][col],_mm256_extractf128_si256(output_even, 0)); //store low 128bit - 16pixels
		filt[2][col+16] = (unsigned char) _mm256_extract_epi8(output_even,16);
		filt[2][col+17] = (unsigned char) _mm256_extract_epi8(output_even,17);
		filt[2][col+18] = (unsigned char) _mm256_extract_epi8(output_even,18);
		filt[2][col+19] = (unsigned char) _mm256_extract_epi8(output_even,19);
		filt[2][col+20] = (unsigned char) _mm256_extract_epi8(output_even,20);
		filt[2][col+21] = (unsigned char) _mm256_extract_epi8(output_even,21);
		filt[2][col+22] = (unsigned char) _mm256_extract_epi8(output_even,22);
		filt[2][col+23] = (unsigned char) _mm256_extract_epi8(output_even,23);
		filt[2][col+24] = (unsigned char) _mm256_extract_epi8(output_even,24);
		filt[2][col+25] = (unsigned char) _mm256_extract_epi8(output_even,25);
		filt[2][col+26] = (unsigned char) _mm256_extract_epi8(output_even,26);
		filt[2][col+27] = (unsigned char) _mm256_extract_epi8(output_even,27);
		filt[2][col+28] = (unsigned char) _mm256_extract_epi8(output_even,28);
		filt[2][col+29] = (unsigned char) _mm256_extract_epi8(output_even,29);

		_mm_storeu_si128( (__m128i *) &filt[0][col],_mm256_extractf128_si256(output_row0_even, 0)); //store low 128bit - 16pixels
		filt[0][col+16] = (unsigned char) _mm256_extract_epi8(output_row0_even,16);
		filt[0][col+17] = (unsigned char) _mm256_extract_epi8(output_row0_even,17);
		filt[0][col+18] = (unsigned char) _mm256_extract_epi8(output_row0_even,18);
		filt[0][col+19] = (unsigned char) _mm256_extract_epi8(output_row0_even,19);
		filt[0][col+20] = (unsigned char) _mm256_extract_epi8(output_row0_even,20);
		filt[0][col+21] = (unsigned char) _mm256_extract_epi8(output_row0_even,21);
		filt[0][col+22] = (unsigned char) _mm256_extract_epi8(output_row0_even,22);
		filt[0][col+23] = (unsigned char) _mm256_extract_epi8(output_row0_even,23);
		filt[0][col+24] = (unsigned char) _mm256_extract_epi8(output_row0_even,24);
		filt[0][col+25] = (unsigned char) _mm256_extract_epi8(output_row0_even,25);
		filt[0][col+26] = (unsigned char) _mm256_extract_epi8(output_row0_even,26);
		filt[0][col+27] = (unsigned char) _mm256_extract_epi8(output_row0_even,27);
		filt[0][col+28] = (unsigned char) _mm256_extract_epi8(output_row0_even,28);
		filt[0][col+29] = (unsigned char) _mm256_extract_epi8(output_row0_even,29);


		_mm_storeu_si128( (__m128i *) &filt[1][col],_mm256_extractf128_si256(output_row1_even, 0)); //store low 128bit - 16pixels
		filt[1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1_even,16);
		filt[1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1_even,17);
		filt[1][col+18] = (unsigned char) _mm256_extract_epi8(output_row1_even,18);
		filt[1][col+19] = (unsigned char) _mm256_extract_epi8(output_row1_even,19);
		filt[1][col+20] = (unsigned char) _mm256_extract_epi8(output_row1_even,20);
		filt[1][col+21] = (unsigned char) _mm256_extract_epi8(output_row1_even,21);
		filt[1][col+22] = (unsigned char) _mm256_extract_epi8(output_row1_even,22);
		filt[1][col+23] = (unsigned char) _mm256_extract_epi8(output_row1_even,23);
		filt[1][col+24] = (unsigned char) _mm256_extract_epi8(output_row1_even,24);
		filt[1][col+25] = (unsigned char) _mm256_extract_epi8(output_row1_even,25);
		filt[1][col+26] = (unsigned char) _mm256_extract_epi8(output_row1_even,26);
		filt[1][col+27] = (unsigned char) _mm256_extract_epi8(output_row1_even,27);
		filt[1][col+28] = (unsigned char) _mm256_extract_epi8(output_row1_even,28);
		filt[1][col+29] = (unsigned char) _mm256_extract_epi8(output_row1_even,29);
		  break;
	case 31:
		_mm_storeu_si128( (__m128i *) &filt[2][col],_mm256_extractf128_si256(output_even, 0)); //store low 128bit - 16pixels
		filt[2][col+16] = (unsigned char) _mm256_extract_epi8(output_even,16);
		filt[2][col+17] = (unsigned char) _mm256_extract_epi8(output_even,17);
		filt[2][col+18] = (unsigned char) _mm256_extract_epi8(output_even,18);
		filt[2][col+19] = (unsigned char) _mm256_extract_epi8(output_even,19);
		filt[2][col+20] = (unsigned char) _mm256_extract_epi8(output_even,20);
		filt[2][col+21] = (unsigned char) _mm256_extract_epi8(output_even,21);
		filt[2][col+22] = (unsigned char) _mm256_extract_epi8(output_even,22);
		filt[2][col+23] = (unsigned char) _mm256_extract_epi8(output_even,23);
		filt[2][col+24] = (unsigned char) _mm256_extract_epi8(output_even,24);
		filt[2][col+25] = (unsigned char) _mm256_extract_epi8(output_even,25);
		filt[2][col+26] = (unsigned char) _mm256_extract_epi8(output_even,26);
		filt[2][col+27] = (unsigned char) _mm256_extract_epi8(output_even,27);
		filt[2][col+28] = (unsigned char) _mm256_extract_epi8(output_even,28);
		filt[2][col+29] = (unsigned char) _mm256_extract_epi8(output_even,29);

		_mm_storeu_si128( (__m128i *) &filt[0][col],_mm256_extractf128_si256(output_row0_even, 0)); //store low 128bit - 16pixels
		filt[0][col+16] = (unsigned char) _mm256_extract_epi8(output_row0_even,16);
		filt[0][col+17] = (unsigned char) _mm256_extract_epi8(output_row0_even,17);
		filt[0][col+18] = (unsigned char) _mm256_extract_epi8(output_row0_even,18);
		filt[0][col+19] = (unsigned char) _mm256_extract_epi8(output_row0_even,19);
		filt[0][col+20] = (unsigned char) _mm256_extract_epi8(output_row0_even,20);
		filt[0][col+21] = (unsigned char) _mm256_extract_epi8(output_row0_even,21);
		filt[0][col+22] = (unsigned char) _mm256_extract_epi8(output_row0_even,22);
		filt[0][col+23] = (unsigned char) _mm256_extract_epi8(output_row0_even,23);
		filt[0][col+24] = (unsigned char) _mm256_extract_epi8(output_row0_even,24);
		filt[0][col+25] = (unsigned char) _mm256_extract_epi8(output_row0_even,25);
		filt[0][col+26] = (unsigned char) _mm256_extract_epi8(output_row0_even,26);
		filt[0][col+27] = (unsigned char) _mm256_extract_epi8(output_row0_even,27);
		filt[0][col+28] = (unsigned char) _mm256_extract_epi8(output_row0_even,28);
		filt[0][col+29] = (unsigned char) _mm256_extract_epi8(output_row0_even,29);


		_mm_storeu_si128( (__m128i *) &filt[1][col],_mm256_extractf128_si256(output_row1_even, 0)); //store low 128bit - 16pixels
		filt[1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1_even,16);
		filt[1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1_even,17);
		filt[1][col+18] = (unsigned char) _mm256_extract_epi8(output_row1_even,18);
		filt[1][col+19] = (unsigned char) _mm256_extract_epi8(output_row1_even,19);
		filt[1][col+20] = (unsigned char) _mm256_extract_epi8(output_row1_even,20);
		filt[1][col+21] = (unsigned char) _mm256_extract_epi8(output_row1_even,21);
		filt[1][col+22] = (unsigned char) _mm256_extract_epi8(output_row1_even,22);
		filt[1][col+23] = (unsigned char) _mm256_extract_epi8(output_row1_even,23);
		filt[1][col+24] = (unsigned char) _mm256_extract_epi8(output_row1_even,24);
		filt[1][col+25] = (unsigned char) _mm256_extract_epi8(output_row1_even,25);
		filt[1][col+26] = (unsigned char) _mm256_extract_epi8(output_row1_even,26);
		filt[1][col+27] = (unsigned char) _mm256_extract_epi8(output_row1_even,27);
		filt[1][col+28] = (unsigned char) _mm256_extract_epi8(output_row1_even,28);
		filt[1][col+29] = (unsigned char) _mm256_extract_epi8(output_row1_even,29);

		//the filt[0:2][M-1] pixel will be computed without vectorization
		int newPixel;
		for (int row=0;row<=2;row++){
		 newPixel = 0;
		for (int rowOffset=-2; rowOffset<=2; rowOffset++) {
			for (int colOffset=-2; colOffset<=2; colOffset++) {

			   if ( ((row+rowOffset)<N) && ((M-1+colOffset)<M) && ((row+rowOffset)>=0) && ((M-1+colOffset)>=0) )
	              newPixel += frame1[row+rowOffset][M-1+colOffset] * filter[2 + rowOffset][2 + colOffset];

			      }
		        }

	   filt[row][M-1] = (unsigned char) (newPixel / divisor);
		}

		  break;
	default:
		printf("\n something went wrong");
	}

return 0;

}





//for row=N-3,N-2,N-1 only
//row0 refers to N-2, while row1 refers to N-1
int loop_reminder_last_less_div(unsigned char **frame1,unsigned char **filt,const unsigned int M, const unsigned int N, const unsigned int col, const unsigned int REMINDER_ITERATIONS,const unsigned int division_case,const __m256i c0,const __m256i c1,const __m256i c2,const __m256i c0_sh1,const __m256i c1_sh1,const __m256i c2_sh1,const __m256i c0_sh2,const __m256i c1_sh2,const __m256i c2_sh2, const __m256i f, const unsigned short int divisor,unsigned char **filter ){

__m256i r0,r1,r2,r3,r4,m0,m1,m2,m3,m4;
__m256i output_even,output_odd;
__m256i output_row0_even,output_row1_even,output_row0_odd,output_row1_odd;

		//const __m256i f  = _mm256_set_epi16(52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759,52759);
		//const __m256i mask  = _mm256_set_epi8(0,0,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255);
		//const __m256i mask2  = _mm256_set_epi8(0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0,0,0,0,255,0,0);
		const __m256i mask3  = _mm256_set_epi16(0,0,0,0,0,0,0,65535,0,0,0,0,0,0,0,0);
		//const __m256i mask4  = _mm256_set_epi8(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,255,0,0,0,0,0,0,0,0,0,0,0,0);
		//const __m256i mask5  = _mm256_set_epi8(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0);

		const __m256i output_mask      = _mm256_set_epi16(0,0,0,65535,0,0,65535,0,0,65535,0,0,65535,0,0,65535);
		const __m256i output_mask_sh1  = _mm256_set_epi16(0,0,65535,0,0,65535,0,0,65535,0,0,65535,0,0,65535,0);
		//const __m256i output_mask_sh2  = _mm256_set_epi16(0,0,0,    0,65535,0,0,65535,0,0,65535,0,0,65535,0,0);
		const __m256i mask_new      = _mm256_set_epi16(0,0,0,0,0,0,0,0,0,65535,0,0,0,0,0,0);
		const __m256i mask_new2      = _mm256_set_epi16(0,0,0,0,0,0,0,0,65535,0,0,0,0,0,0,0);



 __m256i reminder_mask1,reminder_mask2;

	reminder_mask1=_mm256_load_si256( (__m256i *) &reminder_msk1[REMINDER_ITERATIONS-1][0]);
	reminder_mask2=_mm256_load_si256( (__m256i *) &reminder_msk2[REMINDER_ITERATIONS-1][0]);


	 //1st col iteration
	//load the 5 rows
	r0=_mm256_loadu_si256( (__m256i *) &frame1[N-5][col-2]);
	r1=_mm256_loadu_si256( (__m256i *) &frame1[N-4][col-2]);
	r2=_mm256_loadu_si256( (__m256i *) &frame1[N-3][col-2]);
	r3=_mm256_loadu_si256( (__m256i *) &frame1[N-2][col-2]);
	r4=_mm256_loadu_si256( (__m256i *) &frame1[N-1][col-2]);

	/*
	 * The above load operations load outside of the array bounds; these elements are filled with zeros just after
	 * Furthermore, I add two extra zeros in the end to compute col=N-2 and col=N-1. The last value of col is N-1, not N
	 */

	//AND r0-r4 with reminder_mask
	r0=_mm256_and_si256(r0,reminder_mask1);
	r1=_mm256_and_si256(r1,reminder_mask1);
	r2=_mm256_and_si256(r2,reminder_mask1);
	r3=_mm256_and_si256(r3,reminder_mask1);
	r4=_mm256_and_si256(r4,reminder_mask1);

	//row=2
	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c0);
	m1=_mm256_maddubs_epi16(r1,c1);
	m2=_mm256_maddubs_epi16(r2,c2);
	m3=_mm256_maddubs_epi16(r3,c1);
	m4=_mm256_maddubs_epi16(r4,c0);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m2=_mm256_add_epi16(m2,m3);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m4);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m4=_mm256_and_si256(m0,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

	m2=_mm256_add_epi16(m2,m4);

	//m2 has 16 16bit values now. the results I need are in positions 0,3,6,9,12. keep only those, discard others
	output_even=_mm256_and_si256(m2,output_mask);

	//row=0
	//multiply with the mask
	m1=_mm256_maddubs_epi16(r1,c0);
	m2=_mm256_maddubs_epi16(r2,c1);
	m3=_mm256_maddubs_epi16(r3,c2);
	m4=_mm256_maddubs_epi16(r4,c1);

	//vertical add
	m0=_mm256_add_epi16(m1,m2);
	m0=_mm256_add_epi16(m0,m3);
	m0=_mm256_add_epi16(m0,m4);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m4=_mm256_and_si256(m0,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

	m2=_mm256_add_epi16(m2,m4);

	//m2 has 16 16bit values now. the results I need are in positions 0,3,6,9,12. keep only those, discard others
	output_row0_even=_mm256_and_si256(m2,output_mask);


	//row=1
	//multiply with the mask
	m2=_mm256_maddubs_epi16(r2,c0);
	m3=_mm256_maddubs_epi16(r3,c1);
	m4=_mm256_maddubs_epi16(r4,c2);

	//vertical add
	m0=_mm256_add_epi16(m2,m3);
	m0=_mm256_add_epi16(m0,m4);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m4=_mm256_and_si256(m0,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

	m2=_mm256_add_epi16(m2,m4);

	//m2 has 16 16bit values now. the results I need are in positions 0,3,6,9,12. keep only those, discard others
	output_row1_even=_mm256_and_si256(m2,output_mask);

	//2nd col iteration

	//row=2
	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c0_sh1);
	m1=_mm256_maddubs_epi16(r1,c1_sh1);
	m2=_mm256_maddubs_epi16(r2,c2_sh1);
	m3=_mm256_maddubs_epi16(r3,c1_sh1);
	m4=_mm256_maddubs_epi16(r4,c0_sh1);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m2=_mm256_add_epi16(m2,m3);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m4);

	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m4=_mm256_and_si256(m0,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
	m2=_mm256_add_epi16(m2,m4);

	//m2 has 16 16bit values now. the results I need are in positions 0,3,6,9,12. keep only those, discard others
	output_odd = _mm256_and_si256(m2,output_mask);

	//row=0
	//multiply with the mask
	m1=_mm256_maddubs_epi16(r1,c0_sh1);
	m2=_mm256_maddubs_epi16(r2,c1_sh1);
	m3=_mm256_maddubs_epi16(r3,c2_sh1);
	m4=_mm256_maddubs_epi16(r4,c1_sh1);

	//vertical add
	m0=_mm256_add_epi16(m1,m2);
	m0=_mm256_add_epi16(m0,m3);
	m0=_mm256_add_epi16(m0,m4);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m4=_mm256_and_si256(m0,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
	m2=_mm256_add_epi16(m2,m4);

	//m2 has 16 16bit values now. the results I need are in positions 0,3,6,9,12. keep only those, discard others
	output_row0_odd = _mm256_and_si256(m2,output_mask);

	//row=1
	//multiply with the mask
	m2=_mm256_maddubs_epi16(r2,c0_sh1);
	m3=_mm256_maddubs_epi16(r3,c1_sh1);
	m4=_mm256_maddubs_epi16(r4,c2_sh1);

	//vertical add
	m0=_mm256_add_epi16(m2,m3);
	m0=_mm256_add_epi16(m0,m4);

	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m4=_mm256_and_si256(m0,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions
	m2=_mm256_add_epi16(m2,m4);

	//m2 has 16 16bit values now. the results I need are in positions 0,3,6,9,12. keep only those, discard others
	output_row1_odd = _mm256_and_si256(m2,output_mask);

             //3rd col iteration

	//row=2
	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c0_sh2);
	m1=_mm256_maddubs_epi16(r1,c1_sh2);
	m2=_mm256_maddubs_epi16(r2,c2_sh2);
	m3=_mm256_maddubs_epi16(r3,c1_sh2);
	m4=_mm256_maddubs_epi16(r4,c0_sh2);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m2=_mm256_add_epi16(m2,m3);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m4);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
	m4=_mm256_and_si256(m2,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

	m2=_mm256_add_epi16(m2,m4);

	//m2 has 16 16bit values now. the results I need are in positions 1,4,7,10,13. keep only those, discard others
	m2 = _mm256_and_si256(m2,output_mask_sh1);
	output_even = _mm256_add_epi16(output_even,m2);

	//row=0
	//multiply with the mask
	m1=_mm256_maddubs_epi16(r1,c0_sh2);
	m2=_mm256_maddubs_epi16(r2,c1_sh2);
	m3=_mm256_maddubs_epi16(r3,c2_sh2);
	m4=_mm256_maddubs_epi16(r4,c1_sh2);

	//vertical add
	m0=_mm256_add_epi16(m1,m2);
	m0=_mm256_add_epi16(m0,m3);
	m0=_mm256_add_epi16(m0,m4);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
	m4=_mm256_and_si256(m2,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

	m2=_mm256_add_epi16(m2,m4);

	//m2 has 16 16bit values now. the results I need are in positions 1,4,7,10,13. keep only those, discard others
	m2 = _mm256_and_si256(m2,output_mask_sh1);
	output_row0_even = _mm256_add_epi16(output_row0_even,m2);

	//row=1
	//multiply with the mask
	m2=_mm256_maddubs_epi16(r2,c0_sh2);
	m3=_mm256_maddubs_epi16(r3,c1_sh2);
	m4=_mm256_maddubs_epi16(r4,c2_sh2);

	//vertical add
	m0=_mm256_add_epi16(m2,m3);
	m0=_mm256_add_epi16(m0,m4);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
	m4=_mm256_and_si256(m2,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto r2 kai meta na kanw diairesi me ola mazi

	m2=_mm256_add_epi16(m2,m4);

	//m2 has 16 16bit values now. the results I need are in positions 1,4,7,10,13. keep only those, discard others
	m2 = _mm256_and_si256(m2,output_mask_sh1);
	output_row1_even = _mm256_add_epi16(output_row1_even,m2);

	//4th col iteration
	//load the 5 rows
	r0=_mm256_loadu_si256( (__m256i *) &frame1[N-5][col+3-2]);
	r1=_mm256_loadu_si256( (__m256i *) &frame1[N-4][col+3-2]);
	r2=_mm256_loadu_si256( (__m256i *) &frame1[N-3][col+3-2]);
	r3=_mm256_loadu_si256( (__m256i *) &frame1[N-2][col+3-2]);
	r4=_mm256_loadu_si256( (__m256i *) &frame1[N-1][col+3-2]);

	//AND r0-r4 with reminder_mask
	r0=_mm256_and_si256(r0,reminder_mask2);
	r1=_mm256_and_si256(r1,reminder_mask2);
	r2=_mm256_and_si256(r2,reminder_mask2);
	r3=_mm256_and_si256(r3,reminder_mask2);
	r4=_mm256_and_si256(r4,reminder_mask2);

	//row=2
	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c0);
	m1=_mm256_maddubs_epi16(r1,c1);
	m2=_mm256_maddubs_epi16(r2,c2);
	m3=_mm256_maddubs_epi16(r3,c1);
	m4=_mm256_maddubs_epi16(r4,c0);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m2=_mm256_add_epi16(m2,m3);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m4);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m4=_mm256_and_si256(m0,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

	m2=_mm256_add_epi16(m2,m4);

	//m2 has 16 16bit values now. the results I need are in positions 1,4,7,10,13. keep only those, discard others
	m2 = _mm256_and_si256(m2,output_mask);
	m2 = _mm256_slli_si256(m2,2);
	output_odd = _mm256_add_epi16(output_odd,m2);

	//row=0
	//multiply with the mask
	m1=_mm256_maddubs_epi16(r1,c0);
	m2=_mm256_maddubs_epi16(r2,c1);
	m3=_mm256_maddubs_epi16(r3,c2);
	m4=_mm256_maddubs_epi16(r4,c1);

	//vertical add
	m0=_mm256_add_epi16(m1,m2);
	m0=_mm256_add_epi16(m0,m3);
	m0=_mm256_add_epi16(m0,m4);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m4=_mm256_and_si256(m0,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

	m2=_mm256_add_epi16(m2,m4);

	//m2 has 16 16bit values now. the results I need are in positions 1,4,7,10,13. keep only those, discard others
	m2 = _mm256_and_si256(m2,output_mask);
	m2 = _mm256_slli_si256(m2,2);
	output_row0_odd = _mm256_add_epi16(output_row0_odd,m2);

	//row=1
	//multiply with the mask
	m2=_mm256_maddubs_epi16(r2,c0);
	m3=_mm256_maddubs_epi16(r3,c1);
	m4=_mm256_maddubs_epi16(r4,c2);

	//vertical add
	m0=_mm256_add_epi16(m2,m3);
	m0=_mm256_add_epi16(m0,m4);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m4=_mm256_and_si256(m0,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

	m2=_mm256_add_epi16(m2,m4);

	//m2 has 16 16bit values now. the results I need are in positions 1,4,7,10,13. keep only those, discard others
	m2 = _mm256_and_si256(m2,output_mask);
	m2 = _mm256_slli_si256(m2,2);
	output_row1_odd = _mm256_add_epi16(output_row1_odd,m2);

	//5th col iteration

	//row=2
	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c0_sh1);
	m1=_mm256_maddubs_epi16(r1,c1_sh1);
	m2=_mm256_maddubs_epi16(r2,c2_sh1);
	m3=_mm256_maddubs_epi16(r3,c1_sh1);
	m4=_mm256_maddubs_epi16(r4,c0_sh1);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m2=_mm256_add_epi16(m2,m3);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m4);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m4=_mm256_and_si256(m0,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

	m2=_mm256_add_epi16(m2,m4);

	//m2 has 16 16bit values now.
	m2 = _mm256_and_si256(m2,output_mask); //holds results in positions 0,3,6,9,12
	m1 = _mm256_slli_si256(m2,4); //put results in positions 2,5,8,11,14 , but 8 is not written
	m2=_mm256_and_si256(m2,mask_new);//extract only the 6th
	m2=_mm256_permute2f128_si256(m2,m2,1);
	m2=_mm256_srli_si256(m2,12);
	m2 = _mm256_add_epi16(m1,m2);
	output_even = _mm256_add_epi16(output_even,m2);

	//row=0
	//multiply with the mask
	m1=_mm256_maddubs_epi16(r1,c0_sh1);
	m2=_mm256_maddubs_epi16(r2,c1_sh1);
	m3=_mm256_maddubs_epi16(r3,c2_sh1);
	m4=_mm256_maddubs_epi16(r4,c1_sh1);

	//vertical add
	m0=_mm256_add_epi16(m1,m2);
	m0=_mm256_add_epi16(m0,m3);
	m0=_mm256_add_epi16(m0,m4);



	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m4=_mm256_and_si256(m0,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

	m2=_mm256_add_epi16(m2,m4);

	//m2 has 16 16bit values now.
	m2 = _mm256_and_si256(m2,output_mask); //holds results in positions 0,3,6,9,12
	m1 = _mm256_slli_si256(m2,4); //put results in positions 2,5,8,11,14 , but 8 is not written
	m2=_mm256_and_si256(m2,mask_new);//extract only the 6th
	m2=_mm256_permute2f128_si256(m2,m2,1);
	m2=_mm256_srli_si256(m2,12);
	m2 = _mm256_add_epi16(m1,m2);
	output_row0_even = _mm256_add_epi16(output_row0_even,m2);

	//row=1
	//multiply with the mask
	m2=_mm256_maddubs_epi16(r2,c0_sh1);
	m3=_mm256_maddubs_epi16(r3,c1_sh1);
	m4=_mm256_maddubs_epi16(r4,c2_sh1);

	//vertical add
	m0=_mm256_add_epi16(m2,m3);
	m0=_mm256_add_epi16(m0,m4);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);

	//prepei na prosthesw to pixel pu thelw sto m4 kai meta na kanw diairesi me ola mazi
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,0,_mm256_extract_epi16(m0,8),0,0,0,0,0,0);
	m4=_mm256_and_si256(m0,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,12);//shift 6 short int positions or 12 char positions

	m2=_mm256_add_epi16(m2,m4);

	//m2 has 16 16bit values now.
	m2 = _mm256_and_si256(m2,output_mask); //holds results in positions 0,3,6,9,12
	m1 = _mm256_slli_si256(m2,4); //put results in positions 2,5,8,11,14 , but 8 is not written
	m2=_mm256_and_si256(m2,mask_new);//extract only the 6th
	m2=_mm256_permute2f128_si256(m2,m2,1);
	m2=_mm256_srli_si256(m2,12);
	m2 = _mm256_add_epi16(m1,m2);
	output_row1_even = _mm256_add_epi16(output_row1_even,m2);

             //6th col iteration
	//row=2
	//multiply with the mask
	m0=_mm256_maddubs_epi16(r0,c0_sh2);
	m1=_mm256_maddubs_epi16(r1,c1_sh2);
	m2=_mm256_maddubs_epi16(r2,c2_sh2);
	m3=_mm256_maddubs_epi16(r3,c1_sh2);
	m4=_mm256_maddubs_epi16(r4,c0_sh2);

	//vertical add
	m0=_mm256_add_epi16(m0,m1);
	m2=_mm256_add_epi16(m2,m3);
	m0=_mm256_add_epi16(m0,m2);
	m0=_mm256_add_epi16(m0,m4);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
	m4=_mm256_and_si256(m2,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);
	m2=_mm256_add_epi16(m2,m4);

	//m2 has 16 16bit values now.
	m2 = _mm256_and_si256(m2,output_mask_sh1);//holds results in positions 1,4,7,10,13
	m1 = _mm256_slli_si256(m2,2); //put results in positions 2,5,8,11,14 , but 8 is not written
	m2=_mm256_and_si256(m2,mask_new2);//extract only the 7th
	m2=_mm256_permute2f128_si256(m2,m2,1);
	m2=_mm256_srli_si256(m2,14);
	m2 = _mm256_add_epi16(m1,m2);
	output_odd = _mm256_add_epi16(output_odd,m2);


	//now division follows
	output_even=division(division_case,output_even,f);
	output_odd=division(division_case,output_odd,f);

	//shift odd 1 position and add to even
	output_odd = _mm256_slli_si256(output_odd,1);
	output_even = _mm256_add_epi8(output_even,output_odd);

	//row=0
	//multiply with the mask
	m1=_mm256_maddubs_epi16(r1,c0_sh2);
	m2=_mm256_maddubs_epi16(r2,c1_sh2);
	m3=_mm256_maddubs_epi16(r3,c2_sh2);
	m4=_mm256_maddubs_epi16(r4,c1_sh2);

	//vertical add
	m0=_mm256_add_epi16(m1,m2);
	m0=_mm256_add_epi16(m0,m3);
	m0=_mm256_add_epi16(m0,m4);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
	m4=_mm256_and_si256(m2,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);
	m2=_mm256_add_epi16(m2,m4);

	//m2 has 16 16bit values now.
	m2 = _mm256_and_si256(m2,output_mask_sh1);//holds results in positions 1,4,7,10,13
	m1 = _mm256_slli_si256(m2,2); //put results in positions 2,5,8,11,14 , but 8 is not written
	m2=_mm256_and_si256(m2,mask_new2);//extract only the 7th
	m2=_mm256_permute2f128_si256(m2,m2,1);
	m2=_mm256_srli_si256(m2,14);
	m2 = _mm256_add_epi16(m1,m2);
	output_row0_odd = _mm256_add_epi16(output_row0_odd,m2);


	//now division follows
	output_row0_even=division(division_case,output_row0_even,f);
	output_row0_odd=division(division_case,output_row0_odd,f);

	//shift odd 1 position and add to even
	output_row0_odd = _mm256_slli_si256(output_row0_odd,1);
	output_row0_even = _mm256_add_epi8(output_row0_even,output_row0_odd);

	//row=1
	//multiply with the mask
	m2=_mm256_maddubs_epi16(r2,c0_sh2);
	m3=_mm256_maddubs_epi16(r3,c1_sh2);
	m4=_mm256_maddubs_epi16(r4,c2_sh2);

	//vertical add
	m0=_mm256_add_epi16(m2,m3);
	m0=_mm256_add_epi16(m0,m4);


	m1=_mm256_srli_si256(m0,2);
	m2=_mm256_add_epi16(m1,m0);
	//m4=_mm256_set_epi16(0,0,0,0,0,0,0,0,_mm256_extract_epi16(m2,8),0,0,0,0,0,0,0);
	m4=_mm256_and_si256(m2,mask3);
	m4=_mm256_permute2f128_si256(m4,m4,1);
	m4=_mm256_slli_si256(m4,14);//shift 7 short int positions or 14 char positions

	m1=_mm256_srli_si256(m0,4);
	m2=_mm256_add_epi16(m1,m2);
	m2=_mm256_add_epi16(m2,m4);

	//m2 has 16 16bit values now.
	m2 = _mm256_and_si256(m2,output_mask_sh1);//holds results in positions 1,4,7,10,13
	m1 = _mm256_slli_si256(m2,2); //put results in positions 2,5,8,11,14 , but 8 is not written
	m2=_mm256_and_si256(m2,mask_new2);//extract only the 7th
	m2=_mm256_permute2f128_si256(m2,m2,1);
	m2=_mm256_srli_si256(m2,14);
	m2 = _mm256_add_epi16(m1,m2);
	output_row1_odd = _mm256_add_epi16(output_row1_odd,m2);


	//now division follows
	output_row1_even=division(division_case,output_row1_even,f);
	output_row1_odd=division(division_case,output_row1_odd,f);

	//shift odd 1 position and add to even
	output_row1_odd = _mm256_slli_si256(output_row1_odd,1);
	output_row1_even = _mm256_add_epi8(output_row1_even,output_row1_odd);




	switch (REMINDER_ITERATIONS){
	case 1:
		filt[N-3][col] = (unsigned char) _mm256_extract_epi8(output_even,0);
		filt[N-2][col] = (unsigned char) _mm256_extract_epi8(output_row0_even,0);
		filt[N-1][col] = (unsigned char) _mm256_extract_epi8(output_row1_even,0);
		 break;
	case 2:
		filt[N-3][col] = (unsigned char) _mm256_extract_epi8(output_even,0);
		filt[N-3][col+1] = (unsigned char) _mm256_extract_epi8(output_even,1);

		filt[N-2][col] = (unsigned char) _mm256_extract_epi8(output_row0_even,0);
		filt[N-2][col+1] = (unsigned char) _mm256_extract_epi8(output_row0_even,1);

		filt[N-1][col] = (unsigned char) _mm256_extract_epi8(output_row1_even,0);
		filt[N-1][col+1] = (unsigned char) _mm256_extract_epi8(output_row1_even,1);
		 break;
	case 3:
		filt[N-3][col] = (unsigned char) _mm256_extract_epi8(output_even,0);
		filt[N-3][col+1] = (unsigned char) _mm256_extract_epi8(output_even,1);
		filt[N-3][col+2] = (unsigned char) _mm256_extract_epi8(output_even,2);

		filt[N-2][col] = (unsigned char) _mm256_extract_epi8(output_row0_even,0);
		filt[N-2][col+1] = (unsigned char) _mm256_extract_epi8(output_row0_even,1);
		filt[N-2][col+2] = (unsigned char) _mm256_extract_epi8(output_row0_even,2);

		filt[N-1][col] = (unsigned char) _mm256_extract_epi8(output_row1_even,0);
		filt[N-1][col+1] = (unsigned char) _mm256_extract_epi8(output_row1_even,1);
		filt[N-1][col+2] = (unsigned char) _mm256_extract_epi8(output_row1_even,2);
		  break;
	case 4:
		filt[N-3][col] = (unsigned char) _mm256_extract_epi8(output_even,0);
		filt[N-3][col+1] = (unsigned char) _mm256_extract_epi8(output_even,1);
		filt[N-3][col+2] = (unsigned char) _mm256_extract_epi8(output_even,2);
		filt[N-3][col+3] = (unsigned char) _mm256_extract_epi8(output_even,3);

		filt[N-2][col] = (unsigned char) _mm256_extract_epi8(output_row0_even,0);
		filt[N-2][col+1] = (unsigned char) _mm256_extract_epi8(output_row0_even,1);
		filt[N-2][col+2] = (unsigned char) _mm256_extract_epi8(output_row0_even,2);
		filt[N-2][col+3] = (unsigned char) _mm256_extract_epi8(output_row0_even,3);

		filt[N-1][col] = (unsigned char) _mm256_extract_epi8(output_row1_even,0);
		filt[N-1][col+1] = (unsigned char) _mm256_extract_epi8(output_row1_even,1);
		filt[N-1][col+2] = (unsigned char) _mm256_extract_epi8(output_row1_even,2);
		filt[N-1][col+3] = (unsigned char) _mm256_extract_epi8(output_row1_even,3);
		  break;
	case 5:
		filt[N-3][col] = (unsigned char) _mm256_extract_epi8(output_even,0);
		filt[N-3][col+1] = (unsigned char) _mm256_extract_epi8(output_even,1);
		filt[N-3][col+2] = (unsigned char) _mm256_extract_epi8(output_even,2);
		filt[N-3][col+3] = (unsigned char) _mm256_extract_epi8(output_even,3);
		filt[N-3][col+4] = (unsigned char) _mm256_extract_epi8(output_even,4);

		filt[N-2][col] = (unsigned char) _mm256_extract_epi8(output_row0_even,0);
		filt[N-2][col+1] = (unsigned char) _mm256_extract_epi8(output_row0_even,1);
		filt[N-2][col+2] = (unsigned char) _mm256_extract_epi8(output_row0_even,2);
		filt[N-2][col+3] = (unsigned char) _mm256_extract_epi8(output_row0_even,3);
		filt[N-2][col+4] = (unsigned char) _mm256_extract_epi8(output_row0_even,4);

		filt[N-1][col] = (unsigned char) _mm256_extract_epi8(output_row1_even,0);
		filt[N-1][col+1] = (unsigned char) _mm256_extract_epi8(output_row1_even,1);
		filt[N-1][col+2] = (unsigned char) _mm256_extract_epi8(output_row1_even,2);
		filt[N-1][col+3] = (unsigned char) _mm256_extract_epi8(output_row1_even,3);
		filt[N-1][col+4] = (unsigned char) _mm256_extract_epi8(output_row1_even,4);
		  break;
	case 6:
		filt[N-3][col] = (unsigned char) _mm256_extract_epi8(output_even,0);
		filt[N-3][col+1] = (unsigned char) _mm256_extract_epi8(output_even,1);
		filt[N-3][col+2] = (unsigned char) _mm256_extract_epi8(output_even,2);
		filt[N-3][col+3] = (unsigned char) _mm256_extract_epi8(output_even,3);
		filt[N-3][col+4] = (unsigned char) _mm256_extract_epi8(output_even,4);
		filt[N-3][col+5] = (unsigned char) _mm256_extract_epi8(output_even,5);

		filt[N-2][col] = (unsigned char) _mm256_extract_epi8(output_row0_even,0);
		filt[N-2][col+1] = (unsigned char) _mm256_extract_epi8(output_row0_even,1);
		filt[N-2][col+2] = (unsigned char) _mm256_extract_epi8(output_row0_even,2);
		filt[N-2][col+3] = (unsigned char) _mm256_extract_epi8(output_row0_even,3);
		filt[N-2][col+4] = (unsigned char) _mm256_extract_epi8(output_row0_even,4);
		filt[N-2][col+5] = (unsigned char) _mm256_extract_epi8(output_row0_even,5);

		filt[N-1][col] = (unsigned char) _mm256_extract_epi8(output_row1_even,0);
		filt[N-1][col+1] = (unsigned char) _mm256_extract_epi8(output_row1_even,1);
		filt[N-1][col+2] = (unsigned char) _mm256_extract_epi8(output_row1_even,2);
		filt[N-1][col+3] = (unsigned char) _mm256_extract_epi8(output_row1_even,3);
		filt[N-1][col+4] = (unsigned char) _mm256_extract_epi8(output_row1_even,4);
		filt[N-1][col+5] = (unsigned char) _mm256_extract_epi8(output_row1_even,5);
		  break;
	case 7:
		filt[N-3][col] = (unsigned char) _mm256_extract_epi8(output_even,0);
		filt[N-3][col+1] = (unsigned char) _mm256_extract_epi8(output_even,1);
		filt[N-3][col+2] = (unsigned char) _mm256_extract_epi8(output_even,2);
		filt[N-3][col+3] = (unsigned char) _mm256_extract_epi8(output_even,3);
		filt[N-3][col+4] = (unsigned char) _mm256_extract_epi8(output_even,4);
		filt[N-3][col+5] = (unsigned char) _mm256_extract_epi8(output_even,5);
		filt[N-3][col+6] = (unsigned char) _mm256_extract_epi8(output_even,6);

		filt[N-2][col] = (unsigned char) _mm256_extract_epi8(output_row0_even,0);
		filt[N-2][col+1] = (unsigned char) _mm256_extract_epi8(output_row0_even,1);
		filt[N-2][col+2] = (unsigned char) _mm256_extract_epi8(output_row0_even,2);
		filt[N-2][col+3] = (unsigned char) _mm256_extract_epi8(output_row0_even,3);
		filt[N-2][col+4] = (unsigned char) _mm256_extract_epi8(output_row0_even,4);
		filt[N-2][col+5] = (unsigned char) _mm256_extract_epi8(output_row0_even,5);
		filt[N-2][col+6] = (unsigned char) _mm256_extract_epi8(output_row0_even,6);

		filt[N-1][col] = (unsigned char) _mm256_extract_epi8(output_row1_even,0);
		filt[N-1][col+1] = (unsigned char) _mm256_extract_epi8(output_row1_even,1);
		filt[N-1][col+2] = (unsigned char) _mm256_extract_epi8(output_row1_even,2);
		filt[N-1][col+3] = (unsigned char) _mm256_extract_epi8(output_row1_even,3);
		filt[N-1][col+4] = (unsigned char) _mm256_extract_epi8(output_row1_even,4);
		filt[N-1][col+5] = (unsigned char) _mm256_extract_epi8(output_row1_even,5);
		filt[N-1][col+6] = (unsigned char) _mm256_extract_epi8(output_row1_even,6);
		  break;
	case 8:
		filt[N-3][col] = (unsigned char) _mm256_extract_epi8(output_even,0);
		filt[N-3][col+1] = (unsigned char) _mm256_extract_epi8(output_even,1);
		filt[N-3][col+2] = (unsigned char) _mm256_extract_epi8(output_even,2);
		filt[N-3][col+3] = (unsigned char) _mm256_extract_epi8(output_even,3);
		filt[N-3][col+4] = (unsigned char) _mm256_extract_epi8(output_even,4);
		filt[N-3][col+5] = (unsigned char) _mm256_extract_epi8(output_even,5);
		filt[N-3][col+6] = (unsigned char) _mm256_extract_epi8(output_even,6);
		filt[N-3][col+7] = (unsigned char) _mm256_extract_epi8(output_even,7);

		filt[N-2][col] = (unsigned char) _mm256_extract_epi8(output_row0_even,0);
		filt[N-2][col+1] = (unsigned char) _mm256_extract_epi8(output_row0_even,1);
		filt[N-2][col+2] = (unsigned char) _mm256_extract_epi8(output_row0_even,2);
		filt[N-2][col+3] = (unsigned char) _mm256_extract_epi8(output_row0_even,3);
		filt[N-2][col+4] = (unsigned char) _mm256_extract_epi8(output_row0_even,4);
		filt[N-2][col+5] = (unsigned char) _mm256_extract_epi8(output_row0_even,5);
		filt[N-2][col+6] = (unsigned char) _mm256_extract_epi8(output_row0_even,6);
		filt[N-2][col+7] = (unsigned char) _mm256_extract_epi8(output_row0_even,7);

		filt[N-1][col] = (unsigned char) _mm256_extract_epi8(output_row1_even,0);
		filt[N-1][col+1] = (unsigned char) _mm256_extract_epi8(output_row1_even,1);
		filt[N-1][col+2] = (unsigned char) _mm256_extract_epi8(output_row1_even,2);
		filt[N-1][col+3] = (unsigned char) _mm256_extract_epi8(output_row1_even,3);
		filt[N-1][col+4] = (unsigned char) _mm256_extract_epi8(output_row1_even,4);
		filt[N-1][col+5] = (unsigned char) _mm256_extract_epi8(output_row1_even,5);
		filt[N-1][col+6] = (unsigned char) _mm256_extract_epi8(output_row1_even,6);
		filt[N-1][col+7] = (unsigned char) _mm256_extract_epi8(output_row1_even,7);
		  break;
	case 9:
		filt[N-3][col] = (unsigned char) _mm256_extract_epi8(output_even,0);
		filt[N-3][col+1] = (unsigned char) _mm256_extract_epi8(output_even,1);
		filt[N-3][col+2] = (unsigned char) _mm256_extract_epi8(output_even,2);
		filt[N-3][col+3] = (unsigned char) _mm256_extract_epi8(output_even,3);
		filt[N-3][col+4] = (unsigned char) _mm256_extract_epi8(output_even,4);
		filt[N-3][col+5] = (unsigned char) _mm256_extract_epi8(output_even,5);
		filt[N-3][col+6] = (unsigned char) _mm256_extract_epi8(output_even,6);
		filt[N-3][col+7] = (unsigned char) _mm256_extract_epi8(output_even,7);
		filt[N-3][col+8] = (unsigned char) _mm256_extract_epi8(output_even,8);

		filt[N-2][col] = (unsigned char) _mm256_extract_epi8(output_row0_even,0);
		filt[N-2][col+1] = (unsigned char) _mm256_extract_epi8(output_row0_even,1);
		filt[N-2][col+2] = (unsigned char) _mm256_extract_epi8(output_row0_even,2);
		filt[N-2][col+3] = (unsigned char) _mm256_extract_epi8(output_row0_even,3);
		filt[N-2][col+4] = (unsigned char) _mm256_extract_epi8(output_row0_even,4);
		filt[N-2][col+5] = (unsigned char) _mm256_extract_epi8(output_row0_even,5);
		filt[N-2][col+6] = (unsigned char) _mm256_extract_epi8(output_row0_even,6);
		filt[N-2][col+7] = (unsigned char) _mm256_extract_epi8(output_row0_even,7);
		filt[N-2][col+8] = (unsigned char) _mm256_extract_epi8(output_row0_even,8);

		filt[N-1][col] = (unsigned char) _mm256_extract_epi8(output_row1_even,0);
		filt[N-1][col+1] = (unsigned char) _mm256_extract_epi8(output_row1_even,1);
		filt[N-1][col+2] = (unsigned char) _mm256_extract_epi8(output_row1_even,2);
		filt[N-1][col+3] = (unsigned char) _mm256_extract_epi8(output_row1_even,3);
		filt[N-1][col+4] = (unsigned char) _mm256_extract_epi8(output_row1_even,4);
		filt[N-1][col+5] = (unsigned char) _mm256_extract_epi8(output_row1_even,5);
		filt[N-1][col+6] = (unsigned char) _mm256_extract_epi8(output_row1_even,6);
		filt[N-1][col+7] = (unsigned char) _mm256_extract_epi8(output_row1_even,7);
		filt[N-1][col+8] = (unsigned char) _mm256_extract_epi8(output_row1_even,8);
		  break;
	case 10:
		filt[N-3][col] = (unsigned char) _mm256_extract_epi8(output_even,0);
		filt[N-3][col+1] = (unsigned char) _mm256_extract_epi8(output_even,1);
		filt[N-3][col+2] = (unsigned char) _mm256_extract_epi8(output_even,2);
		filt[N-3][col+3] = (unsigned char) _mm256_extract_epi8(output_even,3);
		filt[N-3][col+4] = (unsigned char) _mm256_extract_epi8(output_even,4);
		filt[N-3][col+5] = (unsigned char) _mm256_extract_epi8(output_even,5);
		filt[N-3][col+6] = (unsigned char) _mm256_extract_epi8(output_even,6);
		filt[N-3][col+7] = (unsigned char) _mm256_extract_epi8(output_even,7);
		filt[N-3][col+8] = (unsigned char) _mm256_extract_epi8(output_even,8);
		filt[N-3][col+9] = (unsigned char) _mm256_extract_epi8(output_even,9);

		filt[N-2][col] = (unsigned char) _mm256_extract_epi8(output_row0_even,0);
		filt[N-2][col+1] = (unsigned char) _mm256_extract_epi8(output_row0_even,1);
		filt[N-2][col+2] = (unsigned char) _mm256_extract_epi8(output_row0_even,2);
		filt[N-2][col+3] = (unsigned char) _mm256_extract_epi8(output_row0_even,3);
		filt[N-2][col+4] = (unsigned char) _mm256_extract_epi8(output_row0_even,4);
		filt[N-2][col+5] = (unsigned char) _mm256_extract_epi8(output_row0_even,5);
		filt[N-2][col+6] = (unsigned char) _mm256_extract_epi8(output_row0_even,6);
		filt[N-2][col+7] = (unsigned char) _mm256_extract_epi8(output_row0_even,7);
		filt[N-2][col+8] = (unsigned char) _mm256_extract_epi8(output_row0_even,8);
		filt[N-2][col+9] = (unsigned char) _mm256_extract_epi8(output_row0_even,9);

		filt[N-1][col] = (unsigned char) _mm256_extract_epi8(output_row1_even,0);
		filt[N-1][col+1] = (unsigned char) _mm256_extract_epi8(output_row1_even,1);
		filt[N-1][col+2] = (unsigned char) _mm256_extract_epi8(output_row1_even,2);
		filt[N-1][col+3] = (unsigned char) _mm256_extract_epi8(output_row1_even,3);
		filt[N-1][col+4] = (unsigned char) _mm256_extract_epi8(output_row1_even,4);
		filt[N-1][col+5] = (unsigned char) _mm256_extract_epi8(output_row1_even,5);
		filt[N-1][col+6] = (unsigned char) _mm256_extract_epi8(output_row1_even,6);
		filt[N-1][col+7] = (unsigned char) _mm256_extract_epi8(output_row1_even,7);
		filt[N-1][col+8] = (unsigned char) _mm256_extract_epi8(output_row1_even,8);
		filt[N-1][col+9] = (unsigned char) _mm256_extract_epi8(output_row1_even,9);
		  break;
	case 11:
		filt[N-3][col] = (unsigned char) _mm256_extract_epi8(output_even,0);
		filt[N-3][col+1] = (unsigned char) _mm256_extract_epi8(output_even,1);
		filt[N-3][col+2] = (unsigned char) _mm256_extract_epi8(output_even,2);
		filt[N-3][col+3] = (unsigned char) _mm256_extract_epi8(output_even,3);
		filt[N-3][col+4] = (unsigned char) _mm256_extract_epi8(output_even,4);
		filt[N-3][col+5] = (unsigned char) _mm256_extract_epi8(output_even,5);
		filt[N-3][col+6] = (unsigned char) _mm256_extract_epi8(output_even,6);
		filt[N-3][col+7] = (unsigned char) _mm256_extract_epi8(output_even,7);
		filt[N-3][col+8] = (unsigned char) _mm256_extract_epi8(output_even,8);
		filt[N-3][col+9] = (unsigned char) _mm256_extract_epi8(output_even,9);
		filt[N-3][col+10] = (unsigned char) _mm256_extract_epi8(output_even,10);

		filt[N-2][col] = (unsigned char) _mm256_extract_epi8(output_row0_even,0);
		filt[N-2][col+1] = (unsigned char) _mm256_extract_epi8(output_row0_even,1);
		filt[N-2][col+2] = (unsigned char) _mm256_extract_epi8(output_row0_even,2);
		filt[N-2][col+3] = (unsigned char) _mm256_extract_epi8(output_row0_even,3);
		filt[N-2][col+4] = (unsigned char) _mm256_extract_epi8(output_row0_even,4);
		filt[N-2][col+5] = (unsigned char) _mm256_extract_epi8(output_row0_even,5);
		filt[N-2][col+6] = (unsigned char) _mm256_extract_epi8(output_row0_even,6);
		filt[N-2][col+7] = (unsigned char) _mm256_extract_epi8(output_row0_even,7);
		filt[N-2][col+8] = (unsigned char) _mm256_extract_epi8(output_row0_even,8);
		filt[N-2][col+9] = (unsigned char) _mm256_extract_epi8(output_row0_even,9);
		filt[N-2][col+10] = (unsigned char) _mm256_extract_epi8(output_row0_even,10);

		filt[N-1][col] = (unsigned char) _mm256_extract_epi8(output_row1_even,0);
		filt[N-1][col+1] = (unsigned char) _mm256_extract_epi8(output_row1_even,1);
		filt[N-1][col+2] = (unsigned char) _mm256_extract_epi8(output_row1_even,2);
		filt[N-1][col+3] = (unsigned char) _mm256_extract_epi8(output_row1_even,3);
		filt[N-1][col+4] = (unsigned char) _mm256_extract_epi8(output_row1_even,4);
		filt[N-1][col+5] = (unsigned char) _mm256_extract_epi8(output_row1_even,5);
		filt[N-1][col+6] = (unsigned char) _mm256_extract_epi8(output_row1_even,6);
		filt[N-1][col+7] = (unsigned char) _mm256_extract_epi8(output_row1_even,7);
		filt[N-1][col+8] = (unsigned char) _mm256_extract_epi8(output_row1_even,8);
		filt[N-1][col+9] = (unsigned char) _mm256_extract_epi8(output_row1_even,9);
		filt[N-1][col+10] = (unsigned char) _mm256_extract_epi8(output_row1_even,10);
		  break;
	case 12:
		filt[N-3][col] = (unsigned char) _mm256_extract_epi8(output_even,0);
		filt[N-3][col+1] = (unsigned char) _mm256_extract_epi8(output_even,1);
		filt[N-3][col+2] = (unsigned char) _mm256_extract_epi8(output_even,2);
		filt[N-3][col+3] = (unsigned char) _mm256_extract_epi8(output_even,3);
		filt[N-3][col+4] = (unsigned char) _mm256_extract_epi8(output_even,4);
		filt[N-3][col+5] = (unsigned char) _mm256_extract_epi8(output_even,5);
		filt[N-3][col+6] = (unsigned char) _mm256_extract_epi8(output_even,6);
		filt[N-3][col+7] = (unsigned char) _mm256_extract_epi8(output_even,7);
		filt[N-3][col+8] = (unsigned char) _mm256_extract_epi8(output_even,8);
		filt[N-3][col+9] = (unsigned char) _mm256_extract_epi8(output_even,9);
		filt[N-3][col+10] = (unsigned char) _mm256_extract_epi8(output_even,10);
		filt[N-3][col+11] = (unsigned char) _mm256_extract_epi8(output_even,11);

		filt[N-2][col] = (unsigned char) _mm256_extract_epi8(output_row0_even,0);
		filt[N-2][col+1] = (unsigned char) _mm256_extract_epi8(output_row0_even,1);
		filt[N-2][col+2] = (unsigned char) _mm256_extract_epi8(output_row0_even,2);
		filt[N-2][col+3] = (unsigned char) _mm256_extract_epi8(output_row0_even,3);
		filt[N-2][col+4] = (unsigned char) _mm256_extract_epi8(output_row0_even,4);
		filt[N-2][col+5] = (unsigned char) _mm256_extract_epi8(output_row0_even,5);
		filt[N-2][col+6] = (unsigned char) _mm256_extract_epi8(output_row0_even,6);
		filt[N-2][col+7] = (unsigned char) _mm256_extract_epi8(output_row0_even,7);
		filt[N-2][col+8] = (unsigned char) _mm256_extract_epi8(output_row0_even,8);
		filt[N-2][col+9] = (unsigned char) _mm256_extract_epi8(output_row0_even,9);
		filt[N-2][col+10] = (unsigned char) _mm256_extract_epi8(output_row0_even,10);
		filt[N-2][col+11] = (unsigned char) _mm256_extract_epi8(output_row0_even,11);

		filt[N-1][col] = (unsigned char) _mm256_extract_epi8(output_row1_even,0);
		filt[N-1][col+1] = (unsigned char) _mm256_extract_epi8(output_row1_even,1);
		filt[N-1][col+2] = (unsigned char) _mm256_extract_epi8(output_row1_even,2);
		filt[N-1][col+3] = (unsigned char) _mm256_extract_epi8(output_row1_even,3);
		filt[N-1][col+4] = (unsigned char) _mm256_extract_epi8(output_row1_even,4);
		filt[N-1][col+5] = (unsigned char) _mm256_extract_epi8(output_row1_even,5);
		filt[N-1][col+6] = (unsigned char) _mm256_extract_epi8(output_row1_even,6);
		filt[N-1][col+7] = (unsigned char) _mm256_extract_epi8(output_row1_even,7);
		filt[N-1][col+8] = (unsigned char) _mm256_extract_epi8(output_row1_even,8);
		filt[N-1][col+9] = (unsigned char) _mm256_extract_epi8(output_row1_even,9);
		filt[N-1][col+10] = (unsigned char) _mm256_extract_epi8(output_row1_even,10);
		filt[N-1][col+11] = (unsigned char) _mm256_extract_epi8(output_row1_even,11);
		  break;
	case 13:
		filt[N-3][col] = (unsigned char) _mm256_extract_epi8(output_even,0);
		filt[N-3][col+1] = (unsigned char) _mm256_extract_epi8(output_even,1);
		filt[N-3][col+2] = (unsigned char) _mm256_extract_epi8(output_even,2);
		filt[N-3][col+3] = (unsigned char) _mm256_extract_epi8(output_even,3);
		filt[N-3][col+4] = (unsigned char) _mm256_extract_epi8(output_even,4);
		filt[N-3][col+5] = (unsigned char) _mm256_extract_epi8(output_even,5);
		filt[N-3][col+6] = (unsigned char) _mm256_extract_epi8(output_even,6);
		filt[N-3][col+7] = (unsigned char) _mm256_extract_epi8(output_even,7);
		filt[N-3][col+8] = (unsigned char) _mm256_extract_epi8(output_even,8);
		filt[N-3][col+9] = (unsigned char) _mm256_extract_epi8(output_even,9);
		filt[N-3][col+10] = (unsigned char) _mm256_extract_epi8(output_even,10);
		filt[N-3][col+11] = (unsigned char) _mm256_extract_epi8(output_even,11);
		filt[N-3][col+12] = (unsigned char) _mm256_extract_epi8(output_even,12);

		filt[N-2][col] = (unsigned char) _mm256_extract_epi8(output_row0_even,0);
		filt[N-2][col+1] = (unsigned char) _mm256_extract_epi8(output_row0_even,1);
		filt[N-2][col+2] = (unsigned char) _mm256_extract_epi8(output_row0_even,2);
		filt[N-2][col+3] = (unsigned char) _mm256_extract_epi8(output_row0_even,3);
		filt[N-2][col+4] = (unsigned char) _mm256_extract_epi8(output_row0_even,4);
		filt[N-2][col+5] = (unsigned char) _mm256_extract_epi8(output_row0_even,5);
		filt[N-2][col+6] = (unsigned char) _mm256_extract_epi8(output_row0_even,6);
		filt[N-2][col+7] = (unsigned char) _mm256_extract_epi8(output_row0_even,7);
		filt[N-2][col+8] = (unsigned char) _mm256_extract_epi8(output_row0_even,8);
		filt[N-2][col+9] = (unsigned char) _mm256_extract_epi8(output_row0_even,9);
		filt[N-2][col+10] = (unsigned char) _mm256_extract_epi8(output_row0_even,10);
		filt[N-2][col+11] = (unsigned char) _mm256_extract_epi8(output_row0_even,11);
		filt[N-2][col+12] = (unsigned char) _mm256_extract_epi8(output_row0_even,12);

		filt[N-1][col] = (unsigned char) _mm256_extract_epi8(output_row1_even,0);
		filt[N-1][col+1] = (unsigned char) _mm256_extract_epi8(output_row1_even,1);
		filt[N-1][col+2] = (unsigned char) _mm256_extract_epi8(output_row1_even,2);
		filt[N-1][col+3] = (unsigned char) _mm256_extract_epi8(output_row1_even,3);
		filt[N-1][col+4] = (unsigned char) _mm256_extract_epi8(output_row1_even,4);
		filt[N-1][col+5] = (unsigned char) _mm256_extract_epi8(output_row1_even,5);
		filt[N-1][col+6] = (unsigned char) _mm256_extract_epi8(output_row1_even,6);
		filt[N-1][col+7] = (unsigned char) _mm256_extract_epi8(output_row1_even,7);
		filt[N-1][col+8] = (unsigned char) _mm256_extract_epi8(output_row1_even,8);
		filt[N-1][col+9] = (unsigned char) _mm256_extract_epi8(output_row1_even,9);
		filt[N-1][col+10] = (unsigned char) _mm256_extract_epi8(output_row1_even,10);
		filt[N-1][col+11] = (unsigned char) _mm256_extract_epi8(output_row1_even,11);
		filt[N-1][col+12] = (unsigned char) _mm256_extract_epi8(output_row1_even,12);
		  break;
	case 14:
		filt[N-3][col] = (unsigned char) _mm256_extract_epi8(output_even,0);
		filt[N-3][col+1] = (unsigned char) _mm256_extract_epi8(output_even,1);
		filt[N-3][col+2] = (unsigned char) _mm256_extract_epi8(output_even,2);
		filt[N-3][col+3] = (unsigned char) _mm256_extract_epi8(output_even,3);
		filt[N-3][col+4] = (unsigned char) _mm256_extract_epi8(output_even,4);
		filt[N-3][col+5] = (unsigned char) _mm256_extract_epi8(output_even,5);
		filt[N-3][col+6] = (unsigned char) _mm256_extract_epi8(output_even,6);
		filt[N-3][col+7] = (unsigned char) _mm256_extract_epi8(output_even,7);
		filt[N-3][col+8] = (unsigned char) _mm256_extract_epi8(output_even,8);
		filt[N-3][col+9] = (unsigned char) _mm256_extract_epi8(output_even,9);
		filt[N-3][col+10] = (unsigned char) _mm256_extract_epi8(output_even,10);
		filt[N-3][col+11] = (unsigned char) _mm256_extract_epi8(output_even,11);
		filt[N-3][col+12] = (unsigned char) _mm256_extract_epi8(output_even,12);
		filt[N-3][col+13] = (unsigned char) _mm256_extract_epi8(output_even,13);

		filt[N-2][col] = (unsigned char) _mm256_extract_epi8(output_row0_even,0);
		filt[N-2][col+1] = (unsigned char) _mm256_extract_epi8(output_row0_even,1);
		filt[N-2][col+2] = (unsigned char) _mm256_extract_epi8(output_row0_even,2);
		filt[N-2][col+3] = (unsigned char) _mm256_extract_epi8(output_row0_even,3);
		filt[N-2][col+4] = (unsigned char) _mm256_extract_epi8(output_row0_even,4);
		filt[N-2][col+5] = (unsigned char) _mm256_extract_epi8(output_row0_even,5);
		filt[N-2][col+6] = (unsigned char) _mm256_extract_epi8(output_row0_even,6);
		filt[N-2][col+7] = (unsigned char) _mm256_extract_epi8(output_row0_even,7);
		filt[N-2][col+8] = (unsigned char) _mm256_extract_epi8(output_row0_even,8);
		filt[N-2][col+9] = (unsigned char) _mm256_extract_epi8(output_row0_even,9);
		filt[N-2][col+10] = (unsigned char) _mm256_extract_epi8(output_row0_even,10);
		filt[N-2][col+11] = (unsigned char) _mm256_extract_epi8(output_row0_even,11);
		filt[N-2][col+12] = (unsigned char) _mm256_extract_epi8(output_row0_even,12);
		filt[N-2][col+13] = (unsigned char) _mm256_extract_epi8(output_row0_even,13);

		filt[N-1][col] = (unsigned char) _mm256_extract_epi8(output_row1_even,0);
		filt[N-1][col+1] = (unsigned char) _mm256_extract_epi8(output_row1_even,1);
		filt[N-1][col+2] = (unsigned char) _mm256_extract_epi8(output_row1_even,2);
		filt[N-1][col+3] = (unsigned char) _mm256_extract_epi8(output_row1_even,3);
		filt[N-1][col+4] = (unsigned char) _mm256_extract_epi8(output_row1_even,4);
		filt[N-1][col+5] = (unsigned char) _mm256_extract_epi8(output_row1_even,5);
		filt[N-1][col+6] = (unsigned char) _mm256_extract_epi8(output_row1_even,6);
		filt[N-1][col+7] = (unsigned char) _mm256_extract_epi8(output_row1_even,7);
		filt[N-1][col+8] = (unsigned char) _mm256_extract_epi8(output_row1_even,8);
		filt[N-1][col+9] = (unsigned char) _mm256_extract_epi8(output_row1_even,9);
		filt[N-1][col+10] = (unsigned char) _mm256_extract_epi8(output_row1_even,10);
		filt[N-1][col+11] = (unsigned char) _mm256_extract_epi8(output_row1_even,11);
		filt[N-1][col+12] = (unsigned char) _mm256_extract_epi8(output_row1_even,12);
		filt[N-1][col+13] = (unsigned char) _mm256_extract_epi8(output_row1_even,13);
		  break;
	case 15:
		filt[N-3][col] = (unsigned char) _mm256_extract_epi8(output_even,0);
		filt[N-3][col+1] = (unsigned char) _mm256_extract_epi8(output_even,1);
		filt[N-3][col+2] = (unsigned char) _mm256_extract_epi8(output_even,2);
		filt[N-3][col+3] = (unsigned char) _mm256_extract_epi8(output_even,3);
		filt[N-3][col+4] = (unsigned char) _mm256_extract_epi8(output_even,4);
		filt[N-3][col+5] = (unsigned char) _mm256_extract_epi8(output_even,5);
		filt[N-3][col+6] = (unsigned char) _mm256_extract_epi8(output_even,6);
		filt[N-3][col+7] = (unsigned char) _mm256_extract_epi8(output_even,7);
		filt[N-3][col+8] = (unsigned char) _mm256_extract_epi8(output_even,8);
		filt[N-3][col+9] = (unsigned char) _mm256_extract_epi8(output_even,9);
		filt[N-3][col+10] = (unsigned char) _mm256_extract_epi8(output_even,10);
		filt[N-3][col+11] = (unsigned char) _mm256_extract_epi8(output_even,11);
		filt[N-3][col+12] = (unsigned char) _mm256_extract_epi8(output_even,12);
		filt[N-3][col+13] = (unsigned char) _mm256_extract_epi8(output_even,13);
		filt[N-3][col+14] = (unsigned char) _mm256_extract_epi8(output_even,14);

		filt[N-2][col] = (unsigned char) _mm256_extract_epi8(output_row0_even,0);
		filt[N-2][col+1] = (unsigned char) _mm256_extract_epi8(output_row0_even,1);
		filt[N-2][col+2] = (unsigned char) _mm256_extract_epi8(output_row0_even,2);
		filt[N-2][col+3] = (unsigned char) _mm256_extract_epi8(output_row0_even,3);
		filt[N-2][col+4] = (unsigned char) _mm256_extract_epi8(output_row0_even,4);
		filt[N-2][col+5] = (unsigned char) _mm256_extract_epi8(output_row0_even,5);
		filt[N-2][col+6] = (unsigned char) _mm256_extract_epi8(output_row0_even,6);
		filt[N-2][col+7] = (unsigned char) _mm256_extract_epi8(output_row0_even,7);
		filt[N-2][col+8] = (unsigned char) _mm256_extract_epi8(output_row0_even,8);
		filt[N-2][col+9] = (unsigned char) _mm256_extract_epi8(output_row0_even,9);
		filt[N-2][col+10] = (unsigned char) _mm256_extract_epi8(output_row0_even,10);
		filt[N-2][col+11] = (unsigned char) _mm256_extract_epi8(output_row0_even,11);
		filt[N-2][col+12] = (unsigned char) _mm256_extract_epi8(output_row0_even,12);
		filt[N-2][col+13] = (unsigned char) _mm256_extract_epi8(output_row0_even,13);
		filt[N-2][col+14] = (unsigned char) _mm256_extract_epi8(output_row0_even,14);

		filt[N-1][col] = (unsigned char) _mm256_extract_epi8(output_row1_even,0);
		filt[N-1][col+1] = (unsigned char) _mm256_extract_epi8(output_row1_even,1);
		filt[N-1][col+2] = (unsigned char) _mm256_extract_epi8(output_row1_even,2);
		filt[N-1][col+3] = (unsigned char) _mm256_extract_epi8(output_row1_even,3);
		filt[N-1][col+4] = (unsigned char) _mm256_extract_epi8(output_row1_even,4);
		filt[N-1][col+5] = (unsigned char) _mm256_extract_epi8(output_row1_even,5);
		filt[N-1][col+6] = (unsigned char) _mm256_extract_epi8(output_row1_even,6);
		filt[N-1][col+7] = (unsigned char) _mm256_extract_epi8(output_row1_even,7);
		filt[N-1][col+8] = (unsigned char) _mm256_extract_epi8(output_row1_even,8);
		filt[N-1][col+9] = (unsigned char) _mm256_extract_epi8(output_row1_even,9);
		filt[N-1][col+10] = (unsigned char) _mm256_extract_epi8(output_row1_even,10);
		filt[N-1][col+11] = (unsigned char) _mm256_extract_epi8(output_row1_even,11);
		filt[N-1][col+12] = (unsigned char) _mm256_extract_epi8(output_row1_even,12);
		filt[N-1][col+13] = (unsigned char) _mm256_extract_epi8(output_row1_even,13);
		filt[N-1][col+14] = (unsigned char) _mm256_extract_epi8(output_row1_even,14);
		  break;
	case 16:
		_mm_storeu_si128( (__m128i *) &filt[N-3][col],_mm256_extractf128_si256(output_even, 0)); //store low 128bit - 16pixels
		_mm_storeu_si128( (__m128i *) &filt[N-2][col],_mm256_extractf128_si256(output_row0_even, 0)); //store low 128bit - 16pixels
		_mm_storeu_si128( (__m128i *) &filt[N-1][col],_mm256_extractf128_si256(output_row1_even, 0)); //store low 128bit - 16pixels
		  break;
	case 17:
		_mm_storeu_si128( (__m128i *) &filt[N-3][col],_mm256_extractf128_si256(output_even, 0)); //store low 128bit - 16pixels
		filt[N-3][col+16] = (unsigned char) _mm256_extract_epi8(output_even,16);

		_mm_storeu_si128( (__m128i *) &filt[N-2][col],_mm256_extractf128_si256(output_row0_even, 0)); //store low 128bit - 16pixels
		filt[N-2][col+16] = (unsigned char) _mm256_extract_epi8(output_row0_even,16);

		_mm_storeu_si128( (__m128i *) &filt[N-1][col],_mm256_extractf128_si256(output_row1_even, 0)); //store low 128bit - 16pixels
		filt[N-1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1_even,16);
		  break;
	case 18:
		_mm_storeu_si128( (__m128i *) &filt[N-3][col],_mm256_extractf128_si256(output_even, 0)); //store low 128bit - 16pixels
		filt[N-3][col+16] = (unsigned char) _mm256_extract_epi8(output_even,16);
		filt[N-3][col+17] = (unsigned char) _mm256_extract_epi8(output_even,17);

		_mm_storeu_si128( (__m128i *) &filt[N-2][col],_mm256_extractf128_si256(output_row0_even, 0)); //store low 128bit - 16pixels
		filt[N-2][col+16] = (unsigned char) _mm256_extract_epi8(output_row0_even,16);
		filt[N-2][col+17] = (unsigned char) _mm256_extract_epi8(output_row0_even,17);

		_mm_storeu_si128( (__m128i *) &filt[N-1][col],_mm256_extractf128_si256(output_row1_even, 0)); //store low 128bit - 16pixels
		filt[N-1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1_even,16);
		filt[N-1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1_even,17);
		  break;
	case 19:
		_mm_storeu_si128( (__m128i *) &filt[N-3][col],_mm256_extractf128_si256(output_even, 0)); //store low 128bit - 16pixels
		filt[N-3][col+16] = (unsigned char) _mm256_extract_epi8(output_even,16);
		filt[N-3][col+17] = (unsigned char) _mm256_extract_epi8(output_even,17);
		filt[N-3][col+18] = (unsigned char) _mm256_extract_epi8(output_even,18);

		_mm_storeu_si128( (__m128i *) &filt[N-2][col],_mm256_extractf128_si256(output_row0_even, 0)); //store low 128bit - 16pixels
		filt[N-2][col+16] = (unsigned char) _mm256_extract_epi8(output_row0_even,16);
		filt[N-2][col+17] = (unsigned char) _mm256_extract_epi8(output_row0_even,17);
		filt[N-2][col+18] = (unsigned char) _mm256_extract_epi8(output_row0_even,18);

		_mm_storeu_si128( (__m128i *) &filt[N-1][col],_mm256_extractf128_si256(output_row1_even, 0)); //store low 128bit - 16pixels
		filt[N-1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1_even,16);
		filt[N-1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1_even,17);
		filt[N-1][col+18] = (unsigned char) _mm256_extract_epi8(output_row1_even,18);
		  break;
	case 20:
		_mm_storeu_si128( (__m128i *) &filt[N-3][col],_mm256_extractf128_si256(output_even, 0)); //store low 128bit - 16pixels
		filt[N-3][col+16] = (unsigned char) _mm256_extract_epi8(output_even,16);
		filt[N-3][col+17] = (unsigned char) _mm256_extract_epi8(output_even,17);
		filt[N-3][col+18] = (unsigned char) _mm256_extract_epi8(output_even,18);
		filt[N-3][col+19] = (unsigned char) _mm256_extract_epi8(output_even,19);

		_mm_storeu_si128( (__m128i *) &filt[N-2][col],_mm256_extractf128_si256(output_row0_even, 0)); //store low 128bit - 16pixels
		filt[N-2][col+16] = (unsigned char) _mm256_extract_epi8(output_row0_even,16);
		filt[N-2][col+17] = (unsigned char) _mm256_extract_epi8(output_row0_even,17);
		filt[N-2][col+18] = (unsigned char) _mm256_extract_epi8(output_row0_even,18);
		filt[N-2][col+19] = (unsigned char) _mm256_extract_epi8(output_row0_even,19);

		_mm_storeu_si128( (__m128i *) &filt[N-1][col],_mm256_extractf128_si256(output_row1_even, 0)); //store low 128bit - 16pixels
		filt[N-1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1_even,16);
		filt[N-1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1_even,17);
		filt[N-1][col+18] = (unsigned char) _mm256_extract_epi8(output_row1_even,18);
		filt[N-1][col+19] = (unsigned char) _mm256_extract_epi8(output_row1_even,19);
		  break;
	case 21:
		_mm_storeu_si128( (__m128i *) &filt[N-3][col],_mm256_extractf128_si256(output_even, 0)); //store low 128bit - 16pixels
		filt[N-3][col+16] = (unsigned char) _mm256_extract_epi8(output_even,16);
		filt[N-3][col+17] = (unsigned char) _mm256_extract_epi8(output_even,17);
		filt[N-3][col+18] = (unsigned char) _mm256_extract_epi8(output_even,18);
		filt[N-3][col+19] = (unsigned char) _mm256_extract_epi8(output_even,19);
		filt[N-3][col+20] = (unsigned char) _mm256_extract_epi8(output_even,20);

		_mm_storeu_si128( (__m128i *) &filt[N-2][col],_mm256_extractf128_si256(output_row0_even, 0)); //store low 128bit - 16pixels
		filt[N-2][col+16] = (unsigned char) _mm256_extract_epi8(output_row0_even,16);
		filt[N-2][col+17] = (unsigned char) _mm256_extract_epi8(output_row0_even,17);
		filt[N-2][col+18] = (unsigned char) _mm256_extract_epi8(output_row0_even,18);
		filt[N-2][col+19] = (unsigned char) _mm256_extract_epi8(output_row0_even,19);
		filt[N-2][col+20] = (unsigned char) _mm256_extract_epi8(output_row0_even,20);

		_mm_storeu_si128( (__m128i *) &filt[N-1][col],_mm256_extractf128_si256(output_row1_even, 0)); //store low 128bit - 16pixels
		filt[N-1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1_even,16);
		filt[N-1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1_even,17);
		filt[N-1][col+18] = (unsigned char) _mm256_extract_epi8(output_row1_even,18);
		filt[N-1][col+19] = (unsigned char) _mm256_extract_epi8(output_row1_even,19);
		filt[N-1][col+20] = (unsigned char) _mm256_extract_epi8(output_row1_even,20);
		  break;
	case 22:
		_mm_storeu_si128( (__m128i *) &filt[N-3][col],_mm256_extractf128_si256(output_even, 0)); //store low 128bit - 16pixels
		filt[N-3][col+16] = (unsigned char) _mm256_extract_epi8(output_even,16);
		filt[N-3][col+17] = (unsigned char) _mm256_extract_epi8(output_even,17);
		filt[N-3][col+18] = (unsigned char) _mm256_extract_epi8(output_even,18);
		filt[N-3][col+19] = (unsigned char) _mm256_extract_epi8(output_even,19);
		filt[N-3][col+20] = (unsigned char) _mm256_extract_epi8(output_even,20);
		filt[N-3][col+21] = (unsigned char) _mm256_extract_epi8(output_even,21);

		_mm_storeu_si128( (__m128i *) &filt[N-2][col],_mm256_extractf128_si256(output_row0_even, 0)); //store low 128bit - 16pixels
		filt[N-2][col+16] = (unsigned char) _mm256_extract_epi8(output_row0_even,16);
		filt[N-2][col+17] = (unsigned char) _mm256_extract_epi8(output_row0_even,17);
		filt[N-2][col+18] = (unsigned char) _mm256_extract_epi8(output_row0_even,18);
		filt[N-2][col+19] = (unsigned char) _mm256_extract_epi8(output_row0_even,19);
		filt[N-2][col+20] = (unsigned char) _mm256_extract_epi8(output_row0_even,20);
		filt[N-2][col+21] = (unsigned char) _mm256_extract_epi8(output_row0_even,21);

		_mm_storeu_si128( (__m128i *) &filt[N-1][col],_mm256_extractf128_si256(output_row1_even, 0)); //store low 128bit - 16pixels
		filt[N-1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1_even,16);
		filt[N-1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1_even,17);
		filt[N-1][col+18] = (unsigned char) _mm256_extract_epi8(output_row1_even,18);
		filt[N-1][col+19] = (unsigned char) _mm256_extract_epi8(output_row1_even,19);
		filt[N-1][col+20] = (unsigned char) _mm256_extract_epi8(output_row1_even,20);
		filt[N-1][col+21] = (unsigned char) _mm256_extract_epi8(output_row1_even,21);
		  break;
	case 23:
		_mm_storeu_si128( (__m128i *) &filt[N-3][col],_mm256_extractf128_si256(output_even, 0)); //store low 128bit - 16pixels
		filt[N-3][col+16] = (unsigned char) _mm256_extract_epi8(output_even,16);
		filt[N-3][col+17] = (unsigned char) _mm256_extract_epi8(output_even,17);
		filt[N-3][col+18] = (unsigned char) _mm256_extract_epi8(output_even,18);
		filt[N-3][col+19] = (unsigned char) _mm256_extract_epi8(output_even,19);
		filt[N-3][col+20] = (unsigned char) _mm256_extract_epi8(output_even,20);
		filt[N-3][col+21] = (unsigned char) _mm256_extract_epi8(output_even,21);
		filt[N-3][col+22] = (unsigned char) _mm256_extract_epi8(output_even,22);


		_mm_storeu_si128( (__m128i *) &filt[N-2][col],_mm256_extractf128_si256(output_row0_even, 0)); //store low 128bit - 16pixels
		filt[N-2][col+16] = (unsigned char) _mm256_extract_epi8(output_row0_even,16);
		filt[N-2][col+17] = (unsigned char) _mm256_extract_epi8(output_row0_even,17);
		filt[N-2][col+18] = (unsigned char) _mm256_extract_epi8(output_row0_even,18);
		filt[N-2][col+19] = (unsigned char) _mm256_extract_epi8(output_row0_even,19);
		filt[N-2][col+20] = (unsigned char) _mm256_extract_epi8(output_row0_even,20);
		filt[N-2][col+21] = (unsigned char) _mm256_extract_epi8(output_row0_even,21);
		filt[N-2][col+22] = (unsigned char) _mm256_extract_epi8(output_row0_even,22);

		_mm_storeu_si128( (__m128i *) &filt[N-1][col],_mm256_extractf128_si256(output_row1_even, 0)); //store low 128bit - 16pixels
		filt[N-1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1_even,16);
		filt[N-1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1_even,17);
		filt[N-1][col+18] = (unsigned char) _mm256_extract_epi8(output_row1_even,18);
		filt[N-1][col+19] = (unsigned char) _mm256_extract_epi8(output_row1_even,19);
		filt[N-1][col+20] = (unsigned char) _mm256_extract_epi8(output_row1_even,20);
		filt[N-1][col+21] = (unsigned char) _mm256_extract_epi8(output_row1_even,21);
		filt[N-1][col+22] = (unsigned char) _mm256_extract_epi8(output_row1_even,22);
		  break;
	case 24:
		_mm_storeu_si128( (__m128i *) &filt[N-3][col],_mm256_extractf128_si256(output_even, 0)); //store low 128bit - 16pixels
		filt[N-3][col+16] = (unsigned char) _mm256_extract_epi8(output_even,16);
		filt[N-3][col+17] = (unsigned char) _mm256_extract_epi8(output_even,17);
		filt[N-3][col+18] = (unsigned char) _mm256_extract_epi8(output_even,18);
		filt[N-3][col+19] = (unsigned char) _mm256_extract_epi8(output_even,19);
		filt[N-3][col+20] = (unsigned char) _mm256_extract_epi8(output_even,20);
		filt[N-3][col+21] = (unsigned char) _mm256_extract_epi8(output_even,21);
		filt[N-3][col+22] = (unsigned char) _mm256_extract_epi8(output_even,22);
		filt[N-3][col+23] = (unsigned char) _mm256_extract_epi8(output_even,23);

		_mm_storeu_si128( (__m128i *) &filt[N-2][col],_mm256_extractf128_si256(output_row0_even, 0)); //store low 128bit - 16pixels
		filt[N-2][col+16] = (unsigned char) _mm256_extract_epi8(output_row0_even,16);
		filt[N-2][col+17] = (unsigned char) _mm256_extract_epi8(output_row0_even,17);
		filt[N-2][col+18] = (unsigned char) _mm256_extract_epi8(output_row0_even,18);
		filt[N-2][col+19] = (unsigned char) _mm256_extract_epi8(output_row0_even,19);
		filt[N-2][col+20] = (unsigned char) _mm256_extract_epi8(output_row0_even,20);
		filt[N-2][col+21] = (unsigned char) _mm256_extract_epi8(output_row0_even,21);
		filt[N-2][col+22] = (unsigned char) _mm256_extract_epi8(output_row0_even,22);
		filt[N-2][col+23] = (unsigned char) _mm256_extract_epi8(output_row0_even,23);

		_mm_storeu_si128( (__m128i *) &filt[N-1][col],_mm256_extractf128_si256(output_row1_even, 0)); //store low 128bit - 16pixels
		filt[N-1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1_even,16);
		filt[N-1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1_even,17);
		filt[N-1][col+18] = (unsigned char) _mm256_extract_epi8(output_row1_even,18);
		filt[N-1][col+19] = (unsigned char) _mm256_extract_epi8(output_row1_even,19);
		filt[N-1][col+20] = (unsigned char) _mm256_extract_epi8(output_row1_even,20);
		filt[N-1][col+21] = (unsigned char) _mm256_extract_epi8(output_row1_even,21);
		filt[N-1][col+22] = (unsigned char) _mm256_extract_epi8(output_row1_even,22);
		filt[N-1][col+23] = (unsigned char) _mm256_extract_epi8(output_row1_even,23);
		  break;
	case 25:
		_mm_storeu_si128( (__m128i *) &filt[N-3][col],_mm256_extractf128_si256(output_even, 0)); //store low 128bit - 16pixels
		filt[N-3][col+16] = (unsigned char) _mm256_extract_epi8(output_even,16);
		filt[N-3][col+17] = (unsigned char) _mm256_extract_epi8(output_even,17);
		filt[N-3][col+18] = (unsigned char) _mm256_extract_epi8(output_even,18);
		filt[N-3][col+19] = (unsigned char) _mm256_extract_epi8(output_even,19);
		filt[N-3][col+20] = (unsigned char) _mm256_extract_epi8(output_even,20);
		filt[N-3][col+21] = (unsigned char) _mm256_extract_epi8(output_even,21);
		filt[N-3][col+22] = (unsigned char) _mm256_extract_epi8(output_even,22);
		filt[N-3][col+23] = (unsigned char) _mm256_extract_epi8(output_even,23);
		filt[N-3][col+24] = (unsigned char) _mm256_extract_epi8(output_even,24);

		_mm_storeu_si128( (__m128i *) &filt[N-2][col],_mm256_extractf128_si256(output_row0_even, 0)); //store low 128bit - 16pixels
		filt[N-2][col+16] = (unsigned char) _mm256_extract_epi8(output_row0_even,16);
		filt[N-2][col+17] = (unsigned char) _mm256_extract_epi8(output_row0_even,17);
		filt[N-2][col+18] = (unsigned char) _mm256_extract_epi8(output_row0_even,18);
		filt[N-2][col+19] = (unsigned char) _mm256_extract_epi8(output_row0_even,19);
		filt[N-2][col+20] = (unsigned char) _mm256_extract_epi8(output_row0_even,20);
		filt[N-2][col+21] = (unsigned char) _mm256_extract_epi8(output_row0_even,21);
		filt[N-2][col+22] = (unsigned char) _mm256_extract_epi8(output_row0_even,22);
		filt[N-2][col+23] = (unsigned char) _mm256_extract_epi8(output_row0_even,23);
		filt[N-2][col+24] = (unsigned char) _mm256_extract_epi8(output_row0_even,24);

		_mm_storeu_si128( (__m128i *) &filt[N-1][col],_mm256_extractf128_si256(output_row1_even, 0)); //store low 128bit - 16pixels
		filt[N-1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1_even,16);
		filt[N-1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1_even,17);
		filt[N-1][col+18] = (unsigned char) _mm256_extract_epi8(output_row1_even,18);
		filt[N-1][col+19] = (unsigned char) _mm256_extract_epi8(output_row1_even,19);
		filt[N-1][col+20] = (unsigned char) _mm256_extract_epi8(output_row1_even,20);
		filt[N-1][col+21] = (unsigned char) _mm256_extract_epi8(output_row1_even,21);
		filt[N-1][col+22] = (unsigned char) _mm256_extract_epi8(output_row1_even,22);
		filt[N-1][col+23] = (unsigned char) _mm256_extract_epi8(output_row1_even,23);
		filt[N-1][col+24] = (unsigned char) _mm256_extract_epi8(output_row1_even,24);
		  break;
	case 26:
		_mm_storeu_si128( (__m128i *) &filt[N-3][col],_mm256_extractf128_si256(output_even, 0)); //store low 128bit - 16pixels
		filt[N-3][col+16] = (unsigned char) _mm256_extract_epi8(output_even,16);
		filt[N-3][col+17] = (unsigned char) _mm256_extract_epi8(output_even,17);
		filt[N-3][col+18] = (unsigned char) _mm256_extract_epi8(output_even,18);
		filt[N-3][col+19] = (unsigned char) _mm256_extract_epi8(output_even,19);
		filt[N-3][col+20] = (unsigned char) _mm256_extract_epi8(output_even,20);
		filt[N-3][col+21] = (unsigned char) _mm256_extract_epi8(output_even,21);
		filt[N-3][col+22] = (unsigned char) _mm256_extract_epi8(output_even,22);
		filt[N-3][col+23] = (unsigned char) _mm256_extract_epi8(output_even,23);
		filt[N-3][col+24] = (unsigned char) _mm256_extract_epi8(output_even,24);
		filt[N-3][col+25] = (unsigned char) _mm256_extract_epi8(output_even,25);

		_mm_storeu_si128( (__m128i *) &filt[N-2][col],_mm256_extractf128_si256(output_row0_even, 0)); //store low 128bit - 16pixels
		filt[N-2][col+16] = (unsigned char) _mm256_extract_epi8(output_row0_even,16);
		filt[N-2][col+17] = (unsigned char) _mm256_extract_epi8(output_row0_even,17);
		filt[N-2][col+18] = (unsigned char) _mm256_extract_epi8(output_row0_even,18);
		filt[N-2][col+19] = (unsigned char) _mm256_extract_epi8(output_row0_even,19);
		filt[N-2][col+20] = (unsigned char) _mm256_extract_epi8(output_row0_even,20);
		filt[N-2][col+21] = (unsigned char) _mm256_extract_epi8(output_row0_even,21);
		filt[N-2][col+22] = (unsigned char) _mm256_extract_epi8(output_row0_even,22);
		filt[N-2][col+23] = (unsigned char) _mm256_extract_epi8(output_row0_even,23);
		filt[N-2][col+24] = (unsigned char) _mm256_extract_epi8(output_row0_even,24);
		filt[N-2][col+25] = (unsigned char) _mm256_extract_epi8(output_row0_even,25);

		_mm_storeu_si128( (__m128i *) &filt[N-1][col],_mm256_extractf128_si256(output_row1_even, 0)); //store low 128bit - 16pixels
		filt[N-1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1_even,16);
		filt[N-1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1_even,17);
		filt[N-1][col+18] = (unsigned char) _mm256_extract_epi8(output_row1_even,18);
		filt[N-1][col+19] = (unsigned char) _mm256_extract_epi8(output_row1_even,19);
		filt[N-1][col+20] = (unsigned char) _mm256_extract_epi8(output_row1_even,20);
		filt[N-1][col+21] = (unsigned char) _mm256_extract_epi8(output_row1_even,21);
		filt[N-1][col+22] = (unsigned char) _mm256_extract_epi8(output_row1_even,22);
		filt[N-1][col+23] = (unsigned char) _mm256_extract_epi8(output_row1_even,23);
		filt[N-1][col+24] = (unsigned char) _mm256_extract_epi8(output_row1_even,24);
		filt[N-1][col+25] = (unsigned char) _mm256_extract_epi8(output_row1_even,25);
		  break;
	case 27:
		_mm_storeu_si128( (__m128i *) &filt[N-3][col],_mm256_extractf128_si256(output_even, 0)); //store low 128bit - 16pixels
		filt[N-3][col+16] = (unsigned char) _mm256_extract_epi8(output_even,16);
		filt[N-3][col+17] = (unsigned char) _mm256_extract_epi8(output_even,17);
		filt[N-3][col+18] = (unsigned char) _mm256_extract_epi8(output_even,18);
		filt[N-3][col+19] = (unsigned char) _mm256_extract_epi8(output_even,19);
		filt[N-3][col+20] = (unsigned char) _mm256_extract_epi8(output_even,20);
		filt[N-3][col+21] = (unsigned char) _mm256_extract_epi8(output_even,21);
		filt[N-3][col+22] = (unsigned char) _mm256_extract_epi8(output_even,22);
		filt[N-3][col+23] = (unsigned char) _mm256_extract_epi8(output_even,23);
		filt[N-3][col+24] = (unsigned char) _mm256_extract_epi8(output_even,24);
		filt[N-3][col+25] = (unsigned char) _mm256_extract_epi8(output_even,25);
		filt[N-3][col+26] = (unsigned char) _mm256_extract_epi8(output_even,26);

		_mm_storeu_si128( (__m128i *) &filt[N-2][col],_mm256_extractf128_si256(output_row0_even, 0)); //store low 128bit - 16pixels
		filt[N-2][col+16] = (unsigned char) _mm256_extract_epi8(output_row0_even,16);
		filt[N-2][col+17] = (unsigned char) _mm256_extract_epi8(output_row0_even,17);
		filt[N-2][col+18] = (unsigned char) _mm256_extract_epi8(output_row0_even,18);
		filt[N-2][col+19] = (unsigned char) _mm256_extract_epi8(output_row0_even,19);
		filt[N-2][col+20] = (unsigned char) _mm256_extract_epi8(output_row0_even,20);
		filt[N-2][col+21] = (unsigned char) _mm256_extract_epi8(output_row0_even,21);
		filt[N-2][col+22] = (unsigned char) _mm256_extract_epi8(output_row0_even,22);
		filt[N-2][col+23] = (unsigned char) _mm256_extract_epi8(output_row0_even,23);
		filt[N-2][col+24] = (unsigned char) _mm256_extract_epi8(output_row0_even,24);
		filt[N-2][col+25] = (unsigned char) _mm256_extract_epi8(output_row0_even,25);
		filt[N-2][col+26] = (unsigned char) _mm256_extract_epi8(output_row0_even,26);

		_mm_storeu_si128( (__m128i *) &filt[N-1][col],_mm256_extractf128_si256(output_row1_even, 0)); //store low 128bit - 16pixels
		filt[N-1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1_even,16);
		filt[N-1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1_even,17);
		filt[N-1][col+18] = (unsigned char) _mm256_extract_epi8(output_row1_even,18);
		filt[N-1][col+19] = (unsigned char) _mm256_extract_epi8(output_row1_even,19);
		filt[N-1][col+20] = (unsigned char) _mm256_extract_epi8(output_row1_even,20);
		filt[N-1][col+21] = (unsigned char) _mm256_extract_epi8(output_row1_even,21);
		filt[N-1][col+22] = (unsigned char) _mm256_extract_epi8(output_row1_even,22);
		filt[N-1][col+23] = (unsigned char) _mm256_extract_epi8(output_row1_even,23);
		filt[N-1][col+24] = (unsigned char) _mm256_extract_epi8(output_row1_even,24);
		filt[N-1][col+25] = (unsigned char) _mm256_extract_epi8(output_row1_even,25);
		filt[N-1][col+26] = (unsigned char) _mm256_extract_epi8(output_row1_even,26);
		  break;
	case 28:
		_mm_storeu_si128( (__m128i *) &filt[N-3][col],_mm256_extractf128_si256(output_even, 0)); //store low 128bit - 16pixels
		filt[N-3][col+16] = (unsigned char) _mm256_extract_epi8(output_even,16);
		filt[N-3][col+17] = (unsigned char) _mm256_extract_epi8(output_even,17);
		filt[N-3][col+18] = (unsigned char) _mm256_extract_epi8(output_even,18);
		filt[N-3][col+19] = (unsigned char) _mm256_extract_epi8(output_even,19);
		filt[N-3][col+20] = (unsigned char) _mm256_extract_epi8(output_even,20);
		filt[N-3][col+21] = (unsigned char) _mm256_extract_epi8(output_even,21);
		filt[N-3][col+22] = (unsigned char) _mm256_extract_epi8(output_even,22);
		filt[N-3][col+23] = (unsigned char) _mm256_extract_epi8(output_even,23);
		filt[N-3][col+24] = (unsigned char) _mm256_extract_epi8(output_even,24);
		filt[N-3][col+25] = (unsigned char) _mm256_extract_epi8(output_even,25);
		filt[N-3][col+26] = (unsigned char) _mm256_extract_epi8(output_even,26);
		filt[N-3][col+27] = (unsigned char) _mm256_extract_epi8(output_even,27);

		_mm_storeu_si128( (__m128i *) &filt[N-2][col],_mm256_extractf128_si256(output_row0_even, 0)); //store low 128bit - 16pixels
		filt[N-2][col+16] = (unsigned char) _mm256_extract_epi8(output_row0_even,16);
		filt[N-2][col+17] = (unsigned char) _mm256_extract_epi8(output_row0_even,17);
		filt[N-2][col+18] = (unsigned char) _mm256_extract_epi8(output_row0_even,18);
		filt[N-2][col+19] = (unsigned char) _mm256_extract_epi8(output_row0_even,19);
		filt[N-2][col+20] = (unsigned char) _mm256_extract_epi8(output_row0_even,20);
		filt[N-2][col+21] = (unsigned char) _mm256_extract_epi8(output_row0_even,21);
		filt[N-2][col+22] = (unsigned char) _mm256_extract_epi8(output_row0_even,22);
		filt[N-2][col+23] = (unsigned char) _mm256_extract_epi8(output_row0_even,23);
		filt[N-2][col+24] = (unsigned char) _mm256_extract_epi8(output_row0_even,24);
		filt[N-2][col+25] = (unsigned char) _mm256_extract_epi8(output_row0_even,25);
		filt[N-2][col+26] = (unsigned char) _mm256_extract_epi8(output_row0_even,26);
		filt[N-2][col+27] = (unsigned char) _mm256_extract_epi8(output_row0_even,27);

		_mm_storeu_si128( (__m128i *) &filt[N-1][col],_mm256_extractf128_si256(output_row1_even, 0)); //store low 128bit - 16pixels
		filt[N-1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1_even,16);
		filt[N-1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1_even,17);
		filt[N-1][col+18] = (unsigned char) _mm256_extract_epi8(output_row1_even,18);
		filt[N-1][col+19] = (unsigned char) _mm256_extract_epi8(output_row1_even,19);
		filt[N-1][col+20] = (unsigned char) _mm256_extract_epi8(output_row1_even,20);
		filt[N-1][col+21] = (unsigned char) _mm256_extract_epi8(output_row1_even,21);
		filt[N-1][col+22] = (unsigned char) _mm256_extract_epi8(output_row1_even,22);
		filt[N-1][col+23] = (unsigned char) _mm256_extract_epi8(output_row1_even,23);
		filt[N-1][col+24] = (unsigned char) _mm256_extract_epi8(output_row1_even,24);
		filt[N-1][col+25] = (unsigned char) _mm256_extract_epi8(output_row1_even,25);
		filt[N-1][col+26] = (unsigned char) _mm256_extract_epi8(output_row1_even,26);
		filt[N-1][col+27] = (unsigned char) _mm256_extract_epi8(output_row1_even,27);
		  break;
	case 29:
		_mm_storeu_si128( (__m128i *) &filt[N-3][col],_mm256_extractf128_si256(output_even, 0)); //store low 128bit - 16pixels
		filt[N-3][col+16] = (unsigned char) _mm256_extract_epi8(output_even,16);
		filt[N-3][col+17] = (unsigned char) _mm256_extract_epi8(output_even,17);
		filt[N-3][col+18] = (unsigned char) _mm256_extract_epi8(output_even,18);
		filt[N-3][col+19] = (unsigned char) _mm256_extract_epi8(output_even,19);
		filt[N-3][col+20] = (unsigned char) _mm256_extract_epi8(output_even,20);
		filt[N-3][col+21] = (unsigned char) _mm256_extract_epi8(output_even,21);
		filt[N-3][col+22] = (unsigned char) _mm256_extract_epi8(output_even,22);
		filt[N-3][col+23] = (unsigned char) _mm256_extract_epi8(output_even,23);
		filt[N-3][col+24] = (unsigned char) _mm256_extract_epi8(output_even,24);
		filt[N-3][col+25] = (unsigned char) _mm256_extract_epi8(output_even,25);
		filt[N-3][col+26] = (unsigned char) _mm256_extract_epi8(output_even,26);
		filt[N-3][col+27] = (unsigned char) _mm256_extract_epi8(output_even,27);
		filt[N-3][col+28] = (unsigned char) _mm256_extract_epi8(output_even,28);

		_mm_storeu_si128( (__m128i *) &filt[N-2][col],_mm256_extractf128_si256(output_row0_even, 0)); //store low 128bit - 16pixels
		filt[N-2][col+16] = (unsigned char) _mm256_extract_epi8(output_row0_even,16);
		filt[N-2][col+17] = (unsigned char) _mm256_extract_epi8(output_row0_even,17);
		filt[N-2][col+18] = (unsigned char) _mm256_extract_epi8(output_row0_even,18);
		filt[N-2][col+19] = (unsigned char) _mm256_extract_epi8(output_row0_even,19);
		filt[N-2][col+20] = (unsigned char) _mm256_extract_epi8(output_row0_even,20);
		filt[N-2][col+21] = (unsigned char) _mm256_extract_epi8(output_row0_even,21);
		filt[N-2][col+22] = (unsigned char) _mm256_extract_epi8(output_row0_even,22);
		filt[N-2][col+23] = (unsigned char) _mm256_extract_epi8(output_row0_even,23);
		filt[N-2][col+24] = (unsigned char) _mm256_extract_epi8(output_row0_even,24);
		filt[N-2][col+25] = (unsigned char) _mm256_extract_epi8(output_row0_even,25);
		filt[N-2][col+26] = (unsigned char) _mm256_extract_epi8(output_row0_even,26);
		filt[N-2][col+27] = (unsigned char) _mm256_extract_epi8(output_row0_even,27);
		filt[N-2][col+28] = (unsigned char) _mm256_extract_epi8(output_row0_even,28);

		_mm_storeu_si128( (__m128i *) &filt[N-1][col],_mm256_extractf128_si256(output_row1_even, 0)); //store low 128bit - 16pixels
		filt[N-1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1_even,16);
		filt[N-1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1_even,17);
		filt[N-1][col+18] = (unsigned char) _mm256_extract_epi8(output_row1_even,18);
		filt[N-1][col+19] = (unsigned char) _mm256_extract_epi8(output_row1_even,19);
		filt[N-1][col+20] = (unsigned char) _mm256_extract_epi8(output_row1_even,20);
		filt[N-1][col+21] = (unsigned char) _mm256_extract_epi8(output_row1_even,21);
		filt[N-1][col+22] = (unsigned char) _mm256_extract_epi8(output_row1_even,22);
		filt[N-1][col+23] = (unsigned char) _mm256_extract_epi8(output_row1_even,23);
		filt[N-1][col+24] = (unsigned char) _mm256_extract_epi8(output_row1_even,24);
		filt[N-1][col+25] = (unsigned char) _mm256_extract_epi8(output_row1_even,25);
		filt[N-1][col+26] = (unsigned char) _mm256_extract_epi8(output_row1_even,26);
		filt[N-1][col+27] = (unsigned char) _mm256_extract_epi8(output_row1_even,27);
		filt[N-1][col+28] = (unsigned char) _mm256_extract_epi8(output_row1_even,28);
		  break;
	case 30:
		_mm_storeu_si128( (__m128i *) &filt[N-3][col],_mm256_extractf128_si256(output_even, 0)); //store low 128bit - 16pixels
		filt[N-3][col+16] = (unsigned char) _mm256_extract_epi8(output_even,16);
		filt[N-3][col+17] = (unsigned char) _mm256_extract_epi8(output_even,17);
		filt[N-3][col+18] = (unsigned char) _mm256_extract_epi8(output_even,18);
		filt[N-3][col+19] = (unsigned char) _mm256_extract_epi8(output_even,19);
		filt[N-3][col+20] = (unsigned char) _mm256_extract_epi8(output_even,20);
		filt[N-3][col+21] = (unsigned char) _mm256_extract_epi8(output_even,21);
		filt[N-3][col+22] = (unsigned char) _mm256_extract_epi8(output_even,22);
		filt[N-3][col+23] = (unsigned char) _mm256_extract_epi8(output_even,23);
		filt[N-3][col+24] = (unsigned char) _mm256_extract_epi8(output_even,24);
		filt[N-3][col+25] = (unsigned char) _mm256_extract_epi8(output_even,25);
		filt[N-3][col+26] = (unsigned char) _mm256_extract_epi8(output_even,26);
		filt[N-3][col+27] = (unsigned char) _mm256_extract_epi8(output_even,27);
		filt[N-3][col+28] = (unsigned char) _mm256_extract_epi8(output_even,28);
		filt[N-3][col+29] = (unsigned char) _mm256_extract_epi8(output_even,29);

		_mm_storeu_si128( (__m128i *) &filt[N-2][col],_mm256_extractf128_si256(output_row0_even, 0)); //store low 128bit - 16pixels
		filt[N-2][col+16] = (unsigned char) _mm256_extract_epi8(output_row0_even,16);
		filt[N-2][col+17] = (unsigned char) _mm256_extract_epi8(output_row0_even,17);
		filt[N-2][col+18] = (unsigned char) _mm256_extract_epi8(output_row0_even,18);
		filt[N-2][col+19] = (unsigned char) _mm256_extract_epi8(output_row0_even,19);
		filt[N-2][col+20] = (unsigned char) _mm256_extract_epi8(output_row0_even,20);
		filt[N-2][col+21] = (unsigned char) _mm256_extract_epi8(output_row0_even,21);
		filt[N-2][col+22] = (unsigned char) _mm256_extract_epi8(output_row0_even,22);
		filt[N-2][col+23] = (unsigned char) _mm256_extract_epi8(output_row0_even,23);
		filt[N-2][col+24] = (unsigned char) _mm256_extract_epi8(output_row0_even,24);
		filt[N-2][col+25] = (unsigned char) _mm256_extract_epi8(output_row0_even,25);
		filt[N-2][col+26] = (unsigned char) _mm256_extract_epi8(output_row0_even,26);
		filt[N-2][col+27] = (unsigned char) _mm256_extract_epi8(output_row0_even,27);
		filt[N-2][col+28] = (unsigned char) _mm256_extract_epi8(output_row0_even,28);
		filt[N-2][col+29] = (unsigned char) _mm256_extract_epi8(output_row0_even,29);


		_mm_storeu_si128( (__m128i *) &filt[N-1][col],_mm256_extractf128_si256(output_row1_even, 0)); //store low 128bit - 16pixels
		filt[N-1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1_even,16);
		filt[N-1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1_even,17);
		filt[N-1][col+18] = (unsigned char) _mm256_extract_epi8(output_row1_even,18);
		filt[N-1][col+19] = (unsigned char) _mm256_extract_epi8(output_row1_even,19);
		filt[N-1][col+20] = (unsigned char) _mm256_extract_epi8(output_row1_even,20);
		filt[N-1][col+21] = (unsigned char) _mm256_extract_epi8(output_row1_even,21);
		filt[N-1][col+22] = (unsigned char) _mm256_extract_epi8(output_row1_even,22);
		filt[N-1][col+23] = (unsigned char) _mm256_extract_epi8(output_row1_even,23);
		filt[N-1][col+24] = (unsigned char) _mm256_extract_epi8(output_row1_even,24);
		filt[N-1][col+25] = (unsigned char) _mm256_extract_epi8(output_row1_even,25);
		filt[N-1][col+26] = (unsigned char) _mm256_extract_epi8(output_row1_even,26);
		filt[N-1][col+27] = (unsigned char) _mm256_extract_epi8(output_row1_even,27);
		filt[N-1][col+28] = (unsigned char) _mm256_extract_epi8(output_row1_even,28);
		filt[N-1][col+29] = (unsigned char) _mm256_extract_epi8(output_row1_even,29);
		  break;
	case 31:
		_mm_storeu_si128( (__m128i *) &filt[N-3][col],_mm256_extractf128_si256(output_even, 0)); //store low 128bit - 16pixels
		filt[N-3][col+16] = (unsigned char) _mm256_extract_epi8(output_even,16);
		filt[N-3][col+17] = (unsigned char) _mm256_extract_epi8(output_even,17);
		filt[N-3][col+18] = (unsigned char) _mm256_extract_epi8(output_even,18);
		filt[N-3][col+19] = (unsigned char) _mm256_extract_epi8(output_even,19);
		filt[N-3][col+20] = (unsigned char) _mm256_extract_epi8(output_even,20);
		filt[N-3][col+21] = (unsigned char) _mm256_extract_epi8(output_even,21);
		filt[N-3][col+22] = (unsigned char) _mm256_extract_epi8(output_even,22);
		filt[N-3][col+23] = (unsigned char) _mm256_extract_epi8(output_even,23);
		filt[N-3][col+24] = (unsigned char) _mm256_extract_epi8(output_even,24);
		filt[N-3][col+25] = (unsigned char) _mm256_extract_epi8(output_even,25);
		filt[N-3][col+26] = (unsigned char) _mm256_extract_epi8(output_even,26);
		filt[N-3][col+27] = (unsigned char) _mm256_extract_epi8(output_even,27);
		filt[N-3][col+28] = (unsigned char) _mm256_extract_epi8(output_even,28);
		filt[N-3][col+29] = (unsigned char) _mm256_extract_epi8(output_even,29);

		_mm_storeu_si128( (__m128i *) &filt[N-2][col],_mm256_extractf128_si256(output_row0_even, 0)); //store low 128bit - 16pixels
		filt[N-2][col+16] = (unsigned char) _mm256_extract_epi8(output_row0_even,16);
		filt[N-2][col+17] = (unsigned char) _mm256_extract_epi8(output_row0_even,17);
		filt[N-2][col+18] = (unsigned char) _mm256_extract_epi8(output_row0_even,18);
		filt[N-2][col+19] = (unsigned char) _mm256_extract_epi8(output_row0_even,19);
		filt[N-2][col+20] = (unsigned char) _mm256_extract_epi8(output_row0_even,20);
		filt[N-2][col+21] = (unsigned char) _mm256_extract_epi8(output_row0_even,21);
		filt[N-2][col+22] = (unsigned char) _mm256_extract_epi8(output_row0_even,22);
		filt[N-2][col+23] = (unsigned char) _mm256_extract_epi8(output_row0_even,23);
		filt[N-2][col+24] = (unsigned char) _mm256_extract_epi8(output_row0_even,24);
		filt[N-2][col+25] = (unsigned char) _mm256_extract_epi8(output_row0_even,25);
		filt[N-2][col+26] = (unsigned char) _mm256_extract_epi8(output_row0_even,26);
		filt[N-2][col+27] = (unsigned char) _mm256_extract_epi8(output_row0_even,27);
		filt[N-2][col+28] = (unsigned char) _mm256_extract_epi8(output_row0_even,28);
		filt[N-2][col+29] = (unsigned char) _mm256_extract_epi8(output_row0_even,29);


		_mm_storeu_si128( (__m128i *) &filt[N-1][col],_mm256_extractf128_si256(output_row1_even, 0)); //store low 128bit - 16pixels
		filt[N-1][col+16] = (unsigned char) _mm256_extract_epi8(output_row1_even,16);
		filt[N-1][col+17] = (unsigned char) _mm256_extract_epi8(output_row1_even,17);
		filt[N-1][col+18] = (unsigned char) _mm256_extract_epi8(output_row1_even,18);
		filt[N-1][col+19] = (unsigned char) _mm256_extract_epi8(output_row1_even,19);
		filt[N-1][col+20] = (unsigned char) _mm256_extract_epi8(output_row1_even,20);
		filt[N-1][col+21] = (unsigned char) _mm256_extract_epi8(output_row1_even,21);
		filt[N-1][col+22] = (unsigned char) _mm256_extract_epi8(output_row1_even,22);
		filt[N-1][col+23] = (unsigned char) _mm256_extract_epi8(output_row1_even,23);
		filt[N-1][col+24] = (unsigned char) _mm256_extract_epi8(output_row1_even,24);
		filt[N-1][col+25] = (unsigned char) _mm256_extract_epi8(output_row1_even,25);
		filt[N-1][col+26] = (unsigned char) _mm256_extract_epi8(output_row1_even,26);
		filt[N-1][col+27] = (unsigned char) _mm256_extract_epi8(output_row1_even,27);
		filt[N-1][col+28] = (unsigned char) _mm256_extract_epi8(output_row1_even,28);
		filt[N-1][col+29] = (unsigned char) _mm256_extract_epi8(output_row1_even,29);

		//the filt[0:2][M-1] pixel will be computed without vectorization
		int newPixel;
		for (int row=N-3;row<=N-1;row++){
		 newPixel = 0;
		for (int rowOffset=-2; rowOffset<=2; rowOffset++) {
			for (int colOffset=-2; colOffset<=2; colOffset++) {

			   if ( ((row+rowOffset)<N) && ((M-1+colOffset)<M) && ((row+rowOffset)>=0) && ((M-1+colOffset)>=0) )
	              newPixel += frame1[row+rowOffset][M-1+colOffset] * filter[2 + rowOffset][2 + colOffset];

			      }
		        }
	   filt[row][M-1] = (unsigned char) (newPixel / divisor);
		}

		  break;
	default:
		printf("\n something went wrong");
	}

return 0;

}




